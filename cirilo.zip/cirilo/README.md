# Cirilo!
Emulador de GB, GBC y GBA para Android. Núcleo: mGBA (MPL 2.0, https://mgba.io) compilado como núcleo libretro; `libretro.h` es MIT.
Sube este proyecto a GitHub: el workflow (Actions) clona mGBA, compila y publica el APK como artefacto «cirilo-debug».
Shaders: si está instalada «Emulator Shaders» (com.fastemulator.shaderpack), se leen sus archivos en tiempo de ejecución.
No incluye juegos ni BIOS.

## Biblioteca: List View / Grid View y carátulas
- «+» → Personalization: elige List View o Grid View (se guarda en las preferencias `lib`, clave `view`).
- Carátulas: Libretro Thumbnails (`https://thumbnails.libretro.com/<sistema>/Named_Boxarts/<nombre>.png`), sistemas `Nintendo - Game Boy`, `Nintendo - Game Boy Color`, `Nintendo - Game Boy Advance`.
- La identificación es local (`Covers.kt`, índices en `assets/libretro`). Para regenerar los índices: `tools/gen_libretro_index.py`.
- Mantén pulsado un juego → «Carátula...» para elegir, quitar o volver a buscar la carátula.

## Guardados de My Boy! / My OldBoy!
- Carpetas: `Android/data/com.fastemulator.gba/files/save` (My Boy!, GBA) y `Android/data/com.fastemulator.gbc/files/save` (My OldBoy!, GB/GBC), en el almacenamiento interno y en la tarjeta SD. Se emparejan por nombre de archivo (sin extensión).
- La primera vez que se escanea, se añade un juego o una carpeta y se encuentran `.sav`, se pregunta por cada app: copiar a Cirilo, usar su carpeta (compartido) o ignorar. Luego se avisa de que se puede cambiar en Personalización.
- Personalización → «Preferencias de archivos de guardado»: una fila por app; al pulsarla se abre una ventanita con las tres opciones (`save_mode_gba` / `save_mode_gbc` en `lib`). Lógica en `SaveSync.kt`. Solo se comparten los `.sav`, no los estados.
- Acceso a la carpeta, por orden: directo (Android 10 o menos); **Shizuku** (recomendado, vale en Android 11+ incluido 13+; `Shell.kt`, `ShellService.kt`, `IShell.aidl`); selector de carpetas SAF (algunos Android 11-12). Se ofrece una vez por app instalada y siempre en Personalización → la app → «Dar acceso» (`AccessUi.kt`, con mini tutorial de Shizuku).
- Compartido sin acceso directo: Cirilo juega con una copia espejo local (`saves_shared/`) que se baja al abrir el juego y se sube al pausar/cerrar (`SaveSync.file` / `SaveSync.push`). Si Shizuku no está activa al abrir el juego, se avisa y se usa el guardado de Cirilo.

## Ajustes → Misceláneo
- Preferencias en «c»: `gd`, `gd_acct`, `gd_start`, `gd_change` (Google Drive, solo guardan el ajuste por ahora), `cheats`, `patch` (solo guardan el ajuste por ahora), `auto` (estado automático `<juego>.auto.state` al pausar y carga al iniciar), `ffs` (velocidad de avance rápido ×10: 160, 80, 40, 30, 20, 15, 5, 2), `ffm` (0 alternar / 1 mantener; global, sustituye al modo por control del editor), `confirm`, `full`, `imm`.

## Sincronización con Google Drive (`DriveSync.kt`)
- Ajustes → Misceláneo → «Sincronizar con Google Drive». Permiso `drive.file` (solo ve lo que crea Cirilo) vía `AuthorizationClient` (play-services-auth). Sin Google Play Services la opción sale desactivada.
- Drive: carpeta `Cirilo/GBA` (My Boy!) y `Cirilo/GB y GBC` (My OldBoy!), un `<juego>.sav` por juego. Cada app respeta su modo (`SaveSync`): compartido = carpeta de My Boy; copiar/sin elegir = carpeta de Cirilo; ignorar = no se sincroniza.
- Cuándo: al abrir la biblioteca (completa, bidireccional); «Sincronizar al iniciar el juego» baja ese guardado antes de cargarlo; «Sincronizar al cambiar» sube al pausar/salir. Sin red: `JobScheduler` (`SyncJob`) reintenta cuando hay internet, también tras reiniciar.
- Conflictos: se compara con lo último sincronizado (preferencias `gdsync`); si cambiaron ambos lados gana el más reciente y el otro se guarda en `saves_backup/`.
- Requiere un cliente OAuth Android en Google Cloud con `app.cirilo` y el SHA-1 de la clave fija del workflow (secretos KEYSTORE_*).
