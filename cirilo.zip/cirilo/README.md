# Cirilo!
Emulador de GB, GBC y GBA para Android. Núcleo: mGBA (MPL 2.0, https://mgba.io) compilado como núcleo libretro; `libretro.h` es MIT.
Sube este proyecto a GitHub: el workflow (Actions) clona mGBA, compila y publica el APK como artefacto «cirilo-debug».
Shaders: si está instalada «Emulator Shaders» (com.fastemulator.shaderpack), se leen sus archivos en tiempo de ejecución.
No incluye juegos ni BIOS.

## Biblioteca: List View / Grid View y carátulas
- «+» → Personalization: elige List View o Grid View (se guarda en las preferencias `lib`, clave `view`).
- Carátulas: Libretro Thumbnails (`https://thumbnails.libretro.com/<sistema>/Named_Boxarts/<nombre>.png`), sistemas `Nintendo - Game Boy`, `Nintendo - Game Boy Color`, `Nintendo - Game Boy Advance`.
- La identificación es local (`Covers.kt`, índices en `assets/libretro`). Para regenerar los índices: `tools/gen_libretro_index.py`.
- Mantén pulsado un juego → «Carátula...» para elegir, quitar o volver a buscar la carátula.

## Guardados de My Boy! / My OldBoy!
- Carpetas: `Android/data/com.fastemulator.gba/files/save` (My Boy!, GBA) y `Android/data/com.fastemulator.gbc/files/save` (My OldBoy!, GB/GBC), en el almacenamiento interno y en la tarjeta SD. Se emparejan por nombre de archivo (sin extensión).
- La primera vez que se escanea, se añade un juego o una carpeta y se encuentran `.sav`, se pregunta por cada app: copiar a Cirilo, usar su carpeta (compartido) o ignorar. Luego se avisa de que se puede cambiar en Personalización.
- Personalización → «Preferencias de archivos de guardado»: una fila por app; al pulsarla se abre una ventanita con las tres opciones (`save_mode_gba` / `save_mode_gbc` en `lib`). Lógica en `SaveSync.kt`. Solo se comparten los `.sav`, no los estados.
- Acceso a la carpeta, por orden: directo (Android 10 o menos); **Shizuku** (recomendado, vale en Android 11+ incluido 13+; `Shell.kt`, `ShellService.kt`, `IShell.aidl`); selector de carpetas SAF (algunos Android 11-12). Se ofrece una vez por app instalada y siempre en Personalización → la app → «Dar acceso» (`AccessUi.kt`, con mini tutorial de Shizuku).
- Compartido sin acceso directo: Cirilo juega con una copia espejo local (`saves_shared/`) que se baja al abrir el juego y se sube al pausar/cerrar (`SaveSync.file` / `SaveSync.push`). Si Shizuku no está activa al abrir el juego, se avisa y se usa el guardado de Cirilo.

## Ajustes → Misceláneo
- Preferencias en «c»: `gd`, `gd_acct`, `gd_start`, `gd_change` (Google Drive, solo guardan el ajuste por ahora), `cheats` (interruptor general de trucos; por defecto activo), `patch` (solo guarda el ajuste por ahora), `auto` (estado automático `<juego>.auto.state` al pausar y carga al iniciar), `ffs` (velocidad de avance rápido ×10: 160, 80, 40, 30, 20, 15, 5, 2), `ffm` (0 alternar / 1 mantener; global, sustituye al modo por control del editor), `confirm`, `full`, `imm`.

## Sincronización con Google Drive (`DriveSync.kt`)
- Ajustes → Misceláneo → «Sincronizar con Google Drive». Permiso `drive.file` (solo ve lo que crea Cirilo) vía `AuthorizationClient` (play-services-auth). Sin Google Play Services la opción sale desactivada.
- Drive: carpeta `Cirilo/GBA` (My Boy!) y `Cirilo/GB y GBC` (My OldBoy!), un `<juego>.sav` por juego. Cada app respeta su modo (`SaveSync`): compartido = carpeta de My Boy; copiar/sin elegir = carpeta de Cirilo; ignorar = no se sincroniza.
- Cuándo: al abrir la biblioteca (completa, bidireccional); «Sincronizar al iniciar el juego» baja ese guardado antes de cargarlo; «Sincronizar al cambiar» sube al pausar/salir. Sin red: `JobScheduler` (`SyncJob`) reintenta cuando hay internet, también tras reiniciar.
- Conflictos: se compara con lo último sincronizado (preferencias `gdsync`); si cambiaron ambos lados gana el más reciente y el otro se guarda en `saves_backup/`.
- Requiere un cliente OAuth Android en Google Cloud con `app.cirilo` y el SHA-1 de la clave fija del workflow (secretos KEYSTORE_*).

## Trucos (Cheats)
Menú del juego → **Trucos**. Pantalla «Cheats» (lista con casilla; pulsar = activar/desactivar; mantener pulsado = Editar/Eliminar; ⋮ = Activar todos / Desactivar todos; botón + = «New cheat» con *Cheat name*, *Cheat type*, *Cheat code* y menú ⋮ → Save / Discard). Los trucos nuevos se crean **desactivados**. Ajustes → Misceláneo → «Activar trucos» es el interruptor general.

**Archivos:** `CheatCodes.kt` (formatos, validación y autodetección; lógica pura), `CheatStore.kt` (modelo, identidad del juego y persistencia), `CheatsActivity.kt` / `CheatEditActivity.kt` (interfaz), `GameActivity.kt` (`applyCheats()`), `Native.kt` + `jni.cpp` (`cheatCheck`, `cheatProbe`, `cheatApply`) y `tools/cirilo_cheats.c` (módulo nativo).

**Por qué hay un módulo nativo:** `retro_cheat_set` de mGBA siempre autodetecta y mete todos los códigos en un único set; no deja elegir formato ni mezclarlos. mGBA sí tiene la API tipada (`mCheatAddLine(set, línea, tipo)`, un `mCheatSet` por truco), pero el núcleo libretro no la expone. `tools/cirilo_cheats.c` la expone (`cirilo_cheat_check/apply/probe`); el workflow lo añade al final de `mgba/src/platform/libretro/libretro.c` (comparte su `core` estático). El workflow fija mGBA al commit probado (`MGBA_REF`), porque el módulo usa funciones internas de mGBA. Para actualizar mGBA: cambia `MGBA_REF`, compila y revisa que `tools/cirilo_cheats.c` siga compilando.

**Formatos (GBA):** GameShark v1/v2 y GameShark v3/Action Replay = pares cifrados `XXXXXXXX XXXXXXXX` (cada uno con sus semillas de mGBA; escogerlos explícitamente fuerza el descifrado correcto). Code Breaker = `XXXXXXXX XXXX`. Raw code = `DIRECCIÓN:VALOR` (`02000010:63`, valor de 1, 2 o 4 bytes; también sirve para direcciones de ROM). Auto detect: Raw y Code Breaker se reconocen por estructura; un par 8+8 puede ser GameShark o Action Replay, y ahí se usan las puntuaciones propias de mGBA y solo se acepta si hay margen claro (si no, la app pide elegir el formato). Códigos GameShark/AR **sin cifrar** solo se admiten por Auto detect (mGBA los distingue). **Formatos (GB/GBC):** GameShark `01VVLLHH`, Raw `AAAA:VV` y, solo por Auto detect, Game Genie; GameShark v3 y Code Breaker no existen para GB y se rechazan. Nota: el formato `AAAA:VV` nativo de mGBA para GB escribe el byte equivocado (usa el byte alto de la dirección como valor); Cirilo lo convierte a GameShark `01VVLLHH` antes de enviarlo.

**Persistencia:** preferencias `cheats` (`g.<SHA-1 de la ROM>` → lista JSON con nombre, formato, código tal cual lo escribió el usuario, estado y formato resuelto). El identificador es el SHA-1 de la ROM completa (descomprimida): cada región/revisión/hack tiene el suyo, así que los trucos de una edición nunca se aplican a otra.

**Aplicación:** `Native.cheatApply` vacía el dispositivo de trucos de mGBA y crea un set por truco activo (sin reiniciar el juego y sin duplicar). Se llama al abrir el juego y cada vez que se vuelve de los menús (`onResume`), en el hilo del emulador entre fotogramas. Desactivar un truco deja de escribir, pero no restaura lo ya escrito en memoria.

**Pruebas:** `tools/test/` (arnés C que carga el núcleo real, ROMs mínimas GBA/GB y lee la memoria de la consola; y pruebas de `CheatCodes.kt`). Ver `tools/test/LEEME.txt`.
