# Cirilo!
Emulador de GB, GBC y GBA para Android. Núcleo: mGBA (MPL 2.0, https://mgba.io) compilado como núcleo libretro; `libretro.h` es MIT.
Sube este proyecto a GitHub: el workflow (Actions) clona mGBA, compila y publica el APK como artefacto «cirilo-debug».
Shaders: si está instalada «Emulator Shaders» (com.fastemulator.shaderpack), se leen sus archivos en tiempo de ejecución.
No incluye juegos ni BIOS.

## Biblioteca: List View / Grid View y carátulas
- «+» → Personalization: elige List View o Grid View (se guarda en las preferencias `lib`, clave `view`).
- Carátulas: Libretro Thumbnails (`https://thumbnails.libretro.com/<sistema>/Named_Boxarts/<nombre>.png`), sistemas `Nintendo - Game Boy`, `Nintendo - Game Boy Color`, `Nintendo - Game Boy Advance`.
- La identificación es local (`Covers.kt`, índices en `assets/libretro`). Para regenerar los índices: `tools/gen_libretro_index.py`.
- Mantén pulsado un juego → «Carátula...» para elegir, quitar o volver a buscar la carátula.

## Guardados de My Boy! / My OldBoy!
- Carpetas: `Android/data/com.fastemulator.gba/files/save` (My Boy!, GBA) y `Android/data/com.fastemulator.gbc/files/save` (My OldBoy!, GB/GBC), en el almacenamiento interno y en la tarjeta SD. Se emparejan por nombre de archivo (sin extensión).
- La primera vez que se escanea, se añade un juego o una carpeta y se encuentran `.sav`, se pregunta por cada app: copiar a Cirilo, usar su carpeta (compartido) o ignorar. Luego se avisa de que se puede cambiar en Personalización.
- Personalización → «Preferencias de archivos de guardado»: una fila por app; al pulsarla se abre una ventanita con las tres opciones (`save_mode_gba` / `save_mode_gbc` en `lib`). Lógica en `SaveSync.kt`. Solo se comparten los `.sav`, no los estados.
- Acceso: directo (Android 10 o menos) o, si Android lo impide, con el selector de carpetas (SAF, Android 11-12): se ofrece una vez si la app está instalada, y siempre en Personalización → la app → «Dar acceso». En Android 13+ el sistema bloquea `Android/data` y no hay acceso sin Shizuku/root.
- Compartido por SAF: Cirilo juega con una copia espejo local (`saves_shared/`) que se baja del documento al abrir el juego y se sube al pausar/cerrar (`SaveSync.file` / `SaveSync.push`).
