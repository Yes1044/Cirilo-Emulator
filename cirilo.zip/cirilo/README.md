# Cirilo!
Emulador de GB, GBC y GBA para Android. Núcleo: mGBA (MPL 2.0, https://mgba.io) compilado como núcleo libretro; `libretro.h` es MIT.
Sube este proyecto a GitHub: el workflow (Actions) clona mGBA, compila y publica el APK como artefacto «cirilo-debug».
Shaders: si está instalada «Emulator Shaders» (com.fastemulator.shaderpack), se leen sus archivos en tiempo de ejecución.
No incluye juegos ni BIOS.

## Biblioteca: List View / Grid View y carátulas
- «+» → Personalization: elige List View o Grid View (se guarda en las preferencias `lib`, clave `view`).
- Carátulas: Libretro Thumbnails (`https://thumbnails.libretro.com/<sistema>/Named_Boxarts/<nombre>.png`), sistemas `Nintendo - Game Boy`, `Nintendo - Game Boy Color`, `Nintendo - Game Boy Advance`.
- La identificación es local (`Covers.kt`, índices en `assets/libretro`). Para regenerar los índices: `tools/gen_libretro_index.py`.
- Mantén pulsado un juego → «Carátula...» para elegir, quitar o volver a buscar la carátula.

## Guardados de My Boy!
- La primera vez que se escanea, se añade un juego o una carpeta y se encuentran `.sav` de My Boy! (`MyBoy/Saves`, `MyBoy`, `MyGBC/...` en el almacenamiento interno, emparejados por nombre de archivo) se pregunta: copiar a Cirilo, usar la carpeta de My Boy! (compartido) o ignorar. Luego se avisa de que se puede cambiar en Personalización.
- Personalización → «Preferencias de archivos de guardado» tiene las mismas tres opciones (preferencia `save_mode` en `lib`). Lógica en `SaveSync.kt`. Solo se comparten los `.sav`, no los estados.
