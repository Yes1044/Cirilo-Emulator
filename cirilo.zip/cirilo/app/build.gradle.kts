plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
// Firma fija: el workflow decodifica el secreto KEYSTORE_B64 y define KEYSTORE_FILE. Sin él (build local o sin secretos) se usa la clave de depuración de siempre.
val ks=System.getenv("KEYSTORE_FILE")?.let{File(it)}?.takeIf{it.exists()}
android{
 namespace="app.cirilo";compileSdk=34
 if(ks!=null){signingConfigs{create("cirilo"){storeFile=ks;storePassword=System.getenv("KEYSTORE_PASSWORD");keyAlias=System.getenv("KEY_ALIAS")
  keyPassword=System.getenv("KEY_PASSWORD")?.ifEmpty{null}?:System.getenv("KEYSTORE_PASSWORD")}}
  buildTypes{getByName("debug"){signingConfig=signingConfigs.getByName("cirilo")}}}
 defaultConfig{applicationId="app.cirilo";minSdk=24;targetSdk=34;versionCode=12;versionName="0.12"
  ndk{abiFilters+=listOf("arm64-v8a","armeabi-v7a")}}
 externalNativeBuild{cmake{path=file("src/main/cpp/CMakeLists.txt");version="3.22.1"}}
 defaultConfig{externalNativeBuild{cmake{arguments+=listOf("-DCMAKE_BUILD_TYPE=Release","-DCMAKE_CXX_FLAGS_DEBUG=-O2 -DNDEBUG","-DCMAKE_CXX_FLAGS_RELEASE=-O2 -DNDEBUG")}}}
 buildFeatures{aidl=true}
 packaging{jniLibs{useLegacyPackaging=true}}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
}
dependencies{implementation(project(":core"));if(rootProject.findProject(":core2")!=null)implementation(project(":core2"));implementation("dev.rikka.shizuku:api:13.1.5");implementation("dev.rikka.shizuku:provider:13.1.5");implementation("com.google.android.gms:play-services-auth:21.2.0")}
