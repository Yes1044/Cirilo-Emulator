plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
 namespace="app.cirilo";compileSdk=34
 defaultConfig{applicationId="app.cirilo";minSdk=24;targetSdk=34;versionCode=10;versionName="0.10"
  ndk{abiFilters+=listOf("arm64-v8a","armeabi-v7a")}}
 externalNativeBuild{cmake{path=file("src/main/cpp/CMakeLists.txt");version="3.22.1"}}
 defaultConfig{externalNativeBuild{cmake{arguments+=listOf("-DCMAKE_BUILD_TYPE=Release","-DCMAKE_CXX_FLAGS_DEBUG=-O2 -DNDEBUG","-DCMAKE_CXX_FLAGS_RELEASE=-O2 -DNDEBUG")}}}
 packaging{jniLibs{useLegacyPackaging=true}}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
}
dependencies{implementation(project(":core"))}
