package app.cirilo;
// Servicio que Shizuku ejecuta con los permisos de «shell»: puede leer y escribir en Android/data de otras apps.
interface IShell {
    void destroy() = 16777114; // requerido por Shizuku
    String[] list(String dir); // "nombre\tfecha" de cada .sav de la carpeta
    byte[] read(String path);
    boolean write(String path, in byte[] data);
    boolean delete(String path);
    boolean isDir(String path);
}
