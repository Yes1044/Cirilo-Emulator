package app.cirilo;
// Servicio que Shizuku ejecuta con los permisos de «shell»: puede leer y escribir en Android/data de otras apps.
// Todos los métodos llevan id explícito (AIDL no permite mezclar ids automáticos y explícitos).
interface IShell {
    void destroy() = 16777114; // requerido por Shizuku
    String[] list(String dir) = 1; // "nombre\tfecha" de cada .sav de la carpeta
    byte[] read(String path) = 2;
    boolean write(String path, in byte[] data) = 3;
    boolean delete(String path) = 4;
    boolean isDir(String path) = 5;
}
