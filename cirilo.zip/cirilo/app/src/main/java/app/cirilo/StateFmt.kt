package app.cirilo
import java.text.SimpleDateFormat
import java.util.*

/** Textos de fecha de los estados de partida (lógica pura, sin Android; prueba: tools/test/StateFmtTest.kt). */
object StateFmt{
 /** «hace un momento», «hace 5 min», «hace 2 h», «ayer», «hace 4 días»; pasados 30 días, nada (la fecha exacta se muestra aparte). */
 fun ago(now:Long,t:Long):String{
  val s=maxOf(0L,(now-t)/1000);val m=s/60;val h=m/60;val d=h/24
  return when{s<45->"hace un momento";m<60->"hace "+maxOf(1L,m)+" min";h<24->"hace "+h+" h";d==1L->"ayer";d<=30->"hace "+d+" días";else->""}}
 /** «4 nov, 12:20»; con año si no es el actual. */
 fun stamp(now:Long,t:Long,loc:Locale=Locale.getDefault()):String{
  val a=Calendar.getInstance().apply{timeInMillis=now}.get(Calendar.YEAR);val b=Calendar.getInstance().apply{timeInMillis=t}.get(Calendar.YEAR)
  return SimpleDateFormat(if(a==b)"d MMM, HH:mm" else "d MMM yyyy, HH:mm",loc).format(Date(t))}
 /** Línea secundaria de una ranura: «hace 5 min · 4 nov, 12:20». */
 fun line(now:Long,t:Long):String{val a=ago(now,t);val s=stamp(now,t);return if(a.isEmpty())s else a+" · "+s}
}
