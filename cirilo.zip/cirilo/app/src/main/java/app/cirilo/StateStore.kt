package app.cirilo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/** Estados de partida por juego. Ranura 0 = «Rápido», 1..9 = ranuras. Cada ranura son dos archivos en `states/`:
 *  `<juego>.<n>.state` (volcado del núcleo) y `<juego>.<n>.jpg` (miniatura pequeña y de baja calidad, tomada en el mismo instante en que se guarda). */
object StateStore{
 const val SLOTS=10
 /** La miniatura se guarda a la mitad de la resolución de la consola y con JPEG de calidad baja: unos pocos KB por ranura. */
 private const val THUMB_QUALITY=55
 class Slot(val n:Int,val state:File,val thumb:File){val exists:Boolean get()=state.exists();val time:Long get()=state.lastModified()}
 /** Lo que devuelve un guardado correcto: la miniatura recién tomada (para el aviso en pantalla). */
 class Saved(val thumb:Bitmap?)
 fun slot(c:Context,base:String,n:Int):Slot{val d=c.getExternalFilesDir("states");return Slot(n,File(d,base+"."+n+".state"),File(d,base+"."+n+".jpg"))}
 fun all(c:Context,base:String):List<Slot> =(0 until SLOTS).map{slot(c,base,it)}
 fun title(n:Int)=if(n==0)"Rápido" else "Ranura "+n
 /** Mitad de resolución, con filtrado: es lo que se guarda y lo que se enseña en la lista. */
 fun thumb(full:Bitmap):Bitmap=Bitmap.createScaledBitmap(full,maxOf(1,full.width/2),maxOf(1,full.height/2),true)
 /** Miniatura guardada de una ranura; null si no tiene (estados anteriores a las miniaturas) o no se puede leer. */
 fun thumbOf(s:Slot):Bitmap?=try{if(s.thumb.exists())BitmapFactory.decodeFile(s.thumb.path) else null}catch(e:Exception){null}
 /** Escribe el estado (primero a un temporal, para no dejar una ranura a medias si falla) y su miniatura. Sin miniatura se borra la antigua. */
 fun save(s:Slot,data:ByteArray,thumb:Bitmap?):Boolean=try{
  s.state.parentFile?.mkdirs()
  val tmp=File(s.state.path+".tmp");tmp.writeBytes(data)
  if(!tmp.renameTo(s.state)){s.state.writeBytes(data);tmp.delete()}
  if(thumb!=null){try{s.thumb.outputStream().use{thumb.compress(Bitmap.CompressFormat.JPEG,THUMB_QUALITY,it)}}catch(e:Exception){s.thumb.delete()}} else s.thumb.delete()
  true}catch(e:Exception){false}
}
