package app.cirilo
import kotlin.math.*
/** Importador de layouts de My Boy! (GBA) y My OldBoy! (GB/GBC). Lógica pura, sin Android (se prueba con kotlinc, ver tools/test/LEEME.txt).
 *  Formato (deducido de archivos reales): una carpeta con layouts.xml (<profiles><profile name="..."/>) y, por cada perfil y tamaño de pantalla, «<nombre con %XX>-<ancho>x<alto>.xml»
 *  con <control type="..." bounds="izq,arr,der,aba"/> en píxeles de esa pantalla. Que un control aparezca en el archivo = está en el layout.
 *  Tipos: video, dpad, ab (pareja B+A), turbo_ab (pareja turbo B+A), a, b, a+b, tl, tr, tl+tr, tl+a, tl+b, tr+a, tr+b, start (pareja Select+Start), load, save, ff, ss, menu. */
object LayoutImport{
 class Ctrl(val type:String,val left:Int,val top:Int,val right:Int,val bottom:Int){val w get()=right-left;val h get()=bottom-top;val cx get()=(left+right)/2f;val cy get()=(top+bottom)/2f}
 /** Un archivo «<perfil>-<ancho>x<alto>.xml»: la distribución de ese perfil para una pantalla de ese tamaño. */
 class Shot(val w:Int,val h:Int,val ctrls:List<Ctrl>)
 class Profile(val name:String,val shots:List<Shot>)
 class Result(val p:List<Ctl>,val l:List<Ctl>,val notes:List<String>)
 private val TAG=Regex("<control\\b[^>]*>")
 private val TYPE=Regex("\\btype\\s*=\\s*\"([^\"]*)\"")
 private val BOUNDS=Regex("\\bbounds\\s*=\\s*\"\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\"")
 private val PROF=Regex("<profile\\b[^>]*?\\bname\\s*=\\s*\"([^\"]*)\"")
 private val FILE=Regex("^(.*)-(\\d+)x(\\d+)\\.xml$",RegexOption.IGNORE_CASE)
 /** Tipo de My Boy! → tipo de Cirilo para los controles de un solo botón redondo. */
 private val CIRCLE=mapOf("a" to "a","b" to "b","a+b" to "ab","tl+tr" to "lr","tl+a" to "la","tl+b" to "lb","tr+a" to "ra","tr+b" to "rb","load" to "qload","save" to "qsave","ff" to "ff","ss" to "shot")
 private val NAME=mapOf("menu" to "Menú","tl" to "L","tr" to "R","tl+tr" to "L+R","tl+a" to "L+A","tl+b" to "L+B","tr+a" to "R+A","tr+b" to "R+B")
 fun parseControls(xml:String):List<Ctrl> = TAG.findAll(xml).mapNotNull{m->val s=m.value
  val t=TYPE.find(s)?.groupValues?.get(1)?:return@mapNotNull null
  val b=BOUNDS.find(s)?:return@mapNotNull null;val v=b.groupValues
  Ctrl(t,v[1].toInt(),v[2].toInt(),v[3].toInt(),v[4].toInt())}.toList()
 private fun unesc(s:String)=s.replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&apos;","'").replace("&amp;","&")
 fun profileNames(xml:String):List<String> = PROF.findAll(xml).map{unesc(it.groupValues[1])}.toList()
 /** Los nombres de archivo llevan %XX (UTF-8); el «+» es un «+» de verdad, no un espacio. */
 fun decode(s:String):String=try{java.net.URLDecoder.decode(s.replace("+","%2B"),"UTF-8")}catch(e:Exception){s}
 /** «Mi%20perfil-1541x720.xml» → (Mi perfil, 1541, 720). */
 fun splitFile(file:String):Triple<String,Int,Int>?{val m=FILE.find(decode(file.substringAfterLast('/')))?:return null
  return Triple(m.groupValues[1],m.groupValues[2].toInt(),m.groupValues[3].toInt())}
 /** files: nombre de archivo → contenido. Los nombres de perfil salen de layouts.xml; si falta, de los nombres de archivo. */
 fun profiles(files:Map<String,String>):List<Profile>{
  val shots=LinkedHashMap<String,MutableList<Shot>>();var index:String?=null
  for((fn,txt) in files){val base=fn.substringAfterLast('/')
   if(base.equals("layouts.xml",true)){index=txt;continue}
   val s=splitFile(base)?:continue
   shots.getOrPut(s.first){ArrayList()}.add(Shot(s.second,s.third,parseControls(txt)))}
  val names=index?.let{profileNames(it)}?.takeIf{it.isNotEmpty()}?:shots.keys.toList()
  return names.distinct().mapNotNull{n->shots[n]?.let{Profile(n,it)}}}
 /** Convierte un perfil a controles de Cirilo para la consola dst. De cada orientación se usa el archivo cuya proporción de pantalla se parezca más a la del móvil (devW x devH);
  *  si falta una orientación se usa fallback (la distribución de fábrica). */
 fun convert(p:Profile,dst:String,devW:Int,devH:Int,fallback:(Boolean)->List<Ctl>):Result{
  val notes=LinkedHashSet<String>();val dev=max(devW,devH).toFloat()/max(1,min(devW,devH))
  fun pick(land:Boolean):Shot?=p.shots.filter{(it.w>it.h)==land&&it.w>0&&it.h>0}.sortedBy{abs(max(it.w,it.h).toFloat()/min(it.w,it.h)-dev)}.firstOrNull()
  fun side(land:Boolean):List<Ctl>{val s=pick(land)
   if(s==null){notes.add("Sin distribución "+(if(land)"horizontal" else "vertical")+": se usa la de fábrica");return fallback(land)}
   return shot(s,land,dst,notes,fallback)}
  val pl=side(false);val ll=side(true);return Result(pl,ll,notes.toList())}
 private fun shot(s:Shot,land:Boolean,dst:String,notes:MutableSet<String>,fallback:(Boolean)->List<Ctl>):List<Ctl>{
  val W=s.w.toFloat();val H=s.h.toFloat();val mn=min(W,H);val out=ArrayList<Ctl>();val none=LinkedHashSet<String>();val gone=LinkedHashSet<String>()
  /** Círculo/píldora centrado en (cx,cy) px con tamaño normalizado sz (fracción del lado menor, como Ctl.s). */
  fun add(t:String,cx:Float,cy:Float,sz:Float){out.add(Ctl("m"+out.size,t,(cx/W).coerceIn(0f,1f),(cy/H).coerceIn(0f,1f),sz.coerceIn(.08f,1.2f)))}
  /** Pareja de círculos del alto del recuadro: el primero a la izquierda, el segundo a la derecha. */
  fun pair(t1:String,t2:String,c:Ctrl){val h=c.h.toFloat();add(t1,c.left+h/2f,c.cy,h/mn);add(t2,c.right-h/2f,c.cy,h/mn)}
  for(c in s.ctrls){val d=min(c.w,c.h).toFloat()
   when(c.type){
    "video"->{val a=LSys.aspect(dst);val wt=min(c.w.toFloat(),c.h*a);val fw=if(W/a<=H)W else H*a // ancho de la pantalla ajustada al área, que es la unidad de Ctl.s
     out.add(Ctl("screen","screen",(c.cx/W).coerceIn(0f,1f),if(c.top<=1)-1f else (c.cy/H).coerceIn(0f,1f),(wt/fw).coerceIn(.2f,2f)))}
    "dpad"->add("dpad",c.cx,c.cy,c.w/mn)
    "ab"->pair("b","a",c)
    "turbo_ab"->pair("turbob","turboa",c)
    "tl","tr"->{val t=if(c.type=="tl")"l" else "r"
     if(!LSys.allowed(dst,t))gone.add(NAME[c.type]?:c.type) else add(t,c.cx,c.cy,c.w/(1.3f*mn))} // la píldora de Cirilo mide 2,6·r de ancho: se iguala el ancho
    "start"->{val sz=min(c.w*.46f/(1.3f*mn),c.h/(.55f*mn)) // un solo control de My Boy! = Select (izquierda) + Start (derecha)
     add("select",c.left+c.w*.25f,c.cy,sz);add("start",c.right-c.w*.25f,c.cy,sz)}
    else->{val t=CIRCLE[c.type]
     if(t==null)none.add(NAME[c.type]?:c.type) else if(!LSys.allowed(dst,t))gone.add(NAME[c.type]?:c.type) else add(t,c.cx,c.cy,d/mn)}}}
  if(none.isNotEmpty())notes.add("Sin equivalente en Cirilo: "+none.joinToString(", "))
  if(gone.isNotEmpty())notes.add("GB y GBC no tienen gatillos, se omiten: "+gone.joinToString(", "))
  val scr=out.firstOrNull{it.t=="screen"}?:fallback(land).firstOrNull{it.t=="screen"}
  return (if(scr==null)emptyList() else listOf(scr))+out.filter{it.t!="screen"}}
}
