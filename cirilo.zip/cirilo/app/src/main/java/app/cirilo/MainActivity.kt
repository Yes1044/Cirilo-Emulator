package app.cirilo
import android.app.*
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.*
import android.widget.*
import java.io.File
class MainActivity:Activity(){
 private val emu=Emu();private lateinit var gl:GLView;private var pad=0;private var hw=0;private var idx=0
 private fun send()=Native.keys(pad or hw)
 override fun onCreate(b:Bundle?){
  super.onCreate(b);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);try{window.setSustainedPerformanceMode(true)}catch(e:Exception){}
  gl=GLView(this);val root=FrameLayout(this);root.setBackgroundColor(0xFF000000.toInt());root.addView(gl)
  root.addView(Pad(this){pad=it;send()})
  val pr=getSharedPreferences("c",0);emu.onFrame={gl.requestRender()}
  val tv=TextView(this).apply{setTextColor(0xFF00FF00.toInt());textSize=14f;setShadowLayer(3f,0f,0f,0xFF000000.toInt());setPadding(16,8,16,8);visibility=if(pr.getBoolean("fps",false))View.VISIBLE else View.GONE}
  root.addView(tv,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.START))
  val hd=Handler(Looper.getMainLooper());hd.post(object:Runnable{override fun run(){if(tv.visibility==View.VISIBLE)tv.text=""+emu.fps+" fps"+(if(emu.skip>0)" (salto "+emu.skip+")" else "");hd.postDelayed(this,500)}})
  val bar=LinearLayout(this);bar.addView(Button(this).apply{text="ROM";setOnClickListener{pickRom()}});bar.addView(Button(this).apply{text="FPS";setOnClickListener{val on=tv.visibility!=View.VISIBLE;tv.visibility=if(on)View.VISIBLE else View.GONE;pr.edit().putBoolean("fps",on).apply()}});bar.addView(Button(this).apply{text="Shaders";setOnClickListener{pickShader()}})
  root.addView(bar,FrameLayout.LayoutParams(-2,-2,Gravity.END or Gravity.BOTTOM));setContentView(root)}
 private fun pickRom(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),1)}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){
  val u=d?.data?:return;if(rs!=RESULT_OK)return
  Thread{val name=contentResolver.query(u,null,null,null,null)?.use{if(it.moveToFirst())it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null}?:"game.gba"
   val rom=contentResolver.openInputStream(u)!!.use{it.readBytes()}
   val sv=File(getExternalFilesDir("saves"),name.substringBeforeLast('.')+".sav")
   emu.start(rom,name,sv)}.start()}
 private fun pickShader(){val l=Shaders.list(this)
  val names=l.map{it.name}.toMutableList();if(!Shaders.installed(this))names+="(Instala «Emulator Shaders» para tener más)"
  AlertDialog.Builder(this).setSingleChoiceItems(names.toTypedArray(),idx){d,i->if(i<l.size){idx=i;gl.shader=l[i].takeIf{i>0};gl.requestRender()};d.dismiss()}.show()}
 private fun bit(k:Int)=when(k){KeyEvent.KEYCODE_DPAD_UP->4;KeyEvent.KEYCODE_DPAD_DOWN->5;KeyEvent.KEYCODE_DPAD_LEFT->6;KeyEvent.KEYCODE_DPAD_RIGHT->7
  KeyEvent.KEYCODE_BUTTON_A->8;KeyEvent.KEYCODE_BUTTON_B->0;KeyEvent.KEYCODE_BUTTON_START->3;KeyEvent.KEYCODE_BUTTON_SELECT->2;KeyEvent.KEYCODE_BUTTON_L1->10;KeyEvent.KEYCODE_BUTTON_R1->11;else->-1}
 override fun onKeyDown(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyDown(k,e);hw=hw or(1 shl b);send();return true}
 override fun onKeyUp(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyUp(k,e);hw=hw and(1 shl b).inv();send();return true}
 override fun onPause(){super.onPause();gl.onPause();emu.pause()}
 override fun onResume(){super.onResume();gl.onResume();emu.resume()}
}
