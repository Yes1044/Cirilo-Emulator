package app.cirilo
import android.content.Context
import android.opengl.GLES20.*
import android.opengl.GLSurfaceView
import java.nio.*
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
class GLView(c:Context):GLSurfaceView(c),GLSurfaceView.Renderer{
 private val buf=ByteBuffer.allocateDirect(256*224*2).order(ByteOrder.nativeOrder())
 private fun fb(a:FloatArray)=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(a).also{it.position(0)}
 private val pos=fb(floatArrayOf(-1f,-1f,1f,-1f,-1f,1f,1f,1f));private val uv=fb(floatArrayOf(0f,1f,1f,1f,0f,0f,1f,0f))
 @Volatile var shader:Shader?=null
 private var cur:Shader?=null;private var prog=0;private var tex=0;private var tw=0;private var th=0;private var vw=0;private var vh=0
 init{setEGLContextClientVersion(2);setRenderer(this)}
 override fun onSurfaceCreated(g:GL10?,c:EGLConfig?){prog=0;cur=null;tex=0;tw=0}
 override fun onSurfaceChanged(g:GL10?,w:Int,h:Int){vw=w;vh=h}
 private fun sh(t:Int,s:String):Int{val i=glCreateShader(t);glShaderSource(i,s);glCompileShader(i);val o=IntArray(1);glGetShaderiv(i,GL_COMPILE_STATUS,o,0);return if(o[0]==0)0 else i}
 private fun build(s:Shader?):Int{
  val v=sh(GL_VERTEX_SHADER,s?.vs?:DV);val f=sh(GL_FRAGMENT_SHADER,s?.fs?:DF)
  if(v==0||f==0)return if(s==null)0 else build(null) // si un shader no compila, vuelve al normal
  val p=glCreateProgram();glAttachShader(p,v);glAttachShader(p,f);glBindAttribLocation(p,0,"aPosition");glBindAttribLocation(p,1,"aTexCoord");glLinkProgram(p);return p}
 override fun onDrawFrame(g:GL10?){
  val r=Native.frame(buf)
  if(r!=0){val w=r ushr 16;val h=r and 0xffff
   if(tex==0){val t=IntArray(1);glGenTextures(1,t,0);tex=t[0]}
   glBindTexture(GL_TEXTURE_2D,tex);glPixelStorei(GL_UNPACK_ALIGNMENT,2);buf.position(0)
   if(w!=tw||h!=th){tw=w;th=h;glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,w,h,0,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,buf)}
   else glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,GL_RGB,GL_UNSIGNED_SHORT_5_6_5,buf)}
  glViewport(0,0,vw,vh);glClearColor(0f,0f,0f,1f);glClear(GL_COLOR_BUFFER_BIT)
  if(tw==0||vw==0)return
  val s=shader;if(prog==0||s!==cur){if(prog!=0)glDeleteProgram(prog);prog=build(s);cur=s}
  var pw=vw;var ph=vw*th/tw;if(ph>vh){ph=vh;pw=vh*tw/th}
  glViewport((vw-pw)/2,vh-ph,pw,ph) // arriba y centrado, para dejar abajo los controles
  glUseProgram(prog);val lin=if(s?.linear!=false)GL_LINEAR else GL_NEAREST
  glBindTexture(GL_TEXTURE_2D,tex);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,lin);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,lin)
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE)
  fun u(n:String,a:Float,b:Float){val l=glGetUniformLocation(prog,n);if(l>=0)glUniform2f(l,a,b)}
  glUniform1i(glGetUniformLocation(prog,"rubyTexture"),0)
  u("rubyTextureSize",tw.toFloat(),th.toFloat());u("rubyInputSize",tw.toFloat(),th.toFloat());u("rubyOutputSize",pw.toFloat(),ph.toFloat())
  glEnableVertexAttribArray(0);glVertexAttribPointer(0,2,GL_FLOAT,false,0,pos);glEnableVertexAttribArray(1);glVertexAttribPointer(1,2,GL_FLOAT,false,0,uv)
  glDrawArrays(GL_TRIANGLE_STRIP,0,4)}
}
