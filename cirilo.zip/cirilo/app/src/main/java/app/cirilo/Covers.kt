package app.cirilo
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.*
import java.lang.ref.WeakReference
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.Normalizer
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.CRC32
import java.util.zip.ZipInputStream

/** Entrada de Named_Boxarts de Libretro. base = nombre sin etiquetas; key = base normalizada (solo para BUSCAR, nunca se muestra). */
class Box(val name:String,val key:String,val regs:Set<String>,val langs:Set<String>,val flags:Set<String>,val rev:Int)
class Tags(val regs:Set<String>,val langs:Set<String>,val flags:Set<String>,val rev:Int)
class PlatIdx(val byName:HashMap<String,Box>,val byKey:HashMap<String,MutableList<Box>>,val byCrc:HashMap<Long,String>,val bySerial:HashMap<String,MutableList<String>>)
/** sys: 0 GB, 1 GBC, 2 GBA. how: exact | norm | meta | crc */
class Match(val sys:Int,val name:String,val how:String)

/** Identificación LOCAL de ROMs contra el catálogo de Libretro (índices en assets/libretro, generados por tools/gen_libretro_index.py). La ROM nunca sale del dispositivo. */
object CoverIdx{
 const val VER=1
 /** Nombres de directorio verificados en https://thumbnails.libretro.com/ */
 val SYS=listOf("Nintendo - Game Boy","Nintendo - Game Boy Color","Nintendo - Game Boy Advance")
 private val F=listOf("gb","gbc","gba");private val idx=arrayOfNulls<PlatIdx>(3)
 private val RG=mapOf("USA" to "USA","US" to "USA","U" to "USA","Europe" to "Europe","EU" to "Europe","E" to "Europe","Japan" to "Japan","JP" to "Japan","J" to "Japan","World" to "World","Spain" to "Spain","Germany" to "Germany","France" to "France","Italy" to "Italy","UK" to "UK","Australia" to "Australia","Korea" to "Korea","China" to "China","Netherlands" to "Netherlands","Sweden" to "Sweden","Brazil" to "Brazil","Asia" to "Asia","Taiwan" to "Taiwan","Canada" to "Canada")
 private val MACRO=mapOf("USA" to "USA","Canada" to "USA","Brazil" to "USA","Europe" to "Europe","Spain" to "Europe","Germany" to "Europe","France" to "Europe","Italy" to "Europe","UK" to "Europe","Netherlands" to "Europe","Sweden" to "Europe","Australia" to "Europe","Japan" to "Japan","Korea" to "Asia","China" to "Asia","Taiwan" to "Asia","Asia" to "Asia","World" to "World")
 private val IMPL=mapOf("Spain" to "es","Germany" to "de","France" to "fr","Italy" to "it","Japan" to "ja","USA" to "en","UK" to "en","Australia" to "en","Canada" to "en","Netherlands" to "nl","Brazil" to "pt","Korea" to "ko","China" to "zh","Sweden" to "sv")
 private val PEN=setOf("beta","proto","possible proto","demo","sample","kiosk","unl","hack","alternate","promo","virtual console")
 private val GRP=Regex("\\(([^)]*)\\)");private val LG=Regex("[A-Z][a-z](,[A-Z][a-z])*");private val REV=Regex("Rev (\\d+)")
 /** Los caracteres que Libretro sustituye por «_» en los nombres de archivo. */
 fun san(s:String)=s.replace(Regex("[&*/:`<>?\\\\|]"),"_")
 fun tags(s:String):Tags{val rg=LinkedHashSet<String>();val lg=LinkedHashSet<String>();val fl=LinkedHashSet<String>();var rv=0
  GRP.findAll(s).forEach{m->val t=m.groupValues[1]
   if(LG.matches(t))t.split(",").forEach{lg+=it.lowercase()}
   else{val parts=t.split(",").map{it.trim()};var any=false;parts.forEach{w->RG[w]?.let{rg+=it;any=true}}
    if(!any){val lw=t.lowercase();if(lw in PEN)fl+=lw;REV.find(t)?.let{rv=it.groupValues[1].toInt()}}}}
  return Tags(rg,lg,fl,rv)}
 /** Normalización SOLO para comparar: sin acentos, sin etiquetas, sin puntuación ni artículos. */
 fun norm(s:String):String{val b=s.replace(Regex("\\s*[(\\[].*$"),"")
  val t=Normalizer.normalize(b,Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"").lowercase()
  return t.split(Regex("[^a-z0-9]+")).filter{it.isNotEmpty()&&it!="the"&&it!="and"}.joinToString(" ")}
 @Synchronized fun get(c:Context,p:Int):PlatIdx{idx[p]?.let{return it}
  val bn=HashMap<String,Box>();val bk=HashMap<String,MutableList<Box>>();val bc=HashMap<Long,String>();val bs=HashMap<String,MutableList<String>>()
  c.assets.open("libretro/"+F[p]+".txt").bufferedReader().useLines{ls->ls.forEach{n->if(n.isEmpty())return@forEach
   val t=tags(n);val b=Box(n,norm(n),t.regs,t.langs,t.flags,t.rev);bn[n]=b;bk.getOrPut(b.key){ArrayList()}.add(b)}}
  c.assets.open("libretro/"+F[p]+".dat").bufferedReader().useLines{ls->ls.forEach{l->val a=l.split('\t');if(a.size<3)return@forEach
   a[0].toLongOrNull(16)?.let{bc[it]=a[2]};if(a[1].isNotEmpty())bs.getOrPut(a[1]){ArrayList()}.add(a[2])}}
  return PlatIdx(bn,bk,bc,bs).also{idx[p]=it}}
 private fun score(b:Box,t:Tags,g:Game):Int{var s=0
  val gm=g.reg.split(",").filter{it.isNotEmpty()}.toSet();val gl=g.lang.split(",").filter{it.isNotEmpty()}.toSet()
  val bm=b.regs.map{MACRO[it]?:it}.toSet();val tm=t.regs.map{MACRO[it]?:it}.toSet()
  if(t.regs.isNotEmpty()){if(b.regs.any{it in t.regs})s+=100 else if(bm.any{it in tm})s+=60}
  else if(gm.isNotEmpty()&&bm.any{it in gm})s+=50
  val tl=if(t.langs.isNotEmpty())t.langs else if(t.regs.isNotEmpty())t.regs.mapNotNull{IMPL[it]}.toSet() else gl
  val bl=b.langs+b.regs.mapNotNull{IMPL[it]}
  if(tl.isNotEmpty()&&bl.any{it in tl})s+=30
  b.flags.forEach{if(it in PEN)s+=if(it in t.flags)15 else -15}
  if(t.rev>0&&b.rev==t.rev)s+=10 else s-=b.rev
  s+=if("USA" in b.regs)3 else if("World" in b.regs)2 else if("Europe" in b.regs)1 else 0
  return s}
 private fun best(cs:List<Box>,t:Tags,g:Game)=cs.maxByOrNull{score(it,t,g)}
 private fun jac(a:String,b:String):Double{val x=a.split(" ").toSet();val y=b.split(" ").toSet();if(x.isEmpty()||y.isEmpty())return 0.0;return x.intersect(y).size.toDouble()/x.union(y).size}
 private fun serial(h:ByteArray,p:Int):String?{val r=if(p==2)0xAC..0xAF else 0x13F..0x142;if(h.size<=r.last)return null
  val s=r.map{h[it].toInt().toChar()};return if(s.all{it in 'A'..'Z'||it in '0'..'9'})s.joinToString("") else null}
 private fun crc(c:Context,g:Game):Long?{
  val i:InputStream=(if(g.u.startsWith("/"))FileInputStream(g.u) else c.contentResolver.openInputStream(Uri.parse(g.u)))?:return null
  i.use{val buf=ByteArray(65536);val cr=CRC32()
   fun feed(s:InputStream){while(true){val n=s.read(buf);if(n<0)break;cr.update(buf,0,n)}}
   if(Roms.ext(g.n)!="zip"){feed(it);return cr.value}
   val z=ZipInputStream(it);while(true){val e=z.nextEntry?:return null;if(!e.isDirectory&&Roms.ext(e.name) in Roms.ROM){feed(z);return cr.value}}}
  return null}
 /** Estrategia escalonada. null = sin coincidencia fiable (se usa placeholder). Puede tardar (lee la ROM): ejecutar en segundo plano. */
 fun identify(c:Context,g0:Game):Match?{
  var g=g0;if(g.p<0)g=Roms.meta(c,g);val p=g.p.coerceIn(0,2);val ix=get(c,p);val title=g.title;val t=tags(title)
  // 1. nombre canónico exacto
  ix.byName[san(title)]?.let{return Match(p,it.name,"exact")}
  // 2. nombre normalizado (misma base; la región/idioma/edición solo desempatan)
  val key=norm(title)
  if(key.isNotEmpty())ix.byKey[key]?.let{cs->best(cs,t,g)?.let{return Match(p,it.name,"norm")}}
  // 3. metadatos: código de juego del encabezado, validado contra el nombre (un hack conserva el código del juego original)
  val h=try{Roms.load(c,g.u,g.n,0x150)?.second}catch(e:Exception){null}
  if(h!=null){val sr=serial(h,p);val ns=sr?.let{ix.bySerial[it]}
   if(ns!=null){val cs=ns.mapNotNull{ix.byName[it]}.filter{jac(key,it.key)>=0.6}
    if(cs.isNotEmpty()){val m=best(cs,t,g)!!;return Match(p,m.name,"meta")}}}
  // 4. hash CRC32 local contra la base No-Intro
  val cr=try{crc(c,g)}catch(e:Exception){null}
  cr?.let{ix.byCrc[it]}?.let{return Match(p,it,"crc")}
  return null}
}

/** Placeholder propio: mismas dimensiones que una carátula, sin imagen rota ni hueco. */
class CoverPh(private val p:Int):Drawable(){
 private val bg=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xFF3A3A3A.toInt()};private val fg=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xFF5A5A5A.toInt()}
 private val lb=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xFF80CBC4.toInt();textAlign=Paint.Align.CENTER;typeface=Typeface.DEFAULT_BOLD}
 override fun draw(cv:Canvas){val b=bounds;val w=b.width().toFloat();val h=b.height().toFloat();if(w<=0)return
  val s=minOf(w,h);val r=s*.08f;cv.drawRoundRect(RectF(b.left+s*.04f,b.top+s*.04f,b.right-s*.04f,b.bottom-s*.04f),r,r,bg)
  val cw=s*.46f;val ch=s*.56f;val l=b.exactCenterX()-cw/2;val t=b.exactCenterY()-ch/2-s*.04f
  val path=Path().apply{moveTo(l,t+ch*.12f);lineTo(l+cw*.12f,t);lineTo(l+cw,t);lineTo(l+cw,t+ch);lineTo(l,t+ch);close()};cv.drawPath(path,fg)
  cv.drawRoundRect(RectF(l+cw*.14f,t+ch*.22f,l+cw*.86f,t+ch*.62f),s*.02f,s*.02f,bg)
  lb.textSize=s*.12f;cv.drawText(arrayOf("GB","GBC","GBA").getOrElse(p){"GB"},b.exactCenterX(),t+ch*.48f,lb)}
 override fun setAlpha(a:Int){};override fun setColorFilter(f:ColorFilter?){};override fun getOpacity()=PixelFormat.TRANSLUCENT
}

/** Caché persistente (disco + SharedPreferences «covers») y en memoria, descargas asíncronas y carátulas personalizadas.
 *  Prioridad: personalizada > Libretro (auto) > placeholder. Los archivos automáticos y los personalizados viven en carpetas distintas: una descarga nunca pisa una imagen del usuario. */
object Covers{
 private val main=Handler(Looper.getMainLooper())
 private val io=Executors.newFixedThreadPool(2) // decodificación
 private class Job(val seq:Long,val f:()->Unit):Runnable,Comparable<Job>{override fun run(){f()};override fun compareTo(other:Job)=other.seq.compareTo(seq)} // las más recientes (lo visible ahora) primero
 private val dl=ThreadPoolExecutor(3,3,30,TimeUnit.SECONDS,PriorityBlockingQueue<Runnable>()) // descargas simultáneas limitadas a 3
 private val seq=AtomicLong();private val inflight=ConcurrentHashMap.newKeySet<String>();private val netFail=ConcurrentHashMap<String,Long>()
 private val waiters=ConcurrentHashMap<String,CopyOnWriteArrayList<WeakReference<ImageView>>>();private val idLock=Any()
 private val ver=ConcurrentHashMap<String,Int>();@Volatile private var epoch=0
 private val mem=object:LruCache<String,Bitmap>((Runtime.getRuntime().maxMemory()/8).toInt().coerceAtMost(64*1024*1024)){override fun sizeOf(k:String,v:Bitmap)=v.byteCount}
 private enum class R{OK,NOTFOUND,NET,CANCEL}
 private fun sp(c:Context)=c.getSharedPreferences("covers",0)
 private fun lib(c:Context)=c.getSharedPreferences("lib",0)
 fun autoOn(c:Context)=lib(c).getBoolean("cov_auto",true)
 private fun sha(s:String)=MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
 fun key(g:Game)=sha(g.u).take(20)
 private fun dir(c:Context,n:String)=File(c.filesDir,"covers/"+n).also{it.mkdirs()}
 private fun customFile(c:Context,k:String)=File(dir(c,"custom"),k+".img")
 private fun autoFile(c:Context,sys:Int,name:String)=File(dir(c,"auto"),sha(sys.toString()+"/"+name).take(24)+".png")
 private fun bump(k:String){ver[k]=(ver[k]?:0)+1}
 private fun mk(k:String,w:Int)=k+"#"+epoch+"#"+(ver[k]?:0)+"#"+w
 // ---- consulta ----
 fun hasCustom(c:Context,g:Game)=customFile(c,key(g)).exists()
 fun customOn(c:Context,g:Game)=hasCustom(c,g)&&sp(c).getString("c:"+key(g),"1")=="1"
 fun hasAuto(c:Context,g:Game)=autoOf(c,key(g))!=null
 private fun stored(c:Context,k:String):Match?{val a=sp(c).getString("m:"+k,null)?.split("|")?:return null;return if(a.size>=3)Match(a[0].toInt(),a[1],a[2]) else null}
 private fun autoOf(c:Context,k:String):File?{val m=stored(c,k)?:return null;return autoFile(c,m.sys,m.name).takeIf{it.exists()}}
 private fun current(c:Context,k:String):File?{val cu=customFile(c,k);if(cu.exists()&&sp(c).getString("c:"+k,"1")=="1")return cu;return autoOf(c,k)}
 private fun noMatch(c:Context,k:String)=sp(c).getString("x:"+k,null)==CoverIdx.VER.toString()
 // ---- visualización ----
 /** Pone la carátula en el ImageView: caché en memoria si existe; si no, placeholder inmediato y carga/descarga en segundo plano. Actualiza solo esa tarjeta. */
 fun bind(iv:ImageView,g:Game,w:Int,h:Int){val c=iv.context.applicationContext;val k=key(g);iv.tag=k
  val hit=mem.get(mk(k,w));if(hit!=null){iv.setImageBitmap(hit);return}
  iv.setImageDrawable(CoverPh(g.p));val gg=g
  io.execute{if(!show(c,iv,k,w,h)&&autoOn(c)&&!noMatch(c,k)&&!(customFile(c,k).exists()&&sp(c).getString("c:"+k,"1")=="1")){
   val t=netFail[k];if(t==null||System.currentTimeMillis()-t>60_000)request(c,gg,k,iv)}}}
 private fun show(c:Context,iv:ImageView,k:String,w:Int,h:Int):Boolean{val f=current(c,k)?:return false;val key=mk(k,w)
  val bm=mem.get(key)?:decode(f,w,h)?.also{mem.put(key,it)}?:return false
  main.post{if(iv.tag==k)iv.setImageBitmap(bm)};return true}
 private fun decode(f:File,w:Int,h:Int):Bitmap?=try{val o=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(f.path,o)
  var s=1;while(o.outWidth/(s*2)>=w&&o.outHeight/(s*2)>=h)s*=2 // nunca a resolución completa: se reduce a ~el tamaño de la tarjeta
  BitmapFactory.decodeFile(f.path,BitmapFactory.Options().apply{inSampleSize=s})}catch(e:Throwable){null}
 // ---- descargas ----
 private fun wanted(k:String)=waiters[k]?.any{val v=it.get();v!=null&&v.tag==k&&v.isAttachedToWindow}==true
 private fun request(c:Context,g:Game,k:String,iv:ImageView){val l=waiters.getOrPut(k){CopyOnWriteArrayList()};l.removeAll{it.get()==null};l.add(WeakReference(iv))
  if(!inflight.add(k))return // sin solicitudes duplicadas
  dl.execute(Job(seq.incrementAndGet()){fetch(c,g,k)})}
 private fun fetch(c:Context,g:Game,k:String){
  try{if(!wanted(k))return // cancelada: la tarjeta ya no está en pantalla
   if(sp(c).getString("c:"+k,"1")=="1"&&customFile(c,k).exists())return
   var m=stored(c,k)
   if(m==null){m=synchronized(idLock){CoverIdx.identify(c,g)}
    if(m==null){sp(c).edit().putString("x:"+k,CoverIdx.VER.toString()).apply();bump(k);return}
    sp(c).edit().putString("m:"+k,m.sys.toString()+"|"+m.name+"|"+m.how).apply()}
   val f=autoFile(c,m.sys,m.name)
   if(!f.exists())when(download(c,m,f,k)){R.OK->{}
    R.NOTFOUND->{sp(c).edit().remove("m:"+k).putString("x:"+k,CoverIdx.VER.toString()).apply();return}
    R.NET->{netFail[k]=System.currentTimeMillis();return};R.CANCEL->return}
   netFail.remove(k);bump(k)
   waiters[k]?.forEach{r->val v=r.get();if(v!=null&&v.tag==k)io.execute{show(c,v,k,maxOf(v.width,1),maxOf(v.height,1))}}
  }finally{inflight.remove(k)}}
 private class Cancel:Exception()
 private fun download(c:Context,m:Match,f:File,k:String):R{
  val url=URL("https://thumbnails.libretro.com/"+Uri.encode(CoverIdx.SYS[m.sys])+"/Named_Boxarts/"+Uri.encode(m.name)+".png")
  for(a in 0 until 3){if(!wanted(k))return R.CANCEL
   val tmp=File(f.parentFile,f.name+"."+k+".part");var cn:HttpURLConnection?=null
   try{cn=url.openConnection() as HttpURLConnection;cn.connectTimeout=8000;cn.readTimeout=15000;cn.setRequestProperty("User-Agent","Cirilo")
    val code=cn.responseCode;if(code==404||code==403)return R.NOTFOUND;if(code!=200)throw IOException("HTTP "+code)
    cn.inputStream.use{i->tmp.outputStream().use{o->val b=ByteArray(16384);var tot=0
     while(true){val n=i.read(b);if(n<0)break;tot+=n;if(tot>8_000_000)throw IOException("demasiado grande");o.write(b,0,n);if(!wanted(k))throw Cancel()}}}
    val o=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(tmp.path,o);if(o.outWidth<=0)throw IOException("imagen inválida")
    if(f.exists())tmp.delete() else if(!tmp.renameTo(f))throw IOException("no se pudo guardar")
    return R.OK
   }catch(e:Cancel){tmp.delete();return R.CANCEL}
   catch(e:IOException){tmp.delete();if(a<2)try{Thread.sleep(1000L*(a*2+1))}catch(x:InterruptedException){return R.CANCEL}}
   finally{cn?.disconnect()}}
  return R.NET}
 // ---- carátulas personalizadas y gestión ----
 fun setCustom(c:Context,g:Game,u:Uri):Boolean{val k=key(g)
  return try{val o=BitmapFactory.Options().apply{inJustDecodeBounds=true};c.contentResolver.openInputStream(u)?.use{BitmapFactory.decodeStream(it,null,o)}
   if(o.outWidth<=0)return false;var s=1;while(maxOf(o.outWidth,o.outHeight)/s>1024)s*=2
   val bm=c.contentResolver.openInputStream(u)?.use{BitmapFactory.decodeStream(it,null,BitmapFactory.Options().apply{inSampleSize=s})}?:return false
   val f=customFile(c,k);val tmp=File(f.path+".part")
   tmp.outputStream().use{bm.compress(if(bm.hasAlpha())Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,92,it)}
   if(f.exists())f.delete();tmp.renameTo(f);sp(c).edit().putString("c:"+k,"1").apply();bump(k);true}catch(e:Throwable){false}}
 fun removeCustom(c:Context,g:Game){val k=key(g);customFile(c,k).delete();sp(c).edit().remove("c:"+k).apply();bump(k)}
 fun useAuto(c:Context,g:Game){val k=key(g);sp(c).edit().putString("c:"+k,"0").apply();bump(k)}
 fun useCustom(c:Context,g:Game){val k=key(g);sp(c).edit().putString("c:"+k,"1").apply();bump(k)}
 /** «Buscar de nuevo»: olvida la coincidencia y el archivo automático de este juego (nunca toca la personalizada). */
 fun research(c:Context,g:Game){val k=key(g);val m=stored(c,k);if(m!=null)autoFile(c,m.sys,m.name).delete()
  sp(c).edit().remove("m:"+k).remove("x:"+k).apply();netFail.remove(k);bump(k)}
 fun retryMissing(c:Context){val e=sp(c).edit();sp(c).all.keys.filter{it.startsWith("x:")}.forEach{e.remove(it)};e.apply();netFail.clear();epoch++}
 fun cacheSize(c:Context)=dir(c,"auto").listFiles()?.sumOf{it.length()}?:0L
 fun clearAuto(c:Context){dir(c,"auto").listFiles()?.forEach{it.delete()};val e=sp(c).edit();sp(c).all.keys.filter{it.startsWith("m:")||it.startsWith("x:")}.forEach{e.remove(it)};e.apply();netFail.clear();mem.evictAll();epoch++}
 fun trim(){mem.trimToSize(mem.maxSize()/2)}
}
