package app.cirilo
import android.app.*
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.text.*
import android.view.*
import android.widget.*

/** Color de acento de la app (preferencia «lib» / «accent», RGB opaco). Por defecto el verde azulado de siempre. `Accent.color` se carga al arrancar (App.kt) y se actualiza al guardar. */
object Accent{
 val DEF=0xFF80CBC4.toInt()
 @JvmStatic var color=DEF
 fun load(c:Context){color=c.getSharedPreferences("lib",0).getInt("accent",DEF) or 0xFF000000.toInt()}
 fun save(c:Context,v:Int){color=v or 0xFF000000.toInt();c.getSharedPreferences("lib",0).edit().putInt("accent",color).apply()}
 /** El acento con otra opacidad (a = 0..255), para fondos de selección. */
 fun alpha(a:Int)=(color and 0xFFFFFF) or (a shl 24)
 /** Color de texto legible sobre un fondo de color c: oscuro si c es claro, blanco si es oscuro. */
 fun on(c:Int=color):Int{val l=(0.299*(c shr 16 and 255)+0.587*(c shr 8 and 255)+0.114*(c and 255))/255;return if(l>.6)0xFF212121.toInt() else -1}
 fun hex(c:Int)="#%06X".format(c and 0xFFFFFF)
 /** «#RRGGBB», «RRGGBB», «#RGB» o «RGB» → RGB; null si no es un color válido. */
 fun parse(s:String):Int?{val t=s.trim().removePrefix("#");val h=if(t.length==3)t.map{""+it+it}.joinToString("") else t
  if(h.length!=6||!h.all{it in '0'..'9'||it in 'a'..'f'||it in 'A'..'F'})return null
  return h.toInt(16)}
}

/** Cuadrado saturación (horizontal) / brillo (vertical) para el tono actual. */
class SvView(c:Context,val onChange:(Float,Float)->Unit):View(c){
 var hue=0f;set(v){field=v;invalidate()}
 var sat=1f;set(v){field=v;invalidate()}
 var vl=1f;set(v){field=v;invalidate()}
 private val p=Paint(Paint.ANTI_ALIAS_FLAG);private val dn=resources.displayMetrics.density
 override fun onDraw(cv:Canvas){val w=width.toFloat();val h=height.toFloat();val hc=Color.HSVToColor(floatArrayOf(hue,1f,1f))
  p.style=Paint.Style.FILL;p.shader=ComposeShader(LinearGradient(0f,0f,0f,h,-1,0xFF000000.toInt(),Shader.TileMode.CLAMP),LinearGradient(0f,0f,w,0f,-1,hc,Shader.TileMode.CLAMP),PorterDuff.Mode.MULTIPLY)
  cv.drawRoundRect(RectF(0f,0f,w,h),8*dn,8*dn,p);p.shader=null
  val x=sat*w;val y=(1f-vl)*h;p.style=Paint.Style.STROKE;p.strokeWidth=3*dn;p.color=0xFF000000.toInt();cv.drawCircle(x,y,11*dn,p);p.strokeWidth=2*dn;p.color=-1;cv.drawCircle(x,y,11*dn,p)}
 override fun onTouchEvent(e:MotionEvent):Boolean{parent?.requestDisallowInterceptTouchEvent(true)
  if(e.actionMasked==MotionEvent.ACTION_UP||e.actionMasked==MotionEvent.ACTION_CANCEL)parent?.requestDisallowInterceptTouchEvent(false)
  sat=(e.x/width).coerceIn(0f,1f);vl=1f-(e.y/height).coerceIn(0f,1f);onChange(sat,vl);return true}
}

/** Barra de tono (0..360). */
class HueView(c:Context,val onChange:(Float)->Unit):View(c){
 var hue=0f;set(v){field=v;invalidate()}
 private val p=Paint(Paint.ANTI_ALIAS_FLAG);private val dn=resources.displayMetrics.density
 override fun onDraw(cv:Canvas){val w=width.toFloat();val h=height.toFloat();val cs=IntArray(7){Color.HSVToColor(floatArrayOf(it*60f,1f,1f))}
  p.style=Paint.Style.FILL;p.shader=LinearGradient(0f,0f,w,0f,cs,null,Shader.TileMode.CLAMP);cv.drawRoundRect(RectF(0f,h*.25f,w,h*.75f),h*.25f,h*.25f,p);p.shader=null
  val x=hue/360f*w;p.style=Paint.Style.FILL;p.color=Color.HSVToColor(floatArrayOf(hue,1f,1f));cv.drawCircle(x,h/2,h*.42f,p)
  p.style=Paint.Style.STROKE;p.strokeWidth=3*dn;p.color=-1;cv.drawCircle(x,h/2,h*.42f,p)}
 override fun onTouchEvent(e:MotionEvent):Boolean{parent?.requestDisallowInterceptTouchEvent(true)
  if(e.actionMasked==MotionEvent.ACTION_UP||e.actionMasked==MotionEvent.ACTION_CANCEL)parent?.requestDisallowInterceptTouchEvent(false)
  hue=(e.x/width).coerceIn(0f,1f)*360f;onChange(hue);return true}
}

/** Selector del color de acento: cuadrado saturación/brillo, barra de tono, deslizadores R G B, código hexadecimal y colores sugeridos. Aceptar guarda y llama a done(). */
object AccentPicker{
 private val PRESETS=listOf(0xFF80CBC4L,0xFF4DB6AC,0xFF4FC3F7,0xFF64B5F6,0xFF7986CB,0xFFBA68C8,0xFFF06292,0xFFE57373,0xFFFF8A65,0xFFFFB74D,0xFFFFD54F,0xFFAED581).map{it.toInt()}
 fun show(a:Activity,done:()->Unit){
  val dn=a.resources.displayMetrics.density;fun dp(x:Int)=(x*dn).toInt()
  val hsv=FloatArray(3);var cur=Accent.color and 0xFFFFFF;Color.colorToHSV(cur or 0xFF000000.toInt(),hsv);var lock=false
  val col=LinearLayout(a).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),dp(4))}
  val sw=TextView(a).apply{text="Así se verá el acento";gravity=Gravity.CENTER;textSize=15f;typeface=Typeface.DEFAULT_BOLD;background=GradientDrawable().apply{cornerRadius=dp(10).toFloat()}}
  val hexE=EditText(a).apply{setSingleLine();setTextColor(-1);typeface=Typeface.MONOSPACE;textSize=18f;gravity=Gravity.CENTER;filters=arrayOf(InputFilter.LengthFilter(7),InputFilter.AllCaps())
   inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS}
  val bars=ArrayList<SeekBar>()
  lateinit var sv:SvView;lateinit var hv:HueView
  fun setC(c:Int,src:Int){ // src: 0 cuadrado/tono, 1 hex, 2 deslizadores RGB, 3 sugerido
   lock=true;cur=c and 0xFFFFFF
   if(src!=0){val old=hsv[0];Color.colorToHSV(cur or 0xFF000000.toInt(),hsv);if(hsv[1]==0f||hsv[2]==0f)hsv[0]=old} // los grises no mueven el tono
   sv.hue=hsv[0];sv.sat=hsv[1];sv.vl=hsv[2];hv.hue=hsv[0]
   (sw.background as GradientDrawable).setColor(cur or 0xFF000000.toInt());sw.setTextColor(Accent.on(cur))
   if(src!=1){hexE.setText(Accent.hex(cur));hexE.setTextColor(-1)}
   if(src!=2){bars[0].progress=cur shr 16 and 255;bars[1].progress=cur shr 8 and 255;bars[2].progress=cur and 255}
   lock=false}
  sv=SvView(a){s,v->if(!lock){hsv[1]=s;hsv[2]=v;setC(Color.HSVToColor(hsv) and 0xFFFFFF,0)}}
  hv=HueView(a){h->if(!lock){hsv[0]=h;setC(Color.HSVToColor(hsv) and 0xFFFFFF,0)}}
  col.addView(sw,LinearLayout.LayoutParams(-1,dp(44)).apply{bottomMargin=dp(12)})
  col.addView(sv,LinearLayout.LayoutParams(-1,dp(190)))
  col.addView(hv,LinearLayout.LayoutParams(-1,dp(40)).apply{topMargin=dp(6)})
  listOf("R" to 0xFFE53935.toInt(),"G" to 0xFF43A047.toInt(),"B" to 0xFF1E88E5.toInt()).forEach{(n,cl)->
   val r=LinearLayout(a).apply{gravity=Gravity.CENTER_VERTICAL}
   r.addView(TextView(a).apply{text=n;setTextColor(cl);typeface=Typeface.DEFAULT_BOLD;textSize=15f;gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(24),-2))
   val sb=SeekBar(a).apply{max=255;progressTintList=android.content.res.ColorStateList.valueOf(cl);thumbTintList=android.content.res.ColorStateList.valueOf(cl)
    setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){if(u&&!lock)setC((bars[0].progress shl 16)or(bars[1].progress shl 8)or bars[2].progress,2)}
     override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}})}
   bars.add(sb);r.addView(sb,LinearLayout.LayoutParams(0,-2,1f));col.addView(r)}
  val hr=LinearLayout(a).apply{gravity=Gravity.CENTER_VERTICAL}
  hr.addView(TextView(a).apply{text="Código hex";setTextColor(0xFFBBBBBB.toInt());textSize=14f},LinearLayout.LayoutParams(-2,-2).apply{rightMargin=dp(12)})
  hr.addView(hexE,LinearLayout.LayoutParams(0,-2,1f));col.addView(hr,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(8)})
  hexE.addTextChangedListener(object:TextWatcher{override fun afterTextChanged(e:Editable?){if(lock)return;val v=Accent.parse(e.toString());hexE.setTextColor(if(v==null)0xFFEF5350.toInt() else -1);if(v!=null)setC(v,1)}
   override fun beforeTextChanged(s:CharSequence?,x:Int,y:Int,z:Int){};override fun onTextChanged(s:CharSequence?,x:Int,y:Int,z:Int){}})
  col.addView(TextView(a).apply{text="Sugeridos";setTextColor(0xFFBBBBBB.toInt());textSize=14f;setPadding(0,dp(12),0,dp(4))})
  val ps=LinearLayout(a);PRESETS.forEach{c->ps.addView(View(a).apply{background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(c);setStroke(dp(2),0x55FFFFFF)};setOnClickListener{setC(c,3)}},LinearLayout.LayoutParams(dp(36),dp(36)).apply{rightMargin=dp(8)})}
  col.addView(HorizontalScrollView(a).apply{isHorizontalScrollBarEnabled=false;addView(ps)})
  setC(cur,3)
  AlertDialog.Builder(a).setTitle("Color de acento").setView(ScrollView(a).apply{addView(col)})
   .setPositiveButton("Aceptar"){_,_->Accent.save(a,cur);done()}.setNeutralButton("Predeterminado"){_,_->Accent.save(a,Accent.DEF);done()}.setNegativeButton("Cancelar",null).show()}
}
