package app.cirilo
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.*
import android.os.Bundle
import android.view.*
import android.widget.*
import kotlin.math.*
class IconView(c:Context,val t:String):View(c){override fun onDraw(cv:Canvas){val r=min(width,height)/2.4f;CtlDraw.draw(cv,t,width/2f,height/2f,if(CtlDraw.pill(t))r*.62f else r,0f,255,0,false)}}
/** Vista del editor: pantalla del juego y controles; seleccionar, arrastrar y redimensionar con el punto de la esquina. */
class EditView(c:Context,val onSel:(Ctl?)->Unit,val onDone:()->Unit):View(c){
 var list:MutableList<Ctl> = ArrayList();var sel:String?=null
 private val p=Paint(Paint.ANTI_ALIAS_FLAG);private var mode=0;private var ox=0f;private var oy=0f;private val dn=resources.displayMetrics.density
 fun cur()=list.firstOrNull{it.id==sel}
 fun put(k:Ctl){val i=list.indexOfFirst{it.id==k.id};if(i>=0)list[i]=k}
 private fun rc(k:Ctl)=Layouts.screenRect(width.toFloat(),height.toFloat(),1.5f,k.x,k.y,k.s)
 private fun ctr(k:Ctl):PointF=if(k.t=="screen"){val r=rc(k);PointF(r.centerX(),r.centerY())}else PointF(k.x*width,k.y*height)
 private fun rad(k:Ctl)=k.s*min(width,height)/2f
 private fun handle(k:Ctl):PointF{val c=ctr(k);return if(k.t=="screen"){val r=rc(k);PointF(r.right,r.bottom)}else PointF(c.x+rad(k)*.92f,c.y+rad(k)*.92f)}
 override fun onDraw(cv:Canvas){cv.drawColor(0xFF101418.toInt())
  for(k in list){if(k.t=="screen"){val r=rc(k);p.style=Paint.Style.FILL;p.color=0xFF0D2A4A.toInt();cv.drawRect(r,p);p.color=0x66FFFFFF;p.textAlign=Paint.Align.CENTER;p.textSize=r.height()*.1f;cv.drawText("Pantalla del juego",r.centerX(),r.centerY(),p)}
   else CtlDraw.draw(cv,k.t,k.x*width,k.y*height,rad(k),k.r,if(k.v)(k.o*255).toInt() else 70,k.st,false)}
  cur()?.let{k->val c=ctr(k);p.style=Paint.Style.STROKE;p.strokeWidth=3*dn;p.color=0xFF80CBC4.toInt();p.pathEffect=DashPathEffect(floatArrayOf(14f,10f),0f)
   if(k.t=="screen")cv.drawRect(rc(k),p) else cv.drawCircle(c.x,c.y,rad(k)*1.3f,p);p.pathEffect=null
   val h=handle(k);p.style=Paint.Style.FILL;cv.drawCircle(h.x,h.y,13*dn,p)}}
 private fun pick(x:Float,y:Float):Ctl?{for(k in list.asReversed())if(k.t!="screen"&&Hit.test(k,x,y,width.toFloat(),height.toFloat()))return k
  return list.firstOrNull{it.t=="screen"&&rc(it).contains(x,y)}}
 override fun onTouchEvent(e:MotionEvent):Boolean{val x=e.x;val y=e.y;val w=width.toFloat();val h=height.toFloat()
  when(e.actionMasked){
   MotionEvent.ACTION_DOWN->{val s=cur();val hd=s?.let{handle(it)}
    if(s!=null&&hd!=null&&hypot(x-hd.x,y-hd.y)<30*dn){mode=1}
    else{mode=0;val k=pick(x,y);sel=k?.id;if(k!=null){val c=ctr(k);ox=x-c.x;oy=y-c.y};onSel(k)};invalidate()}
   MotionEvent.ACTION_MOVE->{val s=cur()?:return true;val c=ctr(s)
    if(mode==1){if(s.t=="screen"){val fw=Layouts.screenRect(w,h,1.5f,.5f,.5f,1f).width();put(s.copy(s=(2*abs(x-c.x)/fw).coerceIn(.2f,2f)))}
     else put(s.copy(s=(2*hypot(x-c.x,y-c.y)/1.3f/min(w,h)).coerceIn(.08f,1.2f)))}
    else if(s.t=="screen")put(s.copy(x=((x-ox)/w).coerceIn(0f,1f),y=((y-oy)/h).coerceIn(0f,1f)))
    else put(s.copy(x=((x-ox)/w).coerceIn(.02f,.98f),y=((y-oy)/h).coerceIn(.02f,.98f)))
    invalidate()}
   MotionEvent.ACTION_UP->{if(cur()!=null){onDone();onSel(cur())}}}
  return true}
}
/** Editor del layout (vertical u horizontal: edita la orientación actual). Menú: Añadir control, Restablecer, Quitar todos, Cerrar. */
class LayoutEditorActivity:Activity(){
 private lateinit var st:Store;private lateinit var lay:Lay;private lateinit var ev:EditView;private lateinit var panel:LinearLayout;private lateinit var orient:Button
 private var land=false;private var dn=1f
 private fun dp(x:Int)=(x*dn).toInt()
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density;st=Layouts.load(this)
  lay=st.list.firstOrNull{it.id==intent.getStringExtra("id")}?:st.cur()
  ev=EditView(this,{k->panelFor(k)},{persist()});val root=FrameLayout(this);root.addView(ev)
  panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(8),dp(12),dp(8));setBackgroundColor(0xE6212121.toInt());visibility=View.GONE}
  root.addView(panel,FrameLayout.LayoutParams(-1,-2,Gravity.TOP).apply{rightMargin=dp(100)})
  root.addView(Button(this).apply{text="MENÚ";setOnClickListener{menu()}},FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.END))
  orient=Button(this).apply{setOnClickListener{requestedOrientation=if(land)ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE}}
  root.addView(orient,FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM or Gravity.END));setContentView(root);load()}
 private fun load(){land=resources.configuration.orientation==Configuration.ORIENTATION_LANDSCAPE;ev.list=(if(land)lay.l else lay.p).toMutableList();ev.sel=null;panelFor(null)
  orient.text=if(land)"Horizontal" else "Vertical";ev.invalidate()}
 private fun persist(){lay=if(land)lay.copy(l=ev.list.toList()) else lay.copy(p=ev.list.toList());val i=st.list.indexOfFirst{it.id==lay.id};if(i>=0)st.list[i]=lay;Layouts.save(this,st)}
 override fun onConfigurationChanged(c:Configuration){persist();super.onConfigurationChanged(c);load()}
 override fun onBackPressed(){menu()}
 private fun menu(){Sheet.show(this,lay.name+" ("+(if(land)"horizontal" else "vertical")+")",listOf("Añadir control","Restablecer","Quitar todos","Cerrar"),null,{i->when(i){
  0->catalog()
  1->Ui.confirm(this,"¿Restablecer esta orientación a la distribución de fábrica? Se pierden los cambios de esta orientación."){ev.list=Layouts.factory(land).toMutableList();ev.sel=null;panelFor(null);persist();ev.invalidate()}
  2->Ui.confirm(this,"¿Quitar todos los controles de esta orientación? (La pantalla del juego se conserva.)"){ev.list=ev.list.filter{it.t=="screen"}.toMutableList();ev.sel=null;panelFor(null);persist();ev.invalidate()}
  else->{}}},{})}
 private fun catalog(){val d=Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setPadding(0,dp(12),0,dp(12));col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  col.addView(TextView(this).apply{text="Añadir control";textSize=20f;setTextColor(-1);setPadding(dp(24),dp(8),dp(24),dp(8))})
  var sec=""
  Layouts.CATALOG.forEach{(s,n,ts)->
   if(s!=sec){sec=s;col.addView(TextView(this).apply{text=s;textSize=13f;setTextColor(0xFF80CBC4.toInt());setPadding(dp(24),dp(10),dp(24),dp(2))})}
   val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(4),dp(16),dp(4))
   ts.forEach{t->r.addView(IconView(this,t),LinearLayout.LayoutParams(dp(56),dp(48)))}
   r.addView(TextView(this).apply{text=n;textSize=17f;setTextColor(-1);setPadding(dp(8),0,0,0)})
   r.setOnClickListener{d.dismiss();addCtl(ts)};col.addView(r)}
  col.addView(TextView(this).apply{text="Cancelar";gravity=Gravity.CENTER;textSize=17f;setTextColor(-1);setPadding(0,dp(14),0,dp(14));setOnClickListener{d.dismiss()}})
  val box=FrameLayout(this);box.setPadding(dp(12),dp(12),dp(12),dp(12));box.addView(ScrollView(this).apply{addView(col)})
  d.setContentView(box);d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout(-1,-2)};d.show()}
 private fun addCtl(ts:List<String>){var last:Ctl?=null
  ts.forEachIndexed{i,t->val k=Ctl("c"+System.nanoTime().toString(36)+i,t,if(ts.size>1)0.4f+0.2f*i else 0.5f,.5f,Layouts.defSize(t),.6f);ev.list.add(k);last=k}
  ev.sel=last?.id;ev.invalidate();panelFor(last);persist()}
 private fun upd(f:(Ctl)->Ctl){val k=ev.cur()?:return;ev.put(f(k));ev.invalidate()}
 private fun sk(l:String,mx:Int,v:Int,f:(Int)->Unit){panel.addView(TextView(this).apply{text=l;textSize=12f;setTextColor(0xFFBBBBBB.toInt())})
  panel.addView(SeekBar(this).apply{max=mx;progress=v.coerceIn(0,mx);setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){if(u)f(p)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){persist()}})})}
 /** Propiedades del elemento seleccionado (la pantalla solo tiene tamaño y posición). */
 private fun panelFor(k:Ctl?){panel.removeAllViews();if(k==null){panel.visibility=View.GONE;return};panel.visibility=View.VISIBLE
  panel.addView(TextView(this).apply{text=Layouts.name(k.t);textSize=15f;setTextColor(0xFF80CBC4.toInt())})
  val scr=k.t=="screen"
  sk("Tamaño",if(scr)180 else 100,if(scr)((k.s-.2f)*100).toInt() else ((k.s-.08f)/.0112f).toInt()){p->upd{if(scr)it.copy(s=.2f+p/100f) else it.copy(s=.08f+p*.0112f)}}
  if(scr)return
  sk("Opacidad",100,((k.o-.1f)/.009f).toInt()){p->upd{it.copy(o=.1f+p*.009f)}}
  sk("Rotación",360,k.r.toInt()){p->upd{it.copy(r=p.toFloat())}}
  val row=LinearLayout(this)
  fun btn(t:String,f:()->Unit){row.addView(Button(this).apply{text=t;textSize=11f;setOnClickListener{f()}},LinearLayout.LayoutParams(0,-2,1f))}
  btn("Visible: "+(if(k.v)"sí" else "no")){upd{it.copy(v=!it.v)};persist();panelFor(ev.cur())}
  btn("Estilo: "+(if(k.st==0)"contorno" else "relleno")){upd{it.copy(st=1-it.st)};persist();panelFor(ev.cur())}
  btn("Eliminar"){ev.list.removeAll{it.id==k.id};ev.sel=null;persist();panelFor(null);ev.invalidate()}
  panel.addView(row)}
}
