package app.cirilo
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.*
import android.os.Bundle
import android.view.*
import android.widget.*
import kotlin.math.*
class IconView(c:Context,val t:String):View(c){override fun onDraw(cv:Canvas){val r=min(width,height)/2.4f;CtlDraw.draw(cv,t,width/2f,height/2f,if(CtlDraw.pill(t))r*.62f else r,0f,255,0,false)}}
/** Vista del editor: pantalla del juego y controles; seleccionar, arrastrar y redimensionar con el punto de la esquina. */
class EditView(c:Context,val onSel:(Ctl?)->Unit,val onDone:()->Unit):View(c){
 var list:MutableList<Ctl> = ArrayList();var sel:String?=null;var sys=LSys.GBA // consola: da la proporción nativa y los píxeles de la pantalla (GBA 240x160 = 3:2, GB/GBC 160x144 = 10:9)
 private val p=Paint(Paint.ANTI_ALIAS_FLAG);private var mode=0;private var ox=0f;private var oy=0f;private val dn=resources.displayMetrics.density
 fun cur()=list.firstOrNull{it.id==sel}
 fun put(k:Ctl){val i=list.indexOfFirst{it.id==k.id};if(i>=0)list[i]=k}
 private fun asp(k:Ctl)=LSys.aspectOf(k,sys)
 fun rc(k:Ctl):RectF{val p=LSys.pix(sys);val b=LSys.screenBox(width.toFloat(),height.toFloat(),asp(k),k.m,k.x,k.y,k.s,p[0],p[1]);return RectF(b[0],b[1],b[2],b[3])}
 /** Proporción (ancho/alto) con la que se ve ahora la pantalla, sea cual sea su modo. */
 fun shown(k:Ctl):Float{val r=rc(k);return r.width()/r.height()}
 /** Pasa la pantalla de «completa» o «escala entera» a modo libre conservando el mismo recuadro, para poder moverla o redimensionarla a mano. */
 fun free(k:Ctl):Ctl{if(k.t!="screen"||k.m==0)return k;val r=rc(k);val w=width.toFloat();val h=height.toFloat();val a=r.width()/r.height();val nat=LSys.aspect(sys);val own=abs(a-nat)>=.005f
  return k.copy(m=0,a=if(own)a else 0f,s=(r.width()/LSys.fitW(w,h,if(own)a else nat)).coerceIn(.2f,2f),x=r.centerX()/w,y=r.centerY()/h)}
 private fun ctr(k:Ctl):PointF=if(k.t=="screen"){val r=rc(k);PointF(r.centerX(),r.centerY())}else PointF(k.x*width,k.y*height)
 private fun rad(k:Ctl)=k.s*min(width,height)/2f
 private fun handle(k:Ctl):PointF{val c=ctr(k);return if(k.t=="screen"){val r=rc(k);PointF(r.right,r.bottom)}else PointF(c.x+rad(k)*.92f,c.y+rad(k)*.92f)}
 override fun onDraw(cv:Canvas){cv.drawColor(0xFF101418.toInt())
  for(k in list){if(k.t=="screen"){val r=rc(k);p.style=Paint.Style.FILL;p.color=0xFF0D2A4A.toInt();cv.drawRect(r,p);p.color=0x66FFFFFF;p.textAlign=Paint.Align.CENTER;p.textSize=r.height()*.1f;cv.drawText("Pantalla del juego",r.centerX(),r.centerY(),p)}
   else CtlDraw.draw(cv,k.t,k.x*width,k.y*height,rad(k),k.r,if(k.v)(k.o*255).toInt() else 70,k.st,false)}
  cur()?.let{k->val c=ctr(k);p.style=Paint.Style.STROKE;p.strokeWidth=3*dn;p.color=Accent.color;p.pathEffect=DashPathEffect(floatArrayOf(14f,10f),0f)
   if(k.t=="screen")cv.drawRect(rc(k),p) else cv.drawCircle(c.x,c.y,rad(k)*1.3f,p);p.pathEffect=null
   val h=handle(k);p.style=Paint.Style.FILL;cv.drawCircle(h.x,h.y,13*dn,p)}}
 private fun pick(x:Float,y:Float):Ctl?{for(k in list.asReversed())if(k.t!="screen"&&Hit.test(k,x,y,width.toFloat(),height.toFloat()))return k
  return list.firstOrNull{it.t=="screen"&&rc(it).contains(x,y)}}
 override fun onTouchEvent(e:MotionEvent):Boolean{val x=e.x;val y=e.y;val w=width.toFloat();val h=height.toFloat()
  when(e.actionMasked){
   MotionEvent.ACTION_DOWN->{val s=cur();val hd=s?.let{handle(it)}
    if(s!=null&&hd!=null&&hypot(x-hd.x,y-hd.y)<30*dn){mode=1}
    else{mode=0;val k=pick(x,y);sel=k?.id;if(k!=null){val c=ctr(k);ox=x-c.x;oy=y-c.y};onSel(k)};invalidate()}
   MotionEvent.ACTION_MOVE->{val s0=cur()?:return true;val s=if(s0.t=="screen"&&(s0.m==1||(s0.m!=0&&mode==1)))free(s0) else s0;val c=ctr(s) // completa o escala entera: al arrastrarla/redimensionarla pasa a libre
    if(mode==1){if(s.t=="screen"){val fw=LSys.fitW(w,h,asp(s));put(s.copy(s=(2*abs(x-c.x)/fw).coerceIn(.2f,2f)))}
     else put(s.copy(s=(2*hypot(x-c.x,y-c.y)/1.3f/min(w,h)).coerceIn(.08f,1.2f)))}
    else if(s.t=="screen")put(s.copy(x=((x-ox)/w).coerceIn(0f,1f),y=((y-oy)/h).coerceIn(0f,1f)))
    else put(s.copy(x=((x-ox)/w).coerceIn(.02f,.98f),y=((y-oy)/h).coerceIn(.02f,.98f)))
    invalidate()}
   MotionEvent.ACTION_UP->{if(cur()!=null){onDone();onSel(cur())}}}
  return true}
}
/** Editor del layout (vertical u horizontal: edita la orientación actual). Menú (tecla/gesto atrás; no hay botones fijos): Añadir control, Restablecer, Quitar todos, Cambiar orientación, Guardar, Salir. El layout siempre conserva al menos un control «Menú». */
class LayoutEditorActivity:Activity(){
 private lateinit var st:Store;private lateinit var lay:Lay;private lateinit var ev:EditView;private lateinit var panel:LinearLayout
 private var land=false;private var dn=1f
 private fun dp(x:Int)=(x*dn).toInt()
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density;st=Layouts.load(this)
  lay=st.list.firstOrNull{it.id==intent.getStringExtra("id")}?:st.cur()
  ev=EditView(this,{k->panelFor(k)},{persist()});val root=FrameLayout(this);root.addView(ev)
  panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(8),dp(12),dp(8));setBackgroundColor(0xE6212121.toInt());visibility=View.GONE}
  root.addView(panel,FrameLayout.LayoutParams(-1,-2,Gravity.TOP));setContentView(root);load()} // sin botones fijos: el menú del editor se abre con atrás
 private fun flip(){requestedOrientation=if(land)ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE}
 private fun load(){land=resources.configuration.orientation==Configuration.ORIENTATION_LANDSCAPE;ev.list=(if(land)lay.l else lay.p).toMutableList();ev.sel=null;ev.sys=lay.sys;panelFor(null);ev.invalidate()}
 /** Pasa los cambios del editor al layout en memoria; no escribe en disco (eso es save()). */
 private fun persist(){val nl=if(land)lay.copy(l=ev.list.toList()) else lay.copy(p=ev.list.toList());if(nl!=lay){lay=nl;dirty=true};val i=st.list.indexOfFirst{it.id==lay.id};if(i>=0)st.list[i]=lay}
 private var dirty=false
 private fun save(){persist();Layouts.save(this,st);dirty=false}
 override fun onConfigurationChanged(c:Configuration){persist();super.onConfigurationChanged(c);load()}
 override fun onBackPressed(){menu()}
 private fun menu(){Sheet.show(this,lay.name+" · "+LSys.name(lay.sys)+" ("+(if(land)"horizontal" else "vertical")+")"+(if(dirty)" · sin guardar" else ""),listOf("Añadir control","Restablecer","Quitar todos","Cambiar a "+(if(land)"vertical" else "horizontal"),"Guardar","Guardar y salir","Salir sin guardar","Seguir editando"),null,{i->when(i){
  0->catalog()
  1->Ui.confirm(this,"¿Restablecer esta orientación a la distribución de fábrica? Se pierden los cambios de esta orientación."){ev.list=Layouts.factory(land,lay.sys).toMutableList();ev.sel=null;panelFor(null);persist();ev.invalidate()}
  2->Ui.confirm(this,"¿Quitar todos los controles de esta orientación? (La pantalla del juego y el control Menú se conservan.)"){ev.list=ev.list.filter{it.t=="screen"||it.t=="menu"}.toMutableList();ev.sel=null;panelFor(null);persist();ev.invalidate()}
  3->flip()
  4->{save();Toast.makeText(this,"Layout guardado",Toast.LENGTH_SHORT).show()}
  5->{save();finish()}
  6->if(dirty)Ui.confirm(this,"¿Salir sin guardar? Se pierden los cambios hechos desde la última vez que guardaste."){finish()} else finish()
  else->{}}},{})}
 private fun catalog(){val d=Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setPadding(0,dp(12),0,dp(12));col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  col.addView(TextView(this).apply{text="Añadir control";textSize=20f;setTextColor(-1);setPadding(dp(24),dp(8),dp(24),dp(8))})
  var sec=""
  Layouts.CATALOG.filter{(_,_,ts)->ts.all{LSys.allowed(lay.sys,it)}}.forEach{(s,n,ts)-> // en GB/GBC no hay L ni R
   if(s!=sec){sec=s;col.addView(TextView(this).apply{text=s;textSize=13f;setTextColor(Accent.color);setPadding(dp(24),dp(10),dp(24),dp(2))})}
   val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(4),dp(16),dp(4))
   ts.forEach{t->r.addView(IconView(this,t),LinearLayout.LayoutParams(dp(56),dp(48)))}
   r.addView(TextView(this).apply{text=n;textSize=17f;setTextColor(-1);setPadding(dp(8),0,0,0)})
   r.setOnClickListener{d.dismiss();addCtl(ts)};col.addView(r)}
  col.addView(TextView(this).apply{text="Cancelar";gravity=Gravity.CENTER;textSize=17f;setTextColor(-1);setPadding(0,dp(14),0,dp(14));setOnClickListener{d.dismiss()}})
  val box=FrameLayout(this);box.setPadding(dp(12),dp(12),dp(12),dp(12));box.addView(ScrollView(this).apply{addView(col)})
  d.setContentView(box);d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout(-1,-2)};d.show()}
 private fun addCtl(ts:List<String>){var last:Ctl?=null
  ts.forEachIndexed{i,t->val k=Ctl("c"+System.nanoTime().toString(36)+i,t,if(ts.size>1)0.4f+0.2f*i else 0.5f,.5f,Layouts.defSize(t),.6f);ev.list.add(k);last=k}
  ev.sel=last?.id;ev.invalidate();panelFor(last);persist()}
 private fun upd(f:(Ctl)->Ctl){val k=ev.cur()?:return;ev.put(f(k));ev.invalidate()}
 /** Deslizador con rótulo; lab (opcional) da el rótulo en vivo en función del valor. into = contenedor (por defecto el panel). */
 private fun sk(l:String,mx:Int,v:Int,f:(Int)->Unit,lab:((Int)->String)?=null,into:LinearLayout=panel){val tv=TextView(this).apply{text=lab?.invoke(v.coerceIn(0,mx))?:l;textSize=12f;setTextColor(0xFFBBBBBB.toInt())};into.addView(tv)
  into.addView(SeekBar(this).apply{max=mx;progress=v.coerceIn(0,mx);setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){if(u){f(p);lab?.let{tv.text=it(p)}}};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){persist()}})})}
 private fun asplab(a:Float,nat:Float)=String.format("Proporción de aspecto: %.2f:1",a)+(if(kotlin.math.abs(a-nat)<.01f)" (nativa)" else "")
 /** Opciones de la pantalla del juego: modos (completa, escala entera), centrar, reiniciar posición/proporción, tamaño y proporción de aspecto propia. */
 private fun screenPanel(k:Ctl){val nat=LSys.aspect(lay.sys);val shown=ev.shown(k)
  fun row():LinearLayout=LinearLayout(this)
  fun btn(r:LinearLayout,t:String,f:()->Unit){r.addView(Button(this).apply{text=t;textSize=11f;isAllCaps=false;setOnClickListener{f()}},LinearLayout.LayoutParams(0,-2,1f))}
  fun go(f:(Ctl)->Ctl){upd(f);persist();panelFor(ev.cur())}
  val defPos=Layouts.factory(land,lay.sys).firstOrNull{it.t=="screen"}
  val r1=row();val r2=if(land)r1 else row()
  btn(r1,"Pantalla completa"+(if(k.m==1)" ✓" else "")){go{it.copy(m=1)}}
  btn(r1,"Mejor escala (2x)"+(if(k.m==2)" ✓" else "")){go{it.copy(m=2,a=0f)}}
  btn(r1,"Centrar"){go{it.copy(x=.5f,y=.5f)}}
  btn(r2,"Reiniciar posición"){go{it.copy(x=defPos?.x?:.5f,y=defPos?.y?:-1f,m=if(it.m==1)0 else it.m)}}
  btn(r2,"Reiniciar proporción"){go{it.copy(a=0f,m=if(it.m==1)0 else it.m)}}
  panel.addView(r1);if(!land)panel.addView(r2)
  val cols=if(land)LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL} else panel
  val c1=if(land)LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,0,dp(8),0)} else panel;val c2=if(land)LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),0,0,0)} else panel
  if(land){cols.addView(c1,LinearLayout.LayoutParams(0,-2,1f));cols.addView(c2,LinearLayout.LayoutParams(0,-2,1f));panel.addView(cols)}
  sk("Tamaño",180,((k.s-.2f)*100).toInt(),{p->upd{ev.free(it).copy(s=.2f+p/100f)}},null,c1)
  // proporción: de 0,50 a 3,00; cerca de la nativa se ajusta a ella (a = 0)
  sk("",250,((shown-.5f)*100).toInt(),{p->upd{val a=.5f+p/100f;ev.free(it).copy(a=if(kotlin.math.abs(a-nat)<.02f)0f else a)}},{p->asplab(.5f+p/100f,nat)},c2)}
 /** Propiedades del elemento seleccionado (la pantalla solo tiene tamaño y posición). */
 private fun panelFor(k:Ctl?){panel.removeAllViews();if(k==null){panel.visibility=View.GONE;return};panel.visibility=View.VISIBLE
  panel.layoutParams=FrameLayout.LayoutParams(-1,-2,if(k.y<.5f)Gravity.BOTTOM else Gravity.TOP)
  panel.addView(TextView(this).apply{text=Layouts.name(k.t);textSize=15f;setTextColor(Accent.color)})
  if(k.t=="screen"){screenPanel(k);return}
  sk("Tamaño",100,((k.s-.08f)/.0112f).toInt(),{p->upd{it.copy(s=.08f+p*.0112f)}})
  sk("Opacidad",100,((k.o-.1f)/.009f).toInt(),{p->upd{it.copy(o=.1f+p*.009f)}})
  sk("Rotación",360,k.r.toInt(),{p->upd{it.copy(r=p.toFloat())}})
  val row=LinearLayout(this)
  fun btn(t:String,f:()->Unit){row.addView(Button(this).apply{text=t;textSize=11f;setOnClickListener{f()}},LinearLayout.LayoutParams(0,-2,1f))}
  btn("Visible: "+(if(k.v)"sí" else "no")){upd{it.copy(v=!it.v)};persist();panelFor(ev.cur())}
  btn("Estilo: "+(if(k.st==0)"contorno" else "relleno")){upd{it.copy(st=1-it.st)};persist();panelFor(ev.cur())}
  btn("Eliminar"){if(k.t=="menu"&&ev.list.count{it.t=="menu"}<=1){Toast.makeText(this,"Debe quedar un control Menú: es la forma de abrir el menú del juego",Toast.LENGTH_LONG).show()}
   else{ev.list.removeAll{it.id==k.id};ev.sel=null;persist();panelFor(null);ev.invalidate()}}
  panel.addView(row)}
}
