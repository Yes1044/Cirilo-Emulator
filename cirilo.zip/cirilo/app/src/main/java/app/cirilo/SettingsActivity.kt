package app.cirilo
import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.widget.*
/** Ajustes: Video, Audio, Layouts, Misceláneo y Avanzado. Se guardan en las preferencias «c» y el juego los aplica al volver. */
class SettingsActivity:Activity(){
 private lateinit var p:SharedPreferences;private lateinit var body:LinearLayout;private lateinit var title:TextView;private var page=0;private var dn=1f
 private fun dp(x:Int)=(x*dn).toInt()
 override fun onCreate(b:Bundle?){
  super.onCreate(b);p=getSharedPreferences("c",0);dn=resources.displayMetrics.density
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF303030.toInt())
  title=TextView(this).apply{setTextColor(-1);textSize=22f;setPadding(dp(16),dp(16),dp(16),dp(16));setBackgroundColor(0xFF212121.toInt())}
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL
  col.addView(title);col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));setContentView(col);show(0)}
 override fun onBackPressed(){if(page==4)show(3) else if(page!=0)show(0) else finish()}
 private fun show(pg:Int){page=pg;body.removeAllViews();title.text=when(pg){1->"Video";2->"Audio";3->"Misceláneo";4->"Sincronización";5->"Avanzado";else->"Ajustes"}
  when(pg){
   0->{row("Video",null,R.drawable.ic_video,click={show(1)});row("Audio",null,R.drawable.ic_audio,click={show(2)});row("Layouts",null,R.drawable.ic_layouts,click={startActivity(Intent(this,LayoutsActivity::class.java))});row("Misceláneo",null,R.drawable.ic_misc,click={show(3)});row("Avanzado",null,R.drawable.ic_advanced,click={show(5)})}
   1->{sw("Ajustar a pantalla","Estirar siempre a pantalla completa en horizontal","stretch",false)
    pick("Tamaño de pantalla","size",listOf("100%","90%","80%","70%","60%","50%"),listOf(100,90,80,70,60,50),100)
    pick("Orientación de pantalla","orient",listOf("Automática","Vertical","Horizontal"),listOf(0,1,2),0)
    seek("Saltos de fotogramas máximos","Número máximo de saltos consecutivos","skip",5,2)
    sw("Salto de fotogramas dinámico","En avance rápido, el máximo de saltos sube con la velocidad (solo se omite el dibujo; el audio no cambia)","dynskip",true)
    sw("Filtro lineal",null,"linear",false);shader();sw("Mostrar FPS",null,"fps",false)}
   3->{gdRow()
    sw("Activar trucos",null,"cheats",true)
    cb("Parches de ROM","Aplica al vuelo el .ips/.ups/.bps/.xdelta con el mismo nombre que la ROM (misma carpeta, o elegido con «Añadir juego»); la ROM no se modifica","patch",true)
    sw("Guardado y carga automáticos","Guarda la partida al salir y la carga de nuevo al iniciar","auto",false)
    pick("Velocidad de avance rápido","ffs",listOf("16x","8x","4x","3x","2x","1.5x","0.5x","0.2x"),listOf(160,80,40,30,20,15,5,2),40,null,true)
    pick("Botón de avance rápido","ffm",listOf("Pulsar para alternar","Mantener pulsado para activar"),listOf(0,1),0,"Elige cómo se activa el avance rápido",true)
    sw("Confirmar al cerrar/reiniciar",null,"confirm",false)
    sw("Modo pantalla completa","Los juegos ocupan toda la pantalla ocultando las barras del sistema","full",true)
    sw("Modo inmersivo","Pantalla completa real al ocultar la barra de navegación","imm",true)
    if(pgoFiles().isNotEmpty())row("Exportar perfil PGO","Solo build «perfil»: guarda en un .zip lo que el núcleo ha usado al jugar",click={pgoExport()})}
   5->{note("Los cambios de esta página se aplican la próxima vez que abras un juego.")
    sw("Usar BIOS","Ejecuta el BIOS real si hay un archivo seleccionado; si no, se emula por software","bios_use",true)
    sw("Arrancar con el BIOS","Muestra la pantalla del BIOS al iniciar el juego (necesita el archivo BIOS)","bios_boot",true)
    for((k,n,_) in Adv.BIOS)row("Archivo BIOS de "+n,Adv.name(this,k)?:"Sin seleccionar (toca para elegir; mantén pulsado para quitar)",click={pickBios(k)},hold={if(Adv.name(this,k)!=null)confirmBios(k,n)})
        pick("Tipo de guardado del cartucho GBA","savetype",Adv.SAVE_LABELS,listOf(0,1,2,3,4,5),0,"",true)
    pick("Tipo de guardado del cartucho GBC","savetype_gbc",Adv.RAM_LABELS,listOf(0,1,2,3,4,5),0,"",true)
    pick("Tipo de guardado del cartucho GB","savetype_gb",Adv.RAM_LABELS,listOf(0,1,2,3,4,5),0,"",true)
    sw("Hack de velocidad","Detecta y omite los bucles de espera de los juegos","speedhack",true)
    sw("Efecto mosaico","Emula el efecto mosaico de la GBA","mosaic",true)
    if(Adv.jitAvailable()){sw("Usar JIT experimental","Solo GBA, solo 64 bits. En desarrollo: todavía no acelera y puede ir más lento que el intérprete. Con el panel de FPS activo se ve el porcentaje nativo. Si un juego falla, desactívalo","jit",false)
    pick("JIT: modo de diagnóstico","jitdiag",listOf("Normal","A: solo despachador, sin código nativo","B: nativo sin cargas ni guardados"),listOf(0,2,3),0,"",true)}
    else row("JIT experimental","No disponible: solo funciona en dispositivos de 64 bits (arm64)")
    sw("Registrar rendimiento por fotograma","Guarda en memoria, de cada fotograma, su tiempo, las instrucciones originales y las nativas del JIT (los últimos ~32 000 fotogramas). Aplica al abrir un juego; luego exporta el CSV aquí abajo. Sirve con el JIT apagado para comparar la estabilidad","plog",false)
    row("Exportar registro de rendimiento","Guarda el CSV: resumen de tirones y una fila por fotograma. Primero juega con el registro activado",click={plogExport()})
    sw("Quitar marcos de Super Game Boy","Oculta el marco en los juegos compatibles con SGB (conservan sus colores)","sgb_noborder",true)
    divider();header("Restablecer")
    row("Restablecer ajustes avanzados",null,click={AlertDialog.Builder(this).setMessage("¿Restablecer los ajustes avanzados? También se quitarán los archivos BIOS seleccionados.").setPositiveButton("Aceptar"){_,_->Adv.reset(this);show(5)}.setNegativeButton("Cancelar",null).show()})}
   4->{sw("Sincronizar al iniciar el juego","Descargar los cambios antes de que empiece el juego","gd_start",false)
    sw("Sincronizar al cambiar","Subir los archivos en cuanto cambien","gd_change",false)
    sw("Sincronizar trucos","Subir y bajar los trucos de cada juego junto con los guardados","gd_cheats",true)}
   else->{sw("Activar sonido",null,"snd",true);seek("Volumen del sonido",null,"vol",100,100)
    pick("Frecuencia del sonido","freq",listOf("22050 Hz","32000 Hz","44100 Hz","48000 Hz"),listOf(22050,32000,44100,48000),48000)}}}

 private fun note(t:String){body.addView(TextView(this).apply{text=t;textSize=13f;setTextColor(0xFFBBBBBB.toInt());setPadding(dp(16),dp(10),dp(16),dp(4))})}
 private fun divider(){body.addView(View(this).apply{setBackgroundColor(0xFF444444.toInt())},LinearLayout.LayoutParams(-1,2).apply{topMargin=dp(8)})}
 private fun header(t:String){body.addView(TextView(this).apply{text=t;textSize=15f;setTextColor(Accent.color);setPadding(dp(16),dp(14),dp(16),dp(6))})}
 /** Abre el gestor de archivos (SAF) para elegir el BIOS de la consola k. Códigos 80, 81 y 82. */
 private fun pickBios(k:String){try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),80+Adv.BIOS.indexOfFirst{it.first==k})}catch(e:Exception){Toast.makeText(this,"No se pudo abrir el selector de archivos",Toast.LENGTH_LONG).show()}}
 private fun confirmBios(k:String,n:String){AlertDialog.Builder(this).setMessage("¿Quitar el archivo BIOS de "+n+"?").setPositiveButton("Quitar"){_,_->Adv.remove(this,k);show(5)}.setNegativeButton("Cancelar",null).show()}
 private fun biosPicked(k:String,u:android.net.Uri?){if(u==null)return
  Thread{val e=Adv.import(this,k,u);runOnUiThread{if(e==null){Toast.makeText(this,"BIOS guardado",Toast.LENGTH_SHORT).show();if(page==5)show(5)} else Toast.makeText(this,e,Toast.LENGTH_LONG).show()}}.start()}
 private var plogText=""
 private fun plogExport(){val t=Native.plogDump()
  if(t.isEmpty()){Toast.makeText(this,"Aún no hay registro: activa «Registrar rendimiento», abre un juego y juega un rato",Toast.LENGTH_LONG).show();return}
  plogText=t;try{startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/csv").putExtra(Intent.EXTRA_TITLE,"cirilo-rendimiento.csv"),79)}catch(e:Exception){Toast.makeText(this,"No se pudo abrir el selector: "+e.message,Toast.LENGTH_LONG).show()}}
 private fun plogSave(u:android.net.Uri?){if(u==null)return
  try{contentResolver.openOutputStream(u)?.use{it.write(plogText.toByteArray())};Toast.makeText(this,"Registro guardado",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,"No se pudo guardar: "+e.message,Toast.LENGTH_LONG).show()};plogText=""}
 private fun pgoFiles():List<java.io.File> = java.io.File(filesDir,"pgo").listFiles{f->f.name.endsWith(".profraw")}?.toList()?:emptyList()
 private fun pgoExport(){Native.pgoDump(0);Native.pgoDump(1)
  if(pgoFiles().isEmpty()){Toast.makeText(this,"Aún no hay perfil: juega y sal del juego con «atrás»",Toast.LENGTH_LONG).show();return}
  try{startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/zip").putExtra(Intent.EXTRA_TITLE,"cirilo-pgo.zip"),78)}catch(e:Exception){Toast.makeText(this,"No se pudo abrir el selector de archivos",Toast.LENGTH_LONG).show()}}
 private fun pgoSave(u:android.net.Uri?){if(u==null)return
  try{contentResolver.openOutputStream(u)?.use{o->java.util.zip.ZipOutputStream(o).use{z->for(f in pgoFiles()){z.putNextEntry(java.util.zip.ZipEntry(f.name));f.inputStream().use{it.copyTo(z)};z.closeEntry()}}}
   Toast.makeText(this,"Perfil guardado. Súbelo al repositorio como cirilo-pgo.zip",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,"No se pudo guardar el perfil: "+e.message,Toast.LENGTH_LONG).show()}}
 private fun row(t:String,s:String?,ic:Int=0,trail:View?=null,mid:View?=null,click:(()->Unit)?=null,hold:(()->Unit)?=null){
  val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(14),dp(16),dp(14))
  if(ic!=0)r.addView(ImageView(this).apply{setImageResource(ic)},LinearLayout.LayoutParams(dp(28),dp(28)).apply{rightMargin=dp(24)})
  val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL
  c.addView(TextView(this).apply{text=t;textSize=18f;setTextColor(-1)})
  if(s!=null)c.addView(TextView(this).apply{text=s;textSize=14f;setTextColor(0xFFBBBBBB.toInt())})
  mid?.let{c.addView(it)};r.addView(c,LinearLayout.LayoutParams(0,-2,1f));trail?.let{r.addView(it)}
  if(click!=null)r.setOnClickListener{click()};if(hold!=null)r.setOnLongClickListener{hold();true};body.addView(r)}
 private fun sw(t:String,s:String?,k:String,d:Boolean){val w=Switch(this).apply{isChecked=p.getBoolean(k,d);setOnCheckedChangeListener{_,v->p.edit().putBoolean(k,v).apply()}};row(t,s,trail=w,click={w.toggle()})}
 /** sub: "" = muestra la opción actual; null = sin subtítulo; otro texto = subtítulo fijo. cancel = añade el botón «Cancelar». */
 private fun pick(t:String,k:String,l:List<String>,v:List<Int>,d:Int,sub:String?="",cancel:Boolean=false){val cur=v.indexOf(p.getInt(k,d)).coerceAtLeast(0)
  row(t,if(sub=="")l[cur] else sub,click={val b=AlertDialog.Builder(this).setTitle(t).setSingleChoiceItems(l.toTypedArray(),cur){dl,i->p.edit().putInt(k,v[i]).apply();dl.dismiss();show(page)}
   if(cancel)b.setNegativeButton("Cancelar",null);b.show()})}
 /** Google Drive: desactivado (y atenuado) si el teléfono no tiene Google Play Services. */
 private fun gdRow(){val ok=DriveSync.available(this)
  val sub=if(!ok)"Requiere Google Play Services" else if(!p.getBoolean("gd",false))"Sin cuenta seleccionada" else if(p.getBoolean("gd_auth",false))"Hay que volver a dar permiso: apaga y enciende" else p.getString("gd_acct","")!!.ifEmpty{"Cuenta de Google conectada"}
  val w=Switch(this).apply{isEnabled=ok;isChecked=ok&&p.getBoolean("gd",false)}
  w.setOnCheckedChangeListener{_,v->if(v)gdConnect() else{p.edit().putBoolean("gd",false).putString("gd_acct","").putBoolean("gd_auth",false).apply();DriveSync.cancel(this);show(page)}}
  row("Sincronizar con Google Drive",sub,trail=w,click=if(ok)({w.toggle()}) else null)
  row("Ajustes de sincronización",null,click=if(ok)({show(4)}) else null)
  if(!ok)for(i in 0 until body.childCount)body.getChildAt(i).alpha=.4f}
 private fun gdFail(){Toast.makeText(this,"No se pudo conectar con Google Drive"+(if(DriveSync.lastErr.isNotEmpty())" ("+DriveSync.lastErr+")" else ""),Toast.LENGTH_LONG).show();p.edit().putBoolean("gd",false).apply();show(page)}
 private fun gdDone(email:String){p.edit().putBoolean("gd",true).putString("gd_acct",email).putBoolean("gd_auth",false).apply();show(page)
  Toast.makeText(this,"Sincronizando con Google Drive…",Toast.LENGTH_SHORT).show();DriveSync.async(this)}
 private fun gdConnect(){DriveSync.lastErr="";DriveSync.authorize(this,{i->try{startIntentSenderForResult(i,77,null,0,0,0)}catch(e:Exception){gdFail()}},{e->gdDone(e)},{gdFail()})}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){super.onActivityResult(rq,rs,d);if(rq==78){pgoSave(if(rs==RESULT_OK)d?.data else null);return};if(rq==79){plogSave(if(rs==RESULT_OK)d?.data else null);return};if(rq in 80..82){if(rs==RESULT_OK)biosPicked(Adv.BIOS[rq-80].first,d?.data);return};if(rq!=77)return
  DriveSync.lastErr=if(rs==RESULT_OK)"" else "cancelado o rechazado (resultado "+rs+")"
  val e=if(rs==RESULT_OK)DriveSync.fromIntent(this,d) else null;if(e!=null)gdDone(e) else gdFail()}
 private fun cb(t:String,s:String?,k:String,d:Boolean){val w=CheckBox(this).apply{isChecked=p.getBoolean(k,d);setOnCheckedChangeListener{_,v->p.edit().putBoolean(k,v).apply()}};row(t,s,trail=w,click={w.toggle()})}
 private fun seek(t:String,s:String?,k:String,mx:Int,d:Int,mn:Int=0){val v=TextView(this).apply{textSize=18f;setTextColor(-1);text=p.getInt(k,d).toString()}
  val sb=SeekBar(this).apply{max=mx-mn;progress=p.getInt(k,d)-mn;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onProgressChanged(x:SeekBar?,pr:Int,u:Boolean){v.text=(pr+mn).toString();p.edit().putInt(k,pr+mn).apply()}
   override fun onStartTrackingTouch(x:SeekBar?){};override fun onStopTrackingTouch(x:SeekBar?){}})}
  row(t,s,trail=v,mid=sb)}
 private fun shader(){val l=Shaders.list(this);val cur=p.getString("shader","")?:"";val ci=l.indexOfFirst{it.name==cur}.coerceAtLeast(0)
  row("Shader GLSL","Aplica efectos de video a tus juegos"+(if(ci>0)": "+l[ci].name else ""),click={
   val n=l.map{it.name}.toMutableList();if(!Shaders.installed(this))n+="(Instala «Emulator Shaders» para tener más)"
   AlertDialog.Builder(this).setTitle("Shader GLSL").setSingleChoiceItems(n.toTypedArray(),ci){dl,i->if(i<l.size)p.edit().putString("shader",if(i==0)"" else l[i].name).apply();dl.dismiss();show(page)}.show()})}
}
