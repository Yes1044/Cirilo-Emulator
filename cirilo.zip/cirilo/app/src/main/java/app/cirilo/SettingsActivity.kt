package app.cirilo
import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.*
import android.widget.*
/** Ajustes: Video y Audio. Se guardan en las preferencias «c» y el juego los aplica al volver. */
class SettingsActivity:Activity(){
 private lateinit var p:SharedPreferences;private lateinit var body:LinearLayout;private lateinit var title:TextView;private var page=0;private var dn=1f
 private fun dp(x:Int)=(x*dn).toInt()
 override fun onCreate(b:Bundle?){
  super.onCreate(b);p=getSharedPreferences("c",0);dn=resources.displayMetrics.density
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF303030.toInt())
  title=TextView(this).apply{setTextColor(-1);textSize=22f;setPadding(dp(16),dp(16),dp(16),dp(16));setBackgroundColor(0xFF212121.toInt())}
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL
  col.addView(title);col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));setContentView(col);show(0)}
 override fun onBackPressed(){if(page!=0)show(0) else finish()}
 private fun show(pg:Int){page=pg;body.removeAllViews();title.text=when(pg){1->"Video";2->"Audio";else->"Ajustes"}
  when(pg){
   0->{row("Video",null,R.drawable.ic_video,click={show(1)});row("Audio",null,R.drawable.ic_audio,click={show(2)});row("Layouts",null,R.drawable.ic_layouts,click={startActivity(Intent(this,LayoutsActivity::class.java))})}
   1->{sw("Ajustar a pantalla","Estirar siempre a pantalla completa en horizontal","stretch",false)
    pick("Tamaño de pantalla","size",listOf("100%","90%","80%","70%","60%","50%"),listOf(100,90,80,70,60,50),100)
    pick("Orientación de pantalla","orient",listOf("Automática","Vertical","Horizontal"),listOf(0,1,2),0)
    seek("Saltos de fotogramas máximos","Número máximo de saltos consecutivos","skip",5,2)
    sw("Filtro lineal",null,"linear",false);shader();sw("Mostrar FPS",null,"fps",false)}
   else->{sw("Activar sonido",null,"snd",true);seek("Volumen del sonido",null,"vol",100,100)
    pick("Frecuencia del sonido","freq",listOf("22050 Hz","32000 Hz","44100 Hz","48000 Hz"),listOf(22050,32000,44100,48000),48000)}}}
 private fun row(t:String,s:String?,ic:Int=0,trail:View?=null,mid:View?=null,click:(()->Unit)?=null){
  val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(14),dp(16),dp(14))
  if(ic!=0)r.addView(ImageView(this).apply{setImageResource(ic)},LinearLayout.LayoutParams(dp(28),dp(28)).apply{rightMargin=dp(24)})
  val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL
  c.addView(TextView(this).apply{text=t;textSize=18f;setTextColor(-1)})
  if(s!=null)c.addView(TextView(this).apply{text=s;textSize=14f;setTextColor(0xFFBBBBBB.toInt())})
  mid?.let{c.addView(it)};r.addView(c,LinearLayout.LayoutParams(0,-2,1f));trail?.let{r.addView(it)}
  if(click!=null)r.setOnClickListener{click()};body.addView(r)}
 private fun sw(t:String,s:String?,k:String,d:Boolean){val w=Switch(this).apply{isChecked=p.getBoolean(k,d);setOnCheckedChangeListener{_,v->p.edit().putBoolean(k,v).apply()}};row(t,s,trail=w,click={w.toggle()})}
 private fun pick(t:String,k:String,l:List<String>,v:List<Int>,d:Int){val cur=v.indexOf(p.getInt(k,d)).coerceAtLeast(0)
  row(t,l[cur],click={AlertDialog.Builder(this).setTitle(t).setSingleChoiceItems(l.toTypedArray(),cur){dl,i->p.edit().putInt(k,v[i]).apply();dl.dismiss();show(page)}.show()})}
 private fun seek(t:String,s:String?,k:String,mx:Int,d:Int){val v=TextView(this).apply{textSize=18f;setTextColor(-1);text=p.getInt(k,d).toString()}
  val sb=SeekBar(this).apply{max=mx;progress=p.getInt(k,d);setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onProgressChanged(x:SeekBar?,pr:Int,u:Boolean){v.text=pr.toString();p.edit().putInt(k,pr).apply()}
   override fun onStartTrackingTouch(x:SeekBar?){};override fun onStopTrackingTouch(x:SeekBar?){}})}
  row(t,s,trail=v,mid=sb)}
 private fun shader(){val l=Shaders.list(this);val cur=p.getString("shader","")?:"";val ci=l.indexOfFirst{it.name==cur}.coerceAtLeast(0)
  row("Shader GLSL","Aplica efectos de video a tus juegos"+(if(ci>0)": "+l[ci].name else ""),click={
   val n=l.map{it.name}.toMutableList();if(!Shaders.installed(this))n+="(Instala «Emulator Shaders» para tener más)"
   AlertDialog.Builder(this).setTitle("Shader GLSL").setSingleChoiceItems(n.toTypedArray(),ci){dl,i->if(i<l.size)p.edit().putString("shader",if(i==0)"" else l[i].name).apply();dl.dismiss();show(page)}.show()})}
}
