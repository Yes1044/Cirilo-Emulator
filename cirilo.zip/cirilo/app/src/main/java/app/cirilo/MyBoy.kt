package app.cirilo
import android.content.Context
import android.util.Log
import com.fastemulator.gba.Console
import com.fastemulator.gba.Link
import java.io.File
import java.nio.Buffer
import java.nio.ByteBuffer
import java.nio.ByteOrder
/** Backend que maneja libgba.so (el núcleo de My Boy!) con la misma interfaz que Native usa para los núcleos libretro. Solo GBA y solo la consola 0 (sin Link local).
 *  Varias cosas del núcleo no están documentadas y están ADIVINADAS: las que importan van como variables de abajo para poder cambiarlas sin tocar la lógica. Todo se escribe en logcat con la etiqueta «MyBoy». */
object MyBoy{
 private const val T="MyBoy"
 private const val W=240;private const val H=160
 /** Bytes por píxel del búfer de pantalla del núcleo: 2 = RGB565, 4 = RGBA8888 (se convierte a 565). */
 @JvmField var bpp=2
 /** Valor de runFrame() cuando SÍ hay que dibujar el fotograma (si la imagen sale congelada o va a saltos, prueba false). */
 @JvmField var drawFlag=true
 /** false = siempre se dibuja (más seguro). true = respeta el salto de fotogramas de Emu. */
 @JvmField var honorSkip=false
 /** true si getAudioSamples devuelve pares estéreo en vez de muestras sueltas. */
 @JvmField var audioRetIsFrames=false
 /** true si loadStateFromMemory devuelve 0 cuando todo va bien. */
 @JvmField var loadOkIfZero=true
 /** Valor de reset(): true = reinicio completo. */
 @JvmField var hardReset=true
 @JvmField var err=""
 // bits de cirilo (ids RETRO_DEVICE_ID_JOYPAD) -> bits de setKeys. Se supone el orden del registro KEYINPUT de la GBA: A0 B1 Select2 Start3 Der4 Izq5 Arr6 Abj7 R8 L9
 private val SRC=intArrayOf(8,0,2,3,7,6,4,5,11,10);private val DST=intArrayOf(0,1,2,3,4,5,6,7,8,9)
 private var ctx:Context?=null
 private var rom:ByteBuffer?=null;private var rid:String?=null;private var con:Console?=null;private var scr:ByteBuffer?=null
 private var sav:File?=null;private var sk=0;private var n=0L;private var snd=false;private var logA=0;private var ran=false
 fun init(c:Context){ctx=c.applicationContext}
 private fun sp()=ctx?.getSharedPreferences("c",0)
 fun isGba(r:ByteArray)=r.size>0xC0&&r[0xB2]==0x96.toByte() // byte fijo 0x96 en la cabecera de toda ROM de GBA
 private val lib:Boolean by lazy{try{Link.get();Console.setGameSaveListener(null);true}catch(t:Throwable){err="No carga libgba.so: "+t;Log.e(T,err,t);false}}
 /** Puede usarse: el usuario no lo desactivó, el intento anterior no cerró la app de golpe y la biblioteca carga. */
 fun usable():Boolean{val p=sp()?:return false
  if(!p.getBoolean("core_myboy",true))return false
  if(p.getBoolean("mb_pending",false)){p.edit().putBoolean("core_myboy",false).putBoolean("mb_pending",false).commit();err="El núcleo de My Boy cerró la app la última vez: se desactivó (preferencia core_myboy)";Log.e(T,err);return false}
  return lib}
 fun load(r:ByteArray,name:String):Boolean{unload()
  val p=sp();p?.edit()?.putBoolean("mb_pending",true)?.commit() // si lo nativo mata el proceso, la próxima vez no se vuelve a intentar
  try{val l=Link.get()
   val bb=Link.allocateBuffer(r.size);if(bb==null){err="allocateBuffer devolvió null";return fail()}
   bb.clear();bb.put(r);bb.rewind();rom=bb
   val id=l.loadRom(bb,r.size);if(id.isNullOrEmpty()){err="loadRom falló (ROM no válida para este núcleo)";return fail()}
   rid=id;val c=l.open(id,0);if(c==null){err="nativeOpenConsole devolvió 0";return fail()}
   con=c;val sb=ByteBuffer.allocateDirect(W*H*4).order(ByteOrder.nativeOrder());scr=sb;c.setScreenBuffer(sb)
   snd=false;n=0;ran=false;sk=0
   val d=File(ctx!!.filesDir,"myboy");d.mkdirs();val f=File(d,name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"),"_")+".sav");sav=f
   Log.i(T,"ROM cargada id=$id")
   return true
  }catch(t:Throwable){err="Error cargando: "+t;Log.e(T,err,t);return fail()}}
 private fun fail():Boolean{unload();sp()?.edit()?.putBoolean("mb_pending",false)?.commit();return false}
 fun unload(){val l=try{Link.get()}catch(t:Throwable){return}
  try{con?.let{try{it.saveBattery()}catch(t:Throwable){};l.close(it)}}catch(t:Throwable){Log.e(T,"close",t)}
  try{rid?.let{l.unloadRom(it)}}catch(t:Throwable){Log.e(T,"unloadRom",t)}
  try{rom?.let{Link.deallocateBuffer(it)}}catch(t:Throwable){Log.e(T,"dealloc",t)}
  con=null;rid=null;rom=null;scr=null}
 fun run(){val l=Link.get();n++
  val draw=!honorSkip||sk==0||n%(sk+1)==0L
  l.runFrame(if(drawFlag)draw else !draw)
  if(!ran){ran=true;sp()?.edit()?.putBoolean("mb_pending",false)?.apply();Log.i(T,"primer fotograma ejecutado")}}
 fun info()=doubleArrayOf(32768.0,59.7275)
 fun setSkip(k:Int){sk=k}
 fun keys(k:Int){val c=con?:return;var m=0;for(j in SRC.indices)if((k shr SRC[j]) and 1!=0)m=m or (1 shl DST[j]);c.setKeys(m)}
 fun reset(){con?.reset(hardReset)}
 /** Copia el fotograma como RGB565 a b. Devuelve (ancho<<16)|alto, o 0. */
 fun frame(b:ByteBuffer):Int{val s=scr?:return 0;val sz=W*H*2;if(b.capacity()<sz)return 0
  val bo=b.order();b.clear()
  if(bpp==2){val d=s.duplicate();(d as Buffer).clear();d.limit(sz);b.put(d)}
  else{val o=b.asShortBuffer();for(i in 0 until W*H){val q=i*4;val r=s.get(q).toInt() and 255;val g=s.get(q+1).toInt() and 255;val bl=s.get(q+2).toInt() and 255
    o.put(i,(((r shr 3) shl 11) or ((g shr 2) shl 5) or (bl shr 3)).toShort())}}
  b.order(bo);b.rewind();return (W shl 16) or H}
 fun audio(a:ShortArray):Int{val c=con?:return 0
  if(!snd){c.enableSound(true);snd=true}
  val r=c.getAudioSamples(a,a.size/2)
  if(logA<5){logA++;Log.i(T,"getAudioSamples -> $r (cabe ${a.size})")}
  return if(r<=0)0 else if(audioRetIsFrames)minOf(r*2,a.size) else r}
 fun saveState():ByteArray?=try{con?.saveStateToMemory()}catch(t:Throwable){Log.e(T,"saveState",t);null}
 fun loadState(b:ByteArray):Boolean=try{val r=con?.loadStateFromMemory(b)?:return false;Log.i(T,"loadStateFromMemory -> $r");if(loadOkIfZero)r==0 else r>0}catch(t:Throwable){Log.e(T,"loadState",t);false}
 /** Guardado de batería: el núcleo trabaja con rutas, no con bytes, así que se pasa por un archivo propio. */
 fun setSave(b:ByteArray){val f=sav?:return;val c=con?:return;try{f.writeBytes(b);c.loadBattery(f.absolutePath)}catch(t:Throwable){Log.e(T,"setSave",t)}}
 fun getSave():ByteArray?{val f=sav?:return null;val c=con?:return null;return try{c.saveBattery();if(f.exists()&&f.length()>0)f.readBytes() else null}catch(t:Throwable){Log.e(T,"getSave",t);null}}
}
