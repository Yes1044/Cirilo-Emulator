package app.cirilo
import android.content.Context
const val DV="attribute vec2 aPosition;attribute vec2 aTexCoord;varying vec2 vTexCoord;void main(){gl_Position=vec4(aPosition,0.0,1.0);vTexCoord=aTexCoord;}"
const val DF="precision mediump float;uniform sampler2D rubyTexture;varying vec2 vTexCoord;void main(){gl_FragColor=texture2D(rubyTexture,vTexCoord);}"
data class Shader(val name:String,val vs:String,val fs:String,val linear:Boolean=true)
/** Usa los shaders de la app «Emulator Shaders» (com.fastemulator.shaderpack) si está instalada: son archivos .shader en sus assets. */
object Shaders{
 const val PKG="com.fastemulator.shaderpack"
 private const val H="precision mediump float;uniform sampler2D rubyTexture;uniform vec2 rubyTextureSize;varying vec2 vTexCoord;"
 private val own=listOf(
  Shader("Rejilla LCD (propio)",DV,H+"void main(){vec4 c=texture2D(rubyTexture,vTexCoord);vec2 f=abs(fract(vTexCoord*rubyTextureSize)-0.5)*2.0;float m=1.0-0.35*max(smoothstep(0.6,1.0,f.x),smoothstep(0.6,1.0,f.y));gl_FragColor=vec4(c.rgb*m,1.0);}"),
  Shader("Líneas (propio)",DV,H+"void main(){vec4 c=texture2D(rubyTexture,vTexCoord);float l=0.78+0.22*sin(vTexCoord.y*rubyTextureSize.y*6.2831853);gl_FragColor=vec4(c.rgb*l,1.0);}"))
 fun installed(c:Context)=try{c.packageManager.getPackageInfo(PKG,0);true}catch(e:Exception){false}
 fun list(c:Context):List<Shader>{
  val r=ArrayList<Shader>();r+=Shader("Sin shader",DV,DF);r+=own
  try{val a=c.createPackageContext(PKG,0).assets
   a.list("")?.filter{it.endsWith(".shader")}?.sorted()?.forEach{f->
    val t=a.open(f).bufferedReader().readText();parse(f.removeSuffix(".shader"),t)?.let{r+=it}}}catch(e:Exception){}
  return r}
 private fun parse(n:String,x:String):Shader?{
  if(x.contains("historyTexture"))return null // pendiente: shaders con historial de fotogramas (motion-blur)
  val fo=Regex("<fragment([^>]*)>\\s*<!\\[CDATA\\[(.*?)]]>",RegexOption.DOT_MATCHES_ALL).find(x)?:return null
  val vo=Regex("<vertex[^>]*>\\s*<!\\[CDATA\\[(.*?)]]>",RegexOption.DOT_MATCHES_ALL).find(x)
  return Shader(n,vo?.groupValues?.get(1)?:DV,fo.groupValues[2],!fo.groupValues[1].contains("nearest"))}
}
