package app.cirilo

/** Un truco leído de un texto o archivo, todavía sin validar. fmt = formato explícito (solo respaldos de Cirilo); on = estado de activación (solo respaldos). */
class Draft(val name:String,val code:String,val fmt:CheatFormat?=null,val on:Boolean=false)
/** items = trucos encontrados; ignored = líneas que no se pudieron usar (títulos, texto suelto, nombres sin códigos). */
class Parsed(val items:List<Draft>,val ignored:Int)
enum class Stt{OK,AMBIG,ERR}
/** Un truco analizado. det/label = lo que se guarda en Auto detect; msg = motivo si st == ERR; master = parece un código maestro. */
class ImportItem(val d:Draft,val st:Stt,val fmt:CheatFormat,val det:Int,val label:String,val text:String,val lines:Int,val msg:String,val master:Boolean)

/** Lógica pura (sin Android) para leer listas de trucos pegadas o de archivos: lista de texto (nombre y códigos debajo, «Nombre: código», «Nombre - código»…),
 *  RetroArch .cht (cheatN_desc / cheatN_code), mGBA .cheats («# nombre» y códigos debajo) y «[nombre]». Aquí solo se separa nombre y código;
 *  el formato de cada uno lo decide luego CheatCodes (nunca se adivina en silencio). */
object CheatImport{
 private val CHT=Regex("^\\s*cheat(\\d+)_(desc|code|enable)\\s*=\\s*(.*)$",RegexOption.IGNORE_CASE)
 private val BUL=Regex("^\\s*(?:[-*•]|\\d+[.)])\\s+")
 private val CMT=Regex("\\s*//.*$")
 private val WS=Regex("[ \t]+")
 private val H16=Regex("[0-9A-Fa-f]{16}");private val H12=Regex("[0-9A-Fa-f]{12}")
 private const val SEPS=":=|-–—"
 private const val MAXN=60

 /** Espacios normalizados; en GBA, 16 o 12 dígitos seguidos se separan en 8+8 / 8+4 (así se pegan a veces). No toca mayúsculas ni contenido. */
 private fun norm(plat:Int,l:String):String{val s=l.trim().replace(WS," ")
  if(plat==CheatCodes.GBA&&(H16.matches(s)||H12.matches(s)))return s.substring(0,8)+" "+s.substring(8)
  return s}
 /** Líneas de código de una línea de texto (una, o varias unidas con «+»), o null si no es código. Admite el código entre [corchetes], (paréntesis) o comillas. */
 private fun codesOf(plat:Int,l:String):List<String>?{
  val s=norm(plat,l.trim().trim('[',']','(',')','"','\'').trim())
  if(CheatCodes.isCodeLine(plat,s))return listOf(s)
  if(s.indexOf('+')>=0){val ps=s.split('+').map{norm(plat,it)};if(ps.all{it.isNotEmpty()&&CheatCodes.isCodeLine(plat,it)})return ps}
  return null}
 /** «Nombre código», «Nombre: código», «Nombre - código»: primero se prueba el final de la línea por palabras (así un guion del propio código, como en Game Genie, no corta mal) y luego los separadores. */
 private fun nameCode(plat:Int,l:String):Pair<String,List<String>>?{
  val w=l.trim().split(WS)
  for(k in 2 downTo 1){if(w.size>k){val c=codesOf(plat,w.takeLast(k).joinToString(" "));if(c!=null)return Pair(w.dropLast(k).joinToString(" "),c)}}
  for(i in l.indices){if(SEPS.indexOf(l[i])>=0){val nm=l.substring(0,i).trim();val rest=l.substring(i+1).trim()
   if(nm.isNotEmpty()&&rest.isNotEmpty()){val c=codesOf(plat,rest);if(c!=null)return Pair(nm,c)}}}
  return null}
 private fun cleanName(s:String):String=BUL.replace(s,"").trim().trimEnd(':','=','|','-','–','—').trim().trim('"').trim().take(MAXN)

 fun parse(plat:Int,text:String):Parsed{
  val src=text.replace("\uFEFF","").replace("\r\n","\n").replace('\r','\n')
  if(src.split('\n').any{CHT.matches(it)})return cht(plat,src)
  return generic(plat,src)}

 /** RetroArch .cht: cheat0_desc = "Nombre", cheat0_code = "A+B" (varios códigos unidos con «+»). El estado cheatN_enable se ignora: lo importado entra desactivado. */
 private fun cht(plat:Int,src:String):Parsed{
  val d=java.util.TreeMap<Int,String>();val c=java.util.TreeMap<Int,String>()
  for(l in src.split('\n')){val m=CHT.matchEntire(l)?:continue;val i=m.groupValues[1].toIntOrNull()?:continue
   val raw=m.groupValues[3].trim();val v=if(raw.length>=2&&raw.startsWith("\"")&&raw.endsWith("\""))raw.substring(1,raw.length-1) else raw
   val k=m.groupValues[2].lowercase()
   if(k=="desc")d[i]=v else if(k=="code")c[i]=v}
  val out=ArrayList<Draft>();var ign=0
  for((i,v) in c){val ls=v.split('+').map{norm(plat,it)}.filter{it.isNotEmpty()}
   if(ls.isEmpty()){ign++;continue}
   out+=Draft((d[i]?:"").trim().take(MAXN).ifEmpty{"Truco "+(out.size+1)},ls.joinToString("\n"))}
  return Parsed(out,ign)}

 /** Texto libre. Reglas: una línea sin código es un nombre; las líneas de código que le siguen son su truco (hasta un nombre nuevo o una línea en blanco);
  *  códigos sin nombre → «Truco N». «# nombre» (mGBA) y «[nombre]» también son nombres; «!…» y «;…» se saltan. */
 private fun generic(plat:Int,src:String):Parsed{
  val out=ArrayList<Draft>();var ign=0;var name:String?=null;val lines=ArrayList<String>()
  fun flush(){if(lines.isNotEmpty()){out+=Draft(name?:("Truco "+(out.size+1)),lines.joinToString("\n"));name=null;lines.clear()}}
  fun setName(n:String){if(n.isEmpty())return;if(name!=null&&lines.isEmpty())ign++;name=n}
  for(raw in src.split('\n')){
   val l=CMT.replace(raw,"").trim()
   if(l.isEmpty()){flush();continue}
   if(l.startsWith("!")||l.startsWith(";"))continue
   if(l.startsWith("#")){flush();setName(cleanName(l.trimStart('#')));continue}
   val c=codesOf(plat,l)
   if(c!=null){lines+=c;continue}
   if(l.length>2&&l.startsWith("[")&&l.endsWith("]")){flush();setName(cleanName(l.substring(1,l.length-1)));continue}
   val r=nameCode(plat,l)
   if(r!=null){flush();setName(cleanName(r.first));lines+=r.second;continue}
   flush();setName(cleanName(l))}
  flush();if(name!=null)ign++
  return Parsed(out,ign)}

 /** Valida un truco leído: formato (el de un respaldo, o autodetección; si es ambiguo y hay pick, ese), aceptación de mGBA y si parece código maestro. */
 fun analyze(plat:Int,d:Draft,pick:CheatFormat?,probe:((String)->IntArray?)?,ask:((Int,String)->IntArray)?):ImportItem{
  var f=d.fmt?:CheatFormat.AUTO
  var v=CheatCodes.verify(plat,f,d.code,probe,ask)
  if(v.r.ambiguous&&pick!=null){f=pick;v=CheatCodes.verify(plat,f,d.code,probe,ask)}
  val master=CheatCodes.isMaster(d.name,if(f==CheatFormat.AUTO)v.det else f.ordinal,d.code)
  val e=v.error
  if(e!=null)return ImportItem(d,Stt.ERR,f,0,"","",0,e,master)
  if(v.r.ambiguous)return ImportItem(d,Stt.AMBIG,f,0,"","",v.r.lines,"",master)
  return ImportItem(d,Stt.OK,f,v.det,if(f==CheatFormat.AUTO)v.label else f.label,v.r.text,v.r.lines,"",master)}

 /** Lista legible para compartir o abrir en otros emuladores (estilo .cheats de mGBA: «# nombre» y los códigos debajo). Cada par es (nombre, código). */
 fun toText(l:List<Pair<String,String>>):String=l.joinToString("\n\n"){"# "+it.first+"\n"+CheatCodes.lines(it.second).joinToString("\n")}+"\n"
}
