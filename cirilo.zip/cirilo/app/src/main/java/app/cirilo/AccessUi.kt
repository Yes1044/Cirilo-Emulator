package app.cirilo
import android.app.*
import android.content.Intent
import android.net.Uri
import android.widget.Toast
/** Diálogos para dar acceso a la carpeta de guardados de My Boy! / My OldBoy!: Shizuku (con mini tutorial) o selector de carpetas de Android. */
object AccessUi{
 const val RQ=10 // el selector de carpetas devuelve en onActivityResult RQ + posición de la app
 private const val STEPS="1. Instala Shizuku (Play Store o shizuku.rikka.app).\n\n2. Ábrela y pulsa «Iniciar». En Android 11 o superior sin root: activa «Depuración inalámbrica» en Opciones de desarrollador (con Wi-Fi), en Shizuku pulsa «Emparejar» y sigue los pasos, y luego «Iniciar». Con root basta «Iniciar».\n\n3. Vuelve a Cirilo y pulsa «Conceder permiso».\n\nSin root, Shizuku se detiene al reiniciar el móvil: habrá que iniciarla otra vez. Cirilo solo la necesita al copiar guardados y al abrir o cerrar un juego en modo compartido."
 /** Elige el método. ready() = acceso listo por Shizuku; el selector de carpetas responde en onActivityResult de la actividad; later() = el usuario lo deja para después. */
 fun choose(a:Activity,s:SaveSync.Src,ready:()->Unit,later:()->Unit){
  Sheet.show(a,"Dar acceso a los guardados de "+s.label,listOf("Con Shizuku","Con el selector de carpetas de Android","Ahora no"),
   listOf("Recomendado: sirve en Android 11 o superior, también en 13+","Solo funciona en algunos móviles con Android 11 o 12","Puedes hacerlo luego en Personalización"),
   {i->when(i){0->shizuku(a,s,ready,later);1->a.startActivityForResult(SaveSync.pickIntent(s),RQ+s.ordinal);else->later()}},{later()})}
 /** Según el estado de Shizuku: instalar, iniciar, conceder permiso o listo. */
 fun shizuku(a:Activity,s:SaveSync.Src,ready:()->Unit,later:()->Unit){
  if(Shell.granted()){ready();return}
  val inst=Shell.installed(a);val run=Shell.running()
  val st=if(!inst)"Estado: Shizuku no está instalada." else if(!run)"Estado: Shizuku está instalada pero detenida." else if(Shell.denied())"Estado: Shizuku está en marcha, pero el permiso fue denegado. Abre Shizuku → Aplicaciones autorizadas y activa Cirilo." else "Estado: Shizuku está en marcha. Falta dar permiso a Cirilo."
  val go=if(!inst)"Abrir sitio de Shizuku" else if(!run||Shell.denied())"Abrir Shizuku" else "Conceder permiso"
  AlertDialog.Builder(a).setTitle("Usar Shizuku").setMessage(st+"\n\n"+STEPS)
   .setPositiveButton(go){_,_->
    if(!inst)try{a.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://shizuku.rikka.app/")))}catch(e:Exception){}
    else if(!run||Shell.denied())a.packageManager.getLaunchIntentForPackage(Shell.PKG)?.let{a.startActivity(it)}
    else Shell.ask(100){ok->if(ok)ready() else Toast.makeText(a,"Permiso denegado",Toast.LENGTH_SHORT).show()}}
   .setNeutralButton("Ya lo hice"){_,_->shizuku(a,s,ready,later)}
   .setNegativeButton("Cerrar"){_,_->later()}.setOnCancelListener{later()}.show()}
}
