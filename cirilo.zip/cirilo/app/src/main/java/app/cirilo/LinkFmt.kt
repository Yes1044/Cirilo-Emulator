package app.cirilo

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Contenedor de un estado de Link local: los estados de la consola 1 y de la consola 2 guardados en el mismo instante, en un solo archivo
 * (una ranura de StateStore cuyo nombre es la pareja de juegos). Formato: magic "CLNK", versión, tamaño1, tamaño2, estado1, estado2.
 */
object LinkFmt{
 private const val MAGIC=0x434C4E4B
 private const val VER=1
 fun pack(a:ByteArray,b:ByteArray):ByteArray{
  val bo=ByteArrayOutputStream(a.size+b.size+16);val d=DataOutputStream(bo)
  d.writeInt(MAGIC);d.writeInt(VER);d.writeInt(a.size);d.writeInt(b.size);d.write(a);d.write(b);d.flush();return bo.toByteArray()}
 /** null si el archivo no es un estado de pareja o está incompleto. */
 fun unpack(x:ByteArray):Pair<ByteArray,ByteArray>?=try{
  val d=DataInputStream(ByteArrayInputStream(x))
  if(d.readInt()!=MAGIC||d.readInt()!=VER)null else{
   val n=d.readInt();val m=d.readInt()
   if(n<=0||m<=0||n.toLong()+m+16L!=x.size.toLong())null else{val a=ByteArray(n);d.readFully(a);val b=ByteArray(m);d.readFully(b);Pair(a,b)}}
 }catch(e:Exception){null}
}
