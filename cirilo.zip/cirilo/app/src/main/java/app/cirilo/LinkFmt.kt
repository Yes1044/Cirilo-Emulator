package app.cirilo

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Contenedor de un estado de Link local: los estados de la consola 1 y de la consola 2 guardados en el mismo instante, en un solo archivo
 * (una ranura de StateStore cuyo nombre es la pareja de juegos). Formato: magic "CLNK", versión, tamaño1, tamaño2, estado1, estado2.
 * Versión 2: un lado puede faltar (tamaño = NONE, sin bytes) — lo usa StateStore/GameActivity al sincronizar una ranura que solo
 * existía como guardado suelto de una de las dos consolas (partida solo, antes de activar Link local). Versión 1 (archivos antiguos) se
 * sigue leyendo igual: ambos lados siempre presentes.
 */
object LinkFmt{
 private const val MAGIC=0x434C4E4B
 private const val VER=2
 private const val NONE=-1
 /** Empaqueta un estado de pareja. Cualquiera de los dos lados puede ser null (esa consola no tenía guardado en esa ranura todavía). */
 fun pack(a:ByteArray?,b:ByteArray?):ByteArray{
  val bo=ByteArrayOutputStream((a?.size?:0)+(b?.size?:0)+16);val d=DataOutputStream(bo)
  d.writeInt(MAGIC);d.writeInt(VER);d.writeInt(a?.size?:NONE);d.writeInt(b?.size?:NONE)
  if(a!=null)d.write(a);if(b!=null)d.write(b);d.flush();return bo.toByteArray()}
 /** null si el archivo no es un estado de pareja o está dañado. Dentro, cada lado puede ser null si esa consola no tenía guardado en esa ranura. */
 fun unpack(x:ByteArray):Pair<ByteArray?,ByteArray?>?=try{
  val d=DataInputStream(ByteArrayInputStream(x))
  val magic=d.readInt();val ver=d.readInt()
  if(magic!=MAGIC||(ver!=1&&ver!=2))null else{
   val n=d.readInt();val m=d.readInt()
   if(ver==1&&(n<=0||m<=0))null else{
    val an=if(n==NONE)0 else n;val bn=if(m==NONE)0 else m
    if(an.toLong()+bn+16L!=x.size.toLong())null else{
     val a=if(n==NONE)null else ByteArray(n).also{d.readFully(it)}
     val b=if(m==NONE)null else ByteArray(m).also{d.readFully(it)}
     if(a==null&&b==null)null else Pair(a,b)}}}
 }catch(e:Exception){null}
}
