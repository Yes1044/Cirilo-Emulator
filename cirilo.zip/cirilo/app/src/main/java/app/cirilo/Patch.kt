package app.cirilo
import java.util.zip.CRC32

/** Parches de ROM IPS, UPS y BPS, aplicados en memoria (el archivo de la ROM no se toca). Kotlin puro: sin dependencias de Android. */
object Patch{
 class Bad(m:String):Exception(m)
 private const val MAX=64 shl 20 // tope razonable (la GBA llega a 32 MB): evita pedir memoria de más con un parche corrupto
 fun isPatch(name:String)=name.substringAfterLast('.',"").lowercase().let{it=="ips"||it=="ups"||it=="bps"}

 /** ext: "ips", "ups" o "bps". Lanza Bad si el parche no es válido o no corresponde a esta ROM. */
 fun apply(rom:ByteArray,p:ByteArray,ext:String):ByteArray=when(ext.lowercase()){"ips"->ips(rom,p);"ups"->ups(rom,p);"bps"->bps(rom,p);else->throw Bad("formato no admitido")}

 private fun ips(rom:ByteArray,p:ByteArray):ByteArray{
  if(p.size<8||String(p,0,5,Charsets.ISO_8859_1)!="PATCH")throw Bad("no es un IPS válido")
  fun u8(k:Int)=p[k].toInt() and 0xFF
  fun u16(k:Int)=(u8(k) shl 8) or u8(k+1)
  fun u24(k:Int)=(u8(k) shl 16) or (u8(k+1) shl 8) or u8(k+2)
  var out=rom;var i=5;var trunc=-1
  fun need(n:Int){if(n>MAX)throw Bad("el parche pide demasiada memoria");if(n>out.size)out=out.copyOf(n)} // copyOf rellena con ceros
  while(i+3<=p.size){
   val off=u24(i);i+=3
   if(off==0x454F46){if(i+3<=p.size)trunc=u24(i);break} // «EOF»; si detrás hay 3 bytes, es el tamaño final (extensión de truncado)
   if(i+2>p.size)throw Bad("IPS truncado")
   var len=u16(i);i+=2
   if(len==0){ // bloque RLE: repite un byte
    if(i+3>p.size)throw Bad("IPS truncado")
    len=u16(i);val v=p[i+2];i+=3;need(off+len);if(out===rom)out=out.copyOf();java.util.Arrays.fill(out,off,off+len,v)
   }else{
    if(i+len>p.size)throw Bad("IPS truncado")
    need(off+len);if(out===rom)out=out.copyOf();System.arraycopy(p,i,out,off,len);i+=len}}
  if(trunc in 0 until out.size)out=out.copyOf(trunc)
  return if(out===rom)rom.copyOf() else out}

 private fun crc(b:ByteArray,n:Int=b.size)=CRC32().also{it.update(b,0,n)}.value
 private fun ups(rom:ByteArray,p:ByteArray):ByteArray{
  if(p.size<18||String(p,0,4,Charsets.ISO_8859_1)!="UPS1")throw Bad("no es un UPS válido")
  val e=p.size-12
  fun le(o:Int)=(0..3).fold(0L){a,k->a or ((p[o+k].toLong() and 0xFF) shl (8*k))}
  val ci=le(e);val co=le(e+4);val cp=le(e+8)
  if(crc(p,p.size-4)!=cp)throw Bad("el parche UPS está dañado")
  var i=4
  fun vi():Long{var x=0L;var s=1L
   while(true){if(i>=e)throw Bad("UPS truncado");val b=p[i++].toInt() and 0xFF;x+=(b and 0x7F).toLong()*s;if(b and 0x80!=0)break;s=s shl 7;x+=s;if(s>(1L shl 40))throw Bad("UPS corrupto")}
   return x}
  val si=vi();val so=vi()
  val rc=crc(rom)
  if(rc==co&&rom.size.toLong()==so)return rom.copyOf() // la ROM ya está parcheada
  if(rc!=ci||rom.size.toLong()!=si)throw Bad("el parche UPS no es para esta ROM (CRC32 distinto)")
  if(so>MAX)throw Bad("el parche pide demasiada memoria")
  val out=rom.copyOf(so.toInt());var pos=0L
  while(i<e){
   pos+=vi()
   while(true){if(i>=e)throw Bad("UPS truncado");val b=p[i++].toInt()
    if(pos<so){val k=pos.toInt();out[k]=(out[k].toInt() xor b).toByte()}
    pos++;if(b==0)break}}
  if(crc(out)!=co)throw Bad("el resultado no coincide con el CRC32 del parche")
  return out}

 /** BPS (byuu): SourceRead, TargetRead, SourceCopy y TargetCopy; comprueba los tres CRC32 igual que UPS. */
 private fun bps(rom:ByteArray,p:ByteArray):ByteArray{
  if(p.size<19||String(p,0,4,Charsets.ISO_8859_1)!="BPS1")throw Bad("no es un BPS válido")
  val e=p.size-12
  fun le(o:Int)=(0..3).fold(0L){a,k->a or ((p[o+k].toLong() and 0xFF) shl (8*k))}
  val ci=le(e);val co=le(e+4);val cp=le(e+8)
  if(crc(p,p.size-4)!=cp)throw Bad("el parche BPS está dañado")
  var i=4
  fun vi():Long{var x=0L;var s=1L
   while(true){if(i>=e)throw Bad("BPS truncado");val b=p[i++].toInt() and 0xFF;x+=(b and 0x7F).toLong()*s;if(b and 0x80!=0)break;s=s shl 7;x+=s;if(s>(1L shl 40))throw Bad("BPS corrupto")}
   return x}
  val si=vi();val so=vi();val ms=vi()
  if(ms>e-i)throw Bad("BPS corrupto");i+=ms.toInt() // salta los metadatos
  val rc=crc(rom)
  if(rc==co&&rom.size.toLong()==so)return rom.copyOf() // la ROM ya está parcheada
  if(rc!=ci||rom.size.toLong()!=si)throw Bad("el parche BPS no es para esta ROM (CRC32 distinto)")
  if(so>MAX)throw Bad("el parche pide demasiada memoria")
  val out=ByteArray(so.toInt());var o=0;var sr=0L;var tr=0L
  while(i<e){
   val d=vi();val cmd=(d and 3L).toInt();val l=(d shr 2)+1
   if(l>so-o)throw Bad("BPS corrupto");val n=l.toInt()
   when(cmd){
    0->{if(o+n>rom.size)throw Bad("BPS corrupto");System.arraycopy(rom,o,out,o,n);o+=n}
    1->{if(i+n>e)throw Bad("BPS truncado");System.arraycopy(p,i,out,o,n);i+=n;o+=n}
    else->{val x=vi();val off=if(x and 1L!=0L)-(x shr 1) else x shr 1
     if(cmd==2){sr+=off;if(sr<0||sr+n>rom.size)throw Bad("BPS corrupto");System.arraycopy(rom,sr.toInt(),out,o,n);sr+=n;o+=n}
     else{tr+=off;if(tr<0||tr>=o)throw Bad("BPS corrupto");for(k in 0 until n){out[o]=out[tr.toInt()];o++;tr++}}}}}
  if(crc(out)!=co)throw Bad("el resultado no coincide con el CRC32 del parche")
  return out}
}
