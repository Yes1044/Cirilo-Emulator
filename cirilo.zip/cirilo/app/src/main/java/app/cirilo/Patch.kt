package app.cirilo
import java.util.zip.CRC32

/** Parches de ROM IPS, UPS, BPS y xdelta (VCDIFF, RFC 3284), aplicados en memoria (el archivo de la ROM no se toca). Kotlin puro: sin dependencias de Android. */
object Patch{
 class Bad(m:String):Exception(m)
 private const val MAX=64 shl 20 // tope razonable (la GBA llega a 32 MB): evita pedir memoria de más con un parche corrupto
 fun isPatch(name:String)=name.substringAfterLast('.',"").lowercase().let{it=="ips"||it=="ups"||it=="bps"||it=="xdelta"||it=="xdelta3"||it=="vcdiff"}

 /** El formato se reconoce por la cabecera del archivo (no por la extensión). Lanza Bad si el parche no es válido o no corresponde a esta ROM. */
 fun apply(rom:ByteArray,p:ByteArray):ByteArray{
  fun st(m:String)=p.size>=m.length&&m.indices.all{p[it]==m[it].code.toByte()}
  return when{
   st("PATCH")->ips(rom,p);st("UPS1")->ups(rom,p);st("BPS1")->bps(rom,p)
   p.size>=4&&p[0]==0xD6.toByte()&&p[1]==0xC3.toByte()&&p[2]==0xC4.toByte()->vcd(rom,p)
   else->throw Bad("formato de parche no reconocido")}}

 private fun ips(rom:ByteArray,p:ByteArray):ByteArray{
  if(p.size<8||String(p,0,5,Charsets.ISO_8859_1)!="PATCH")throw Bad("no es un IPS válido")
  fun u8(k:Int)=p[k].toInt() and 0xFF
  fun u16(k:Int)=(u8(k) shl 8) or u8(k+1)
  fun u24(k:Int)=(u8(k) shl 16) or (u8(k+1) shl 8) or u8(k+2)
  var out=rom;var i=5;var trunc=-1
  fun need(n:Int){if(n>MAX)throw Bad("el parche pide demasiada memoria");if(n>out.size)out=out.copyOf(n)} // copyOf rellena con ceros
  while(i+3<=p.size){
   val off=u24(i);i+=3
   if(off==0x454F46){if(i+3<=p.size)trunc=u24(i);break} // «EOF»; si detrás hay 3 bytes, es el tamaño final (extensión de truncado)
   if(i+2>p.size)throw Bad("IPS truncado")
   var len=u16(i);i+=2
   if(len==0){ // bloque RLE: repite un byte
    if(i+3>p.size)throw Bad("IPS truncado")
    len=u16(i);val v=p[i+2];i+=3;need(off+len);if(out===rom)out=out.copyOf();java.util.Arrays.fill(out,off,off+len,v)
   }else{
    if(i+len>p.size)throw Bad("IPS truncado")
    need(off+len);if(out===rom)out=out.copyOf();System.arraycopy(p,i,out,off,len);i+=len}}
  if(trunc in 0 until out.size)out=out.copyOf(trunc)
  return if(out===rom)rom.copyOf() else out}

 private fun crc(b:ByteArray,n:Int=b.size)=CRC32().also{it.update(b,0,n)}.value
 private fun ups(rom:ByteArray,p:ByteArray):ByteArray{
  if(p.size<18||String(p,0,4,Charsets.ISO_8859_1)!="UPS1")throw Bad("no es un UPS válido")
  val e=p.size-12
  fun le(o:Int)=(0..3).fold(0L){a,k->a or ((p[o+k].toLong() and 0xFF) shl (8*k))}
  val ci=le(e);val co=le(e+4);val cp=le(e+8)
  if(crc(p,p.size-4)!=cp)throw Bad("el parche UPS está dañado")
  var i=4
  fun vi():Long{var x=0L;var s=1L
   while(true){if(i>=e)throw Bad("UPS truncado");val b=p[i++].toInt() and 0xFF;x+=(b and 0x7F).toLong()*s;if(b and 0x80!=0)break;s=s shl 7;x+=s;if(s>(1L shl 40))throw Bad("UPS corrupto")}
   return x}
  val si=vi();val so=vi()
  val rc=crc(rom)
  if(rc==co&&rom.size.toLong()==so)return rom.copyOf() // la ROM ya está parcheada
  if(rc!=ci||rom.size.toLong()!=si)throw Bad("el parche UPS no es para esta ROM (CRC32 distinto)")
  if(so>MAX)throw Bad("el parche pide demasiada memoria")
  val out=rom.copyOf(so.toInt());var pos=0L
  while(i<e){
   pos+=vi()
   while(true){if(i>=e)throw Bad("UPS truncado");val b=p[i++].toInt()
    if(pos<so){val k=pos.toInt();out[k]=(out[k].toInt() xor b).toByte()}
    pos++;if(b==0)break}}
  if(crc(out)!=co)throw Bad("el resultado no coincide con el CRC32 del parche")
  return out}

 /** BPS (byuu): SourceRead, TargetRead, SourceCopy y TargetCopy; comprueba los tres CRC32 igual que UPS. */
 private fun bps(rom:ByteArray,p:ByteArray):ByteArray{
  if(p.size<19||String(p,0,4,Charsets.ISO_8859_1)!="BPS1")throw Bad("no es un BPS válido")
  val e=p.size-12
  fun le(o:Int)=(0..3).fold(0L){a,k->a or ((p[o+k].toLong() and 0xFF) shl (8*k))}
  val ci=le(e);val co=le(e+4);val cp=le(e+8)
  if(crc(p,p.size-4)!=cp)throw Bad("el parche BPS está dañado")
  var i=4
  fun vi():Long{var x=0L;var s=1L
   while(true){if(i>=e)throw Bad("BPS truncado");val b=p[i++].toInt() and 0xFF;x+=(b and 0x7F).toLong()*s;if(b and 0x80!=0)break;s=s shl 7;x+=s;if(s>(1L shl 40))throw Bad("BPS corrupto")}
   return x}
  val si=vi();val so=vi();val ms=vi()
  if(ms>e-i)throw Bad("BPS corrupto");i+=ms.toInt() // salta los metadatos
  val rc=crc(rom)
  if(rc==co&&rom.size.toLong()==so)return rom.copyOf() // la ROM ya está parcheada
  if(rc!=ci||rom.size.toLong()!=si)throw Bad("el parche BPS no es para esta ROM (CRC32 distinto)")
  if(so>MAX)throw Bad("el parche pide demasiada memoria")
  val out=ByteArray(so.toInt());var o=0;var sr=0L;var tr=0L
  while(i<e){
   val d=vi();val cmd=(d and 3L).toInt();val l=(d shr 2)+1
   if(l>so-o)throw Bad("BPS corrupto");val n=l.toInt()
   when(cmd){
    0->{if(o+n>rom.size)throw Bad("BPS corrupto");System.arraycopy(rom,o,out,o,n);o+=n}
    1->{if(i+n>e)throw Bad("BPS truncado");System.arraycopy(p,i,out,o,n);i+=n;o+=n}
    else->{val x=vi();val off=if(x and 1L!=0L)-(x shr 1) else x shr 1
     if(cmd==2){sr+=off;if(sr<0||sr+n>rom.size)throw Bad("BPS corrupto");System.arraycopy(rom,sr.toInt(),out,o,n);sr+=n;o+=n}
     else{tr+=off;if(tr<0||tr>=o)throw Bad("BPS corrupto");for(k in 0 until n){out[o]=out[tr.toInt()];o++;tr++}}}}}
  if(crc(out)!=co)throw Bad("el resultado no coincide con el CRC32 del parche")
  return out}

 /** Tabla de códigos por defecto de VCDIFF (RFC 3284, 5.6): 256 entradas de 6 números (tipo1, tamaño1, modo1, tipo2, tamaño2, modo2). Tipos: 0 nada, 1 ADD, 2 RUN, 3 COPY. */
 private val VT=IntArray(256*6).also{t->
  var n=0
  fun put(a:Int,b:Int,c:Int,d:Int,e:Int,f:Int){val o=n*6;t[o]=a;t[o+1]=b;t[o+2]=c;t[o+3]=d;t[o+4]=e;t[o+5]=f;n++}
  put(2,0,0,0,0,0)
  for(s in 0..17)put(1,s,0,0,0,0)
  for(m in 0..8){put(3,0,m,0,0,0);for(s in 4..18)put(3,s,m,0,0,0)}
  for(m in 0..5)for(a in 1..4)for(c in 4..6)put(1,a,0,3,c,m)
  for(m in 6..8)for(a in 1..4)put(1,a,0,3,4,m)
  for(m in 0..8)put(3,4,m,1,1,0)}

 /** xdelta / VCDIFF. Admite la tabla de códigos por defecto, ventanas con origen (ROM) o destino, cabecera de aplicación y Adler32 de xdelta3.
  *  No admite compresión secundaria (xdelta3 con -S lzma/djw/fgk) ni tablas de códigos propias: se avisa con un mensaje claro. */
 private fun vcd(rom:ByteArray,p:ByteArray):ByteArray{
  if(p.size<5||p[3]!=0.toByte())throw Bad("no es un xdelta válido")
  val ps=IntArray(4);ps[0]=5 // cursores: 0 cabecera y ventanas, 1 datos (ADD/RUN), 2 instrucciones, 3 direcciones (COPY)
  fun vk(k:Int,lim:Int):Long{var x=0L;var b:Int
   do{if(ps[k]>=lim)throw Bad("xdelta truncado");b=p[ps[k]++].toInt() and 0xFF;x=(x shl 7) or (b and 0x7F).toLong();if(x>(1L shl 40))throw Bad("xdelta corrupto")}while(b and 0x80!=0)
   return x}
  val hi=p[4].toInt() and 0xFF
  if(hi and 2!=0)throw Bad("tabla de códigos propia no admitida")
  if(hi and 1!=0){if(ps[0]>=p.size)throw Bad("xdelta truncado");ps[0]++} // id del compresor secundario: si alguna ventana lo usa se rechaza más abajo
  if(hi and 4!=0){val n=vk(0,p.size);if(n>p.size-ps[0])throw Bad("xdelta truncado");ps[0]+=n.toInt()} // cabecera de aplicación (xdelta3 guarda aquí el nombre de los archivos)
  var out=ByteArray(0);var ol=0
  while(ps[0]<p.size){
   val wi=p[ps[0]++].toInt() and 0xFF
   if((wi and 3)==3||(wi and 0xF8)!=0)throw Bad("ventana no válida")
   var ss=0L;var sp=0L
   if((wi and 3)!=0){ss=vk(0,p.size);sp=vk(0,p.size)}
   val dl=vk(0,p.size);if(dl>p.size-ps[0])throw Bad("xdelta truncado")
   val end=ps[0]+dl.toInt()
   val tl=vk(0,end);if(ol+tl>MAX)throw Bad("el parche pide demasiada memoria")
   if(ps[0]>=end)throw Bad("xdelta truncado")
   if(p[ps[0]++].toInt()!=0)throw Bad("usa compresión secundaria (crea el parche con xdelta3 -S none, o usa IPS/UPS/BPS)")
   val al=vk(0,end);val il=vk(0,end);val dr=vk(0,end)
   var ck=-1L
   if((wi and 4)!=0){if(ps[0]+4>end)throw Bad("xdelta truncado");ck=0L;for(k in 0..3)ck=(ck shl 8) or (p[ps[0]+k].toLong() and 0xFF);ps[0]+=4}
   if(al+il+dr!=(end-ps[0]).toLong())throw Bad("xdelta corrupto")
   ps[1]=ps[0];ps[2]=ps[1]+al.toInt();ps[3]=ps[2]+il.toInt()
   val dEnd=ps[2];val iEnd=ps[3]
   val n0=ol+tl.toInt()
   if(n0>out.size)out=out.copyOf(maxOf(n0,minOf(out.size.toLong()*2,MAX.toLong()).toInt()))
   val fromT=(wi and 2)!=0
   val src=if(fromT)out else rom
   val sLim=if(fromT)ol else rom.size
   if((wi and 3)!=0&&sp+ss>sLim)throw Bad("el parche xdelta no es para esta ROM (segmento de origen fuera de rango)")
   val sb=sp.toInt();val sz=ss.toInt()
   val near=IntArray(4);val same=IntArray(768);var nx=0
   var o=ol
   while(ps[2]<iEnd){
    val op=(p[ps[2]++].toInt() and 0xFF)*6
    for(h in 0..1){
     val t=VT[op+h*3];if(t==0)continue
     val m=VT[op+h*3+2];var s=VT[op+h*3+1].toLong()
     if(s==0L)s=vk(2,iEnd)
     if(s>n0-o)throw Bad("xdelta corrupto");val n=s.toInt()
     when(t){
      1->{if(ps[1]+n>dEnd)throw Bad("xdelta truncado");System.arraycopy(p,ps[1],out,o,n);ps[1]+=n;o+=n}
      2->{if(ps[1]>=dEnd)throw Bad("xdelta truncado");java.util.Arrays.fill(out,o,o+n,p[ps[1]++]);o+=n}
      else->{
       val a:Long=when{
        m==0->vk(3,end)
        m==1->(sz+(o-ol)).toLong()-vk(3,end) // «here»: posición en origen+destino
        m<6->near[m-2].toLong()+vk(3,end)
        else->{if(ps[3]>=end)throw Bad("xdelta truncado");same[(m-6)*256+(p[ps[3]++].toInt() and 0xFF)].toLong()}}
       if(a<0||a>Int.MAX_VALUE)throw Bad("xdelta corrupto")
       var q=a.toInt()
       near[nx]=q;nx=(nx+1) and 3;same[q%768]=q
       if(q+n<=sz){System.arraycopy(src,sb+q,out,o,n);o+=n}
       else for(k in 0 until n){
        if(q<sz)out[o]=src[sb+q]
        else{val k2=q-sz;if(k2>=o-ol)throw Bad("xdelta corrupto");out[o]=out[ol+k2]} // copia desde el propio destino (puede solaparse)
        o++;q++}}}}}
   if(o!=n0||ps[1]!=dEnd||ps[3]!=end)throw Bad("xdelta corrupto")
   if(ck>=0){val ad=java.util.zip.Adler32();ad.update(out,ol,n0-ol);if(ad.value!=ck)throw Bad("el parche xdelta no es para esta ROM (Adler32 distinto)")}
   ol=n0;ps[0]=end}
  if(ol==0)throw Bad("parche vacío")
  return if(out.size==ol)out else out.copyOf(ol)}
}
