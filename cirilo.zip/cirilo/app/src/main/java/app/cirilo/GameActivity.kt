package app.cirilo
import android.app.*
import android.content.*
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.nio.*
import java.text.SimpleDateFormat
import java.util.*
/** Escena de juego. Botón MENÚ (o atrás) abre la hoja de opciones; los ajustes se leen de las preferencias «c». */
class GameActivity:Activity(){
 private val emu=Emu();private lateinit var gl:GLView;private lateinit var tv:TextView;private lateinit var base:String
 @Volatile private var gid:GameInfo?=null // identidad de la ROM en ejecución (SHA-1): los trucos se guardan y aplican por juego
 private var gname="";private var romName="";private fun syncOut(){if(romName.isNotEmpty()){SaveSync.push(this,gname,romName);if(getSharedPreferences("c",0).getBoolean("gd_change",false))DriveSync.async(this,setOf(SaveSync.keyOf(gname)),SaveSync.srcOf(romName),gid?.let{setOf(it.id)})}} // sube el guardado compartido por SAF
 private lateinit var padV:Pad;private var pad=0;private var hw=0;private var ffHold=false;private var fs=true;private var imm=true
 private fun autoFile()=File(getExternalFilesDir("states"),base+".auto.state")
 private fun send()=Native.keys(pad or hw)
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun sf(s:Int)=File(getExternalFilesDir("states"),base+"."+s+".state") // 0 = rápido, 1..9 = ranuras
 override fun onCreate(b:Bundle?){
  super.onCreate(b);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);try{window.setSustainedPerformanceMode(true)}catch(e:Exception){}
  val n=intent.getStringExtra("n")?:"";val u=intent.getStringExtra("u")?:"";base=n.substringBeforeLast('.');gname=n
  gl=GLView(this);val root=FrameLayout(this);root.setBackgroundColor(0xFF000000.toInt());root.addView(gl)
  padV=Pad(this,{pad=it;send()},{id,d->action(id,d)});root.addView(padV);emu.onFrame={gl.requestRender()}
  tv=TextView(this).apply{setTextColor(0xFF00FF00.toInt());textSize=14f;setShadowLayer(3f,0f,0f,0xFF000000.toInt());setPadding(16,8,16,8)}
  root.addView(tv,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.START))
  root.addView(Button(this).apply{text="MENÚ";alpha=.7f;setOnClickListener{menu()}},FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.END))
  val hd=Handler(Looper.getMainLooper());hd.post(object:Runnable{override fun run(){if(tv.visibility==View.VISIBLE)tv.text=""+emu.fps+" fps / "+"%.1f".format(emu.ms)+" ms"+(if(emu.skip>0)" (salto "+emu.skip+")" else "")+(if(emu.ff)" x"+emu.ffSpeed.let{if(it==it.toInt().toDouble())it.toInt().toString() else it.toString()} else "");hd.postDelayed(this,500)}})
  setContentView(root);applyPrefs()
  Thread{val r=Roms.load(this,u,n);romName=r?.first?:"";gid=r?.let{GameId.of(it.second,it.first)}
   if(r!=null&&getSharedPreferences("c",0).getBoolean("gd_start",false))DriveSync.syncNow(this,setOf(SaveSync.keyOf(n)),SaveSync.srcOf(r.first),gid?.let{setOf(it.id)}) // baja lo último de Drive antes de cargar el guardado
   val sf=if(r!=null)SaveSync.file(this,n,r.first) else null
   if(r!=null&&sf!=null&&SaveSync.fellBack(this,n,r.first,sf))ui("Guardado compartido no disponible (¿Shizuku detenida?): se usa el de Cirilo")
   if(r==null||sf==null||!emu.start(r.second,r.first,sf))runOnUiThread{t("No se pudo abrir el juego");finish()} else{
    applyCheats()
    val af=autoFile();if(getSharedPreferences("c",0).getBoolean("auto",false)&&af.exists())emu.post{try{Native.loadState(af.readBytes())}catch(e:Exception){}}
    Lib.all(this).firstOrNull{it.u==u}?.let{Lib.upd(this,listOf(it.copy(played=System.currentTimeMillis())))}}}.start()}
 /** Sustituye los trucos del núcleo por los activos de este juego (un set por truco, con su formato). Se ejecuta en el hilo del emulador, entre fotogramas, sin reiniciar el juego; respeta Ajustes → «Activar trucos».
  *  Los que mGBA no acepta se guardan (CheatStore.status) para marcarlos en la lista de Trucos; el aviso emergente solo sale cuando aparece un fallo nuevo. */
 private fun applyCheats(){val g=gid?:return;val on=getSharedPreferences("c",0).getBoolean("cheats",true)
  val l=if(on)CheatStore.active(this,g) else emptyList()
  emu.post{val st=Native.cheatApply(l.map{it.mode}.toIntArray(),l.map{it.text}.toTypedArray())
   if(st.any{it==-9999})ui("El núcleo no incluye el módulo de trucos: recompila con el workflow actualizado") else{
    val old=CheatStore.status(this,g.id);val now=HashMap<String,Int>();l.forEachIndexed{i,c->if(st[i]<0)now[c.id]=st[i]}
    CheatStore.setStatus(this,g.id,now);val fresh=now.keys.count{it !in old}
    if(fresh>0)ui(if(fresh==1)"1 truco no se pudo aplicar. Míralo en Trucos" else fresh.toString()+" trucos no se pudieron aplicar. Míralos en Trucos")}}}
 private fun applyPrefs(){applyLayout();val p=getSharedPreferences("c",0)
  gl.stretch=p.getBoolean("stretch",false);gl.size=p.getInt("size",100);gl.linear=p.getBoolean("linear",false)
  val sn=p.getString("shader","")?:"";gl.shader=if(sn.isEmpty())null else Shaders.list(this).firstOrNull{it.name==sn}
  tv.visibility=if(p.getBoolean("fps",false))View.VISIBLE else View.GONE;padV.cheatsOn=p.getBoolean("cheats",true)
  emu.maxSkip=p.getInt("skip",2);emu.ffSpeed=p.getInt("ffs",40)/10.0;ffHold=p.getInt("ffm",0)==1;fs=p.getBoolean("full",true);imm=p.getBoolean("imm",true);applySystemUi();emu.rate=p.getInt("freq",48000);emu.vol=if(p.getBoolean("snd",true))p.getInt("vol",100) else 0
  requestedOrientation=when(p.getInt("orient",0)){1->ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;2->ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;else->ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED}
  gl.requestRender()}
 /** Pantalla completa (barra de estado) e inmersivo (barra de navegación), según Ajustes → Misceláneo. */
 @Suppress("DEPRECATION") private fun applySystemUi(){
  if(fs)window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN) else window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
  var f=0;if(fs)f=f or View.SYSTEM_UI_FLAG_FULLSCREEN
  if(imm)f=f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
  window.decorView.systemUiVisibility=f}
 override fun onWindowFocusChanged(h:Boolean){super.onWindowFocusChanged(h);if(h)applySystemUi()}
 /** Layout activo para la orientación actual: controles y posición de la pantalla del juego. */
 private fun applyLayout(){val land=resources.configuration.orientation==Configuration.ORIENTATION_LANDSCAPE;val L=Layouts.load(this).cur();val cl=if(land)L.l else L.p
  padV.list=cl;val sc=cl.firstOrNull{it.t=="screen"};gl.sx=sc?.x?:.5f;gl.sy=sc?.y?:-1f;gl.ss=sc?.s?:1f}
 override fun onConfigurationChanged(c:Configuration){super.onConfigurationChanged(c);applyLayout();gl.requestRender()}
 private fun ui(s:String)=runOnUiThread{t(s)}
 /** Guardado/carga rápidos = la ranura «Rápido» del menú; se ejecutan en el hilo del emulador entre fotogramas. */
 private fun quick(save:Boolean){emu.post{if(save){Native.saveState()?.let{sf(0).writeBytes(it);ui("Estado guardado (rápido)")}?:ui("No se pudo guardar")}
  else if(sf(0).exists())ui(if(Native.loadState(sf(0).readBytes()))"Estado cargado (rápido)" else "No se pudo cargar") else ui("No hay estado rápido")}}
 private fun action(id:String,down:Boolean){when(id){"qsave"->quick(true);"qload"->quick(false);"ff"->if(ffHold)emu.ff=down else if(down)emu.ff=!emu.ff;"shot"->shot();"cheats"->toggleCheats()}}
 /** Botón «Trucos» del layout: alterna el interruptor general (Ajustes → Activar trucos) y lo aplica al instante. */
 private fun toggleCheats(){val p=getSharedPreferences("c",0);val on=!p.getBoolean("cheats",true);p.edit().putBoolean("cheats",on).apply();padV.cheatsOn=on;applyCheats()
  val n=gid?.let{g->CheatStore.list(this,g.id).count{it.enabled}}?:0
  t(if(!on)"Trucos desactivados" else if(n>0)"Trucos activados ("+n+")" else "Trucos activados, pero ninguno está marcado")}
 private fun menu(){emu.pause()
  val cn=gid?.let{g->CheatStore.list(this,g.id).count{it.enabled}}?:0;val con=getSharedPreferences("c",0).getBoolean("cheats",true)
  val o=listOf("Cargar","Guardar","Avance rápido"+(if(emu.ff)": sí" else ""),"Trucos"+(if(cn>0)" ("+cn+")" else ""),"Ajustes","Link remoto","Link local","Captura de pantalla","Reiniciar","Salir","Cerrar")
  Sheet.show(this,null,o,o.indices.map{if(it==3&&cn>0&&!con)"Desactivados en Ajustes" else null},{i->when(i){
   0->slots(false);1->slots(true);2->{emu.ff=!emu.ff;emu.resume()}
   3->{val g=gid;if(g==null){t("El juego aún se está cargando");emu.resume()} else startActivity(CheatsActivity.intent(this,g))}
   5,6->{t("Próximamente");emu.resume()}
   4->startActivity(Intent(this,SettingsActivity::class.java))
   7->{shot();emu.resume()};8->sure("¿Reiniciar el juego?"){Native.reset();emu.resume()};9->sure("¿Salir del juego?"){finish()};else->emu.resume()}},{emu.resume()})}
 /** Pide confirmación si «Confirmar al cerrar/reiniciar» está activo; al cancelar el juego continúa. */
 private fun sure(m:String,ok:()->Unit){if(!getSharedPreferences("c",0).getBoolean("confirm",false)){ok();return}
  AlertDialog.Builder(this).setMessage(m).setPositiveButton("Aceptar"){_,_->ok()}.setNegativeButton("Cancelar"){_,_->emu.resume()}.setOnCancelListener{emu.resume()}.show()}
 private fun slots(save:Boolean){
  val fs=(0..9).map{sf(it)}
  if(!save&&fs.none{it.exists()}){t("No hay estados guardados");emu.resume();return}
  val df=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault())
  Sheet.show(this,if(save)"Guardar estado" else "Cargar estado",(0..9).map{if(it==0)"Rápido" else "Ranura "+it},fs.map{if(it.exists())df.format(Date(it.lastModified())) else "<vacío>"},{i->
   if(save){Native.saveState()?.let{fs[i].writeBytes(it);t("Estado guardado")}?:t("No se pudo guardar")}
   else if(fs[i].exists())t(if(Native.loadState(fs[i].readBytes()))"Estado cargado" else "No se pudo cargar") else t("Vacío")
   emu.resume()},{emu.resume()})}
 private fun shot(){
  val bb=ByteBuffer.allocateDirect(256*224*2).order(ByteOrder.nativeOrder());val r=Native.last(bb)
  if(r==0){t("No hay imagen que capturar");return}
  val w=r ushr 16;val h=r and 0xffff;val bm=Bitmap.createBitmap(w,h,Bitmap.Config.RGB_565);bb.position(0);bm.copyPixelsFromBuffer(bb)
  val sc=Bitmap.createScaledBitmap(bm,w*3,h*3,false);val name=base+"_"+System.currentTimeMillis()+".png"
  try{if(Build.VERSION.SDK_INT>=29){val cv=ContentValues().apply{put(MediaStore.MediaColumns.DISPLAY_NAME,name);put(MediaStore.MediaColumns.MIME_TYPE,"image/png");put(MediaStore.MediaColumns.RELATIVE_PATH,"Pictures/Cirilo")}
    contentResolver.openOutputStream(contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv)!!)!!.use{sc.compress(Bitmap.CompressFormat.PNG,100,it)}}
   else File(getExternalFilesDir("screenshots"),name).outputStream().use{sc.compress(Bitmap.CompressFormat.PNG,100,it)}
   t("Captura guardada")}catch(e:Exception){t("No se pudo guardar la captura")}}
 private fun bit(k:Int)=when(k){KeyEvent.KEYCODE_DPAD_UP->4;KeyEvent.KEYCODE_DPAD_DOWN->5;KeyEvent.KEYCODE_DPAD_LEFT->6;KeyEvent.KEYCODE_DPAD_RIGHT->7
  KeyEvent.KEYCODE_BUTTON_A->8;KeyEvent.KEYCODE_BUTTON_B->0;KeyEvent.KEYCODE_BUTTON_START->3;KeyEvent.KEYCODE_BUTTON_SELECT->2;KeyEvent.KEYCODE_BUTTON_L1->10;KeyEvent.KEYCODE_BUTTON_R1->11;else->-1}
 override fun onKeyDown(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyDown(k,e);hw=hw or(1 shl b);send();return true}
 override fun onKeyUp(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyUp(k,e);hw=hw and(1 shl b).inv();send();return true}
 override fun onBackPressed(){menu()}
 override fun onPause(){super.onPause();gl.onPause();emu.pause();if(getSharedPreferences("c",0).getBoolean("auto",false))emu.snap(autoFile());syncOut()}
 override fun onResume(){super.onResume();gl.onResume();applyPrefs();applyCheats();emu.resume()}
 override fun onDestroy(){super.onDestroy();emu.stop();syncOut()}
}
