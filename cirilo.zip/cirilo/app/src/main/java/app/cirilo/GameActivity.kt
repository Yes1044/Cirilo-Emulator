package app.cirilo
import android.app.*
import android.content.*
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.nio.*
import java.text.SimpleDateFormat
import java.util.*
/** Escena de juego. El control «Menú» del layout (o atrás) abre la hoja de opciones (no hay botón MENÚ fijo); los ajustes se leen de las preferencias «c». */
class GameActivity:Activity(){
 /** Una consola abierta en esta pantalla. Sin Link local solo existe la 0; con Link local, la 0 y la 1 (el cable las une). priv = guardado propio (juego.link2.sav): no se sincroniza con My Boy! ni Drive. */
 private class Sl{var u="";var n="";var base="";@Volatile var gid:GameInfo?=null;var rom="";var sys=LSys.GBA;@Volatile var on=false;var priv=false}
 private val em=arrayOf(Emu(0),Emu(1));private val sl=arrayOf(Sl(),Sl());@Volatile private var cur=0;@Volatile private var linked=false
 /** true mientras haya una hoja o un diálogo propio abierto (menú, estados, cable, confirmación): onResume y recuperar el foco NO reanudan el juego hasta que se cierre. */
 @Volatile private var modal=false
 /** true entre onResume y onPause. */
 @Volatile private var fg=false
 /** true justo al salir a Ajustes/Trucos/Biblioteca (una Activity nueva, no una hoja): onResume() reanuda solo porque esto estaba a true, sin esperar a que «modal» baje por su cuenta.
  *  Mientras se sale, «modal» se queda en true (no se toca) para que un aviso de foco de ventana suelto durante la transición no reanude el juego antes de tiempo. */
 @Volatile private var leaving=false
 private val lbusy=java.util.concurrent.atomic.AtomicBoolean(false)
 private val emu get()=em[cur];private val st get()=em[cur] /* cada consola tiene su hilo y sus fps; se muestran los de la que se ve */;private val S get()=sl[cur]
 private lateinit var gl:GLView;private lateinit var tv:TextView
 // lo que ya existía (juego, ROM, SHA-1 para los trucos, consola del layout) ahora es el de la consola que se está viendo
 private val base get()=S.base;private val gid get()=S.gid;private val gname get()=S.n;private val romName get()=S.rom;private val gsys get()=S.sys
 /** Sube el guardado compartido por SAF de la consola k (si usa su guardado normal) y, si toca, a Drive. */
 private fun syncOut(k:Int=cur){val x=sl[k];if(x.rom.isNotEmpty()&&!x.priv){SaveSync.push(this,x.n,x.rom);if(getSharedPreferences("c",0).getBoolean("gd_change",false))DriveSync.async(this,setOf(SaveSync.keyOf(x.n)),SaveSync.srcOf(x.rom),x.gid?.let{setOf(it.id)})}}
 private fun syncAll(){for(k in 0..1)if(sl[k].on)syncOut(k)}
 private lateinit var rootV:FrameLayout;private lateinit var padV:Pad;private var pad=0;private var hw=0;private var ffHold=false;private var fs=true;private var imm=true
 private fun autoFile()=File(getExternalFilesDir("states"),base+".auto.state")
 private fun send()=Native.keys(cur,pad or hw)
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun slot(n:Int)=StateStore.slot(this,skey(),n)
 /** Clave de la pareja de juegos (Link local): fija según sl[0]/sl[1], no según cuál se está viendo. */
 private fun pairKey()="link_"+sl[0].base+"+"+sl[1].base
 /** Clave de las ranuras: con Link local es la pareja de juegos (las mismas ranuras desde cualquiera de las dos consolas); si no, el juego. */
 private fun skey()=if(linked)pairKey() else base // 0 = rápido, 1..9 = ranuras (estado + miniatura, ver StateStore)
 /** Al activar Link local: mete en las ranuras de la pareja lo que ya hubiera guardado SUELTO en la consola 1 o la 2 (partidas de antes de enlazar),
  *  para que no desaparezcan de la lista al enlazar. No se toca una ranura de la pareja que ya tenga los dos lados; si le falta uno, se completa si
  *  ya existe el guardado suelto correspondiente. Los guardados sueltos originales no se tocan ni se borran. Se llama con las dos consolas paradas,
  *  antes de que la UI pueda guardar o cargar, así que es seguro leer/escribir aquí mismo (hilo de carga de la segunda ROM). */
 private fun syncLinkSlots(){
  val key=pairKey();val baseA=sl[0].base;val baseB=sl[1].base
  for(n in 0 until StateStore.SLOTS){
   val ls=StateStore.slot(this,key,n)
   val had=if(ls.exists)try{LinkFmt.unpack(ls.state.readBytes())}catch(e:Exception){null} else null
   var a=had?.first;var b=had?.second
   if(a==null){val s0=StateStore.slot(this,baseA,n);if(s0.exists)a=try{s0.state.readBytes()}catch(e:Exception){null}}
   if(b==null&&baseB!=baseA){val s1=StateStore.slot(this,baseB,n);if(s1.exists)b=try{s1.state.readBytes()}catch(e:Exception){null}}
   if(a==null||b==null)continue // una ranura de pareja es una foto de las dos consolas: sin las dos mitades no se crea
   if(a===had?.first&&b===had?.second)continue // ya estaba completo (o ya sincronizado antes): no se reescribe
   val th=StateStore.thumbOf(ls)?:StateStore.thumbOf(StateStore.slot(this,baseA,n))?:StateStore.thumbOf(StateStore.slot(this,baseB,n))
   StateStore.save(ls,LinkFmt.pack(a,b),th)
  }}
 override fun onCreate(b:Bundle?){
  super.onCreate(b);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);try{window.setSustainedPerformanceMode(true)}catch(e:Exception){}
  val n=intent.getStringExtra("n")?:"";val u=intent.getStringExtra("u")?:"";Native.libDir(applicationInfo.nativeLibraryDir);Adv.push(this);Native.act=0;cur=0;linked=false;sl[0].u=u;sl[0].n=n;sl[0].base=n.substringBeforeLast('.');sl[0].sys=Layouts.sysFor(this,u,n)
  gl=GLView(this);val root=FrameLayout(this);rootV=root;root.setBackgroundColor(0xFF000000.toInt());root.addView(gl)
  padV=Pad(this,{pad=it;send()},{id,d->action(id,d)});root.addView(padV);em[0].onFrame={if(Native.act==0)gl.requestRender()};em[1].onFrame={if(Native.act==1)gl.requestRender()} // cada hilo avisa de su fotograma; solo se dibuja el de la consola que se ve
  tv=TextView(this).apply{setTextColor(0xFF00FF00.toInt());textSize=14f;setShadowLayer(3f,0f,0f,0xFF000000.toInt());setPadding(16,8,16,8)}
  root.addView(tv,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.START))
  val hd=Handler(Looper.getMainLooper());hd.post(object:Runnable{override fun run(){if(tv.visibility==View.VISIBLE)tv.text="%.1f".format(st.fps)+" fps / "+"%.1f".format(st.ms)+" ms"+(if(st.skip>0)" (salto "+st.skip+")" else "")+(if(Native.lnk)" | "+Native.linkDbg()+" | "+st.aud else "")+(if(emu.ff)" x"+emu.ffSpeed.let{if(it==it.toInt().toDouble())it.toInt().toString() else it.toString()}+(if(st.fps<emu.ffSpeed*59.7275*0.9)" (real x%.1f)".format(st.fps/59.7275) else "") else "")+Native.profDbg().let{if(it.isEmpty())"" else "\n"+it}+(if(st.prof.isEmpty())"" else "\n"+st.prof+(if(android.os.Build.VERSION.SDK_INT>=29)" t"+(getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager).currentThermalStatus else ""));hd.postDelayed(this,500)}})
  setContentView(root);applyPrefs()
  Thread{val r=Roms.load(this,u,n);Roms.patchMsg?.let{ui(it)};Roms.patchErr?.let{showErr("No se pudo aplicar el parche",it)};sl[0].rom=r?.first?:"";sl[0].gid=r?.let{GameId.of(it.second,it.first)}
   if(r!=null&&getSharedPreferences("c",0).getBoolean("gd_start",false))DriveSync.syncNow(this,setOf(SaveSync.keyOf(n)),SaveSync.srcOf(r.first),gid?.let{setOf(it.id)}) // baja lo último de Drive antes de cargar el guardado
   val sf=if(r!=null)SaveSync.file(this,n,r.first) else null
   if(r!=null&&sf!=null&&SaveSync.fellBack(this,n,r.first,sf))ui("Guardado compartido no disponible (¿Shizuku detenida?): se usa el de Cirilo")
   if(r==null||sf==null||!em[0].start(r.second,r.first,sf))runOnUiThread{t("No se pudo abrir el juego");finish()} else{
    sl[0].on=true;applyCheats(0)
    val af=autoFile();if(getSharedPreferences("c",0).getBoolean("auto",false)&&af.exists())em[0].post{try{Native.loadState(0,af.readBytes())}catch(e:Exception){}}
    Lib.all(this).firstOrNull{it.u==u}?.let{Lib.upd(this,listOf(it.copy(played=System.currentTimeMillis())))}}}.start()}
 /** Sustituye los trucos del núcleo por los activos de este juego (un set por truco, con su formato). Se ejecuta en el hilo del emulador, entre fotogramas, sin reiniciar el juego; respeta Ajustes → «Activar trucos».
  *  Los que mGBA no acepta se guardan (CheatStore.status) para marcarlos en la lista de Trucos; el aviso emergente solo sale cuando aparece un fallo nuevo. */
 private fun applyCheats(k:Int=cur){val g=sl[k].gid?:return;val on=getSharedPreferences("c",0).getBoolean("cheats",true)
  val l=if(on)CheatStore.active(this,g) else emptyList()
  em[k].post{val st=Native.cheatApply(k,l.map{it.mode}.toIntArray(),l.map{it.text}.toTypedArray())
   if(st.any{it==-9999})ui("El núcleo no incluye el módulo de trucos: recompila con el workflow actualizado") else{
    val old=CheatStore.status(this,g.id);val now=HashMap<String,Int>();l.forEachIndexed{i,c->if(st[i]<0)now[c.id]=st[i]}
    CheatStore.setStatus(this,g.id,now);val fresh=now.keys.count{it !in old}
    if(fresh>0)ui(if(fresh==1)"1 truco no se pudo aplicar. Míralo en Trucos" else fresh.toString()+" trucos no se pudieron aplicar. Míralos en Trucos")}}}
 private fun applyPrefs(){applyLayout();val p=getSharedPreferences("c",0)
  gl.stretch=p.getBoolean("stretch",false);gl.size=p.getInt("size",100);gl.linear=p.getBoolean("linear",false)
  val sn=p.getString("shader","")?:"";gl.shader=if(sn.isEmpty())null else Shaders.list(this).firstOrNull{it.name==sn}
  tv.visibility=if(p.getBoolean("fps",false))View.VISIBLE else View.GONE;padV.cheatsOn=p.getBoolean("cheats",true)
  em.forEach{it.maxSkip=p.getInt("skip",2);it.dynSkip=p.getBoolean("dynskip",true);it.ffSpeed=p.getInt("ffs",40)/10.0};ffHold=p.getInt("ffm",0)==1;fs=p.getBoolean("full",true);imm=p.getBoolean("imm",true);applySystemUi();em.forEach{it.rate=p.getInt("freq",48000);it.vol=if(p.getBoolean("snd",true))p.getInt("vol",100) else 0}
  requestedOrientation=when(p.getInt("orient",0)){1->ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;2->ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;else->ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED}
  gl.requestRender()}
 /** Pantalla completa (barra de estado) e inmersivo (barra de navegación), según Ajustes → Misceláneo. */
 @Suppress("DEPRECATION") private fun applySystemUi(){
  if(fs)window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN) else window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
  var f=0;if(fs)f=f or View.SYSTEM_UI_FLAG_FULLSCREEN
  if(imm)f=f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
  window.decorView.systemUiVisibility=f}
 private val uiH=Handler(Looper.getMainLooper());private var focusResume:Runnable?=null
 /** cortina de notificaciones, ventana flotante, diálogos del sistema: las consolas duermen. Perder el foco pausa al instante (es seguro llamarlo de más).
  *  Recuperarlo NO reanuda al instante: se espera un pelín (se reaplica el modo inmersivo, que en algunos Android dispara un «foco recuperado» suelto
  *  justo cuando en realidad la app se está yendo a segundo plano) y solo se reanuda si para entonces el foco se mantiene y seguimos en primer plano. */
 override fun onWindowFocusChanged(h:Boolean){super.onWindowFocusChanged(h)
  focusResume?.let{uiH.removeCallbacks(it)};focusResume=null
  if(h){applySystemUi();if(fg&&!modal){val r=Runnable{if(hasWindowFocus()&&fg&&!modal)resumeAll()};focusResume=r;uiH.postDelayed(r,60)}}
  else if(fg&&!modal)pauseAll()}
 /** Layout activo para la orientación actual: controles y posición de la pantalla del juego. */
 private fun applyLayout(){val land=resources.configuration.orientation==Configuration.ORIENTATION_LANDSCAPE;val L=Layouts.load(this).cur(gsys);val cl=if(land)L.l else L.p
  padV.list=cl;val sc=cl.firstOrNull{it.t=="screen"};gl.sx=sc?.x?:.5f;gl.sy=sc?.y?:-1f;gl.ss=sc?.s?:1f;gl.sm=sc?.m?:0;gl.sa=sc?.a?:0f}
 override fun onConfigurationChanged(c:Configuration){super.onConfigurationChanged(c);applyLayout();gl.requestRender()}
 private fun ui(s:String)=runOnUiThread{t(s)}
 /** Diálogo con el texto seleccionable y botón «Copiar» (los avisos emergentes se cortan y no se pueden copiar). */
 private fun showErr(title:String,msg:String)=runOnUiThread{if(!isFinishing){
  val tv=TextView(this).apply{text=msg;setTextIsSelectable(true);textSize=13f;setPadding(48,24,48,24)}
  AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply{addView(tv)}).setPositiveButton("Copiar",null).setNegativeButton("Cerrar",null).create().apply{
   setOnShowListener{getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{(getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(title,msg));t("Copiado")}}}.show()}}
 /** Guardado/carga rápidos = la ranura «Rápido» del menú; se ejecutan en el hilo del emulador entre fotogramas. */
 private fun quick(save:Boolean){if(linked){linkState(save,0);return};emu.post{if(save)saveTo(0) else loadFrom(0)}}
 /** Fotograma actual del núcleo (RGB565) como imagen; null si todavía no ha dibujado ninguno. Sirve para las capturas y para las miniaturas de los estados. */
 private fun grab():Bitmap?{val bb=ByteBuffer.allocateDirect(256*224*2).order(ByteOrder.nativeOrder());val r=Native.last(cur,bb);if(r==0)return null
  val w=r ushr 16;val h=r and 0xffff;val bm=Bitmap.createBitmap(w,h,Bitmap.Config.RGB_565);bb.position(0);bm.copyPixelsFromBuffer(bb);return bm}
 /** Aviso con miniatura (StateToast) sobre la escena del juego; se puede llamar desde cualquier hilo. */
 private fun card(title:String,sub:String,thumb:Bitmap?)=runOnUiThread{if(StateToast.enabled(this))StateToast.show(this,rootV,thumb,title,sub)}
 /** Guarda el estado en la ranura n junto con una miniatura tomada en ese mismo instante. Solo con el emulador parado o desde su hilo (entre fotogramas). */
 private fun saveTo(n:Int){
  val data=Native.saveState(cur);if(data==null){ui("No se pudo guardar");return}
  val th=grab()?.let{StateStore.thumb(it)}
  if(StateStore.save(slot(n),data,th))card("Estado guardado",StateStore.title(n),th) else ui("No se pudo guardar")}
 /** Carga la ranura n. Mismas condiciones de hilo que saveTo. */
 private fun loadFrom(n:Int){val s=slot(n)
  if(!s.exists){ui(if(n==0)"No hay estado rápido" else "Esa ranura está vacía");return}
  val ok=try{Native.loadState(cur,s.state.readBytes())}catch(e:Exception){false}
  if(ok)card("Estado cargado",StateStore.title(n),StateStore.thumbOf(s)) else ui("No se pudo cargar")}
 private fun action(id:String,down:Boolean){when(id){"qsave"->quick(true);"qload"->quick(false);"ff"->if(ffHold)setFf(down) else if(down)setFf(!emu.ff);"shot"->shot();"cheats"->toggleCheats();"menu"->menu()}}
 /** Botón «Trucos» del layout: alterna el interruptor general (Ajustes → Activar trucos) y lo aplica al instante. */
 private fun toggleCheats(){val p=getSharedPreferences("c",0);val on=!p.getBoolean("cheats",true);p.edit().putBoolean("cheats",on).apply();padV.cheatsOn=on;applyCheats()
  val n=gid?.let{g->CheatStore.list(this,g.id).count{it.enabled}}?:0
  t(if(!on)"Trucos desactivados" else if(n>0)"Trucos activados ("+n+")" else "Trucos activados, pero ninguno está marcado")}
/** Pausa/reanuda las dos consolas. Pausar es en dos fases (primero se pide parar a las dos, luego se espera a cada hilo) y con el cable se avisa antes: así ninguna se queda esperando a la otra dentro de retro_run. */
 private fun pauseAll(){em.forEach{it.halt()};Native.linkInterrupt(true);em.forEach{it.pause()};Native.linkInterrupt(false)}
 private fun resumeAll(){modal=false;em.forEach{it.resume()}}
 /**
  * Guarda o carga la ranura n de la PAREJA de juegos (Link local). Guardar: los estados de las dos consolas en el mismo instante, en un solo archivo. Cargar: las dos consolas a la vez
  * (la ranura es una sola foto compartida). Se hace en un hilo aparte: para las dos consolas, y al terminar las reanuda. GB/GBC: el lockstep del cable no se serializa,
  * así que solo se guarda sin transferencia en curso (si la hay se reanuda unos ms y se reintenta). Al cargar, Native.linkCut() antes y Native.linkResync() después.
  */
 private fun linkState(save:Boolean,n:Int){
  if(!lbusy.compareAndSet(false,true)){ui("Espera un momento…");return}
  Thread{
   try{
    pauseAll()
    // GB/GBC: tanto para guardar como para cargar hace falta que NINGUNA consola esté a mitad de una transferencia (el lockstep no se serializa y se reinicia): si la hay, se reanuda unos ms y se reintenta
    var tries=0
    while(!Native.linkIdle()&&tries<80){resumeAll();try{Thread.sleep(3)}catch(e:InterruptedException){};pauseAll();tries++}
    if(!Native.linkIdle()){ui("El cable está transfiriendo datos. Inténtalo otra vez");return@Thread}
    if(save){
     val a=Native.saveState(0);val b=Native.saveState(1)
     if(a==null||b==null){ui("No se pudo guardar");return@Thread}
     val th=grab()?.let{StateStore.thumb(it)}
     if(StateStore.save(slot(n),LinkFmt.pack(a,b),th))card("Estado guardado",StateStore.title(n)+" · 2 consolas",th) else ui("No se pudo guardar")
    }else{
     val s=slot(n)
     if(!s.exists){ui(if(n==0)"No hay estado rápido" else "Esa ranura está vacía");return@Thread}
     val p=try{LinkFmt.unpack(s.state.readBytes())}catch(e:Exception){null}
     if(p==null){ui("El estado está dañado o no es de esta pareja");return@Thread}
     // La ranura es una foto de las DOS consolas en el mismo instante: se restauran las dos a la vez (si no, la que no se carga sigue en otro punto y parece que no se cargó nada).
     val a=p.first;val b=p.second
     if(a==null||b==null){ui("Esa ranura no tiene las dos consolas");return@Thread}
     if(Native.lnk)Native.linkCut()
     val ok0=Native.loadState(0,a);val ok1=Native.loadState(1,b);val ok=ok0&&ok1
     if(Native.lnk)Native.linkResync()
     if(ok)card("Estado cargado",StateStore.title(n)+" · 2 consolas",StateStore.thumbOf(s)) else ui("No se pudo cargar")
    }
   }catch(e:Exception){ui("No se pudo "+(if(save)"guardar" else "cargar"))}
   finally{lbusy.set(false);resumeAll()}
  }.start()}
 /** El avance rápido vale para las dos consolas a la vez (si no, la que va despacio retendría a la otra por el cable). */
 private fun setFf(v:Boolean){em.forEach{it.ff=v}}
 private fun menu(){modal=true;pauseAll()
  val cn=gid?.let{g->CheatStore.list(this,g.id).count{it.enabled}}?:0;val con=getSharedPreferences("c",0).getBoolean("cheats",true)
  val o=ArrayList<String>();val sb=ArrayList<String?>();val ac=ArrayList<()->Unit>()
  fun add(t:String,s:String?,f:()->Unit){o+=t;sb+=s;ac+=f}
  val other=1-cur
  add("Cargar",if(linked)"Las dos consolas a la vez" else null){slots(false)}
  add("Guardar",if(linked)"Las dos consolas a la vez" else null){slots(true)}
  add("Avance rápido"+(if(emu.ff)": sí" else ""),null){setFf(!emu.ff);resumeAll()}
  add("Trucos"+(if(cn>0)" ("+cn+")" else ""),if(cn>0&&!con)"Desactivados en Ajustes" else null){val g=gid;if(g==null){t("El juego aún se está cargando");resumeAll()} else{leaving=true;startActivity(CheatsActivity.intent(this,g))}}
  add("Ajustes",null){leaving=true;startActivity(Intent(this,SettingsActivity::class.java))}
  add("Link remoto",null){t("Próximamente");resumeAll()}
  add("Link local",if(linked)"Activo · ahora ves el juego "+(cur+1)+" de 2" else null){if(linked){t("Link local ya está activo");resumeAll()} else linkMenu()}
  // solo se activa después de elegir Link local: alterna entre el juego 1 y el juego 2
  add("Cambiar al juego "+(other+1),if(linked)sl[other].n.substringBeforeLast('.') else "Primero elige Link local"){if(linked)switchTo(other) else{t("Primero elige Link local");resumeAll()}}
  add("Captura de pantalla",null){shot();resumeAll()}
  add("Reiniciar",null){sure(if(linked)"¿Reiniciar el juego "+(cur+1)+"?" else "¿Reiniciar el juego?"){Native.reset(cur);resumeAll()}}
  if(linked){
   add("Cerrar todos","Sales de los dos juegos"){sure("¿Cerrar los dos juegos?"){finish()}}
   add("Cerrar esta instancia","Cierra el juego "+(cur+1)+" y sigues con el "+(other+1)){sure("¿Cerrar el juego "+(cur+1)+"?"){closeThis()}}
  } else add("Salir",null){sure("¿Salir del juego?"){finish()}}
  add("Cerrar",null){resumeAll()}
  Sheet.show(this,null,o,sb,{i->ac[i]()},{resumeAll()})}
 /** Alterna entre las dos consolas del Link local: cambia lo que se ve y lo que suena, y los controles pasan a la otra. La que no se ve sigue corriendo (el cable lo exige). */
 private fun switchTo(k:Int){
  if(!linked||k==cur||!sl[k].on){resumeAll();return}
  Native.keys(cur,0);cur=k;Native.act=k;applyLayout();send();gl.requestRender()
  t("Juego "+(k+1)+": "+S.n.substringBeforeLast('.'));resumeAll()}
 /** Menú sencillo de Link local: el mismo juego otra vez, u otro de la biblioteca. */
 private fun linkMenu(){modal=true;
  Sheet.show(this,"Link local",listOf("Mismo juego","Otro juego de la biblioteca"),listOf(S.n.substringBeforeLast('.')+" en las dos consolas","Elige uno de tu biblioteca (misma consola)"),
   {i->if(i==0)startLink(S.u,S.n) else{leaving=true;startActivityForResult(Intent(this,LibraryActivity::class.java).putExtra("pick",true).putExtra("plat",if(S.sys==LSys.GB)0 else 2).putExtra("ttl","Elige el juego 2"),77)}},{resumeAll()})}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){super.onActivityResult(rq,rs,d)
  if(rq==77&&rs==RESULT_OK&&d!=null){val u=d.getStringExtra("u");val n=d.getStringExtra("n");if(u!=null&&n!=null)startLink(u,n)}}
 /** Abre el segundo juego en la otra consola y las une. Si es el mismo juego, la segunda consola usa su propio guardado (juego.link2.sav, vacío la primera vez). */
 private fun startLink(u2:String,n2:String){
  if(linked||sl[1-cur].on){resumeAll();return}
  val me=cur;val k=1-me;val same=(u2==sl[me].u);val b0=sl[me].base;t("Abriendo el juego 2…")
  Thread{
   val r=try{Roms.load(this,u2,n2)}catch(e:Exception){null};Roms.patchMsg?.let{ui(it)};Roms.patchErr?.let{showErr("No se pudo aplicar el parche",it)}
   if(r==null){ui("No se pudo abrir el juego");runOnUiThread{resumeAll()};return@Thread}
   val x=sl[k];x.u=u2;x.n=n2;x.base=n2.substringBeforeLast('.');x.sys=Layouts.sysFor(this,u2,n2);x.rom=r.first;x.gid=GameId.of(r.second,r.first);x.priv=same
   val sf=if(same)File(getExternalFilesDir("saves"),b0+".link2.sav") else SaveSync.file(this,n2,r.first)
   if(!em[k].start(r.second,r.first,sf,false)){val er=Native.lastError();if(er.isNotEmpty())runOnUiThread{AlertDialog.Builder(this).setTitle("Error del segundo núcleo").setMessage(er).setPositiveButton("Aceptar",null).show()};val f=File(applicationInfo.nativeLibraryDir,"libmgba2_libretro.so");ui(if(!f.exists())"El APK no incluye el segundo núcleo (libmgba2_libretro.so): mira el paso «Segundo núcleo» del workflow" else "No se pudo cargar el segundo núcleo");runOnUiThread{resumeAll()};return@Thread}
   x.on=true
   syncLinkSlots() // mete aquí los guardados sueltos previos de cualquiera de las dos consolas, antes de que la UI pueda tocar las ranuras
   runOnUiThread{
    pauseAll() // el cable se conecta con las dos consolas paradas (onResume pudo reanudar la primera mientras se cargaba la ROM)
    val rc=Native.linkStart()
    if(rc<0){em[k].stop();x.on=false;t("No se pudo conectar el cable (error "+rc+")");resumeAll();return@runOnUiThread}
    linked=true;Native.lnk=(rc==1);applyCheats(k)
    t(if(rc==1)"Link local activo: juego 1 y juego 2" else "Abierto SIN cable: solo hay cable entre dos juegos de GBA, o entre dos de GB/GBC, y con el módulo de link en el núcleo")
    resumeAll()}}.start()}
 /** Cierra solo la consola que se está viendo y sigues con la otra (ya sin Link local: estados y trucos vuelven a funcionar). */
 private fun closeThis(){
  if(!linked){finish();return}
  val k=cur;val o=1-k
  pauseAll();Native.keys(k,0);Native.linkStop();Native.lnk=false // el cable se corta antes de descargar la consola
  em[k].stop();syncOut(k);sl[k].on=false;sl[k].priv=false
  linked=false;cur=o;Native.act=o;applyLayout();send();gl.requestRender()
  t("Instancia cerrada. Sigues en el juego "+(o+1));resumeAll()}
 /** Pide confirmación si «Confirmar al cerrar/reiniciar» está activo; al cancelar el juego continúa. */
 private fun sure(m:String,ok:()->Unit){if(!getSharedPreferences("c",0).getBoolean("confirm",false)){ok();return};modal=true
  AlertDialog.Builder(this).setMessage(m).setPositiveButton("Aceptar"){_,_->ok()}.setNegativeButton("Cancelar"){_,_->resumeAll()}.setOnCancelListener{resumeAll()}.show()}
 /** «Guardar» muestra las 10 ranuras (las vacías como huecos); «Cargar» solo las que tienen estado. */
 private fun slots(save:Boolean){modal=true
  val all=StateStore.all(this,skey())
  if(!save&&all.none{it.exists}){t("No hay estados guardados");resumeAll();return}
  StateSheet.show(this,save,all,{s->if(linked)linkState(save,s.n) else{if(save)saveTo(s.n) else loadFrom(s.n);resumeAll()}},
   {s->if(StateStore.delete(s))ui("Estado eliminado ("+StateStore.title(s.n)+")") else ui("No se pudo eliminar");slots(save)},
   {s,to->if(StateStore.duplicate(s,to))card("Estado duplicado",StateStore.title(s.n)+" → "+StateStore.title(to.n),StateStore.thumbOf(to)) else ui("No se pudo duplicar");slots(save)},{resumeAll()})}
 private fun shot(){
  val bm=grab();if(bm==null){t("No hay imagen que capturar");return}
  val sc=Bitmap.createScaledBitmap(bm,bm.width*3,bm.height*3,false);val name=base+"_"+System.currentTimeMillis()+".png"
  try{if(Build.VERSION.SDK_INT>=29){val cv=ContentValues().apply{put(MediaStore.MediaColumns.DISPLAY_NAME,name);put(MediaStore.MediaColumns.MIME_TYPE,"image/png");put(MediaStore.MediaColumns.RELATIVE_PATH,"Pictures/Cirilo")}
    contentResolver.openOutputStream(contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv)!!)!!.use{sc.compress(Bitmap.CompressFormat.PNG,100,it)}}
   else File(getExternalFilesDir("screenshots"),name).outputStream().use{sc.compress(Bitmap.CompressFormat.PNG,100,it)}
   t("Captura guardada")}catch(e:Exception){t("No se pudo guardar la captura")}}
 private fun bit(k:Int)=when(k){KeyEvent.KEYCODE_DPAD_UP->4;KeyEvent.KEYCODE_DPAD_DOWN->5;KeyEvent.KEYCODE_DPAD_LEFT->6;KeyEvent.KEYCODE_DPAD_RIGHT->7
  KeyEvent.KEYCODE_BUTTON_A->8;KeyEvent.KEYCODE_BUTTON_B->0;KeyEvent.KEYCODE_BUTTON_START->3;KeyEvent.KEYCODE_BUTTON_SELECT->2;KeyEvent.KEYCODE_BUTTON_L1->10;KeyEvent.KEYCODE_BUTTON_R1->11;else->-1}
 override fun onKeyDown(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyDown(k,e);hw=hw or(1 shl b);send();return true}
 override fun onKeyUp(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyUp(k,e);hw=hw and(1 shl b).inv();send();return true}
 override fun onBackPressed(){menu()}
 override fun onPause(){super.onPause();fg=false;focusResume?.let{uiH.removeCallbacks(it)};focusResume=null;gl.onPause();pauseAll();if(!linked&&getSharedPreferences("c",0).getBoolean("auto",false))emu.snap(autoFile());syncAll()}
 override fun onResume(){super.onResume();gl.onResume();applyPrefs();for(k in 0..1)if(sl[k].on)applyCheats(k);fg=true
  if(leaving){leaving=false;resumeAll()} else if(!modal)resumeAll()}
 override fun onDestroy(){super.onDestroy();focusResume?.let{uiH.removeCallbacks(it)};pauseAll();Native.linkStop();Native.lnk=false;em.forEach{it.stop()};Native.pgoDump(0);Native.pgoDump(1);syncAll()}
}
