package app.cirilo
import android.app.*
import android.content.*
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.*
import java.io.File
import java.nio.*
import java.text.SimpleDateFormat
import java.util.*
/** Escena de juego. El control «Menú» del layout (o atrás) abre la hoja de opciones (no hay botón MENÚ fijo); los ajustes se leen de las preferencias «c». */
class GameActivity:Activity(){
 /** Una consola abierta en esta pantalla. Sin Link local solo existe la 0; con Link local, la 0 y la 1 (el cable las une). priv = guardado propio (juego.link2.sav): no se sincroniza con My Boy! ni Drive. */
 private class Sl{var u="";var n="";var base="";@Volatile var gid:GameInfo?=null;var rom="";var sys=LSys.GBA;@Volatile var on=false;var priv=false}
 private val em=arrayOf(Emu(0),Emu(1));private val sl=arrayOf(Sl(),Sl());@Volatile private var cur=0;@Volatile private var linked=false
 private val emu get()=em[cur];private val st get()=if(Native.lnk)em[0] else em[cur] /* con cable los fps son los del hilo de la consola 0 */;private val S get()=sl[cur]
 private lateinit var gl:GLView;private lateinit var tv:TextView
 // lo que ya existía (juego, ROM, SHA-1 para los trucos, consola del layout) ahora es el de la consola que se está viendo
 private val base get()=S.base;private val gid get()=S.gid;private val gname get()=S.n;private val romName get()=S.rom;private val gsys get()=S.sys
 /** Sube el guardado compartido por SAF de la consola k (si usa su guardado normal) y, si toca, a Drive. */
 private fun syncOut(k:Int=cur){val x=sl[k];if(x.rom.isNotEmpty()&&!x.priv){SaveSync.push(this,x.n,x.rom);if(getSharedPreferences("c",0).getBoolean("gd_change",false))DriveSync.async(this,setOf(SaveSync.keyOf(x.n)),SaveSync.srcOf(x.rom),x.gid?.let{setOf(it.id)})}}
 private fun syncAll(){for(k in 0..1)if(sl[k].on)syncOut(k)}
 private lateinit var rootV:FrameLayout;private lateinit var padV:Pad;private var pad=0;private var hw=0;private var ffHold=false;private var fs=true;private var imm=true
 private fun autoFile()=File(getExternalFilesDir("states"),base+".auto.state")
 private fun send()=Native.keys(cur,pad or hw)
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun slot(n:Int)=StateStore.slot(this,base,n) // 0 = rápido, 1..9 = ranuras (estado + miniatura, ver StateStore)
 override fun onCreate(b:Bundle?){
  super.onCreate(b);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);try{window.setSustainedPerformanceMode(true)}catch(e:Exception){}
  val n=intent.getStringExtra("n")?:"";val u=intent.getStringExtra("u")?:"";Native.libDir(applicationInfo.nativeLibraryDir);Native.act=0;cur=0;linked=false;sl[0].u=u;sl[0].n=n;sl[0].base=n.substringBeforeLast('.');sl[0].sys=Layouts.sysFor(this,u,n)
  gl=GLView(this);val root=FrameLayout(this);rootV=root;root.setBackgroundColor(0xFF000000.toInt());root.addView(gl)
  padV=Pad(this,{pad=it;send()},{id,d->action(id,d)});root.addView(padV);em[0].onFrame={if(Native.act==0||Native.lnk)gl.requestRender()};em[1].onFrame={if(Native.act==1)gl.requestRender()} // con cable el hilo de la consola 0 mueve las dos: dibuja la que se vea
  tv=TextView(this).apply{setTextColor(0xFF00FF00.toInt());textSize=14f;setShadowLayer(3f,0f,0f,0xFF000000.toInt());setPadding(16,8,16,8)}
  root.addView(tv,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.START))
  val hd=Handler(Looper.getMainLooper());hd.post(object:Runnable{override fun run(){if(tv.visibility==View.VISIBLE)tv.text="%.1f".format(st.fps)+" fps / "+"%.1f".format(st.ms)+" ms"+(if(st.skip>0)" (salto "+st.skip+")" else "")+(if(Native.lnk)" | "+Native.linkDbg()+" | "+st.aud else "")+(if(emu.ff)" x"+emu.ffSpeed.let{if(it==it.toInt().toDouble())it.toInt().toString() else it.toString()}+(if(st.fps<emu.ffSpeed*59.7275*0.9)" (real x%.1f)".format(st.fps/59.7275) else "") else "")+Native.profDbg().let{if(it.isEmpty())"" else "\n"+it}+(if(st.prof.isEmpty())"" else "\n"+st.prof);hd.postDelayed(this,500)}})
  setContentView(root);applyPrefs()
  Thread{val r=Roms.load(this,u,n);sl[0].rom=r?.first?:"";sl[0].gid=r?.let{GameId.of(it.second,it.first)}
   if(r!=null&&getSharedPreferences("c",0).getBoolean("gd_start",false))DriveSync.syncNow(this,setOf(SaveSync.keyOf(n)),SaveSync.srcOf(r.first),gid?.let{setOf(it.id)}) // baja lo último de Drive antes de cargar el guardado
   val sf=if(r!=null)SaveSync.file(this,n,r.first) else null
   if(r!=null&&sf!=null&&SaveSync.fellBack(this,n,r.first,sf))ui("Guardado compartido no disponible (¿Shizuku detenida?): se usa el de Cirilo")
   if(r==null||sf==null||!em[0].start(r.second,r.first,sf))runOnUiThread{t("No se pudo abrir el juego");finish()} else{
    sl[0].on=true;applyCheats(0)
    val af=autoFile();if(getSharedPreferences("c",0).getBoolean("auto",false)&&af.exists())em[0].post{try{Native.loadState(0,af.readBytes())}catch(e:Exception){}}
    Lib.all(this).firstOrNull{it.u==u}?.let{Lib.upd(this,listOf(it.copy(played=System.currentTimeMillis())))}}}.start()}
 /** Sustituye los trucos del núcleo por los activos de este juego (un set por truco, con su formato). Se ejecuta en el hilo del emulador, entre fotogramas, sin reiniciar el juego; respeta Ajustes → «Activar trucos».
  *  Los que mGBA no acepta se guardan (CheatStore.status) para marcarlos en la lista de Trucos; el aviso emergente solo sale cuando aparece un fallo nuevo. */
 private fun applyCheats(k:Int=cur){val g=sl[k].gid?:return;val on=getSharedPreferences("c",0).getBoolean("cheats",true)
  val l=if(on)CheatStore.active(this,g) else emptyList()
  em[if(Native.lnk&&k==1)0 else k].post{val st=Native.cheatApply(k,l.map{it.mode}.toIntArray(),l.map{it.text}.toTypedArray())
   if(st.any{it==-9999})ui("El núcleo no incluye el módulo de trucos: recompila con el workflow actualizado") else{
    val old=CheatStore.status(this,g.id);val now=HashMap<String,Int>();l.forEachIndexed{i,c->if(st[i]<0)now[c.id]=st[i]}
    CheatStore.setStatus(this,g.id,now);val fresh=now.keys.count{it !in old}
    if(fresh>0)ui(if(fresh==1)"1 truco no se pudo aplicar. Míralo en Trucos" else fresh.toString()+" trucos no se pudieron aplicar. Míralos en Trucos")}}}
 private fun applyPrefs(){applyLayout();val p=getSharedPreferences("c",0)
  gl.stretch=p.getBoolean("stretch",false);gl.size=p.getInt("size",100);gl.linear=p.getBoolean("linear",false)
  val sn=p.getString("shader","")?:"";gl.shader=if(sn.isEmpty())null else Shaders.list(this).firstOrNull{it.name==sn}
  tv.visibility=if(p.getBoolean("fps",false))View.VISIBLE else View.GONE;padV.cheatsOn=p.getBoolean("cheats",true)
  em.forEach{it.maxSkip=p.getInt("skip",2);it.ffSpeed=p.getInt("ffs",40)/10.0};ffHold=p.getInt("ffm",0)==1;fs=p.getBoolean("full",true);imm=p.getBoolean("imm",true);applySystemUi();em.forEach{it.rate=p.getInt("freq",48000);it.vol=if(p.getBoolean("snd",true))p.getInt("vol",100) else 0}
  requestedOrientation=when(p.getInt("orient",0)){1->ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;2->ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;else->ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED}
  gl.requestRender()}
 /** Pantalla completa (barra de estado) e inmersivo (barra de navegación), según Ajustes → Misceláneo. */
 @Suppress("DEPRECATION") private fun applySystemUi(){
  if(fs)window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN) else window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
  var f=0;if(fs)f=f or View.SYSTEM_UI_FLAG_FULLSCREEN
  if(imm)f=f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
  window.decorView.systemUiVisibility=f}
 override fun onWindowFocusChanged(h:Boolean){super.onWindowFocusChanged(h);if(h)applySystemUi()}
 /** Layout activo para la orientación actual: controles y posición de la pantalla del juego. */
 private fun applyLayout(){val land=resources.configuration.orientation==Configuration.ORIENTATION_LANDSCAPE;val L=Layouts.load(this).cur(gsys);val cl=if(land)L.l else L.p
  padV.list=cl;val sc=cl.firstOrNull{it.t=="screen"};gl.sx=sc?.x?:.5f;gl.sy=sc?.y?:-1f;gl.ss=sc?.s?:1f;gl.sm=sc?.m?:0;gl.sa=sc?.a?:0f}
 override fun onConfigurationChanged(c:Configuration){super.onConfigurationChanged(c);applyLayout();gl.requestRender()}
 private fun ui(s:String)=runOnUiThread{t(s)}
 /** Guardado/carga rápidos = la ranura «Rápido» del menú; se ejecutan en el hilo del emulador entre fotogramas. */
 private fun quick(save:Boolean){if(linked){ui(NOSTATE);return};emu.post{if(save)saveTo(0) else loadFrom(0)}}
 /** Fotograma actual del núcleo (RGB565) como imagen; null si todavía no ha dibujado ninguno. Sirve para las capturas y para las miniaturas de los estados. */
 private fun grab():Bitmap?{val bb=ByteBuffer.allocateDirect(256*224*2).order(ByteOrder.nativeOrder());val r=Native.last(cur,bb);if(r==0)return null
  val w=r ushr 16;val h=r and 0xffff;val bm=Bitmap.createBitmap(w,h,Bitmap.Config.RGB_565);bb.position(0);bm.copyPixelsFromBuffer(bb);return bm}
 /** Aviso con miniatura (StateToast) sobre la escena del juego; se puede llamar desde cualquier hilo. */
 private fun card(title:String,sub:String,thumb:Bitmap?)=runOnUiThread{if(StateToast.enabled(this))StateToast.show(this,rootV,thumb,title,sub)}
 /** Guarda el estado en la ranura n junto con una miniatura tomada en ese mismo instante. Solo con el emulador parado o desde su hilo (entre fotogramas). */
 private fun saveTo(n:Int){
  val data=Native.saveState(cur);if(data==null){ui("No se pudo guardar");return}
  val th=grab()?.let{StateStore.thumb(it)}
  if(StateStore.save(slot(n),data,th))card("Estado guardado",StateStore.title(n),th) else ui("No se pudo guardar")}
 /** Carga la ranura n. Mismas condiciones de hilo que saveTo. */
 private fun loadFrom(n:Int){val s=slot(n)
  if(!s.exists){ui(if(n==0)"No hay estado rápido" else "Esa ranura está vacía");return}
  val ok=try{Native.loadState(cur,s.state.readBytes())}catch(e:Exception){false}
  if(ok)card("Estado cargado",StateStore.title(n),StateStore.thumbOf(s)) else ui("No se pudo cargar")}
 private fun action(id:String,down:Boolean){when(id){"qsave"->quick(true);"qload"->quick(false);"ff"->if(ffHold)setFf(down) else if(down)setFf(!emu.ff);"shot"->shot();"cheats"->toggleCheats();"menu"->menu()}}
 /** Botón «Trucos» del layout: alterna el interruptor general (Ajustes → Activar trucos) y lo aplica al instante. */
 private fun toggleCheats(){val p=getSharedPreferences("c",0);val on=!p.getBoolean("cheats",true);p.edit().putBoolean("cheats",on).apply();padV.cheatsOn=on;applyCheats()
  val n=gid?.let{g->CheatStore.list(this,g.id).count{it.enabled}}?:0
  t(if(!on)"Trucos desactivados" else if(n>0)"Trucos activados ("+n+")" else "Trucos activados, pero ninguno está marcado")}
/** Pausa/reanuda las dos consolas. Pausar es en dos fases (primero se pide parar a las dos, luego se espera a cada hilo) y con el cable se avisa antes: así ninguna se queda esperando a la otra dentro de retro_run. */
 private fun pauseAll(){em.forEach{it.halt()};Native.linkInterrupt(true);em.forEach{it.pause()};Native.linkInterrupt(false)}
 private fun resumeAll(){em.forEach{it.resume()}}
 /** El avance rápido vale para las dos consolas a la vez (si no, la que va despacio retendría a la otra por el cable). */
 private fun setFf(v:Boolean){em.forEach{it.ff=v}}
 private val NOSTATE="Los estados no están disponibles con Link local"
 private fun menu(){pauseAll()
  val cn=gid?.let{g->CheatStore.list(this,g.id).count{it.enabled}}?:0;val con=getSharedPreferences("c",0).getBoolean("cheats",true)
  val o=ArrayList<String>();val sb=ArrayList<String?>();val ac=ArrayList<()->Unit>()
  fun add(t:String,s:String?,f:()->Unit){o+=t;sb+=s;ac+=f}
  val other=1-cur
  add("Cargar",if(linked)"No disponible con Link local" else null){if(linked){t(NOSTATE);resumeAll()} else slots(false)}
  add("Guardar",if(linked)"No disponible con Link local" else null){if(linked){t(NOSTATE);resumeAll()} else slots(true)}
  add("Avance rápido"+(if(emu.ff)": sí" else ""),null){setFf(!emu.ff);resumeAll()}
  add("Trucos"+(if(cn>0)" ("+cn+")" else ""),if(cn>0&&!con)"Desactivados en Ajustes" else null){val g=gid;if(g==null){t("El juego aún se está cargando");resumeAll()} else startActivity(CheatsActivity.intent(this,g))}
  add("Ajustes",null){startActivity(Intent(this,SettingsActivity::class.java))}
  add("Link remoto",null){t("Próximamente");resumeAll()}
  add("Link local",if(linked)"Activo · ahora ves el juego "+(cur+1)+" de 2" else null){if(linked){t("Link local ya está activo");resumeAll()} else linkMenu()}
  // solo se activa después de elegir Link local: alterna entre el juego 1 y el juego 2
  add("Cambiar al juego "+(other+1),if(linked)sl[other].n.substringBeforeLast('.') else "Primero elige Link local"){if(linked)switchTo(other) else{t("Primero elige Link local");resumeAll()}}
  add("Captura de pantalla",null){shot();resumeAll()}
  add("Reiniciar",null){sure(if(linked)"¿Reiniciar el juego "+(cur+1)+"?" else "¿Reiniciar el juego?"){Native.reset(cur);resumeAll()}}
  if(linked){
   add("Cerrar todos","Sales de los dos juegos"){sure("¿Cerrar los dos juegos?"){finish()}}
   add("Cerrar esta instancia","Cierra el juego "+(cur+1)+" y sigues con el "+(other+1)){sure("¿Cerrar el juego "+(cur+1)+"?"){closeThis()}}
  } else add("Salir",null){sure("¿Salir del juego?"){finish()}}
  add("Cerrar",null){resumeAll()}
  Sheet.show(this,null,o,sb,{i->ac[i]()},{resumeAll()})}
 /** Alterna entre las dos consolas del Link local: cambia lo que se ve y lo que suena, y los controles pasan a la otra. La que no se ve sigue corriendo (el cable lo exige). */
 private fun switchTo(k:Int){
  if(!linked||k==cur||!sl[k].on){resumeAll();return}
  Native.keys(cur,0);cur=k;Native.act=k;applyLayout();send();gl.requestRender()
  t("Juego "+(k+1)+": "+S.n.substringBeforeLast('.'));resumeAll()}
 /** Menú sencillo de Link local: el mismo juego otra vez, u otro de la biblioteca. */
 private fun linkMenu(){
  Sheet.show(this,"Link local",listOf("Mismo juego","Otro juego de la biblioteca"),listOf(S.n.substringBeforeLast('.')+" en las dos consolas","Elige uno de tu biblioteca (misma consola)"),
   {i->if(i==0)startLink(S.u,S.n) else startActivityForResult(Intent(this,LibraryActivity::class.java).putExtra("pick",true).putExtra("plat",if(S.sys==LSys.GB)0 else 2).putExtra("ttl","Elige el juego 2"),77)},{resumeAll()})}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){super.onActivityResult(rq,rs,d)
  if(rq==77&&rs==RESULT_OK&&d!=null){val u=d.getStringExtra("u");val n=d.getStringExtra("n");if(u!=null&&n!=null)startLink(u,n)}}
 /** Abre el segundo juego en la otra consola y las une. Si es el mismo juego, la segunda consola usa su propio guardado (juego.link2.sav, vacío la primera vez). */
 private fun startLink(u2:String,n2:String){
  if(linked||sl[1-cur].on){resumeAll();return}
  val me=cur;val k=1-me;val same=(u2==sl[me].u);val b0=sl[me].base;t("Abriendo el juego 2…")
  Thread{
   val r=try{Roms.load(this,u2,n2)}catch(e:Exception){null}
   if(r==null){ui("No se pudo abrir el juego");runOnUiThread{resumeAll()};return@Thread}
   val x=sl[k];x.u=u2;x.n=n2;x.base=n2.substringBeforeLast('.');x.sys=Layouts.sysFor(this,u2,n2);x.rom=r.first;x.gid=GameId.of(r.second,r.first);x.priv=same
   val sf=if(same)File(getExternalFilesDir("saves"),b0+".link2.sav") else SaveSync.file(this,n2,r.first)
   if(!em[k].start(r.second,r.first,sf,false)){val er=Native.lastError();if(er.isNotEmpty())runOnUiThread{AlertDialog.Builder(this).setTitle("Error del segundo núcleo").setMessage(er).setPositiveButton("Aceptar",null).show()};val f=File(applicationInfo.nativeLibraryDir,"libmgba2_libretro.so");ui(if(!f.exists())"El APK no incluye el segundo núcleo (libmgba2_libretro.so): mira el paso «Segundo núcleo» del workflow" else "No se pudo cargar el segundo núcleo");runOnUiThread{resumeAll()};return@Thread}
   x.on=true
   runOnUiThread{
    pauseAll() // el cable se conecta con las dos consolas paradas (onResume pudo reanudar la primera mientras se cargaba la ROM)
    val rc=Native.linkStart()
    if(rc<0){em[k].stop();x.on=false;t("No se pudo conectar el cable (error "+rc+")");resumeAll();return@runOnUiThread}
    linked=true;Native.lnk=(rc==1);applyCheats(k)
    t(if(rc==1)"Link local activo: juego 1 y juego 2" else "Abierto SIN cable: solo hay cable para juegos de GBA y con el módulo de link en el núcleo")
    resumeAll()}}.start()}
 /** Cierra solo la consola que se está viendo y sigues con la otra (ya sin Link local: estados y trucos vuelven a funcionar). */
 private fun closeThis(){
  if(!linked){finish();return}
  val k=cur;val o=1-k
  pauseAll();Native.keys(k,0);Native.linkStop();Native.lnk=false // el cable se corta antes de descargar la consola
  em[k].stop();syncOut(k);sl[k].on=false;sl[k].priv=false
  linked=false;cur=o;Native.act=o;applyLayout();send();gl.requestRender()
  t("Instancia cerrada. Sigues en el juego "+(o+1));resumeAll()}
 /** Pide confirmación si «Confirmar al cerrar/reiniciar» está activo; al cancelar el juego continúa. */
 private fun sure(m:String,ok:()->Unit){if(!getSharedPreferences("c",0).getBoolean("confirm",false)){ok();return}
  AlertDialog.Builder(this).setMessage(m).setPositiveButton("Aceptar"){_,_->ok()}.setNegativeButton("Cancelar"){_,_->resumeAll()}.setOnCancelListener{resumeAll()}.show()}
 /** «Guardar» muestra las 10 ranuras (las vacías como huecos); «Cargar» solo las que tienen estado. */
 private fun slots(save:Boolean){
  val all=StateStore.all(this,base)
  if(!save&&all.none{it.exists}){t("No hay estados guardados");resumeAll();return}
  StateSheet.show(this,save,all,{s->if(save)saveTo(s.n) else loadFrom(s.n);resumeAll()},
   {s->if(StateStore.delete(s))ui("Estado eliminado ("+StateStore.title(s.n)+")") else ui("No se pudo eliminar");slots(save)},
   {s,to->if(StateStore.duplicate(s,to))card("Estado duplicado",StateStore.title(s.n)+" → "+StateStore.title(to.n),StateStore.thumbOf(to)) else ui("No se pudo duplicar");slots(save)},{resumeAll()})}
 private fun shot(){
  val bm=grab();if(bm==null){t("No hay imagen que capturar");return}
  val sc=Bitmap.createScaledBitmap(bm,bm.width*3,bm.height*3,false);val name=base+"_"+System.currentTimeMillis()+".png"
  try{if(Build.VERSION.SDK_INT>=29){val cv=ContentValues().apply{put(MediaStore.MediaColumns.DISPLAY_NAME,name);put(MediaStore.MediaColumns.MIME_TYPE,"image/png");put(MediaStore.MediaColumns.RELATIVE_PATH,"Pictures/Cirilo")}
    contentResolver.openOutputStream(contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv)!!)!!.use{sc.compress(Bitmap.CompressFormat.PNG,100,it)}}
   else File(getExternalFilesDir("screenshots"),name).outputStream().use{sc.compress(Bitmap.CompressFormat.PNG,100,it)}
   t("Captura guardada")}catch(e:Exception){t("No se pudo guardar la captura")}}
 private fun bit(k:Int)=when(k){KeyEvent.KEYCODE_DPAD_UP->4;KeyEvent.KEYCODE_DPAD_DOWN->5;KeyEvent.KEYCODE_DPAD_LEFT->6;KeyEvent.KEYCODE_DPAD_RIGHT->7
  KeyEvent.KEYCODE_BUTTON_A->8;KeyEvent.KEYCODE_BUTTON_B->0;KeyEvent.KEYCODE_BUTTON_START->3;KeyEvent.KEYCODE_BUTTON_SELECT->2;KeyEvent.KEYCODE_BUTTON_L1->10;KeyEvent.KEYCODE_BUTTON_R1->11;else->-1}
 override fun onKeyDown(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyDown(k,e);hw=hw or(1 shl b);send();return true}
 override fun onKeyUp(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyUp(k,e);hw=hw and(1 shl b).inv();send();return true}
 override fun onBackPressed(){menu()}
 override fun onPause(){super.onPause();gl.onPause();pauseAll();if(!linked&&getSharedPreferences("c",0).getBoolean("auto",false))emu.snap(autoFile());syncAll()}
 override fun onResume(){super.onResume();gl.onResume();applyPrefs();for(k in 0..1)if(sl[k].on)applyCheats(k);resumeAll()}
 override fun onDestroy(){super.onDestroy();pauseAll();Native.linkStop();Native.lnk=false;em.forEach{it.stop()};syncAll()}
}
