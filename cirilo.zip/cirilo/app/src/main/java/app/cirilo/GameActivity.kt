package app.cirilo
import android.app.*
import android.os.*
import android.view.*
import android.widget.*
import java.io.File
/** Escena de juego. Botón MENÚ (o el botón atrás): reiniciar, guardar/cargar estado, avance rápido, shaders, FPS, ajustes y salir. */
class GameActivity:Activity(){
 private val emu=Emu();private lateinit var gl:GLView;private lateinit var tv:TextView;private lateinit var base:String
 private var pad=0;private var hw=0;private var idx=0
 private fun send()=Native.keys(pad or hw)
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun sf()=File(getExternalFilesDir("states"),base+".state")
 override fun onCreate(b:Bundle?){
  super.onCreate(b);window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);try{window.setSustainedPerformanceMode(true)}catch(e:Exception){}
  val n=intent.getStringExtra("n")?:"";val u=intent.getStringExtra("u")?:"";base=n.substringBeforeLast('.')
  gl=GLView(this);val root=FrameLayout(this);root.setBackgroundColor(0xFF000000.toInt());root.addView(gl)
  root.addView(Pad(this){pad=it;send()})
  val pr=getSharedPreferences("c",0);emu.onFrame={gl.requestRender()}
  tv=TextView(this).apply{setTextColor(0xFF00FF00.toInt());textSize=14f;setShadowLayer(3f,0f,0f,0xFF000000.toInt());setPadding(16,8,16,8);visibility=if(pr.getBoolean("fps",false))View.VISIBLE else View.GONE}
  root.addView(tv,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.START))
  root.addView(Button(this).apply{text="MENÚ";alpha=.7f;setOnClickListener{menu()}},FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.END))
  val hd=Handler(Looper.getMainLooper());hd.post(object:Runnable{override fun run(){if(tv.visibility==View.VISIBLE)tv.text=""+emu.fps+" fps / "+"%.1f".format(emu.ms)+" ms"+(if(emu.skip>0)" (salto "+emu.skip+")" else "")+(if(emu.ff)" x4" else "");hd.postDelayed(this,500)}})
  setContentView(root)
  Thread{val r=Roms.load(this,u,n)
   if(r==null||!emu.start(r.second,r.first,File(getExternalFilesDir("saves"),base+".sav")))runOnUiThread{t("No se pudo abrir el juego");finish()}}.start()}
 private fun menu(){emu.pause()
  val pr=getSharedPreferences("c",0)
  val it=arrayOf("Continuar","Reiniciar","Guardar estado","Cargar estado","Avance rápido: "+(if(emu.ff)"sí" else "no"),"Shaders","FPS: "+(if(tv.visibility==View.VISIBLE)"sí" else "no"),"Ajustes","Salir")
  AlertDialog.Builder(this).setItems(it){_,i->when(i){
   1->{Native.reset();emu.resume()}
   2->{Native.saveState()?.let{sf().writeBytes(it);t("Estado guardado")}?:t("No se pudo guardar");emu.resume()}
   3->{if(sf().exists())t(if(Native.loadState(sf().readBytes()))"Estado cargado" else "No se pudo cargar") else t("No hay estado guardado");emu.resume()}
   4->{emu.ff=!emu.ff;emu.resume()}
   5->shaders()
   6->{val on=tv.visibility!=View.VISIBLE;tv.visibility=if(on)View.VISIBLE else View.GONE;pr.edit().putBoolean("fps",on).apply();emu.resume()}
   7->AlertDialog.Builder(this).setTitle("Ajustes").setMessage("Por ahora está vacío.").setPositiveButton("Cerrar",null).setOnDismissListener{emu.resume()}.show()
   8->finish()
   else->emu.resume()}}.setOnCancelListener{emu.resume()}.show()}
 private fun shaders(){val l=Shaders.list(this)
  val names=l.map{it.name}.toMutableList();if(!Shaders.installed(this))names+="(Instala «Emulator Shaders» para tener más)"
  AlertDialog.Builder(this).setSingleChoiceItems(names.toTypedArray(),idx){d,i->if(i<l.size){idx=i;gl.shader=l[i].takeIf{i>0};gl.requestRender()};d.dismiss()}.setOnDismissListener{emu.resume()}.show()}
 private fun bit(k:Int)=when(k){KeyEvent.KEYCODE_DPAD_UP->4;KeyEvent.KEYCODE_DPAD_DOWN->5;KeyEvent.KEYCODE_DPAD_LEFT->6;KeyEvent.KEYCODE_DPAD_RIGHT->7
  KeyEvent.KEYCODE_BUTTON_A->8;KeyEvent.KEYCODE_BUTTON_B->0;KeyEvent.KEYCODE_BUTTON_START->3;KeyEvent.KEYCODE_BUTTON_SELECT->2;KeyEvent.KEYCODE_BUTTON_L1->10;KeyEvent.KEYCODE_BUTTON_R1->11;else->-1}
 override fun onKeyDown(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyDown(k,e);hw=hw or(1 shl b);send();return true}
 override fun onKeyUp(k:Int,e:KeyEvent):Boolean{val b=bit(k);if(b<0)return super.onKeyUp(k,e);hw=hw and(1 shl b).inv();send();return true}
 override fun onBackPressed(){menu()}
 override fun onPause(){super.onPause();gl.onPause();emu.pause()}
 override fun onResume(){super.onResume();gl.onResume();emu.resume()}
 override fun onDestroy(){super.onDestroy();emu.stop()}
}
