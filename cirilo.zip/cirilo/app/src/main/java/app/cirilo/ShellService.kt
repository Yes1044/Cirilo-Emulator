package app.cirilo
import java.io.File
/** Corre en el proceso de Shizuku (uid shell). No usar Context ni nada de la app aquí. */
class ShellService:IShell.Stub(){
 override fun destroy(){System.exit(0)}
 override fun list(dir:String):Array<String> = File(dir).listFiles()?.filter{it.isFile&&it.name.endsWith(".sav",true)}?.map{it.name+"\t"+it.lastModified()}?.toTypedArray()?:emptyArray()
 override fun read(path:String):ByteArray? = try{File(path).readBytes()}catch(e:Exception){null}
 override fun write(path:String,data:ByteArray):Boolean = try{File(path).writeBytes(data);true}catch(e:Exception){false}
 override fun delete(path:String):Boolean = try{File(path).delete()}catch(e:Exception){false}
 override fun isDir(path:String):Boolean = File(path).isDirectory
}
