package app.cirilo
import android.app.*
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.*
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.*
import android.view.*
import android.widget.*

/** Importar trucos: se pega una lista (o se abre un archivo: RetroArch .cht, mGBA .cheats, texto, respaldo de Cirilo) y debajo aparece lo detectado, con su formato, repetidos, errores y códigos maestros.
 *  Cada truco se marca o desmarca; ✓ importa los marcados (quedan desactivados, salvo los de un respaldo de Cirilo, que conservan su estado). */
class CheatImportActivity:Activity(){
 private class Res(val items:List<ImportItem>,val ign:Int,val note:String)
 private lateinit var g:GameInfo;private lateinit var input:EditText;private lateinit var sum:TextView;private lateinit var res:LinearLayout;private lateinit var okB:ImageView
 private var dn=1f;private var items=listOf<ImportItem>();private val sel=HashMap<Int,Boolean>();private var pick:CheatFormat?=null
 private var ign=0;private var note="";private var gen=0;private var existing=mapOf<String,String>()
 private val hd=Handler(Looper.getMainLooper());private val go=Runnable{analyze()}
 private val accent=0xFF80CBC4.toInt();private val gray=0xFF9E9E9E.toInt();private val warnC=0xFFFFB74D.toInt();private val errC=0xFFEF5350.toInt()
 private fun dp(x:Int)=(x*dn).toInt()
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 companion object{const val OPEN=41;const val MAXN=400
  fun intent(a:Activity,g:GameInfo)=CheatsActivity.intent(a,g).setClass(a,CheatImportActivity::class.java)}
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density;g=CheatsActivity.info(intent)
  existing=CheatStore.list(this,g.id).associate{CheatCodes.key(it.code) to it.name}
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF303030.toInt())
  val head=LinearLayout(this);head.gravity=Gravity.CENTER_VERTICAL;head.setBackgroundColor(0xFF212121.toInt());head.setPadding(dp(16),0,dp(8),0)
  head.addView(TextView(this).apply{text="Importar trucos";setTextColor(-1);textSize=22f;setPadding(0,dp(16),0,dp(16))},LinearLayout.LayoutParams(0,-2,1f))
  okB=ImageView(this).apply{setImageResource(R.drawable.ic_check);setPadding(dp(10),dp(10),dp(10),dp(10));alpha=.4f;setOnClickListener{doImport()}}
  head.addView(okB,LinearLayout.LayoutParams(dp(48),dp(48)))
  val f=LinearLayout(this);f.orientation=LinearLayout.VERTICAL;f.setPadding(dp(16),dp(8),dp(16),dp(24))
  input=EditText(this).apply{hint="Pega aquí la lista de trucos";setHintTextColor(0xFF757575.toInt());setTextColor(-1);typeface=Typeface.MONOSPACE;textSize=14f;minLines=6;maxLines=12;gravity=Gravity.TOP or Gravity.START
   inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
   addTextChangedListener(object:TextWatcher{override fun afterTextChanged(s:Editable?){sel.clear();hd.removeCallbacks(go);hd.postDelayed(go,350)};override fun beforeTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){};override fun onTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){}})}
  f.addView(input,LinearLayout.LayoutParams(-1,-2))
  val br=LinearLayout(this)
  fun btn(t:String,act:()->Unit)=TextView(this).apply{text=t;textSize=14f;setTextColor(accent);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(12),dp(24),dp(12));setOnClickListener{act()}}
  br.addView(btn("PEGAR"){paste()});br.addView(btn("ABRIR ARCHIVO"){openFile()})
  f.addView(br,LinearLayout.LayoutParams(-1,-2))
  sum=TextView(this).apply{textSize=14f;setTextColor(gray);setPadding(0,dp(4),0,dp(8))};f.addView(sum,LinearLayout.LayoutParams(-1,-2))
  res=LinearLayout(this);res.orientation=LinearLayout.VERTICAL;f.addView(res,LinearLayout.LayoutParams(-1,-2))
  col.addView(head);col.addView(ScrollView(this).apply{addView(f)},LinearLayout.LayoutParams(-1,0,1f))
  window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);setContentView(col)
  val t=intent.getStringExtra("text");if(t!=null)input.setText(t) else draw()}
 override fun onDestroy(){super.onDestroy();hd.removeCallbacks(go);gen++}
 override fun onBackPressed(){if(input.text.isNotBlank()&&items.indices.any{picked(it)})Ui.confirm(this,"¿Salir sin importar los trucos?"){finish()} else finish()}

 // ---- entrada ----
 private fun paste(){val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager;val c=cm.primaryClip
  val s=if(c!=null&&c.itemCount>0)c.getItemAt(0).coerceToText(this)?.toString() else null
  if(s==null||s.isBlank())toast("El portapapeles está vacío") else input.setText(s)}
 private fun openFile(){try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),OPEN)}catch(e:Exception){toast("No se pudo abrir el selector de archivos")}}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){super.onActivityResult(rq,rs,d);if(rq!=OPEN||rs!=RESULT_OK)return;val u=d?.data?:return
  Thread{val s=try{readText(u)}catch(e:Exception){null};runOnUiThread{if(s==null)toast("No se pudo leer el archivo") else input.setText(s)}}.start()}
 /** Hasta 500 KB; UTF-8 y, si no lo es, ISO-8859-1 (archivos antiguos). */
 private fun readText(u:Uri):String{return contentResolver.openInputStream(u)!!.use{i->val b=ByteArray(500000);var n=0
  while(n<b.size){val r=i.read(b,n,b.size-n);if(r<0)break;n+=r}
  val s=String(b,0,n,Charsets.UTF_8);if(s.indexOf('\uFFFD')>=0)String(b,0,n,Charsets.ISO_8859_1) else s}}

 // ---- análisis (en segundo plano: el emulador está en pausa, así que el núcleo se puede consultar) ----
 private fun work(t:String,pk:CheatFormat?):Res{var note="";var ds=emptyList<Draft>();var ign=0;val s=t.trim()
  val bk=if(s.startsWith("{"))CheatStore.unpack(s) else null
  if(bk!=null){ds=bk.cheats.map{Draft(it.name,it.code,it.format,it.enabled)}
   if(bk.id.isNotEmpty()&&bk.id!=g.id)note="Este respaldo es de otra versión del juego"+(if(bk.title.isNotEmpty())" («"+bk.title+"»)" else "")+". Los trucos pueden no servir en esta."}
  else{val p=CheatImport.parse(g.plat,t);ds=p.items;ign=p.ignored
   if(ds.isEmpty()&&CheatImport.parse(1-g.plat,t).items.isNotEmpty())note="Estos códigos parecen de "+(if(g.plat==CheatCodes.GBA)"Game Boy / Game Boy Color" else "Game Boy Advance")+", no de este juego."}
  if(ds.size>MAXN){note+=(if(note.isEmpty())"" else " ")+"Solo se analizan los primeros "+MAXN+" trucos.";ds=ds.take(MAXN)}
  return Res(ds.map{CheatImport.analyze(g.plat,it,pk,{l->Native.cheatProbe(l)},{m,x->Native.cheatCheck(m,x)})},ign,note)}
 private fun analyze(){val t=input.text.toString();val my=++gen
  if(t.isBlank()){items=emptyList();ign=0;note="";draw();return}
  val pk=pick
  Thread{val r=work(t,pk);runOnUiThread{if(my==gen){items=r.items;ign=r.ign;note=r.note;draw()}}}.start()}
 private fun dup(x:ImportItem):String?=existing[CheatCodes.key(x.d.code)]
 /** Marcado por defecto: los que se pueden importar y no están ya; el usuario puede cambiarlo. */
 private fun picked(i:Int):Boolean{val x=items[i];if(x.st!=Stt.OK)return false;return sel[i]?:(dup(x)==null)}

 // ---- pantalla ----
 private fun draw(){res.removeAllViews()
  val n=items.size;val ok=items.indices.count{picked(it)};val dups=items.count{it.st==Stt.OK&&dup(it)!=null};val errs=items.count{it.st==Stt.ERR};val ambs=items.count{it.st==Stt.AMBIG}
  okB.alpha=if(ok>0)1f else .4f
  if(input.text.isBlank()){sum.text="Sirve una lista con el nombre y sus códigos debajo, un archivo .cht de RetroArch, .cheats de mGBA o un respaldo de Cirilo.";return}
  val sb=StringBuilder();sb.append(if(n==1)"1 truco detectado" else n.toString()+" trucos detectados")
  if(n>0)sb.append(" · ").append(ok).append(" para importar")
  if(dups>0)sb.append(" · ").append(dups).append(if(dups==1)" repetido" else " repetidos")
  if(errs>0)sb.append(" · ").append(errs).append(if(errs==1)" con error" else " con errores")
  if(ign>0)sb.append(" · ").append(ign).append(if(ign==1)" línea ignorada" else " líneas ignoradas")
  sum.text=sb.toString()
  if(note.isNotEmpty())res.addView(TextView(this).apply{text=note;textSize=14f;setTextColor(warnC);setPadding(0,0,0,dp(8))})
  if(ambs>0)ambRow(ambs)
  items.forEachIndexed{i,x->res.addView(row(i,x));res.addView(View(this).apply{setBackgroundColor(0xFF444444.toInt())},LinearLayout.LayoutParams(-1,2))}}
 /** Códigos «XXXXXXXX XXXXXXXX» que no se pueden identificar solos: se elige un formato para todos. */
 private fun ambRow(n:Int){val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setBackgroundColor(0xFF262626.toInt());r.setPadding(dp(12),dp(10),dp(12),dp(10))
  r.background=RippleDrawable(ColorStateList.valueOf(0x22FFFFFF),ColorDrawable(0xFF262626.toInt()),ColorDrawable(-1))
  r.addView(TextView(this).apply{text=n.toString()+(if(n==1)" código no se puede identificar" else " códigos no se pueden identificar");textSize=16f;setTextColor(-1)})
  r.addView(TextView(this).apply{text="Pueden ser GameShark o Action Replay. Elige cuál usar para "+(if(n==1)"él" else "todos")+": "+(pick?.label?:"sin elegir");textSize=13f;setTextColor(warnC)})
  r.setOnClickListener{val v=listOf(CheatFormat.GS12,CheatFormat.GS3)
   AlertDialog.Builder(this).setTitle("Formato de los códigos sin identificar").setSingleChoiceItems(v.map{it.label}.toTypedArray(),v.indexOf(pick)){d,i->pick=v[i];d.dismiss();analyze()}.setNegativeButton("Cancelar",null).show()}
  res.addView(r,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})}
 private fun row(i:Int,x:ImportItem):View{val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(0,dp(10),0,dp(10))
  r.background=RippleDrawable(ColorStateList.valueOf(0x22FFFFFF),null,ColorDrawable(-1))
  r.addView(CheckBox(this).apply{isChecked=picked(i);isEnabled=x.st==Stt.OK;buttonTintList=ColorStateList.valueOf(accent);isClickable=false;isFocusable=false})
  val tx=LinearLayout(this);tx.orientation=LinearLayout.VERTICAL
  tx.addView(TextView(this).apply{text=x.d.name;textSize=17f;setTextColor(-1)})
  val d=dup(x)
  val s:String;val c:Int
  if(x.st==Stt.ERR){s=x.msg;c=errC}
  else if(x.st==Stt.AMBIG){s="Formato sin identificar";c=warnC}
  else if(d!=null){s="Ya existe como «"+d+"»";c=warnC}
  else{s=x.label+(if(x.lines>1)" · "+x.lines+" líneas" else "")+(if(x.master)" · código maestro" else "");c=gray}
  tx.addView(TextView(this).apply{text=s;textSize=13f;setTextColor(c)})
  r.addView(tx,LinearLayout.LayoutParams(0,-2,1f))
  r.setOnClickListener{if(x.st==Stt.OK){sel[i]=!picked(i);draw()}}
  return r}

 private fun doImport(){val l=CheatStore.list(this,g.id);var n=0
  items.forEachIndexed{i,x->if(picked(i)){l+=Cheat(CheatStore.newId(),x.d.name.ifBlank{"Truco "+(l.size+1)},x.fmt,x.d.code,x.d.on,x.det,if(x.fmt==CheatFormat.AUTO)x.label else "");n++}}
  if(n==0){toast("No hay ningún truco marcado");return}
  CheatStore.save(this,g,l);toast(if(n==1)"1 truco importado" else n.toString()+" trucos importados");setResult(RESULT_OK);finish()}
}
