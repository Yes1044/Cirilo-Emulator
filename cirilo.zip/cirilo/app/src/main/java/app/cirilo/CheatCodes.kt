package app.cirilo

/** Formatos de truco ofrecidos al usuario. El orden (ordinal) es el «modo» que entiende cirilo_cheats.c; no lo cambies sin tocar el C. */
enum class CheatFormat(val label:String){
 AUTO("Auto detect"),GS12("GameShark v1/v2"),GS3("GameShark v3 (Action Replay)"),CB("Code Breaker"),RAW("Raw code");
 companion object{fun of(i:Int)=values().getOrElse(i){AUTO}}
}

/** Lógica pura (sin Android) para validar e interpretar códigos. Nunca modifica lo que escribe el usuario: solo produce el texto de transporte para el núcleo. */
object CheatCodes{
 const val GBA=0;const val GB=1
 /** Resultado de interpretar un código. mode = formato que se envía al núcleo (ordinal de CheatFormat; 0 = que lo autodetecte mGBA). */
 class Resolved(val mode:Int,val label:String,val text:String,val lines:Int,val error:String?=null,val ambiguous:Boolean=false)
 private fun err(m:String)=Resolved(0,"","",0,error=m)

 private val H8=Regex("[0-9A-Fa-f]{8}");private val H4=Regex("[0-9A-Fa-f]{4}")
 private val GBA_PAIR=Regex("[0-9A-Fa-f]{8}[ \t]+[0-9A-Fa-f]{8}");private val GBA_CB=Regex("[0-9A-Fa-f]{8}[ \t]+[0-9A-Fa-f]{4}")
 private val GBA_RAW=Regex("[0-9A-Fa-f]{8}:([0-9A-Fa-f]{2}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{8})")
 private val GB_GS=H8;private val GB_RAW=Regex("[0-9A-Fa-f]{4}:[0-9A-Fa-f]{2}")
 private val GB_GG=Regex("[0-9A-Fa-f]{3}-[0-9A-Fa-f]{3}(-[0-9A-Fa-f]{3})?")

 /** Líneas no vacías, recortadas, tal cual (sin cambiar mayúsculas ni contenido). */
 fun lines(code:String)=code.split('\n','\r').map{it.trim()}.filter{it.isNotEmpty()}
 /** Texto de transporte: una línea por renglón y espacios entre palabras normalizados a uno. */
 private fun transport(l:List<String>)=l.joinToString("\n"){it.replace(Regex("[ \t]+")," ")}

 private fun pairShape(plat:Int)=if(plat==GBA)"XXXXXXXX XXXXXXXX" else "XXXXXXXX"
 private fun expect(plat:Int,f:CheatFormat)=when(f){
  CheatFormat.GS12,CheatFormat.GS3->if(plat==GBA)"8+8 dígitos hexadecimales, p. ej. «${pairShape(plat)}»" else "8 dígitos hexadecimales (01VVLLHH)"
  CheatFormat.CB->"8+4 dígitos hexadecimales, p. ej. «XXXXXXXX XXXX»"
  CheatFormat.RAW->if(plat==GBA)"«DIRECCIÓN:VALOR» con 8 dígitos de dirección y 1, 2 o 4 bytes de valor, p. ej. «02000010:63»" else "«DIRECCIÓN:VALOR», p. ej. «C020:63»"
  else->""}

 /** Forma de una línea en autodetección, o null si no encaja en ningún formato. */
 private fun shape(plat:Int,l:String):String?=if(plat==GBA)when{GBA_RAW.matches(l)->"raw";GBA_CB.matches(l)->"cb";GBA_PAIR.matches(l)->"pair";else->null}
  else when{GB_GS.matches(l)->"gs";GB_RAW.matches(l)->"raw";GB_GG.matches(l)->"gg";else->null}

 /**
  * Valida y resuelve el formato. probe(línea) devuelve las 4 puntuaciones de mGBA {GS cifrado, AR v3 cifrado, GS sin cifrar, AR sin cifrar}
  * (o null); solo se usa para distinguir GameShark de Action Replay en autodetección. Sin probe, esos códigos quedan en modo 0 (autodetección del núcleo).
  */
 fun resolve(plat:Int,f:CheatFormat,code:String,probe:((String)->IntArray?)?=null):Resolved{
  val ls=lines(code);if(ls.isEmpty())return err("Escribe el código del truco.")
  if(f!=CheatFormat.AUTO){
   if(plat==GB&&(f==CheatFormat.GS3||f==CheatFormat.CB))return err("«"+f.label+"» no existe para Game Boy / Game Boy Color. Usa GameShark v1/v2 o Raw code.")
   val re=when(f){CheatFormat.GS12,CheatFormat.GS3->if(plat==GBA)GBA_PAIR else GB_GS;CheatFormat.CB->GBA_CB;else->if(plat==GBA)GBA_RAW else GB_RAW}
   ls.forEachIndexed{i,l->if(!re.matches(l))return err("Línea ${i+1}: «"+l.take(24)+"» no es un código "+f.label+" válido. Se espera "+expect(plat,f)+".")}
   return Resolved(f.ordinal,f.label,transport(ls),ls.size)}
  // Auto detect: todas las líneas deben tener la misma forma; nunca se adivina en silencio.
  val sh=ls.mapIndexed{i,l->shape(plat,l)?:return err("Línea ${i+1}: «"+l.take(24)+"» no coincide con ningún formato conocido ("+(if(plat==GBA)"GameShark/Action Replay «XXXXXXXX XXXXXXXX», Code Breaker «XXXXXXXX XXXX» o Raw «DIRECCIÓN:VALOR»" else "GameShark «XXXXXXXX», Game Genie «XXX-XXX-XXX» o Raw «DIRECCIÓN:VALOR»")+"). Elige el formato manualmente.")}
  if(sh.toSet().size>1)return err("Las líneas mezclan formatos distintos ("+sh.toSet().joinToString(", ")+"). Pon cada formato en un truco distinto o elige el formato manualmente.")
  val t=transport(ls)
  return when(sh[0]){
   "raw"->Resolved(CheatFormat.RAW.ordinal,CheatFormat.RAW.label,t,ls.size)
   "cb"->Resolved(CheatFormat.CB.ordinal,CheatFormat.CB.label,t,ls.size)
   "gs"->Resolved(CheatFormat.GS12.ordinal,CheatFormat.GS12.label,t,ls.size)
   "gg"->Resolved(0,"Game Genie",t,ls.size)
   else->pair(ls,t,probe)}}

 /** Pares «8+8» de GBA: la estructura no distingue GameShark de Action Replay (ni cifrado de sin cifrar), así que se usan las puntuaciones de mGBA y solo se acepta con margen claro. */
 private fun pair(ls:List<String>,t:String,probe:((String)->IntArray?)?):Resolved{
  if(probe==null)return Resolved(0,"GameShark / Action Replay (lo detecta mGBA)",t,ls.size)
  val names=listOf("GameShark v1/v2","GameShark v3 (Action Replay)","GameShark v1/v2 (sin cifrar)","Action Replay v3 (sin cifrar)")
  val votes=HashSet<Int>()
  for(l in ls){val s=probe(l)?:continue;val o=s.indices.sortedByDescending{s[it]}
   if(s[o[0]]>=48&&s[o[0]]-s[o[1]]>=32)votes+=o[0]}   // línea concluyente
  if(votes.size!=1)return Resolved(0,"",t,ls.size,ambiguous=true)
  val k=votes.first()
  return Resolved(when(k){0->CheatFormat.GS12.ordinal;1->CheatFormat.GS3.ordinal;else->0},names[k],t,ls.size)}

 /** Texto de transporte para activar un truco ya guardado (la validación se hizo al guardar; el núcleo vuelve a validar). */
 fun transportOf(code:String)=transport(lines(code))
}
