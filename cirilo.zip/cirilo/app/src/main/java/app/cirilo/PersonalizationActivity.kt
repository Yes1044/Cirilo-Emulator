package app.cirilo
import android.app.*
import android.graphics.drawable.*
import android.content.Intent
import android.os.Bundle
import android.text.*
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
/** Personalización: vista de la biblioteca (List/Grid), color de acento (Accent.kt, pref. «accent»), zoom del menú principal con previsualización en vivo y ajustes de carátulas. Se guarda en las preferencias «lib» (view, ui_zoom, cov_auto). */
class PersonalizationActivity:Activity(){
 private lateinit var body:LinearLayout;private lateinit var pv:FrameLayout;private var dn=1f;private var zoom=100;private var sync=false
 private val P by lazy{getSharedPreferences("lib",0)}
 private fun dp(x:Int)=(x*dn).toInt()
 override fun onCreate(b:Bundle?){
  super.onCreate(b);dn=resources.displayMetrics.density;zoom=P.getInt("ui_zoom",100).coerceIn(60,160)
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF303030.toInt())
  col.addView(TextView(this).apply{text="Personalización";setTextColor(-1);textSize=22f;setPadding(dp(16),dp(16),dp(16),dp(16));setBackgroundColor(0xFF212121.toInt())})
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL
  col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));setContentView(col);render()}
 private fun head(s:String)=TextView(this).apply{text=s;textSize=14f;setTextColor(Accent.color);setPadding(dp(16),dp(18),dp(16),dp(4))}
 private fun row(t:String,s:String?,trail:View?=null,click:(()->Unit)?=null){
  val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(14),dp(16),dp(14))
  val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.addView(TextView(this).apply{text=t;textSize=18f;setTextColor(-1)})
  if(s!=null)c.addView(TextView(this).apply{text=s;textSize=14f;setTextColor(0xFFBBBBBB.toInt())})
  r.addView(c,LinearLayout.LayoutParams(0,-2,1f));trail?.let{r.addView(it)};if(click!=null)r.setOnClickListener{click()};body.addView(r)}
 private fun radio(on:Boolean):View{val ring=GradientDrawable().apply{shape=GradientDrawable.OVAL;setStroke(dp(3),Accent.color);setColor(0)}
  val dot=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Accent.color)}
  return View(this).apply{background=if(on)LayerDrawable(arrayOf(ring,dot)).apply{setLayerInset(1,dp(6),dp(6),dp(6),dp(6))} else ring;layoutParams=LinearLayout.LayoutParams(dp(26),dp(26))}}
 private fun mb(n:Long)=if(n<1024*1024)(n/1024).toString()+" KB" else "%.1f MB".format(n/1048576.0)
 private fun modeName(s:SaveSync.Src,m:String?)=when(m){SaveSync.COPY->"Copiar a Cirilo";SaveSync.SHARED->"Usar la carpeta de "+s.label+" (compartido)";SaveSync.IGNORE->"Ignorar";else->"Sin elegir"}
 /** Ventanita con las tres opciones para una app. */
 private fun saveDlg(s:SaveSync.Src){val ms=listOf(SaveSync.COPY,SaveSync.SHARED,SaveSync.IGNORE)
  AlertDialog.Builder(this).setTitle(s.label+" ("+s.sys+")").setSingleChoiceItems(ms.map{modeName(s,it)}.toTypedArray(),ms.indexOf(SaveSync.mode(this,s))){dl,i->dl.dismiss();pickSave(s,ms[i])}.let{b->if(SaveSync.hasDirect(this,s))b else b.setNeutralButton(if(SaveSync.accessible(this,s))"Cambiar acceso" else "Dar acceso"){_,_->AccessUi.choose(this,s,{afterAccess(s)},{})}}.setNegativeButton("Cancelar",null).show()}
 private fun pickSave(s:SaveSync.Src,m:String){SaveSync.setMode(this,s,m)
  if(m==SaveSync.COPY)Thread{val n=SaveSync.copyIn(this,SaveSync.find(this,s,Lib.all(this)));runOnUiThread{Toast.makeText(this,n.toString()+" guardados copiados",Toast.LENGTH_SHORT).show();render()}}.start()
  else{if(m==SaveSync.SHARED)Thread{if(!SaveSync.writable(this,s))runOnUiThread{Toast.makeText(this,"Cirilo no puede escribir en la carpeta de "+s.label+": se guardará en Cirilo",Toast.LENGTH_LONG).show()}}.start();render()}}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){if(rq!in AccessUi.RQ..AccessUi.RQ+1||rs!=RESULT_OK)return;val u=d?.data?:return;val s=SaveSync.Src.values()[rq-AccessUi.RQ];SaveSync.setTree(this,s,u);afterAccess(s)}
 private fun afterAccess(s:SaveSync.Src){Thread{val n=SaveSync.find(this,s,Lib.all(this)).size;runOnUiThread{Toast.makeText(this,if(n>0)"Acceso concedido: "+n+" guardados de "+s.label+" encontrados" else "Acceso concedido, pero no se encontraron guardados de "+s.label,Toast.LENGTH_LONG).show();render()}}.start()}
 private fun setZoom(z:Int){zoom=z.coerceIn(60,160);P.edit().putInt("ui_zoom",zoom).apply();preview()}
 private fun render(){body.removeAllViews();val grid=P.getString("view","list")=="grid"
  body.addView(head("VISTA DE LA BIBLIOTECA"))
  row("List View","Lista vertical (la de siempre)",radio(!grid)){P.edit().putString("view","list").apply();render()}
  row("Grid View","Cuadrícula de carátulas con el nombre debajo",radio(grid)){P.edit().putString("view","grid").apply();render()}
  body.addView(head("COLOR DE ACENTO"))
  val dot=View(this).apply{background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Accent.color);setStroke(dp(2),0x66FFFFFF)};layoutParams=LinearLayout.LayoutParams(dp(30),dp(30))}
  row("Color de acento",Accent.hex(Accent.color)+(if(Accent.color==Accent.DEF)" (predeterminado)" else "")+" · botones, selección y controles de acción",dot){AccentPicker.show(this){render()}}
  body.addView(head("ZOOM DEL MENÚ"))
  val sb=SeekBar(this).apply{max=100;progress=zoom-60}
  val ed=EditText(this).apply{setText(zoom.toString());setSelectAllOnFocus(true);setSingleLine();gravity=Gravity.CENTER;setTextColor(-1);inputType=InputType.TYPE_CLASS_NUMBER;imeOptions=EditorInfo.IME_ACTION_DONE;filters=arrayOf(InputFilter.LengthFilter(3))}
  fun fix(){val v=(ed.text.toString().toIntOrNull()?:zoom).coerceIn(60,160);sync=true;ed.setText(v.toString());sb.progress=v-60;sync=false;setZoom(v)}
  sb.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(x:SeekBar?,p:Int,u:Boolean){if(u&&!sync){sync=true;ed.setText((p+60).toString());sync=false;setZoom(p+60)}}
   override fun onStartTrackingTouch(x:SeekBar?){};override fun onStopTrackingTouch(x:SeekBar?){}})
  ed.addTextChangedListener(object:TextWatcher{override fun afterTextChanged(e:Editable?){if(sync)return;val v=e.toString().toIntOrNull()?:return;if(v in 60..160){sync=true;sb.progress=v-60;sync=false;setZoom(v)}}
   override fun beforeTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){};override fun onTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){}})
  ed.setOnEditorActionListener{_,_,_->fix();ed.clearFocus();(getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(ed.windowToken,0);true}
  ed.setOnFocusChangeListener{_,h->if(!h)fix()}
  val zr=LinearLayout(this);zr.gravity=Gravity.CENTER_VERTICAL;zr.setPadding(dp(16),dp(8),dp(16),dp(8))
  zr.addView(sb,LinearLayout.LayoutParams(0,-2,1f));zr.addView(ed,LinearLayout.LayoutParams(dp(64),-2));zr.addView(TextView(this).apply{text="%";textSize=18f;setTextColor(-1)})
  body.addView(zr)
  body.addView(TextView(this).apply{text="De 60 % a 160 %. Se aplica al menú principal al volver a la biblioteca.";textSize=13f;setTextColor(0xFFBBBBBB.toInt());setPadding(dp(16),0,dp(16),dp(4))})
  body.addView(head("CARÁTULAS (LIBRETRO THUMBNAILS)"))
  val w=Switch(this).apply{isChecked=Covers.autoOn(this@PersonalizationActivity);setOnCheckedChangeListener{_,v->P.edit().putBoolean("cov_auto",v).apply()}}
  row("Descargar carátulas automáticamente","Se identifican en el dispositivo; solo se descarga la imagen",w){w.toggle()}
  row("Buscar de nuevo las que faltan","Reintenta los juegos que quedaron sin carátula"){Covers.retryMissing(this);Toast.makeText(this,"Se buscarán de nuevo al abrir la biblioteca",Toast.LENGTH_SHORT).show()}
  row("Borrar carátulas descargadas","Ocupan "+mb(Covers.cacheSize(this))+". Las personalizadas no se borran"){Ui.confirm(this,"¿Borrar las carátulas descargadas? Se volverán a descargar cuando hagan falta."){Covers.clearAuto(this);render()}}
  body.addView(head("ESTADOS DE PARTIDA"))
  val ws=Switch(this).apply{isChecked=StateToast.enabled(this@PersonalizationActivity);setOnCheckedChangeListener{_,v->P.edit().putBoolean("state_toast",v).apply()}}
  row("Mostrar aviso de estado","Tarjeta con la miniatura al guardar, cargar o duplicar un estado",ws){ws.toggle()}
  val wa=Switch(this).apply{isChecked=!StateToast.fluid(this@PersonalizationActivity);setOnCheckedChangeListener{_,v->P.edit().putBoolean("state_anim_simple",v).apply()}}
  row("Animaciones simples","Solo fundidos cortos, sin rebotes ni efectos: más ligero en móviles modestos",wa){wa.toggle()}
  body.addView(head("PREFERENCIAS DE ARCHIVOS DE GUARDADO"))
  SaveSync.Src.values().forEach{s->row(s.label,s.sys+" · "+modeName(s,SaveSync.mode(this,s))+(SaveSync.how(this,s).let{if(it.isEmpty())"" else " · acceso: "+it})){saveDlg(s)}}
  val seen=SaveSync.Src.values().any{SaveSync.accessible(this,it)}
  body.addView(TextView(this).apply{text=if(seen)"Solo se comparten las partidas guardadas (.sav), no los estados guardados." else "Cirilo no puede leer las carpetas de My Boy! / My OldBoy! (Android/data/<app>/files/save). Toca una de ellas y elige «Dar acceso»: con Shizuku (recomendado, sirve también en Android 13 o superior) o con el selector de carpetas de Android.";textSize=13f;setTextColor(0xFFBBBBBB.toInt());setPadding(dp(16),0,dp(16),dp(4))})
  body.addView(head("PREVISUALIZACIÓN"))
  pv=FrameLayout(this);body.addView(pv,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(16),dp(8),dp(16),dp(24))});preview()}
 /** Maqueta del menú principal con la vista y el zoom actuales. Se dibuja a tamaño real de pantalla y se reduce para caber; usa tus juegos y carátulas reales. */
 private fun preview(){pv.removeAllViews()
  val grid=P.getString("view","list")=="grid";val z=zoom/100f;val W=resources.displayMetrics.widthPixels;val H=(W*1.25f).toInt();val bw=W-dp(32);val sc=bw/W.toFloat()
  fun d(x:Int)=(x*dn*z).toInt()
  val all=Lib.all(this).sortedBy{it.title.lowercase()};val gs=all.take(24)
  val virt=FrameLayout(this).apply{setBackgroundColor(0xFF303030.toInt());pivotX=0f;pivotY=0f;scaleX=sc;scaleY=sc}
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  val hd=FrameLayout(this).apply{setBackgroundColor(0xFF212121.toInt());setPadding(d(16),0,d(12),0)}
  hd.addView(TextView(this).apply{text="Juegos ("+all.size+")";setTextColor(-1);textSize=22f*z;gravity=Gravity.CENTER_VERTICAL},FrameLayout.LayoutParams(-2,d(64),Gravity.START))
  hd.addView(ImageView(this).apply{setImageResource(R.drawable.ic_sort);setPadding(d(10),d(10),d(10),d(10))},FrameLayout.LayoutParams(d(48),d(48),Gravity.END or Gravity.CENTER_VERTICAL))
  val pl=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;background=GradientDrawable().apply{setColor(-1);cornerRadius=d(20).toFloat()}}
  pl.setPadding(d(15),0,0,0);pl.addView(ImageView(this).apply{setImageResource(R.drawable.ic_search)},LinearLayout.LayoutParams(d(24),d(24)))
  pl.addView(TextView(this).apply{text="...";textSize=18f*z;typeface=android.graphics.Typeface.DEFAULT_BOLD;setTextColor(0xFF9E9E9E.toInt());setPadding(0,0,0,d(4))},LinearLayout.LayoutParams(-2,-2).apply{leftMargin=d(4)})
  hd.addView(pl,FrameLayout.LayoutParams(d(76),d(40),Gravity.END or Gravity.CENTER_VERTICAL).apply{rightMargin=d(52)})
  col.addView(hd)
  if(!grid){(if(gs.isEmpty())(1..6).map{"Juego de ejemplo "+it} else gs.map{it.title}).forEach{n->
   col.addView(TextView(this).apply{text=n;textSize=17f*z;setTextColor(-1);setSingleLine();setPadding(d(16),d(12),d(12),d(12))})
   col.addView(View(this).apply{setBackgroundColor(0xFF444444.toInt())},LinearLayout.LayoutParams(-1,2))}}
  else{val n=(((W/(dn*z))-16)/118).toInt().coerceIn(2,8);val cw=(W-2*d(8)-(n-1)*d(8))/n
   val gp=LinearLayout(this);gp.orientation=LinearLayout.VERTICAL;gp.setPadding(d(8),d(8),d(8),d(8));col.addView(gp)
   for(r in 0 until 4){val row=LinearLayout(this);gp.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=d(8)})
    for(c in 0 until n){val i=r*n+c;val cell=LinearLayout(this);cell.orientation=LinearLayout.VERTICAL
     val iv=ImageView(this).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setPadding(d(3),d(3),d(3),d(3));background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=d(8).toFloat()}}
     cell.addView(iv,LinearLayout.LayoutParams(cw,cw))
     if(i<gs.size){Covers.bind(iv,gs[i],cw,cw)}else iv.setImageDrawable(CoverPh(2))
     cell.addView(TextView(this).apply{text=if(i<gs.size)gs[i].title else "Juego de ejemplo "+(i+1);textSize=12f*z;setTextColor(-1);maxLines=2;minLines=2;ellipsize=TextUtils.TruncateAt.END;gravity=Gravity.CENTER_HORIZONTAL;setPadding(d(2),d(4),d(2),0)},LinearLayout.LayoutParams(cw,-2))
     row.addView(cell,LinearLayout.LayoutParams(cw,-2).apply{if(c<n-1)rightMargin=d(8)})}}}
  virt.addView(col,FrameLayout.LayoutParams(-1,-1))
  virt.addView(TextView(this).apply{text="+";textSize=32f*z;gravity=Gravity.CENTER;setTextColor(Accent.on());background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Accent.color)}},FrameLayout.LayoutParams(d(56),d(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,d(24),d(24))})
  val box=FrameLayout(this).apply{background=GradientDrawable().apply{setColor(0xFF303030.toInt());setStroke(dp(2),0xFF555555.toInt())}}
  box.addView(virt,FrameLayout.LayoutParams(W,H))
  pv.addView(box,FrameLayout.LayoutParams(bw,(H*sc).toInt()))}
}
