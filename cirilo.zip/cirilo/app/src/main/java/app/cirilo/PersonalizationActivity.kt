package app.cirilo
import android.app.*
import android.graphics.drawable.*
import android.os.Bundle
import android.view.*
import android.widget.*
/** Personalization: presentación de la biblioteca (List View / Grid View, guardado en las preferencias «lib», clave «view») y ajustes de carátulas. */
class PersonalizationActivity:Activity(){
 private lateinit var body:LinearLayout;private var dn=1f
 private val P by lazy{getSharedPreferences("lib",0)}
 private fun dp(x:Int)=(x*dn).toInt()
 override fun onCreate(b:Bundle?){
  super.onCreate(b);dn=resources.displayMetrics.density
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF303030.toInt())
  col.addView(TextView(this).apply{text="Personalización";setTextColor(-1);textSize=22f;setPadding(dp(16),dp(16),dp(16),dp(16));setBackgroundColor(0xFF212121.toInt())})
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL
  col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));setContentView(col);render()}
 override fun onResume(){super.onResume();render()}
 private fun head(s:String)=TextView(this).apply{text=s;textSize=14f;setTextColor(0xFF80CBC4.toInt());setPadding(dp(16),dp(18),dp(16),dp(4))}
 private fun row(t:String,s:String?,trail:View?=null,click:(()->Unit)?=null){
  val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(14),dp(16),dp(14))
  val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.addView(TextView(this).apply{text=t;textSize=18f;setTextColor(-1)})
  if(s!=null)c.addView(TextView(this).apply{text=s;textSize=14f;setTextColor(0xFFBBBBBB.toInt())})
  r.addView(c,LinearLayout.LayoutParams(0,-2,1f));trail?.let{r.addView(it)};if(click!=null)r.setOnClickListener{click()};body.addView(r)}
 private fun radio(on:Boolean):View{val ring=GradientDrawable().apply{shape=GradientDrawable.OVAL;setStroke(dp(3),0xFF80CBC4.toInt());setColor(0)}
  val dot=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xFF80CBC4.toInt())}
  return View(this).apply{background=if(on)LayerDrawable(arrayOf(ring,dot)).apply{setLayerInset(1,dp(6),dp(6),dp(6),dp(6))} else ring;layoutParams=LinearLayout.LayoutParams(dp(26),dp(26))}}
 private fun mb(n:Long)=if(n<1024*1024)(n/1024).toString()+" KB" else "%.1f MB".format(n/1048576.0)
 private fun render(){body.removeAllViews();val grid=P.getString("view","list")=="grid"
  body.addView(head("VISTA DE LA BIBLIOTECA"))
  row("List View","Lista vertical (la de siempre)",radio(!grid)){P.edit().putString("view","list").apply();render()}
  row("Grid View","Cuadrícula de carátulas con el nombre debajo",radio(grid)){P.edit().putString("view","grid").apply();render()}
  body.addView(head("CARÁTULAS (LIBRETRO THUMBNAILS)"))
  val w=Switch(this).apply{isChecked=Covers.autoOn(this@PersonalizationActivity);setOnCheckedChangeListener{_,v->P.edit().putBoolean("cov_auto",v).apply()}}
  row("Descargar carátulas automáticamente","Se identifican en el dispositivo; solo se descarga la imagen",w){w.toggle()}
  row("Buscar de nuevo las que faltan","Reintenta los juegos que quedaron sin carátula"){Covers.retryMissing(this);Toast.makeText(this,"Se buscarán de nuevo al abrir la biblioteca",Toast.LENGTH_SHORT).show()}
  row("Borrar carátulas descargadas","Ocupan "+mb(Covers.cacheSize(this))+". Las personalizadas no se borran"){Ui.confirm(this,"¿Borrar las carátulas descargadas? Se volverán a descargar cuando hagan falta."){Covers.clearAuto(this);render()}}}
}
