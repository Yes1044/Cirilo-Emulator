package app.cirilo
import android.app.*
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.*
import android.widget.*

/** Formulario «New cheat» / «Edit cheat»: nombre, tipo (diálogo de selección) y código (varias líneas, sin tocar). ⋮ → Save / Discard. */
class CheatEditActivity:Activity(){
 private lateinit var g:GameInfo;private var cid:String?=null;private var old:Cheat?=null;private var fmt=CheatFormat.AUTO
 private lateinit var nameE:EditText;private lateinit var codeE:EditText;private lateinit var typeV:TextView;private var dn=1f
 private var n0="";private var c0="";private var f0=CheatFormat.AUTO
 private fun dp(x:Int)=(x*dn).toInt()
 companion object{fun intent(a:Activity,g:GameInfo,id:String?)=CheatsActivity.intent(a,g).setClass(a,CheatEditActivity::class.java).putExtra("cid",id)}
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density;g=CheatsActivity.info(intent);cid=intent.getStringExtra("cid")
  old=cid?.let{i->CheatStore.list(this,g.id).firstOrNull{it.id==i}}
  if(b==null){old?.let{fmt=it.format;n0=it.name;c0=it.code;f0=it.format}} else {fmt=CheatFormat.of(b.getInt("fmt"));n0=b.getString("n0")?:"";c0=b.getString("c0")?:"";f0=CheatFormat.of(b.getInt("f0"))}
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF303030.toInt())
  val head=LinearLayout(this);head.gravity=Gravity.CENTER_VERTICAL;head.setBackgroundColor(0xFF212121.toInt());head.setPadding(dp(16),0,dp(8),0)
  head.addView(TextView(this).apply{text=if(cid==null)"New cheat" else "Edit cheat";setTextColor(-1);textSize=22f;setPadding(0,dp(16),0,dp(16))},LinearLayout.LayoutParams(0,-2,1f))
  val more=ImageView(this).apply{setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10))};head.addView(more,LinearLayout.LayoutParams(dp(48),dp(48)))
  more.setOnClickListener{PopupMenu(this,more).apply{menu.add(0,0,0,"Save");menu.add(0,1,0,"Discard");setOnMenuItemClickListener{if(it.itemId==0)save() else discard();true}}.show()}
  val f=LinearLayout(this);f.orientation=LinearLayout.VERTICAL;f.setPadding(dp(16),dp(16),dp(16),dp(16))
  fun lab(s:String)=TextView(this).apply{text=s;textSize=13f;setTextColor(0xFFB0B0B0.toInt());setPadding(0,dp(12),0,dp(4))}
  nameE=EditText(this).apply{setText(if(b==null)n0 else b.getString("n")?:"");setTextColor(-1);setSingleLine();inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES}
  typeV=TextView(this).apply{textSize=18f;setTextColor(-1);setPadding(0,dp(8),0,dp(12));setOnClickListener{pick()}}
  codeE=EditText(this).apply{setText(if(b==null)c0 else b.getString("c")?:"");setTextColor(-1);typeface=Typeface.MONOSPACE;minLines=6;gravity=Gravity.TOP or Gravity.START
   inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD} // sin mayúsculas ni autocorrección: el código se guarda tal cual
  f.addView(lab("Cheat name"));f.addView(nameE,LinearLayout.LayoutParams(-1,-2))
  f.addView(lab("Cheat type"));f.addView(typeV,LinearLayout.LayoutParams(-1,-2))
  f.addView(lab("Cheat code"));f.addView(codeE,LinearLayout.LayoutParams(-1,-2))
  col.addView(head);col.addView(ScrollView(this).apply{isFillViewport=true;addView(f)},LinearLayout.LayoutParams(-1,0,1f))
  window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);setContentView(col);showType()}
 override fun onSaveInstanceState(o:Bundle){super.onSaveInstanceState(o);o.putInt("fmt",fmt.ordinal);o.putString("n",nameE.text.toString());o.putString("c",codeE.text.toString());o.putString("n0",n0);o.putString("c0",c0);o.putInt("f0",f0.ordinal)}
 private fun showType(){typeV.text=fmt.label}
 private fun pick(){val v=CheatFormat.values()
  AlertDialog.Builder(this).setTitle("Cheat type").setSingleChoiceItems(v.map{it.label}.toTypedArray(),fmt.ordinal){d,i->fmt=v[i];showType();codeE.error=null;d.dismiss()}.setNegativeButton("Cancelar",null).show()}
 private fun dirty()=nameE.text.toString()!=n0||codeE.text.toString()!=c0||fmt!=f0
 private fun discard(){if(dirty())Ui.confirm(this,"Hay cambios sin guardar. ¿Descartarlos?"){finish()} else finish()}
 override fun onBackPressed(){discard()}
 /** Mensaje para un resultado negativo de cheatCheck. */
 private fun why(r:Int,label:String)=when{
  r==-9999->"Este núcleo de mGBA no incluye el módulo de trucos de Cirilo (cirilo_cheats.c). Recompila con el workflow actualizado."
  r==-9000->"El juego no está cargado en el núcleo. Vuelve al juego y abre Cheats desde su menú."
  r==-9001->"«"+label+"» no es compatible con este tipo de juego."
  r==-9002->"Escribe el código del truco."
  r<0->"Línea ${-r}: mGBA no aceptó este código como «"+label+"»."
  else->""}
 private fun save(){
  val name=nameE.text.toString().trim();val code=codeE.text.toString()
  if(name.isEmpty()){nameE.error="Escribe un nombre";nameE.requestFocus();return}
  val r=CheatCodes.resolve(g.plat,fmt,code){Native.cheatProbe(it)}
  if(r.error!=null){codeE.error=r.error;codeE.requestFocus();return}
  if(r.ambiguous){AlertDialog.Builder(this).setTitle("Formato no identificado").setMessage("No se pudo identificar el formato con suficiente seguridad: un código «XXXXXXXX XXXXXXXX» puede ser GameShark o Action Replay. No voy a adivinarlo: elige el formato manualmente.")
   .setPositiveButton("Elegir formato"){_,_->pick()}.setNegativeButton("Cancelar",null).show();return}
  val chk=Native.cheatCheck(r.mode,r.text);val ver=chk[1]
  if(chk[0]<0){codeE.error=why(chk[0],r.label.ifEmpty{fmt.label});codeE.requestFocus();return}
  if(chk[0]!=r.lines){codeE.error="mGBA solo aceptó "+chk[0]+" de "+r.lines+" líneas.";return}
  // En autodetección de GBA con códigos sin cifrar, el nombre sale de lo que mGBA decidió (1/3 = cifrado; 2/4 = sin cifrar)
  val label=if(fmt==CheatFormat.AUTO&&r.mode==0&&ver==2)"GameShark v1/v2 (sin cifrar)" else if(fmt==CheatFormat.AUTO&&r.mode==0&&ver==4)"Action Replay v3 (sin cifrar)" else if(fmt==CheatFormat.AUTO)r.label else ""
  val c=Cheat(old?.id?:CheatStore.newId(),name,fmt,code,old?.enabled?:false,if(fmt==CheatFormat.AUTO)r.mode else 0,label)
  val l=CheatStore.list(this,g.id);val i=l.indexOfFirst{it.id==c.id};if(i>=0)l[i]=c else l+=c
  CheatStore.save(this,g,l)
  Toast.makeText(this,"Cheat guardado"+(if(fmt==CheatFormat.AUTO&&label.isNotEmpty())" · detectado: "+label else ""),Toast.LENGTH_SHORT).show()
  setResult(RESULT_OK);finish()}
}
