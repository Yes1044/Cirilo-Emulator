package app.cirilo
import android.app.*
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.*
import android.text.style.BackgroundColorSpan
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*

/** Formulario «Nuevo truco» / «Editar truco»: nombre, tipo (diálogo de selección) y código (varias líneas, sin tocar). Mientras se escribe se muestra el formato detectado, se marca la línea con error y,
 *  si lo que se pega es una lista de varios trucos, se ofrece importarla. Teclado hexadecimal propio opcional. ✓ o ⋮ → Guardar / Descartar. */
class CheatEditActivity:Activity(){
 private lateinit var g:GameInfo;private var cid:String?=null;private var old:Cheat?=null;private var fmt=CheatFormat.AUTO
 private lateinit var nameE:EditText;private lateinit var codeE:EditText;private lateinit var typeV:TextView;private lateinit var hintV:TextView;private lateinit var pad:LinearLayout;private lateinit var hexT:TextView
 private var dn=1f;private var n0="";private var c0="";private var f0=CheatFormat.AUTO;private var hex=false
 private var sug:CheatFormat?=null;private var amb=false;private var many=0;private var repeated=false
 private val hd=Handler(Looper.getMainLooper());private val chk=Runnable{validate()}
 private val rep=object:Runnable{override fun run(){repeated=true;del();hd.postDelayed(this,70)}}
 private val accent get()=Accent.color;private val gray=0xFF9E9E9E.toInt();private val warnC=0xFFFFB74D.toInt();private val errC=0xFFEF5350.toInt()
 private fun dp(x:Int)=(x*dn).toInt()
 private fun imm()=getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
 companion object{fun intent(a:Activity,g:GameInfo,id:String?)=CheatsActivity.intent(a,g).setClass(a,CheatEditActivity::class.java).putExtra("cid",id)}
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density;g=CheatsActivity.info(intent);cid=intent.getStringExtra("cid")
  old=cid?.let{i->CheatStore.list(this,g.id).firstOrNull{it.id==i}}
  if(b==null){old?.let{fmt=it.format;n0=it.name;c0=it.code;f0=it.format}} else {fmt=CheatFormat.of(b.getInt("fmt"));n0=b.getString("n0")?:"";c0=b.getString("c0")?:"";f0=CheatFormat.of(b.getInt("f0"))}
  hex=getSharedPreferences("c",0).getBoolean("cheat_hex",false)
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF303030.toInt())
  val head=LinearLayout(this);head.gravity=Gravity.CENTER_VERTICAL;head.setBackgroundColor(0xFF212121.toInt());head.setPadding(dp(16),0,dp(8),0)
  head.addView(TextView(this).apply{text=if(cid==null)"Nuevo truco" else "Editar truco";setTextColor(-1);textSize=22f;setPadding(0,dp(16),0,dp(16))},LinearLayout.LayoutParams(0,-2,1f))
  head.addView(ImageView(this).apply{setImageResource(R.drawable.ic_check);setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{save()}},LinearLayout.LayoutParams(dp(48),dp(48)))
  val more=ImageView(this).apply{setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10))};head.addView(more,LinearLayout.LayoutParams(dp(48),dp(48)))
  more.setOnClickListener{PopupMenu(this,more).apply{menu.add(0,0,0,"Guardar");menu.add(0,1,0,"Descartar");setOnMenuItemClickListener{if(it.itemId==0)save() else discard();true}}.show()}
  val f=LinearLayout(this);f.orientation=LinearLayout.VERTICAL;f.setPadding(dp(16),dp(16),dp(16),dp(16))
  fun lab(s:String)=TextView(this).apply{text=s;textSize=13f;setTextColor(0xFFB0B0B0.toInt());setPadding(0,dp(12),0,dp(4))}
  nameE=EditText(this).apply{setText(if(b==null)n0 else b.getString("n")?:"");setTextColor(-1);setSingleLine();inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES}
  typeV=TextView(this).apply{textSize=18f;setTextColor(-1);gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(8),0,dp(12));compoundDrawablePadding=dp(8);setCompoundDrawablesWithIntrinsicBounds(0,0,R.drawable.ic_expand,0)
   background=RippleDrawable(ColorStateList.valueOf(0x22FFFFFF),null,ColorDrawable(-1));setOnClickListener{pick()}}
  codeE=EditText(this).apply{setText(if(b==null)c0 else b.getString("c")?:"");setTextColor(-1);typeface=Typeface.MONOSPACE;minLines=6;gravity=Gravity.TOP or Gravity.START
   inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD // sin mayúsculas ni autocorrección: el código se guarda tal cual
   setShowSoftInputOnFocus(!hex);setOnFocusChangeListener{_,_->syncPad()}
   addTextChangedListener(object:TextWatcher{override fun afterTextChanged(s:Editable?){hd.removeCallbacks(chk);hd.postDelayed(chk,250)};override fun beforeTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){};override fun onTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){}})}
  hexT=TextView(this).apply{textSize=12f;setTextColor(accent);typeface=Typeface.DEFAULT_BOLD;setPadding(dp(8),dp(12),0,dp(4));setOnClickListener{setHex(!hex)}}
  val lr=LinearLayout(this);lr.gravity=Gravity.BOTTOM;lr.addView(lab("Código del truco"),LinearLayout.LayoutParams(0,-2,1f));lr.addView(hexT)
  hintV=TextView(this).apply{textSize=14f;minLines=2;setPadding(0,dp(8),0,0);setOnClickListener{hintTap()}}
  f.addView(lab("Nombre del truco"));f.addView(nameE,LinearLayout.LayoutParams(-1,-2))
  f.addView(lab("Tipo de truco"));f.addView(typeV,LinearLayout.LayoutParams(-1,-2))
  f.addView(lr,LinearLayout.LayoutParams(-1,-2));f.addView(codeE,LinearLayout.LayoutParams(-1,-2));f.addView(hintV,LinearLayout.LayoutParams(-1,-2))
  pad=keypad();pad.visibility=View.GONE
  col.addView(head);col.addView(ScrollView(this).apply{isFillViewport=true;addView(f)},LinearLayout.LayoutParams(-1,0,1f));col.addView(pad,LinearLayout.LayoutParams(-1,-2))
  window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);setContentView(col);showType();setHexLabel();validate()}
 override fun onSaveInstanceState(o:Bundle){super.onSaveInstanceState(o);o.putInt("fmt",fmt.ordinal);o.putString("n",nameE.text.toString());o.putString("c",codeE.text.toString());o.putString("n0",n0);o.putString("c0",c0);o.putInt("f0",f0.ordinal)}
 override fun onDestroy(){super.onDestroy();hd.removeCallbacks(chk);hd.removeCallbacks(rep)}
 private fun showType(){typeV.text=fmt.label}
 private fun pick(){val v=CheatFormat.values()
  AlertDialog.Builder(this).setTitle("Tipo de truco").setSingleChoiceItems(v.map{it.label}.toTypedArray(),fmt.ordinal){d,i->fmt=v[i];showType();codeE.error=null;d.dismiss();validate()}.setNegativeButton("Cancelar",null).show()}
 private fun dirty()=nameE.text.toString()!=n0||codeE.text.toString()!=c0||fmt!=f0
 private fun discard(){if(dirty())Ui.confirm(this,"Hay cambios sin guardar. ¿Descartarlos?"){finish()} else finish()}
 override fun onBackPressed(){if(pad.visibility==View.VISIBLE){codeE.clearFocus();return};discard()}

 // ---- retroalimentación al escribir ----
 private fun hint(t:String,c:Int){hintV.text=t;hintV.setTextColor(c)}
 /** Resalta la línea n (contando solo las no vacías, igual que CheatCodes.lines). */
 private fun mark(n:Int){if(n<1)return;val e=codeE.text;val s=e.toString();var i=0;var cnt=0
  while(i<s.length){var j=i;while(j<s.length&&s[j]!='\n'&&s[j]!='\r')j++
   if(s.substring(i,j).isNotBlank()){cnt++;if(cnt==n){e.setSpan(BackgroundColorSpan(0x55EF5350),i,j,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);return}}
   i=j+1}}
 private fun validate(){val e=codeE.text;e.getSpans(0,e.length,BackgroundColorSpan::class.java).forEach{e.removeSpan(it)}
  sug=null;amb=false;many=0;val code=e.toString()
  if(CheatCodes.lines(code).isEmpty()){hint("Escribe o pega el código, una línea por renglón. Si pegas una lista de varios trucos, te ofreceré importarla.",gray);return}
  val v=CheatCodes.verify(g.plat,fmt,code,{Native.cheatProbe(it)},{m,t->Native.cheatCheck(m,t)})
  if(v.r.ambiguous){amb=true;hint("Puede ser GameShark o Action Replay: toca aquí para elegir el tipo.",warnC);return}
  val er=v.error
  if(er!=null){mark(v.line)
   val n=CheatImport.parse(g.plat,code).items.size
   if(n>1){many=n;hint("Parece una lista de "+n+" trucos. Toca aquí para importarla.",accent);return}
   var m=er
   if(fmt!=CheatFormat.AUTO){val a=CheatCodes.resolve(g.plat,CheatFormat.AUTO,code){Native.cheatProbe(it)}
    if(a.error==null&&!a.ambiguous&&a.mode in 1..4&&a.mode!=fmt.ordinal){val sg=CheatFormat.of(a.mode);sug=sg;m+="\nParece «"+sg.label+"». Toca aquí para cambiar el tipo."}}
   hint(m,errC);return}
  val n=v.r.lines;val ls=n.toString()+(if(n==1)" línea" else " líneas")
  hint(if(fmt==CheatFormat.AUTO)"Detectado: "+v.label+" · "+ls else "Válido como "+fmt.label+" · "+ls,accent)}
 private fun hintTap(){val s=sug
  if(s!=null){fmt=s;showType();validate()}
  else if(amb)pick()
  else if(many>1){startActivity(CheatImportActivity.intent(this,g).putExtra("text",codeE.text.toString()));if(cid==null)finish()}}

 // ---- teclado hexadecimal propio (opcional; se guarda en Ajustes «c», clave cheat_hex) ----
 private fun setHexLabel(){hexT.text=if(hex)"TECLADO NORMAL" else "TECLADO HEX"}
 private fun setHex(on:Boolean){hex=on;getSharedPreferences("c",0).edit().putBoolean("cheat_hex",on).apply();setHexLabel();codeE.setShowSoftInputOnFocus(!on)
  if(on)imm().hideSoftInputFromWindow(codeE.windowToken,0) else if(codeE.hasFocus())imm().showSoftInput(codeE,0)
  syncPad()}
 private fun syncPad(){pad.visibility=if(hex&&codeE.hasFocus())View.VISIBLE else View.GONE}
 private fun ins(s:String){val a=minOf(codeE.selectionStart,codeE.selectionEnd).coerceAtLeast(0);val z=maxOf(codeE.selectionStart,codeE.selectionEnd).coerceAtLeast(0)
  codeE.text.replace(a,z,s);codeE.setSelection(a+s.length)}
 private fun del(){val a=minOf(codeE.selectionStart,codeE.selectionEnd).coerceAtLeast(0);val z=maxOf(codeE.selectionStart,codeE.selectionEnd).coerceAtLeast(0)
  if(a!=z){codeE.text.delete(a,z);codeE.setSelection(a)} else if(a>0){codeE.text.delete(a-1,a);codeE.setSelection(a-1)}}
 private fun press(k:String){when(k){"BORRAR"->del();"INTRO"->ins("\n");"ESPACIO"->ins(" ");"<"->codeE.setSelection((codeE.selectionEnd-1).coerceAtLeast(0));">"->codeE.setSelection((codeE.selectionEnd+1).coerceAtMost(codeE.text.length))
   "OK"->{codeE.clearFocus();imm().hideSoftInputFromWindow(codeE.windowToken,0)};else->ins(k)}}
 private fun key(k:String):TextView{val sp=k.length>1||k=="<"||k==">"
  return TextView(this).apply{text=k;gravity=Gravity.CENTER;textSize=if(k.length>1)11f else 20f;typeface=if(sp)Typeface.DEFAULT_BOLD else Typeface.MONOSPACE;setTextColor(if(sp)accent else -1)
   background=RippleDrawable(ColorStateList.valueOf(0x44FFFFFF),ColorDrawable(0xFF262626.toInt()),ColorDrawable(-1))
   if(k=="BORRAR")setOnTouchListener{_,e->when(e.actionMasked){MotionEvent.ACTION_DOWN->{repeated=false;hd.postDelayed(rep,400)};MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->hd.removeCallbacks(rep)};false}
   setOnClickListener{performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);if(k=="BORRAR"&&repeated){repeated=false}else{press(k)}}}}
 private fun keypad():LinearLayout{val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setBackgroundColor(0xFF212121.toInt())
  listOf(listOf("7","8","9","A","B","BORRAR"),listOf("4","5","6","C","D","INTRO"),listOf("1","2","3","E","F","ESPACIO"),listOf("0",":","-","<",">","OK")).forEach{ks->
   val r=LinearLayout(this);ks.forEach{k->r.addView(key(k),LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(1),dp(1),dp(1),0)})};col.addView(r)}
  return col}

 // ---- guardar ----
 private fun save(){
  val name=nameE.text.toString().trim();val code=codeE.text.toString()
  if(name.isEmpty()){nameE.error="Escribe un nombre";nameE.requestFocus();return}
  val v=CheatCodes.verify(g.plat,fmt,code,{Native.cheatProbe(it)},{m,t->Native.cheatCheck(m,t)})
  val er=v.error
  if(er!=null){codeE.error=er;codeE.requestFocus();mark(v.line);return}
  if(v.r.ambiguous){AlertDialog.Builder(this).setTitle("Formato no identificado").setMessage("No se pudo identificar el formato con suficiente seguridad: un código «XXXXXXXX XXXXXXXX» puede ser GameShark o Action Replay. No voy a adivinarlo: elige el formato manualmente.")
   .setPositiveButton("Elegir formato"){_,_->pick()}.setNegativeButton("Cancelar",null).show();return}
  val c=Cheat(old?.id?:CheatStore.newId(),name,fmt,code,old?.enabled?:false,v.det,v.label)
  val l=CheatStore.list(this,g.id);val i=l.indexOfFirst{it.id==c.id};if(i>=0)l[i]=c else l+=c
  CheatStore.save(this,g,l)
  Toast.makeText(this,"Truco guardado"+(if(fmt==CheatFormat.AUTO&&v.label.isNotEmpty())" · detectado: "+v.label else ""),Toast.LENGTH_SHORT).show()
  setResult(RESULT_OK);finish()}
}
