package app.cirilo
import kotlin.math.floor
import kotlin.math.min
/** Un control del layout. x,y = centro normalizado (0..1 del área); s = diámetro como fracción del lado menor; o = opacidad; r = grados; v = visible (oculto sigue activo en el juego); m = modo (ff: 0 alternar, 1 mantener; pantalla: 0 libre, 1 pantalla completa, 2 escala entera); st = estilo (0 contorno, 1 relleno); a = solo pantalla: proporción de aspecto propia (ancho/alto; 0 = la nativa de la consola). t == "screen" es la pantalla del juego (y = -1: arriba, como antes). */
data class Ctl(val id:String,val t:String,val x:Float,val y:Float,val s:Float,val o:Float=.6f,val r:Float=0f,val v:Boolean=true,val m:Int=0,val st:Int=0,val a:Float=0f)
/** p = distribución en vertical, l = en horizontal (cada orientación conserva la suya). sys = consola: «gba» o «gb» (GB y GBC comparten layouts; no tienen gatillos L/R). */
data class Lay(val id:String,val name:String,val p:List<Ctl>,val l:List<Ctl>,val sys:String="gba")
/** active = layout activo de GBA; activeGb = el de GB/GBC. */
class Store(var active:String,val list:MutableList<Lay>,var activeGb:String=""){
 fun activeOf(sys:String)=if(sys==LSys.GB)activeGb else active
 fun setActive(sys:String,id:String){if(sys==LSys.GB)activeGb=id else active=id}
 fun of(sys:String):List<Lay> = list.filter{it.sys==sys}
 fun cur(sys:String=LSys.GBA):Lay{val id=activeOf(sys);return list.firstOrNull{it.id==id&&it.sys==sys}?:list.firstOrNull{it.sys==sys}?:list[0]}
}
/** Diferencias entre consolas (lógica pura). */
object LSys{
 const val GBA="gba";const val GB="gb"
 /** Controles que necesitan los gatillos L/R, que solo tiene la GBA: en GB/GBC no se pueden añadir y se descartan al convertir. */
 val SHOULDER=setOf("l","r","lr","la","lb","ra","rb","turbol","turbor")
 fun allowed(sys:String,t:String)=sys!=GB||t !in SHOULDER
 /** Proporción de la pantalla del juego: GBA 240x160, GB/GBC 160x144. */
 fun aspect(sys:String)=if(sys==GB)160f/144f else 1.5f
 /** Píxeles nativos de la pantalla: GBA 240x160, GB/GBC 160x144. */
 fun pix(sys:String)=if(sys==GB)floatArrayOf(160f,144f) else floatArrayOf(240f,160f)
 /** Proporción con la que se dibuja la pantalla del juego: la propia del control (a > 0) o la nativa. */
 fun aspectOf(k:Ctl,sys:String)=if(k.a>0f)k.a else aspect(sys)
 /** Ancho de un rectángulo de esa proporción ajustado a un área w×h (la unidad de Ctl.s). */
 fun fitW(w:Float,h:Float,asp:Float)=if(w/asp<=h)w else h*asp
 /** Mayor múltiplo entero de la resolución nativa que cabe en el área (mínimo 1). */
 fun bestScale(w:Float,h:Float,nw:Float,nh:Float):Int=floor(min(w/nw,h/nh)).toInt().coerceAtLeast(1)
 /** Recuadro (izq, arr, der, aba) de la pantalla del juego en un área w×h. m: 0 libre (ajusta a la proporción asp y aplica s), 1 pantalla completa (toda el área, estirada), 2 escala entera (nativa × n entero, la mayor que cabe; no usa asp ni s).
  *  x,y = centro normalizado (y < 0 = pegada arriba). Lo usan el editor y GLView. */
 fun screenBox(w:Float,h:Float,asp:Float,m:Int,x:Float,y:Float,s:Float,nw:Float,nh:Float):FloatArray{
  if(m==1)return floatArrayOf(0f,0f,w,h)
  val pw:Float;val ph:Float
  if(m==2){val n=bestScale(w,h,nw,nh).toFloat();pw=nw*n;ph=nh*n}else{val fw=fitW(w,h,asp);pw=fw*s;ph=fw/asp*s}
  val top=if(y<0)0f else y*h-ph/2f
  return floatArrayOf(x*w-pw/2f,top,x*w+pw/2f,top+ph)}
 fun name(sys:String)=if(sys==GB)"GB y GBC" else "GBA"
 fun other(sys:String)=if(sys==GB)GBA else GB
 /** El control «Menú» es la única vía táctil al menú del juego (ya no hay botón MENÚ fijo): toda distribución lo lleva. Si falta, se añade arriba del todo, en el centro, en las dos orientaciones (y = radio/alto: en vertical el alto es ~2,2 veces el ancho; en horizontal el lado menor es el alto). */
 fun menuCtl(land:Boolean)=Ctl("menu","menu",.5f,if(land).065f else .03f,.12f)
 fun hasMenu(c:List<Ctl>)=c.any{it.t=="menu"}
 fun ensureMenu(c:List<Ctl>,land:Boolean):List<Ctl> = if(hasMenu(c))c else c+menuCtl(land)
 /** Quita los controles que la consola no admite y garantiza el control «Menú» en las dos orientaciones. */
 fun sanitize(x:Lay):Lay=x.copy(p=ensureMenu(x.p.filter{allowed(x.sys,it.t)},false),l=ensureMenu(x.l.filter{allowed(x.sys,it.t)},true))
 /** Mantiene la pantalla dentro del mismo recuadro al cambiar de proporción: en vertical manda el ancho, en horizontal el alto. */
 private fun rescale(s:Float,port:Boolean,a:Float,b:Float):Float=(if(port)s*min(1f,b/a) else s*min(1f,a/b)).coerceIn(.2f,2f)
 /** Copia del layout para otra consola. A GB/GBC se pierden L, R y sus combinaciones; a GBA no se añade nada (los gatillos se ponen a mano). */
 fun convert(x:Lay,to:String):Lay{if(x.sys==to)return x;val a=aspect(x.sys);val b=aspect(to)
  fun f(c:List<Ctl>,port:Boolean):List<Ctl> = c.filter{allowed(to,it.t)}.map{if(it.t=="screen"&&it.a<=0f&&it.m==0)it.copy(s=rescale(it.s,port,a,b)) else it} // con proporción propia, pantalla completa o escala entera el tamaño no depende de la consola
  return x.copy(sys=to,p=f(x.p,true),l=f(x.l,false))}
}
