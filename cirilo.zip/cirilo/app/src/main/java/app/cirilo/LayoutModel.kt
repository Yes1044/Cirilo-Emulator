package app.cirilo
import kotlin.math.min
/** Un control del layout. x,y = centro normalizado (0..1 del área); s = diámetro como fracción del lado menor; o = opacidad; r = grados; v = visible (oculto sigue activo en el juego); m = modo (ff: 0 alternar, 1 mantener); st = estilo (0 contorno, 1 relleno). t == "screen" es la pantalla del juego (y = -1: arriba, como antes). */
data class Ctl(val id:String,val t:String,val x:Float,val y:Float,val s:Float,val o:Float=.6f,val r:Float=0f,val v:Boolean=true,val m:Int=0,val st:Int=0)
/** p = distribución en vertical, l = en horizontal (cada orientación conserva la suya). sys = consola: «gba» o «gb» (GB y GBC comparten layouts; no tienen gatillos L/R). */
data class Lay(val id:String,val name:String,val p:List<Ctl>,val l:List<Ctl>,val sys:String="gba")
/** active = layout activo de GBA; activeGb = el de GB/GBC. */
class Store(var active:String,val list:MutableList<Lay>,var activeGb:String=""){
 fun activeOf(sys:String)=if(sys==LSys.GB)activeGb else active
 fun setActive(sys:String,id:String){if(sys==LSys.GB)activeGb=id else active=id}
 fun of(sys:String):List<Lay> = list.filter{it.sys==sys}
 fun cur(sys:String=LSys.GBA):Lay{val id=activeOf(sys);return list.firstOrNull{it.id==id&&it.sys==sys}?:list.firstOrNull{it.sys==sys}?:list[0]}
}
/** Diferencias entre consolas (lógica pura). */
object LSys{
 const val GBA="gba";const val GB="gb"
 /** Controles que necesitan los gatillos L/R, que solo tiene la GBA: en GB/GBC no se pueden añadir y se descartan al convertir. */
 val SHOULDER=setOf("l","r","lr","la","lb","ra","rb","turbol","turbor")
 fun allowed(sys:String,t:String)=sys!=GB||t !in SHOULDER
 /** Proporción de la pantalla del juego: GBA 240x160, GB/GBC 160x144. */
 fun aspect(sys:String)=if(sys==GB)160f/144f else 1.5f
 fun name(sys:String)=if(sys==GB)"GB y GBC" else "GBA"
 fun other(sys:String)=if(sys==GB)GBA else GB
 /** El control «Menú» es la única vía táctil al menú del juego (ya no hay botón MENÚ fijo): toda distribución lo lleva. Si falta, se añade en vertical arriba a la derecha (bajo el botón MENÚ del editor) y en horizontal arriba al centro (para no pisar L/R). */
 fun menuCtl(land:Boolean)=Ctl("menu","menu",if(land).5f else .92f,if(land).07f else .14f,.12f)
 fun hasMenu(c:List<Ctl>)=c.any{it.t=="menu"}
 fun ensureMenu(c:List<Ctl>,land:Boolean):List<Ctl> = if(hasMenu(c))c else c+menuCtl(land)
 /** Quita los controles que la consola no admite y garantiza el control «Menú» en las dos orientaciones. */
 fun sanitize(x:Lay):Lay=x.copy(p=ensureMenu(x.p.filter{allowed(x.sys,it.t)},false),l=ensureMenu(x.l.filter{allowed(x.sys,it.t)},true))
 /** Mantiene la pantalla dentro del mismo recuadro al cambiar de proporción: en vertical manda el ancho, en horizontal el alto. */
 private fun rescale(s:Float,port:Boolean,a:Float,b:Float):Float=(if(port)s*min(1f,b/a) else s*min(1f,a/b)).coerceIn(.2f,2f)
 /** Copia del layout para otra consola. A GB/GBC se pierden L, R y sus combinaciones; a GBA no se añade nada (los gatillos se ponen a mano). */
 fun convert(x:Lay,to:String):Lay{if(x.sys==to)return x;val a=aspect(x.sys);val b=aspect(to)
  fun f(c:List<Ctl>,port:Boolean):List<Ctl> = c.filter{allowed(to,it.t)}.map{if(it.t=="screen")it.copy(s=rescale(it.s,port,a,b)) else it}
  return x.copy(sys=to,p=f(x.p,true),l=f(x.l,false))}
}
