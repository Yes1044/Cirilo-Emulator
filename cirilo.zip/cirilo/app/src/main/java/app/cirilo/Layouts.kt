package app.cirilo
import android.app.*
import android.content.Context
import android.graphics.RectF
import android.widget.EditText
import org.json.*
object Ui{
 fun confirm(a:Activity,m:String,ok:()->Unit){AlertDialog.Builder(a).setMessage(m).setPositiveButton("Aceptar"){_,_->ok()}.setNegativeButton("Cancelar",null).show()}
 fun ask(a:Activity,ti:String,init:String,ok:(String)->Unit){val e=EditText(a).apply{setText(init);setSingleLine()}
  AlertDialog.Builder(a).setTitle(ti).setView(e).setPositiveButton("Aceptar"){_,_->val s=e.text.toString().trim();if(s.isNotEmpty())ok(s)}.setNegativeButton("Cancelar",null).show()}
}
object Layouts{
 /** Catálogo de «Añadir control»: (sección, nombre, tipos que añade). */
 val CATALOG=listOf(
  Triple("Entradas individuales","Button A",listOf("a")),Triple("Entradas individuales","Button B",listOf("b")),Triple("Entradas individuales","D-Pad",listOf("dpad")),
  Triple("Entradas individuales","L (TL)",listOf("l")),Triple("Entradas individuales","R (TR)",listOf("r")),Triple("Entradas individuales","Start",listOf("start")),Triple("Entradas individuales","Select",listOf("select")),
  Triple("Entradas individuales","Arriba",listOf("up")),Triple("Entradas individuales","Abajo",listOf("down")),Triple("Entradas individuales","Izquierda",listOf("left")),Triple("Entradas individuales","Derecha",listOf("right")),
  Triple("Combinaciones y turbo","A/B turbo",listOf("turbob","turboa")),Triple("Combinaciones y turbo","A+B",listOf("ab")),Triple("Combinaciones y turbo","TL+TR",listOf("lr")),
  Triple("Combinaciones y turbo","TL+A",listOf("la")),Triple("Combinaciones y turbo","TL+B",listOf("lb")),Triple("Combinaciones y turbo","TR+A",listOf("ra")),Triple("Combinaciones y turbo","TR+B",listOf("rb")),
  Triple("Combinaciones y turbo","Turbo TL",listOf("turbol")),Triple("Combinaciones y turbo","Turbo TR",listOf("turbor")),
  Triple("Acciones del emulador","Quick load",listOf("qload")),Triple("Acciones del emulador","Quick save",listOf("qsave")),Triple("Acciones del emulador","Fast forward",listOf("ff")),Triple("Acciones del emulador","Screenshot",listOf("shot")),Triple("Acciones del emulador","Trucos",listOf("cheats")))
 fun name(t:String)=CATALOG.firstOrNull{it.third.size==1&&it.third[0]==t}?.second?:when(t){"turboa"->"Turbo A";"turbob"->"Turbo B";"screen"->"Pantalla del juego";else->t}
 fun defSize(t:String)=when{t=="dpad"->.46f;CtlDraw.pill(t)->.15f;t in CtlDraw.ACT->.17f;else->.22f}
 /** Máscara de entrada con los ids de joypad de libretro (los que usa el núcleo mGBA): B0 SELECT2 START3 ARRIBA4 ABAJO5 IZQ6 DER7 A8 L10 R11. Las acciones del emulador valen 0: nunca son entradas del juego. */
 fun mask(t:String):Int{val A=1 shl 8;val B=1;val L=1 shl 10;val R=1 shl 11
  return when(t){"a","turboa"->A;"b","turbob"->B;"l","turbol"->L;"r","turbor"->R;"start"->1 shl 3;"select"->1 shl 2;"up"->1 shl 4;"down"->1 shl 5;"left"->1 shl 6;"right"->1 shl 7
   "ab"->A or B;"lr"->L or R;"la"->L or A;"lb"->L or B;"ra"->R or A;"rb"->R or B;else->0}}
 /** Distribución de fábrica (la que antes estaba fija en el código). En GB/GBC sin L ni R. */
 fun factory(land:Boolean,sys:String=LSys.GBA):List<Ctl> = (if(!land)listOf(Ctl("screen","screen",.5f,-1f,1f,1f),Ctl("dpad","dpad",.22f,.79f,.46f),Ctl("a","a",.88f,.74f,.24f),Ctl("b","b",.70f,.84f,.24f),
   Ctl("l","l",.14f,.60f,.15f),Ctl("r","r",.86f,.60f,.15f),Ctl("select","select",.36f,.95f,.13f),Ctl("start","start",.64f,.95f,.13f))
  else listOf(Ctl("screen","screen",.5f,.5f,1f,1f),Ctl("dpad","dpad",.11f,.66f,.52f),Ctl("a","a",.93f,.58f,.26f),Ctl("b","b",.83f,.80f,.26f),
   Ctl("l","l",.07f,.12f,.16f),Ctl("r","r",.93f,.12f,.16f),Ctl("select","select",.42f,.93f,.13f),Ctl("start","start",.58f,.93f,.13f))).filter{LSys.allowed(sys,it.t)}
 /** Consola del juego que se abre: por el tipo guardado en la biblioteca (0 GB, 1 GBC, 2 GBA) o, si no se conoce, por la extensión. */
 fun sysFor(c:Context,u:String,n:String):String{val p=Lib.all(c).firstOrNull{it.u==u}?.p?:-1;val e=Roms.ext(n)
  return if(p==0||p==1)LSys.GB else if(p==2)LSys.GBA else if(e=="gb"||e=="gbc")LSys.GB else LSys.GBA}
 /** Rectángulo de la pantalla del juego (misma fórmula que GLView): ajusta al área, aplica escala s y coloca el centro en x,y (y < 0 = pegada arriba). */
 fun screenRect(w:Float,h:Float,aspect:Float,x:Float,y:Float,s:Float):RectF{var pw=w;var ph=w/aspect;if(ph>h){ph=h;pw=h*aspect};pw*=s;ph*=s
  val top=if(y<0)0f else y*h-ph/2f;return RectF(x*w-pw/2f,top,x*w+pw/2f,top+ph)}
 private fun cj(c:Ctl)=JSONObject().put("i",c.id).put("t",c.t).put("x",c.x.toDouble()).put("y",c.y.toDouble()).put("s",c.s.toDouble()).put("o",c.o.toDouble()).put("r",c.r.toDouble()).put("v",c.v).put("m",c.m).put("st",c.st)
 private fun co(o:JSONObject)=Ctl(o.getString("i"),o.getString("t"),o.getDouble("x").toFloat(),o.getDouble("y").toFloat(),o.getDouble("s").toFloat(),o.optDouble("o",.6).toFloat(),o.optDouble("r",0.0).toFloat(),o.optBoolean("v",true),o.optInt("m",0),o.optInt("st",0))
 private fun ar(a:JSONArray)=List(a.length()){co(a.getJSONObject(it))}
 private fun ja(c:List<Ctl>)=JSONArray().also{j->c.forEach{j.put(cj(it))}}
 private fun defaults(sys:String)=Lay(if(sys==LSys.GB)"default_gb" else "default","Default",factory(false,sys),factory(true,sys),sys)
 fun load(c:Context):Store{
  try{val o=JSONObject(c.getSharedPreferences("layouts",0).getString("j","")!!);val a=o.getJSONArray("l");val l=ArrayList<Lay>()
   for(i in 0 until a.length()){val q=a.getJSONObject(i);val x=Lay(q.getString("id"),q.getString("n"),ar(q.getJSONArray("p")),ar(q.getJSONArray("q")),LSys.GBA);val sy=q.optString("sy","")
    // los layouts de versiones anteriores (sin consola) valían para todo: pasan a GBA y se crea su copia para GB/GBC, sin L ni R
    if(sy.isEmpty()){l.add(x);l.add(LSys.convert(x,LSys.GB).copy(id=x.id+"_gb"))} else l.add(LSys.sanitize(x.copy(sys=if(sy==LSys.GB)LSys.GB else LSys.GBA)))}
   if(l.none{it.sys==LSys.GBA})l.add(defaults(LSys.GBA))
   if(l.none{it.sys==LSys.GB})l.add(defaults(LSys.GB))
   val ac=o.optString("a","");return Store(ac,l,o.optString("ag",ac+"_gb"))}catch(e:Exception){}
  return Store("default",mutableListOf(defaults(LSys.GBA),defaults(LSys.GB)),"default_gb")}
 fun save(c:Context,s:Store){val a=JSONArray();s.list.forEach{l->a.put(JSONObject().put("id",l.id).put("n",l.name).put("sy",l.sys).put("p",ja(l.p)).put("q",ja(l.l)))}
  c.getSharedPreferences("layouts",0).edit().putString("j",JSONObject().put("v",2).put("a",s.active).put("ag",s.activeGb).put("l",a).toString()).apply()}
 /** Archivo de respaldo/intercambio de un layout (Cirilo → Cirilo). */
 fun export(l:Lay):String=JSONObject().put("cirilo","layout").put("v",1).put("n",l.name).put("sy",l.sys).put("p",ja(l.p)).put("q",ja(l.l)).toString(1)
 /** Lee un archivo de layout de Cirilo; null si no lo es. El layout recibe un id nuevo. */
 fun parse(t:String):Lay?{try{val o=JSONObject(t);if(o.optString("cirilo")!="layout")return null
   return LSys.sanitize(Lay("l"+System.currentTimeMillis().toString(36),o.getString("n"),ar(o.getJSONArray("p")),ar(o.getJSONArray("q")),if(o.optString("sy")==LSys.GB)LSys.GB else LSys.GBA))}catch(e:Exception){return null}}
}
