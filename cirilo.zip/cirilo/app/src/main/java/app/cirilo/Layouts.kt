package app.cirilo
import android.app.*
import android.content.Context
import android.graphics.RectF
import android.widget.EditText
import org.json.*
/** Un control del layout. x,y = centro normalizado (0..1 del área); s = diámetro como fracción del lado menor; o = opacidad; r = grados; v = visible (oculto sigue activo en el juego); m = modo (ff: 0 alternar, 1 mantener); st = estilo (0 contorno, 1 relleno). t == "screen" es la pantalla del juego (y = -1: arriba, como antes). */
data class Ctl(val id:String,val t:String,val x:Float,val y:Float,val s:Float,val o:Float=.6f,val r:Float=0f,val v:Boolean=true,val m:Int=0,val st:Int=0)
/** p = distribución en vertical, l = en horizontal (cada orientación conserva la suya). */
data class Lay(val id:String,val name:String,val p:List<Ctl>,val l:List<Ctl>)
class Store(var active:String,val list:MutableList<Lay>){fun cur():Lay=list.firstOrNull{it.id==active}?:list[0]}
object Ui{
 fun confirm(a:Activity,m:String,ok:()->Unit){AlertDialog.Builder(a).setMessage(m).setPositiveButton("Aceptar"){_,_->ok()}.setNegativeButton("Cancelar",null).show()}
 fun ask(a:Activity,ti:String,init:String,ok:(String)->Unit){val e=EditText(a).apply{setText(init);setSingleLine()}
  AlertDialog.Builder(a).setTitle(ti).setView(e).setPositiveButton("Aceptar"){_,_->val s=e.text.toString().trim();if(s.isNotEmpty())ok(s)}.setNegativeButton("Cancelar",null).show()}
}
object Layouts{
 /** Catálogo de «Añadir control»: (sección, nombre, tipos que añade). */
 val CATALOG=listOf(
  Triple("Entradas individuales","Button A",listOf("a")),Triple("Entradas individuales","Button B",listOf("b")),Triple("Entradas individuales","D-Pad",listOf("dpad")),
  Triple("Entradas individuales","L (TL)",listOf("l")),Triple("Entradas individuales","R (TR)",listOf("r")),Triple("Entradas individuales","Start",listOf("start")),Triple("Entradas individuales","Select",listOf("select")),
  Triple("Entradas individuales","Arriba",listOf("up")),Triple("Entradas individuales","Abajo",listOf("down")),Triple("Entradas individuales","Izquierda",listOf("left")),Triple("Entradas individuales","Derecha",listOf("right")),
  Triple("Combinaciones y turbo","A/B turbo",listOf("turbob","turboa")),Triple("Combinaciones y turbo","A+B",listOf("ab")),Triple("Combinaciones y turbo","TL+TR",listOf("lr")),
  Triple("Combinaciones y turbo","TL+A",listOf("la")),Triple("Combinaciones y turbo","TL+B",listOf("lb")),Triple("Combinaciones y turbo","TR+A",listOf("ra")),Triple("Combinaciones y turbo","TR+B",listOf("rb")),
  Triple("Combinaciones y turbo","Turbo TL",listOf("turbol")),Triple("Combinaciones y turbo","Turbo TR",listOf("turbor")),
  Triple("Acciones del emulador","Quick load",listOf("qload")),Triple("Acciones del emulador","Quick save",listOf("qsave")),Triple("Acciones del emulador","Fast forward",listOf("ff")),Triple("Acciones del emulador","Screenshot",listOf("shot")),Triple("Acciones del emulador","Trucos",listOf("cheats")))
 fun name(t:String)=CATALOG.firstOrNull{it.third.size==1&&it.third[0]==t}?.second?:when(t){"turboa"->"Turbo A";"turbob"->"Turbo B";"screen"->"Pantalla del juego";else->t}
 fun defSize(t:String)=when{t=="dpad"->.46f;CtlDraw.pill(t)->.15f;t in CtlDraw.ACT->.17f;else->.22f}
 /** Máscara de entrada con los ids de joypad de libretro (los que usa el núcleo mGBA): B0 SELECT2 START3 ARRIBA4 ABAJO5 IZQ6 DER7 A8 L10 R11. Las acciones del emulador valen 0: nunca son entradas del juego. */
 fun mask(t:String):Int{val A=1 shl 8;val B=1;val L=1 shl 10;val R=1 shl 11
  return when(t){"a","turboa"->A;"b","turbob"->B;"l","turbol"->L;"r","turbor"->R;"start"->1 shl 3;"select"->1 shl 2;"up"->1 shl 4;"down"->1 shl 5;"left"->1 shl 6;"right"->1 shl 7
   "ab"->A or B;"lr"->L or R;"la"->L or A;"lb"->L or B;"ra"->R or A;"rb"->R or B;else->0}}
 /** Distribución de fábrica (la que antes estaba fija en el código). */
 fun factory(land:Boolean):List<Ctl> = if(!land)listOf(Ctl("screen","screen",.5f,-1f,1f,1f),Ctl("dpad","dpad",.22f,.79f,.46f),Ctl("a","a",.88f,.74f,.24f),Ctl("b","b",.70f,.84f,.24f),
   Ctl("l","l",.14f,.60f,.15f),Ctl("r","r",.86f,.60f,.15f),Ctl("select","select",.36f,.95f,.13f),Ctl("start","start",.64f,.95f,.13f))
  else listOf(Ctl("screen","screen",.5f,.5f,1f,1f),Ctl("dpad","dpad",.11f,.66f,.52f),Ctl("a","a",.93f,.58f,.26f),Ctl("b","b",.83f,.80f,.26f),
   Ctl("l","l",.07f,.12f,.16f),Ctl("r","r",.93f,.12f,.16f),Ctl("select","select",.42f,.93f,.13f),Ctl("start","start",.58f,.93f,.13f))
 /** Rectángulo de la pantalla del juego (misma fórmula que GLView): ajusta al área, aplica escala s y coloca el centro en x,y (y < 0 = pegada arriba). */
 fun screenRect(w:Float,h:Float,aspect:Float,x:Float,y:Float,s:Float):RectF{var pw=w;var ph=w/aspect;if(ph>h){ph=h;pw=h*aspect};pw*=s;ph*=s
  val top=if(y<0)0f else y*h-ph/2f;return RectF(x*w-pw/2f,top,x*w+pw/2f,top+ph)}
 private fun cj(c:Ctl)=JSONObject().put("i",c.id).put("t",c.t).put("x",c.x.toDouble()).put("y",c.y.toDouble()).put("s",c.s.toDouble()).put("o",c.o.toDouble()).put("r",c.r.toDouble()).put("v",c.v).put("m",c.m).put("st",c.st)
 private fun co(o:JSONObject)=Ctl(o.getString("i"),o.getString("t"),o.getDouble("x").toFloat(),o.getDouble("y").toFloat(),o.getDouble("s").toFloat(),o.optDouble("o",.6).toFloat(),o.optDouble("r",0.0).toFloat(),o.optBoolean("v",true),o.optInt("m",0),o.optInt("st",0))
 private fun ar(a:JSONArray)=List(a.length()){co(a.getJSONObject(it))}
 fun load(c:Context):Store{
  try{val o=JSONObject(c.getSharedPreferences("layouts",0).getString("j","")!!);val a=o.getJSONArray("l")
   val l=MutableList(a.length()){val q=a.getJSONObject(it);Lay(q.getString("id"),q.getString("n"),ar(q.getJSONArray("p")),ar(q.getJSONArray("q")))}
   if(l.isNotEmpty())return Store(o.optString("a",l[0].id),l)}catch(e:Exception){}
  return Store("default",mutableListOf(Lay("default","Default",factory(false),factory(true))))}
 fun save(c:Context,s:Store){val a=JSONArray();s.list.forEach{l->a.put(JSONObject().put("id",l.id).put("n",l.name).put("p",JSONArray().also{j->l.p.forEach{j.put(cj(it))}}).put("q",JSONArray().also{j->l.l.forEach{j.put(cj(it))}}))}
  c.getSharedPreferences("layouts",0).edit().putString("j",JSONObject().put("v",1).put("a",s.active).put("l",a).toString()).apply()}
}
