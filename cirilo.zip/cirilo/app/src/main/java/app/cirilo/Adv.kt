package app.cirilo
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.zip.ZipInputStream
/** Ajustes avanzados (Ajustes → Avanzado). Se guardan en las preferencias «c» y se envían al núcleo al abrir un juego. */
object Adv{
 val SAVE_LABELS=listOf("Automático","EEPROM","SRAM","Flash 64K","Flash 128K","Ninguno")
 /** k = gba, gbc o gb; tamaño exacto que debe tener cada BIOS. */
 val BIOS=listOf(Triple("gba","GBA",16384),Triple("gbc","GBC",2304),Triple("gb","GB",256))
 fun dir(c:Context)=File(c.filesDir,"system")
 fun file(c:Context,k:String)=File(dir(c),k+"_bios.bin")
 fun name(c:Context,k:String):String?=if(file(c,k).length()>0)c.getSharedPreferences("c",0).getString("bios_"+k,null)?:k+"_bios.bin" else null
 fun remove(c:Context,k:String){file(c,k).delete();c.getSharedPreferences("c",0).edit().remove("bios_"+k).apply()}
 /** Copia el BIOS elegido (archivo suelto o .zip) a la carpeta privada de la app. Devuelve null si salió bien, o el texto del error. */
 fun import(c:Context,k:String,u:Uri):String?{
  val b=BIOS.first{it.first==k};val size=b.third
  try{
   var dn=k+"_bios.bin";var sz=-1L
   c.contentResolver.query(u,null,null,null,null)?.use{q->if(q.moveToFirst()){val a=q.getColumnIndex(OpenableColumns.DISPLAY_NAME);val z=q.getColumnIndex(OpenableColumns.SIZE);if(a>=0)dn=q.getString(a)?:dn;if(z>=0&&!q.isNull(z))sz=q.getLong(z)}}
   if(sz>8_000_000)return "El archivo es demasiado grande para ser un BIOS de "+b.second
   val raw=c.contentResolver.openInputStream(u)?.use{it.readBytes()}?:return "No se pudo leer el archivo"
   var data=raw
   if(raw.size>4&&raw[0]==0x50.toByte()&&raw[1]==0x4B.toByte()){ // .zip: se busca dentro el que se llame igual o, si no, uno con el tamaño exacto
    var byName:ByteArray?=null;var bySize:ByteArray?=null
    ZipInputStream(raw.inputStream()).use{z->while(true){val e=z.nextEntry?:break;if(e.isDirectory)continue;val d=z.readBytes()
     if(e.name.substringAfterLast('/').lowercase()==k+"_bios.bin")byName=d else if(d.size==size&&bySize==null)bySize=d}}
    data=byName?:bySize?:return "El .zip no trae ningún BIOS de "+b.second}
   if(data.size!=size)return "No parece un BIOS de "+b.second+": debe pesar "+size+" bytes y pesa "+data.size
   dir(c).mkdirs();file(c,k).writeBytes(data)
   c.getSharedPreferences("c",0).edit().putString("bios_"+k,dn).apply()
   return null
  }catch(e:Exception){return "No se pudo guardar el BIOS: "+(e.message?:"")}}
 /** Envía los ajustes a las dos consolas; valen para el próximo juego que se cargue. */
 fun push(c:Context){val p=c.getSharedPreferences("c",0)
  for(i in 0..1)Native.advConfig(i,p.getBoolean("bios_use",true),!p.getBoolean("bios_boot",true),p.getBoolean("speedhack",true),p.getInt("savetype",0),p.getBoolean("mosaic",true),dir(c).absolutePath)}
 fun reset(c:Context){BIOS.forEach{remove(c,it.first)};c.getSharedPreferences("c",0).edit().remove("bios_use").remove("bios_boot").remove("savetype").remove("speedhack").remove("mosaic").apply()}
}
