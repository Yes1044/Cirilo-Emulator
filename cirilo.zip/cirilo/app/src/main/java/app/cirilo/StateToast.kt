package app.cirilo
import android.app.Activity
import android.graphics.*
import android.graphics.drawable.*
import android.view.*
import android.view.animation.*
import android.widget.*

/** Aviso flotante al guardar o cargar un estado: tarjeta con la miniatura, arriba y centrada, que entra con rebote y se va sola.
 *  Va dentro de la escena del juego (no es un Toast: los Toast personalizados ya no se pueden dibujar desde Android 11) y no captura toques. */
object StateToast{
 private var cur:View?=null
 fun show(a:Activity,host:FrameLayout,thumb:Bitmap?,title:String,sub:String){
  val dn=a.resources.displayMetrics.density;fun dp(x:Int)=(x*dn).toInt()
  cur?.let{old->host.removeView(old);old.animate().cancel()}
  val c=LinearLayout(a);c.orientation=LinearLayout.HORIZONTAL;c.gravity=Gravity.CENTER_VERTICAL;c.setPadding(dp(8),dp(8),dp(16),dp(8));c.elevation=dp(8).toFloat()
  c.background=GradientDrawable().apply{setColor(0xF2262626.toInt());cornerRadius=dp(18).toFloat();setStroke(dp(2),Accent.color)}
  if(thumb!=null){
   val f=FrameLayout(a);f.setBackgroundColor(0xFF000000.toInt());f.outlineProvider=object:ViewOutlineProvider(){override fun getOutline(v:View,o:Outline){o.setRoundRect(0,0,v.width,v.height,dp(10).toFloat())}};f.clipToOutline=true
   f.addView(ImageView(a).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setImageDrawable(BitmapDrawable(a.resources,thumb).apply{isFilterBitmap=false})},FrameLayout.LayoutParams(-1,-1))
   c.addView(f,LinearLayout.LayoutParams(dp(84),dp(56)).apply{rightMargin=dp(12)})}
  val tx=LinearLayout(a);tx.orientation=LinearLayout.VERTICAL
  tx.addView(TextView(a).apply{text=title;textSize=15f;typeface=Typeface.DEFAULT_BOLD;setTextColor(-1)})
  tx.addView(TextView(a).apply{text=sub;textSize=13f;setTextColor(Accent.color)})
  c.addView(tx)
  host.addView(c,FrameLayout.LayoutParams(-2,-2,Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply{topMargin=dp(16)})
  cur=c;c.isClickable=false
  c.translationY=-dp(90).toFloat();c.alpha=0f;c.scaleX=.88f;c.scaleY=.88f
  c.animate().setStartDelay(0).translationY(0f).alpha(1f).scaleX(1f).scaleY(1f).setDuration(340).setInterpolator(OvershootInterpolator(1.3f)).withEndAction{
   if(c.parent!=null)c.animate().setStartDelay(1400).translationY(-dp(40).toFloat()).alpha(0f).setDuration(220).setInterpolator(AccelerateInterpolator()).withEndAction{host.removeView(c);if(cur===c)cur=null}.start()}.start()}
}
