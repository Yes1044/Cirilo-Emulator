package app.cirilo
import android.app.*
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.*
import android.view.*
import android.view.animation.*
import android.widget.*

/** Hoja de «Guardar estado» / «Cargar estado» (misma familia visual que `Sheet`, con el color de acento).
 *  Cada ranura con estado es una tarjeta con su miniatura y cuándo se guardó; al guardar, las vacías salen como huecos discontinuos con «+».
 *  Al cargar solo salen las ranuras que tienen estado. Al mantener pulsada una tarjeta con estado (en ambos modos) salen dos botones: eliminarlo o duplicarlo en la ranura siguiente (la 9 no tiene siguiente). Entrada con rebote y tarjetas escalonadas; las tarjetas se hunden un poco al pulsarlas. */
object StateSheet{
 fun show(a:Activity,save:Boolean,slots:List<StateStore.Slot>,onPick:(StateStore.Slot)->Unit,onDelete:(StateStore.Slot)->Unit,onDuplicate:(StateStore.Slot,StateStore.Slot)->Unit,onCancel:()->Unit){
  val dm=a.resources.displayMetrics;val dn=dm.density;fun dp(x:Int)=(x*dn).toInt()
  val acc=Accent.color;val now=System.currentTimeMillis();val fluid=StateToast.fluid(a) // false = animaciones simples
  val d=Dialog(a);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val shown=if(save)slots else slots.filter{it.exists}
  val filled=slots.count{it.exists}

  val card=LinearLayout(a);card.orientation=LinearLayout.VERTICAL;card.isClickable=true // no deja pasar los toques al fondo (que cancela)
  card.setPadding(dp(12),dp(18),dp(12),dp(12))
  card.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}

  // cabecera: barrita de acento, título y cuántos estados hay
  val head=LinearLayout(a);head.orientation=LinearLayout.HORIZONTAL;head.gravity=Gravity.CENTER_VERTICAL;head.setPadding(dp(10),0,dp(10),dp(12))
  head.addView(View(a).apply{background=GradientDrawable().apply{setColor(acc);cornerRadius=dp(2).toFloat()}},LinearLayout.LayoutParams(dp(4),dp(36)).apply{rightMargin=dp(12)})
  val tt=LinearLayout(a);tt.orientation=LinearLayout.VERTICAL
  tt.addView(TextView(a).apply{text=if(save)"Guardar estado" else "Cargar estado";textSize=21f;setTextColor(-1);typeface=Typeface.DEFAULT_BOLD})
  tt.addView(TextView(a).apply{text=(when(filled){0->"Sin estados guardados";1->"1 estado guardado";else->filled.toString()+" estados guardados"})+(if(filled>0)" · mantén pulsado para más" else "");textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
  head.addView(tt);card.addView(head)

  var done=false
  fun finish(f:()->Unit){if(done)return;done=true;card.animate().setStartDelay(0).translationY(if(fluid)dp(70).toFloat() else 0f).alpha(0f).setDuration(if(fluid)150L else 90L).setInterpolator(AccelerateInterpolator()).withEndAction{d.dismiss();f()}.start()}

  val list=LinearLayout(a);list.orientation=LinearLayout.VERTICAL
  val rows=ArrayList<View>()
  var opened:View?=null // la tarjeta con sus botones abiertos (solo una a la vez)
  fun hide(v:View){if(opened===v)opened=null;if(!fluid){v.visibility=View.GONE;return};v.animate().setStartDelay(0).alpha(0f).setDuration(140).withEndAction{v.visibility=View.GONE}.start()}
  for(s in shown){
   val full=s.exists
   val r=LinearLayout(a);r.orientation=LinearLayout.HORIZONTAL;r.gravity=Gravity.CENTER_VERTICAL
   r.setPadding(dp(10),dp(if(full)10 else 8),dp(14),dp(if(full)10 else 8))
   val bg=GradientDrawable().apply{cornerRadius=dp(18).toFloat();if(full)setColor(0xFF323232.toInt()) else{setColor(0);setStroke(dp(1),0x55FFFFFF,dp(6).toFloat(),dp(5).toFloat())}}
   val mask=GradientDrawable().apply{setColor(-1);cornerRadius=dp(18).toFloat()}
   r.background=RippleDrawable(ColorStateList.valueOf(Accent.alpha(80)),bg,mask)

   // miniatura (o hueco con «+»)
   val box=FrameLayout(a)
   if(full){
    box.setBackgroundColor(0xFF000000.toInt());box.outlineProvider=object:ViewOutlineProvider(){override fun getOutline(v:View,o:Outline){o.setRoundRect(0,0,v.width,v.height,dp(12).toFloat())}};box.clipToOutline=true
    val bm=StateStore.thumbOf(s)
    if(bm!=null)box.addView(ImageView(a).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setImageDrawable(BitmapDrawable(a.resources,bm).apply{isFilterBitmap=false})},FrameLayout.LayoutParams(-1,-1))
    else box.addView(TextView(a).apply{text="Sin vista\nprevia";textSize=11f;gravity=Gravity.CENTER;setTextColor(0xFF757575.toInt())},FrameLayout.LayoutParams(-1,-1))
    r.addView(box,LinearLayout.LayoutParams(dp(120),dp(80)))
   }else{
    box.background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Accent.alpha(40))}
    box.addView(TextView(a).apply{text="+";textSize=24f;gravity=Gravity.CENTER;setTextColor(acc)},FrameLayout.LayoutParams(-1,-1))
    r.addView(box,LinearLayout.LayoutParams(dp(40),dp(40)))
   }

   // texto
   val tx=LinearLayout(a);tx.orientation=LinearLayout.VERTICAL
   tx.addView(TextView(a).apply{text=StateStore.title(s.n);textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(if(s.n==0)acc else -1)})
   tx.addView(TextView(a).apply{text=if(full)StateFmt.line(now,s.time) else "Vacía";textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
   if(full&&save)tx.addView(TextView(a).apply{text="Toca para sobrescribir";textSize=12f;setTextColor(Accent.alpha(200));setPadding(0,dp(3),0,0)})
   r.addView(tx,LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(14)})

   if(fluid)r.setOnTouchListener{v,e->
    when(e.actionMasked){
     MotionEvent.ACTION_DOWN->v.animate().setStartDelay(0).scaleX(.97f).scaleY(.97f).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
     MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->v.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()}
    false}
   r.setOnClickListener{finish{onPick(s)}}
   val wrap=FrameLayout(a);wrap.addView(r,FrameLayout.LayoutParams(-1,-2))
   if(full){
    // botones que salen al mantener pulsado: eliminar y duplicar en la ranura siguiente
    val nx=slots.getOrNull(s.n+1)
    val ov=LinearLayout(a);ov.orientation=LinearLayout.HORIZONTAL;ov.gravity=Gravity.CENTER;ov.visibility=View.GONE;ov.alpha=0f;ov.isClickable=true
    ov.setPadding(dp(10),dp(10),dp(10),dp(10))
    ov.background=GradientDrawable().apply{setColor(0xF2202020.toInt());cornerRadius=dp(18).toFloat()}
    fun btn(label:String,sub:String?,col:Int,on:Boolean,f:()->Unit){
     val b=LinearLayout(a);b.orientation=LinearLayout.VERTICAL;b.gravity=Gravity.CENTER;b.alpha=if(on)1f else .4f
     b.background=RippleDrawable(ColorStateList.valueOf((col and 0xFFFFFF) or 0x50000000),GradientDrawable().apply{setColor((col and 0xFFFFFF) or 0x28000000);cornerRadius=dp(14).toFloat();setStroke(dp(1),(col and 0xFFFFFF) or 0x80000000.toInt())},GradientDrawable().apply{setColor(-1);cornerRadius=dp(14).toFloat()})
     b.addView(TextView(a).apply{text=label;textSize=15f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(col)})
     if(sub!=null)b.addView(TextView(a).apply{text=sub;textSize=11f;gravity=Gravity.CENTER;setTextColor(0xFF9E9E9E.toInt())})
     if(on)b.setOnClickListener{f()}
     ov.addView(b,LinearLayout.LayoutParams(0,-1,1f).apply{leftMargin=dp(4);rightMargin=dp(4)})}
    btn("Eliminar",null,0xFFEF9A9A.toInt(),true){finish{onDelete(s)}}
    btn(if(nx!=null)"Duplicar en "+StateStore.title(nx.n) else "Duplicar",if(nx==null)"No hay ranura siguiente" else if(nx.exists)"Sobrescribe lo que hay" else null,acc,nx!=null){finish{onDuplicate(s,nx!!)}}
    ov.setOnClickListener{hide(ov)}
    wrap.addView(ov,FrameLayout.LayoutParams(-1,-1))
    r.setOnLongClickListener{opened?.let{o->if(o!==ov)hide(o)}
     r.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);opened=ov;ov.visibility=View.VISIBLE
     if(fluid){ov.scaleX=.94f;ov.scaleY=.94f;ov.animate().setStartDelay(0).alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()} else ov.alpha=1f
     true}}
   list.addView(wrap,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})
   rows.add(wrap)}
  card.addView(ScrollView(a).apply{addView(list);isVerticalScrollBarEnabled=false;overScrollMode=View.OVER_SCROLL_NEVER},LinearLayout.LayoutParams(-1,-2))

  val root=FrameLayout(a);root.setPadding(dp(12),dp(12),dp(12),dp(12));root.addView(card,FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
  root.setOnClickListener{d.cancel()}
  d.setContentView(root);d.setOnCancelListener{if(!done){done=true;onCancel()}}
  d.window?.apply{setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0));setLayout(minOf(dm.widthPixels,dp(504)),-2);setGravity(Gravity.BOTTOM)}

  // entrada: la hoja sube con un pequeño rebote y las tarjetas aparecen una tras otra
  if(!fluid){card.alpha=0f;d.show();card.animate().setStartDelay(0).alpha(1f).setDuration(120L).start();return}
  card.translationY=dp(90).toFloat();card.alpha=0f
  rows.forEach{it.alpha=0f;it.translationY=dp(26).toFloat()}
  d.show()
  card.animate().translationY(0f).alpha(1f).setStartDelay(0).setDuration(320).setInterpolator(OvershootInterpolator(.9f)).start()
  rows.forEachIndexed{i,v->v.animate().alpha(1f).translationY(0f).setStartDelay(90L+i*45L).setDuration(260).setInterpolator(DecelerateInterpolator()).start()}
 }
}
