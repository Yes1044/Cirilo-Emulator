package app.cirilo
import android.app.*
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.*
import android.view.*
import android.view.animation.*
import android.widget.*

/** Hoja de «Guardar estado» / «Cargar estado» (misma familia visual que `Sheet`, con el color de acento).
 *  Cada ranura con estado es una tarjeta con su miniatura y cuándo se guardó; al guardar, las vacías salen como huecos discontinuos con «+».
 *  Al cargar solo salen las ranuras que tienen estado. Entrada con rebote y tarjetas escalonadas; las tarjetas se hunden un poco al pulsarlas. */
object StateSheet{
 fun show(a:Activity,save:Boolean,slots:List<StateStore.Slot>,onPick:(StateStore.Slot)->Unit,onCancel:()->Unit){
  val dm=a.resources.displayMetrics;val dn=dm.density;fun dp(x:Int)=(x*dn).toInt()
  val acc=Accent.color;val now=System.currentTimeMillis()
  val d=Dialog(a);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val shown=if(save)slots else slots.filter{it.exists}
  val filled=slots.count{it.exists}

  val card=LinearLayout(a);card.orientation=LinearLayout.VERTICAL;card.isClickable=true // no deja pasar los toques al fondo (que cancela)
  card.setPadding(dp(12),dp(18),dp(12),dp(12))
  card.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}

  // cabecera: barrita de acento, título y cuántos estados hay
  val head=LinearLayout(a);head.orientation=LinearLayout.HORIZONTAL;head.gravity=Gravity.CENTER_VERTICAL;head.setPadding(dp(10),0,dp(10),dp(12))
  head.addView(View(a).apply{background=GradientDrawable().apply{setColor(acc);cornerRadius=dp(2).toFloat()}},LinearLayout.LayoutParams(dp(4),dp(36)).apply{rightMargin=dp(12)})
  val tt=LinearLayout(a);tt.orientation=LinearLayout.VERTICAL
  tt.addView(TextView(a).apply{text=if(save)"Guardar estado" else "Cargar estado";textSize=21f;setTextColor(-1);typeface=Typeface.DEFAULT_BOLD})
  tt.addView(TextView(a).apply{text=when(filled){0->"Sin estados guardados";1->"1 estado guardado";else->filled.toString()+" estados guardados"};textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
  head.addView(tt);card.addView(head)

  var done=false
  fun finish(f:()->Unit){if(done)return;done=true;card.animate().setStartDelay(0).translationY(dp(70).toFloat()).alpha(0f).setDuration(150).setInterpolator(AccelerateInterpolator()).withEndAction{d.dismiss();f()}.start()}

  val list=LinearLayout(a);list.orientation=LinearLayout.VERTICAL
  val rows=ArrayList<View>()
  for(s in shown){
   val full=s.exists
   val r=LinearLayout(a);r.orientation=LinearLayout.HORIZONTAL;r.gravity=Gravity.CENTER_VERTICAL
   r.setPadding(dp(10),dp(if(full)10 else 8),dp(14),dp(if(full)10 else 8))
   val bg=GradientDrawable().apply{cornerRadius=dp(18).toFloat();if(full)setColor(0xFF323232.toInt()) else{setColor(0);setStroke(dp(1),0x55FFFFFF,dp(6).toFloat(),dp(5).toFloat())}}
   val mask=GradientDrawable().apply{setColor(-1);cornerRadius=dp(18).toFloat()}
   r.background=RippleDrawable(ColorStateList.valueOf(Accent.alpha(80)),bg,mask)

   // miniatura (o hueco con «+»)
   val box=FrameLayout(a)
   if(full){
    box.setBackgroundColor(0xFF000000.toInt());box.outlineProvider=object:ViewOutlineProvider(){override fun getOutline(v:View,o:Outline){o.setRoundRect(0,0,v.width,v.height,dp(12).toFloat())}};box.clipToOutline=true
    val bm=StateStore.thumbOf(s)
    if(bm!=null)box.addView(ImageView(a).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setImageDrawable(BitmapDrawable(a.resources,bm).apply{isFilterBitmap=false})},FrameLayout.LayoutParams(-1,-1))
    else box.addView(TextView(a).apply{text="Sin vista\nprevia";textSize=11f;gravity=Gravity.CENTER;setTextColor(0xFF757575.toInt())},FrameLayout.LayoutParams(-1,-1))
    r.addView(box,LinearLayout.LayoutParams(dp(120),dp(80)))
   }else{
    box.background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Accent.alpha(40))}
    box.addView(TextView(a).apply{text="+";textSize=24f;gravity=Gravity.CENTER;setTextColor(acc)},FrameLayout.LayoutParams(-1,-1))
    r.addView(box,LinearLayout.LayoutParams(dp(40),dp(40)))
   }

   // texto
   val tx=LinearLayout(a);tx.orientation=LinearLayout.VERTICAL
   tx.addView(TextView(a).apply{text=StateStore.title(s.n);textSize=17f;typeface=Typeface.DEFAULT_BOLD;setTextColor(if(s.n==0)acc else -1)})
   tx.addView(TextView(a).apply{text=if(full)StateFmt.line(now,s.time) else "Vacía";textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
   if(full&&save)tx.addView(TextView(a).apply{text="Toca para sobrescribir";textSize=12f;setTextColor(Accent.alpha(200));setPadding(0,dp(3),0,0)})
   r.addView(tx,LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(14)})

   r.setOnTouchListener{v,e->
    when(e.actionMasked){
     MotionEvent.ACTION_DOWN->v.animate().setStartDelay(0).scaleX(.97f).scaleY(.97f).setDuration(90).setInterpolator(DecelerateInterpolator()).start()
     MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->v.animate().setStartDelay(0).scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()}
    false}
   r.setOnClickListener{finish{onPick(s)}}
   list.addView(r,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})
   rows.add(r)}
  card.addView(ScrollView(a).apply{addView(list);isVerticalScrollBarEnabled=false;overScrollMode=View.OVER_SCROLL_NEVER},LinearLayout.LayoutParams(-1,-2))

  val root=FrameLayout(a);root.setPadding(dp(12),dp(12),dp(12),dp(12));root.addView(card,FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
  root.setOnClickListener{d.cancel()}
  d.setContentView(root);d.setOnCancelListener{if(!done){done=true;onCancel()}}
  d.window?.apply{setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0));setLayout(minOf(dm.widthPixels,dp(504)),-2);setGravity(Gravity.BOTTOM)}

  // entrada: la hoja sube con un pequeño rebote y las tarjetas aparecen una tras otra
  card.translationY=dp(90).toFloat();card.alpha=0f
  rows.forEach{it.alpha=0f;it.translationY=dp(26).toFloat()}
  d.show()
  card.animate().translationY(0f).alpha(1f).setStartDelay(0).setDuration(320).setInterpolator(OvershootInterpolator(.9f)).start()
  rows.forEachIndexed{i,v->v.animate().alpha(1f).translationY(0f).setStartDelay(90L+i*45L).setDuration(260).setInterpolator(DecelerateInterpolator()).start()}
 }
}
