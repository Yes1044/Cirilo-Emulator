package app.cirilo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract as DC
import java.io.File
/** Guardados de My Boy! (GBA) y My OldBoy! (GB/GBC). Una preferencia por app en «lib» (save_mode_gba / save_mode_gbc): ausente = aún sin elegir; copy = copiar a Cirilo; shared = usar su carpeta; ignore = ignorar.
 *  Acceso a la carpeta: 1) directo (Android 10 o menos), 2) Shizuku (Android 11+) o 3) selector de carpetas (SAF, algunos Android 11-12). En modo compartido sin acceso directo se trabaja con una copia espejo local que se sincroniza al abrir y al salir del juego. */
object SaveSync{
 const val COPY="copy";const val SHARED="shared";const val IGNORE="ignore"
 enum class Src(val pkg:String,val label:String,val sys:String,val key:String){
  BOY("com.fastemulator.gba","My Boy!","GBA","save_mode_gba"),OLD("com.fastemulator.gbc","My OldBoy!","GB y GBC","save_mode_gbc")}
 /** Un guardado de My Boy!: archivo directo o lector de un acceso remoto (Shizuku / SAF). */
 class Sv(val f:File?,private val open:(()->java.io.InputStream?)?=null){fun copy(o:File):Boolean{o.parentFile?.mkdirs();if(f!=null){f.copyTo(o,true);return true}
  val i=open?.invoke()?:return false;i.use{x->o.outputStream().use{x.copyTo(it)}};return true}}
 private class RE(val lm:Long,val ref:String) // entrada remota: fecha y ruta/URI
 private class Rem(val list:()->Map<String,RE>,val open:(RE)->java.io.InputStream?,val put:(RE?,String,File)->Boolean,val del:(RE)->Unit)
 private class D(val id:String,val name:String,val dir:Boolean,val lm:Long)
 private fun sp(c:Context)=c.getSharedPreferences("lib",0)
 fun mode(c:Context,s:Src):String?=sp(c).getString(s.key,null)
 fun setMode(c:Context,s:Src,m:String){sp(c).edit().putString(s.key,m).apply()}
 fun anyShared(c:Context)=Src.values().any{mode(c,it)==SHARED}
 private fun base(n:String)=n.substringBeforeLast('.')
 private fun own(c:Context,n:String)=File(c.getExternalFilesDir("saves"),base(n)+".sav")
 private fun mirror(c:Context,s:Src,b:String)=File(c.getExternalFilesDir("saves_shared"),s.key+"/"+b+".sav")
 // ---- acceso directo ----
 /** Almacenamiento interno y tarjeta SD (cada volumen, deducido de las carpetas externas de esta app). */
 private fun roots(c:Context):List<File>{val l=ArrayList<File>();l+=Environment.getExternalStorageDirectory()
  c.getExternalFilesDirs(null).forEach{f->val p=f?.absolutePath?:return@forEach;val i=p.indexOf("/Android/data");if(i>0)l+=File(p.substring(0,i))}
  return l.distinctBy{it.absolutePath}}
 /** .../Android/data/<paquete>/files/save en cada volumen. */
 fun dirs(c:Context,s:Src)=roots(c).map{File(it,"Android/data/"+s.pkg+"/files/save")}
 private fun savs(d:File)=d.listFiles()?.filter{it.isFile&&it.extension.equals("sav",true)}?:emptyList()
 private fun direct(c:Context,s:Src):Map<String,File>{val m=HashMap<String,File>();dirs(c,s).forEach{d->savs(d).forEach{m.putIfAbsent(it.nameWithoutExtension.lowercase(),it)}};return m}
 /** ¿Puede Cirilo listar la carpeta directamente? Android 11+ lo impide en Android/data de otras apps. */
 fun hasDirect(c:Context,s:Src)=dirs(c,s).any{it.listFiles()!=null}
 // ---- acceso por selector de carpetas (SAF) ----
 private fun treeUri(c:Context,s:Src):Uri?{val u=sp(c).getString(s.key+"_tree",null)?.let{Uri.parse(it)}?:return null
  return if(c.contentResolver.persistedUriPermissions.any{it.uri==u&&it.isReadPermission})u else null}
 fun hasTree(c:Context,s:Src)=treeUri(c,s)!=null
 fun setTree(c:Context,s:Src,u:Uri){try{c.contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)}catch(e:Exception){}
  sp(c).edit().putString(s.key+"_tree",u.toString()).apply()}
 /** Selector de carpetas abierto ya en Android/data/<paquete>/files/save. */
 fun pickIntent(s:Src):Intent{val i=Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
  if(Build.VERSION.SDK_INT>=26)i.putExtra(DC.EXTRA_INITIAL_URI,DC.buildDocumentUri("com.android.externalstorage.documents","primary:Android/data/"+s.pkg+"/files/save"))
  return i}
 fun installed(c:Context,s:Src)=try{c.packageManager.getPackageInfo(s.pkg,0);true}catch(e:Exception){false}
 fun markAsked(c:Context,s:Src){sp(c).edit().putBoolean(s.key+"_asked",true).apply()}
 /** Apps instaladas, sin elección, sin acceso de ninguna clase y a las que aún no se ha ofrecido el selector. */
 fun needAccess(c:Context):List<Src> = Src.values().filter{mode(c,it)==null&&!hasDirect(c,it)&&treeUri(c,it)==null&&!Shell.granted()&&installed(c,it)&&!sp(c).getBoolean(it.key+"_asked",false)}
 /** Acceso de cualquier clase. */
 fun accessible(c:Context,s:Src)=hasDirect(c,s)||Shell.granted()||treeUri(c,s)!=null
 private fun kids(c:Context,t:Uri,id:String):List<D>{val o=ArrayList<D>()
  try{c.contentResolver.query(DC.buildChildDocumentsUriUsingTree(t,id),arrayOf(DC.Document.COLUMN_DOCUMENT_ID,DC.Document.COLUMN_DISPLAY_NAME,DC.Document.COLUMN_MIME_TYPE,DC.Document.COLUMN_LAST_MODIFIED),null,null,null)?.use{q->
   while(q.moveToNext())o+=D(q.getString(0),q.getString(1)?:"",q.getString(2)==DC.Document.MIME_TYPE_DIR,q.getLong(3))}}catch(e:Exception){}
  return o}
 /** Carpeta elegida; si el usuario eligió «files» (sin .sav y con una subcarpeta «save»), esa subcarpeta. */
 private fun saveDir(c:Context,t:Uri):String{val root=DC.getTreeDocumentId(t);val k=kids(c,t,root)
  return k.firstOrNull{it.dir&&it.name.equals("save",true)}?.takeIf{k.none{x->!x.dir&&x.name.endsWith(".sav",true)}}?.id?:root}
 private fun docs(c:Context,t:Uri):Map<String,D>{val m=HashMap<String,D>();kids(c,t,saveDir(c,t)).forEach{if(!it.dir&&it.name.endsWith(".sav",true))m.putIfAbsent(it.name.substringBeforeLast('.').lowercase(),it)};return m}
 // ---- acceso remoto: Shizuku (si está concedido) o selector de carpetas ----
 private fun shellRem(c:Context,s:Src):Rem{val ds=dirs(c,s).map{it.absolutePath}
  return Rem({val m=HashMap<String,RE>();ds.forEach{d->Shell.list(c,d).forEach{(n,lm)->m.putIfAbsent(n.substringBeforeLast('.').lowercase(),RE(lm,d+"/"+n))}};m},
   {e->Shell.read(c,e.ref)?.let{java.io.ByteArrayInputStream(it)}},
   {e,name,m->val p=e?.ref?:ds.firstOrNull{Shell.isDir(c,it)}?.let{it+"/"+name+".sav"};p!=null&&Shell.write(c,p,m.readBytes())},
   {Shell.delete(c,it.ref)})}
 private fun safRem(c:Context,t:Uri):Rem=Rem({docs(c,t).mapValues{(_,d)->RE(d.lm,DC.buildDocumentUriUsingTree(t,d.id).toString())}},
   {e->c.contentResolver.openInputStream(Uri.parse(e.ref))},
   {e,name,m->try{val u=if(e!=null)Uri.parse(e.ref) else DC.createDocument(c.contentResolver,DC.buildDocumentUriUsingTree(t,saveDir(c,t)),"application/octet-stream",name+".sav")
    if(u==null)false else{c.contentResolver.openOutputStream(u,"wt")!!.use{o->m.inputStream().use{it.copyTo(o)}};true}}catch(x:Exception){false}},
   {DC.deleteDocument(c.contentResolver,Uri.parse(it.ref))})
 private fun rem(c:Context,s:Src):Rem?=if(Shell.granted())shellRem(c,s) else treeUri(c,s)?.let{safRem(c,it)}
 /** Cómo se accede a la carpeta: "" (directo o sin acceso), "Shizuku" o "selector". */
 fun how(c:Context,s:Src)=if(hasDirect(c,s))"" else if(Shell.granted())"Shizuku" else if(treeUri(c,s)!=null)"selector" else ""
 private fun index(c:Context,s:Src):Map<String,Sv>{val m=LinkedHashMap<String,Sv>();direct(c,s).forEach{(k,f)->m[k]=Sv(f)}
  rem(c,s)?.let{r->r.list().forEach{(k,e)->m.putIfAbsent(k,Sv(null,{r.open(e)}))}};return m}
 fun writable(c:Context,s:Src)=dirs(c,s).any{it.isDirectory&&it.canWrite()}||Shell.granted()||treeUri(c,s)!=null
 /** Qué app corresponde a un juego: GBA → My Boy!, GB/GBC → My OldBoy!. Un .zip sin plataforma calculada vale para ambas. */
 private fun srcs(g:Game):List<Src> = when(g.p){2->listOf(Src.BOY);0,1->listOf(Src.OLD);else->when(Roms.ext(g.n)){"gba"->listOf(Src.BOY);"gb","gbc"->listOf(Src.OLD);else->Src.values().toList()}}
 /** Juegos de la lista con guardado en la app s (se empareja por nombre de archivo, sin extensión). */
 fun find(c:Context,s:Src,gs:List<Game>):List<Pair<Game,Sv>>{val ix=index(c,s);if(ix.isEmpty())return emptyList();return gs.filter{s in srcs(it)}.mapNotNull{g->ix[base(g.n).lowercase()]?.let{g to it}}}
 /** Copia a la carpeta de Cirilo sin pisar guardados que ya existan. Devuelve cuántos copió. */
 fun copyIn(c:Context,f:List<Pair<Game,Sv>>):Int{var n=0
  f.forEach{(g,s)->val o=own(c,g.n);if(!o.exists())try{if(s.copy(o))n++}catch(e:Exception){}};return n}
 /** Tras añadir juegos. Por cada app: sin elección previa devuelve lo encontrado en TODA la biblioteca para preguntar; en modo copiar copia los nuevos en silencio. */
 fun pending(c:Context,added:List<Game>):List<Pair<Src,List<Pair<Game,Sv>>>>{val out=ArrayList<Pair<Src,List<Pair<Game,Sv>>>>()
  Src.values().forEach{s->when(mode(c,s)){null->{val f=find(c,s,Lib.all(c));if(f.isNotEmpty())out+=s to f};COPY->copyIn(c,find(c,s,added));else->{}}};return out}
 // ---- modo compartido ----
 fun srcOf(rom:String)=if(Roms.ext(rom)=="gba")Src.BOY else Src.OLD
 /** Archivo de guardado que usa el emulador. n = nombre del archivo elegido; rom = nombre de la ROM real (dentro del .zip si lo es), que decide la app.
  *  Compartido: archivo directo si se puede; si no, copia espejo del documento SAF (se vuelve a subir con push). Sin acceso de escritura se usa la carpeta de Cirilo. */
 @Synchronized fun file(c:Context,n:String,rom:String):File{val o=own(c,n);val s=srcOf(rom)
  if(mode(c,s)!=SHARED)return o
  val b=base(n);val ex=direct(c,s)[b.lowercase()]
  if(ex!=null)return if(ex.canWrite())ex else o
  val d=dirs(c,s).firstOrNull{it.isDirectory&&it.canWrite()}
  if(d!=null){val f=File(d,b+".sav");if(o.exists())try{o.copyTo(f)}catch(e:Exception){return o};return f} // no perder el progreso que ya había en Cirilo
  val r=rem(c,s)?:return o
  val m=mirror(c,s,b);m.parentFile?.mkdirs();val e=r.list()[b.lowercase()];val k="sync_"+s.key+"_"+b
  try{if(e!=null){if(!m.exists()||sp(c).getLong(k,-1)!=e.lm){r.open(e)!!.use{i->m.outputStream().use{i.copyTo(it)}};sp(c).edit().putLong(k,e.lm).apply()}}
   else if(!m.exists()&&o.exists())o.copyTo(m)}catch(x:Exception){return o}
  return m}
 // ---- Google Drive: el «almacén activo» de cada app (carpeta de My Boy si es compartido; carpeta de Cirilo si es copiar o sin elegir; nada si se ignora) ----
 class Loc(val name:String,val lm:Long)
 fun keyOf(n:String)=base(n).lowercase()
 private fun ownGames(c:Context,s:Src)=Lib.all(c).filter{srcs(it).firstOrNull()==s}
 private fun ownF(c:Context,name:String)=File(c.getExternalFilesDir("saves"),name+".sav")
 /** Guardados del almacén activo: clave (nombre en minúsculas) → nombre real y fecha. null = esta app se ignora. */
 fun storeList(c:Context,s:Src):Map<String,Loc>?{val m=LinkedHashMap<String,Loc>()
  when(mode(c,s)){IGNORE->return null
   SHARED->{direct(c,s).forEach{(k,f)->m[k]=Loc(f.nameWithoutExtension,f.lastModified())}
    rem(c,s)?.let{r->r.list().forEach{(k,e)->m.putIfAbsent(k,Loc(base(Uri.decode(e.ref).substringAfterLast('/')),e.lm))}}}
   else->ownGames(c,s).forEach{g->val f=ownF(c,base(g.n));if(f.exists())m[base(g.n).lowercase()]=Loc(base(g.n),f.lastModified())}}
  return m}
 /** ¿Se puede guardar aquí un guardado que solo existe en Drive? En «copiar» solo si el juego está en la biblioteca. */
 fun canStore(c:Context,s:Src,k:String)=when(mode(c,s)){IGNORE->false;SHARED->true;else->ownGames(c,s).any{base(it.n).lowercase()==k}}
 fun storeRead(c:Context,s:Src,k:String,name:String):ByteArray?{
  if(mode(c,s)!=SHARED)return ownF(c,name).takeIf{it.exists()}?.readBytes()
  direct(c,s)[k]?.let{return it.readBytes()}
  val r=rem(c,s)?:return null;val e=r.list()[k]?:return null;return r.open(e)?.use{it.readBytes()}}
 fun storeWrite(c:Context,s:Src,k:String,name:String,b:ByteArray):Boolean{
  try{if(mode(c,s)!=SHARED){val f=ownF(c,name);f.parentFile?.mkdirs();f.writeBytes(b);return true}
   val ex=direct(c,s)[k];if(ex!=null&&ex.canWrite()){ex.writeBytes(b);return true}
   val d=dirs(c,s).firstOrNull{it.isDirectory&&it.canWrite()};if(d!=null){File(d,name+".sav").writeBytes(b);return true}
   val r=rem(c,s)?:return false;val t=File.createTempFile("gd",".sav",c.cacheDir)
   try{t.writeBytes(b);return r.put(r.list()[k],name,t)}finally{t.delete()}}catch(e:Exception){return false}}
 /** ¿Se pidió modo compartido pero se acabó usando el guardado de Cirilo? */
 fun fellBack(c:Context,n:String,rom:String,f:File)=mode(c,srcOf(rom))==SHARED&&f==own(c,n)
 /** Sube la copia espejo al acceso remoto (al pausar o cerrar el juego). No hace nada si no se usó espejo. */
 @Synchronized fun push(c:Context,n:String,rom:String){val s=srcOf(rom);if(mode(c,s)!=SHARED)return
  val b=base(n);val key=b.lowercase();if(direct(c,s)[key]!=null||dirs(c,s).any{it.isDirectory&&it.canWrite()})return
  val r=rem(c,s)?:return;val m=mirror(c,s,b);if(!m.exists())return
  try{if(r.put(r.list()[key],b,m))r.list()[key]?.let{sp(c).edit().putLong("sync_"+s.key+"_"+b,it.lm).apply()}}catch(x:Exception){}}
 /** Borra los guardados compartidos de este juego (solo de las apps en modo compartido), incluida la copia espejo. Llamar fuera del hilo principal. */
 fun deleteShared(c:Context,g:Game){val b=base(g.n);val key=b.lowercase()
  srcs(g).filter{mode(c,it)==SHARED}.forEach{s->try{direct(c,s)[key]?.delete();rem(c,s)?.let{r->r.list()[key]?.let{r.del(it)}};mirror(c,s,b).delete()}catch(x:Exception){}}}
}
