package app.cirilo
import android.content.Context
import android.os.Environment
import java.io.File
/** Guardados de My Boy!/My GBC!. Preferencia «save_mode» en «lib»: ausente = aún sin elegir; copy = copiar a Cirilo; shared = usar la carpeta de My Boy!; ignore = ignorar. */
object SaveSync{
 const val COPY="copy";const val SHARED="shared";const val IGNORE="ignore"
 /** Carpetas (bajo el almacenamiento interno) donde My Boy! deja los .sav. Ajusta la lista si tu versión usa otra. */
 private val DIRS=listOf("MyBoy/Saves","MyBoy/Save","MyBoy","MyGBC/Saves","MyGBC")
 private fun sp(c:Context)=c.getSharedPreferences("lib",0)
 fun mode(c:Context):String?=sp(c).getString("save_mode",null)
 fun setMode(c:Context,m:String){sp(c).edit().putString("save_mode",m).apply()}
 private fun base(n:String)=n.substringBeforeLast('.')
 private fun own(c:Context,n:String)=File(c.getExternalFilesDir("saves"),base(n)+".sav")
 private fun dirs()=DIRS.map{File(Environment.getExternalStorageDirectory(),it)}.filter{it.isDirectory}
 private fun savs(d:File)=d.listFiles()?.filter{it.isFile&&it.extension.equals("sav",true)}?:emptyList()
 /** Nombre sin extensión (en minúsculas) → archivo .sav de My Boy!. */
 private fun index():Map<String,File>{val m=HashMap<String,File>();dirs().forEach{d->savs(d).forEach{m.putIfAbsent(it.nameWithoutExtension.lowercase(),it)}};return m}
 /** Carpeta de My Boy! que se usa en modo compartido: la que ya tiene .sav, o la primera que exista, o MyBoy/Saves. */
 fun sharedDir():File{val d=dirs();return d.firstOrNull{savs(it).isNotEmpty()}?:d.firstOrNull()?:File(Environment.getExternalStorageDirectory(),DIRS[0])}
 fun writable():Boolean{val d=sharedDir();d.mkdirs();return d.canWrite()}
 /** Juegos de la lista que tienen guardado en My Boy! (se empareja por nombre de archivo, sin extensión). */
 fun find(gs:List<Game>):List<Pair<Game,File>>{val ix=index();if(ix.isEmpty())return emptyList();return gs.mapNotNull{g->ix[base(g.n).lowercase()]?.let{g to it}}}
 /** Copia a la carpeta de Cirilo sin pisar guardados que ya existan. Devuelve cuántos copió. */
 fun copyIn(c:Context,f:List<Pair<Game,File>>):Int{var n=0
  f.forEach{(g,s)->val o=own(c,g.n);if(!o.exists())try{o.parentFile?.mkdirs();s.copyTo(o);n++}catch(e:Exception){}};return n}
 /** Tras añadir juegos: sin elección previa devuelve lo encontrado en TODA la biblioteca para preguntar; en modo copiar copia los nuevos en silencio. */
 fun pending(c:Context,added:List<Game>):List<Pair<Game,File>>{
  return when(mode(c)){null->find(Lib.all(c));COPY->{copyIn(c,find(added));emptyList()};else->emptyList()}}
 /** Archivo de guardado que usa el emulador para este juego. En modo compartido, si no se puede escribir en la carpeta de My Boy! se usa la de Cirilo. */
 fun file(c:Context,name:String):File{val o=own(c,name)
  if(mode(c)!=SHARED)return o
  val b=base(name);val ex=index()[b.lowercase()]
  if(ex!=null)return if(ex.canWrite())ex else o
  val d=sharedDir();d.mkdirs();if(!d.canWrite())return o
  val f=File(d,b+".sav");if(o.exists())try{o.copyTo(f)}catch(e:Exception){return o} // no perder el progreso que ya había en Cirilo
  return f}
 /** Guardado de My Boy! de este juego, si existe (sin crear nada). */
 fun existing(name:String):File?=index()[base(name).lowercase()]
}
