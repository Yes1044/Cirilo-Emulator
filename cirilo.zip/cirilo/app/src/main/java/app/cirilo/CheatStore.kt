package app.cirilo
import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/** Identidad del juego en ejecución. id = SHA-1 de la ROM completa (ya descomprimida): distingue regiones, revisiones y hacks, así que los trucos de una edición nunca se aplican a otra. */
class GameInfo(val id:String,val plat:Int,val code:String,val title:String)
object GameId{
 fun of(rom:ByteArray,name:String):GameInfo{
  val gba=Roms.ext(name)=="gba"
  val sha=MessageDigest.getInstance("SHA-1").digest(rom).joinToString(""){"%02x".format(it)}
  // código de producto de la cabecera (solo informativo): GBA 0xAC..0xAF; GB/GBC 0x13F..0x142
  val o=if(gba)0xAC else 0x13F
  val code=if(rom.size>o+4)String(rom,o,4,Charsets.ISO_8859_1).filter{it in ' '..'~'}.trim() else ""
  return GameInfo(sha,if(gba)CheatCodes.GBA else CheatCodes.GB,code,name.substringBeforeLast('.'))}
}

/** Un truco guardado. code se conserva exactamente como lo escribió el usuario. det = modo resuelto en detección automática (ordinal de CheatFormat; 0 = lo detecta mGBA). */
data class Cheat(val id:String,val name:String,val format:CheatFormat,val code:String,val enabled:Boolean=false,val det:Int=0,val label:String=""){
 /** Modo que se envía al núcleo. */
 val mode get()=if(format==CheatFormat.AUTO)det else format.ordinal
 /** Texto de transporte para el núcleo. */
 val text get()=CheatCodes.transportOf(code)
 val lines get()=CheatCodes.lines(code).size
 /** Nombre del formato: el elegido, o el detectado. Si det es 1..4 se deduce de él (así no dependemos de textos guardados por versiones anteriores). */
 val fmtName:String get(){if(format!=CheatFormat.AUTO)return format.label
  val l=if(det in 1..4)CheatFormat.of(det).label else label
  return if(l.isEmpty())CheatFormat.AUTO.label else l}
 val shown:String get()=if(format==CheatFormat.AUTO&&fmtName!=CheatFormat.AUTO.label)fmtName+" (detectado)" else fmtName
}

/** Respaldo de los trucos de un juego (archivo de Cirilo y Google Drive). */
class Pack(val id:String,val title:String,val cheats:List<Cheat>)

/** Persistencia: SharedPreferences «cheats»; una entrada por ROM (clave g.<sha1>) con la lista completa en JSON, más t.<sha1> (título), m.<sha1> (fecha de la última modificación, para Drive),
 *  s.<sha1> (trucos que mGBA no pudo aplicar la última vez) y mm.<sha1> (aviso del código maestro ya leído). Sobrevive a cierres de la app. */
object CheatStore{
 private fun p(c:Context)=c.getSharedPreferences("cheats",0)
 private fun obj(it:Cheat)=JSONObject().put("id",it.id).put("name",it.name).put("fmt",it.format.ordinal).put("code",it.code).put("on",it.enabled).put("det",it.det).put("label",it.label)
 private fun parse(a:JSONArray):MutableList<Cheat>{val out=ArrayList<Cheat>()
  for(i in 0 until a.length()){val o=a.getJSONObject(i)
   out+=Cheat(o.getString("id"),o.getString("name"),CheatFormat.of(o.optInt("fmt",0)),o.getString("code"),o.optBoolean("on",false),o.optInt("det",0),o.optString("label",""))}
  return out}
 fun list(c:Context,g:String):MutableList<Cheat>{val s=p(c).getString("g."+g,null)?:return ArrayList()
  return try{parse(JSONArray(s))}catch(e:Exception){ArrayList()}}
 fun save(c:Context,g:GameInfo,l:List<Cheat>){
  val a=JSONArray();l.forEach{a.put(obj(it))}
  p(c).edit().putString("g."+g.id,a.toString()).putString("t."+g.id,g.title+(if(g.code.isNotEmpty())" ["+g.code+"]" else "")).putLong("m."+g.id,System.currentTimeMillis()).commit()
  touch(c,g.id)}
 fun newId()=java.util.UUID.randomUUID().toString()
 /** Trucos activos de este juego. */
 fun active(c:Context,g:GameInfo):List<Cheat> = list(c,g.id).filter{it.enabled}

 // ---- identidad y fechas (Drive) ----
 fun ids(c:Context):List<String> = p(c).all.keys.filter{it.startsWith("g.")}.map{it.substring(2)}
 fun has(c:Context,id:String)=p(c).contains("g."+id)
 fun title(c:Context,id:String)=p(c).getString("t."+id,"")?:""
 /** Fecha de la última modificación local. Los trucos guardados antes de existir esta fecha reciben la de ahora la primera vez que se pregunta. */
 fun stamp(c:Context,id:String):Long{val s=p(c);val m=s.getLong("m."+id,0L);if(m!=0L||!s.contains("g."+id))return m
  val n=System.currentTimeMillis();s.edit().putLong("m."+id,n).commit();return n}

 // ---- respaldo / Drive ----
 /** JSON de los trucos de un juego (nombres, formatos, códigos y estado), o null si no hay. El orden es estable: el mismo contenido da el mismo texto. */
 fun pack(c:Context,id:String):String?{val s=p(c).getString("g."+id,null)?:return null
  return try{JSONObject().put("v",1).put("game",id).put("title",title(c,id)).put("cheats",JSONArray(s)).toString()}catch(e:Exception){null}}
 fun unpack(json:String):Pack?{
  return try{val o=JSONObject(json);Pack(o.optString("game",""),o.optString("title",""),parse(o.getJSONArray("cheats")))}catch(e:Exception){null}}
 /** Guarda un respaldo bajado de Drive. m = fecha que se le asigna (la de Drive), para no volver a subirlo. */
 fun restore(c:Context,json:String,m:Long):Boolean{val k=unpack(json)?:return false;if(k.id.isEmpty())return false
  val a=JSONArray();k.cheats.forEach{a.put(obj(it))}
  p(c).edit().putString("g."+k.id,a.toString()).putString("t."+k.id,k.title).putLong("m."+k.id,m).commit();return true}

 private val hd=Handler(Looper.getMainLooper());private val pend=HashMap<String,Runnable>()
 /** Tras guardar: si Drive y «Sincronizar al cambiar» están activos, sube los trucos de este juego 5 s después del último cambio (así no se sube en cada casilla). */
 private fun touch(c:Context,id:String){val a=c.applicationContext;val s=a.getSharedPreferences("c",0)
  if(!s.getBoolean("gd",false)||!s.getBoolean("gd_change",false)||!s.getBoolean("gd_cheats",true))return
  synchronized(pend){pend.remove(id)?.let{hd.removeCallbacks(it)}
   val r=Runnable{synchronized(pend){pend.remove(id)};DriveSync.async(a,emptySet(),null,setOf(id),false)}
   pend[id]=r;hd.postDelayed(r,5000)}}

 // ---- avisos ----
 /** Trucos activos que mGBA no pudo aplicar la última vez: id → código de error (negativo). */
 fun status(c:Context,id:String):Map<String,Int>{val m=HashMap<String,Int>()
  try{val o=JSONObject(p(c).getString("s."+id,"{}")?:"{}");val k=o.keys();while(k.hasNext()){val x=k.next();m[x]=o.getInt(x)}}catch(e:Exception){}
  return m}
 fun setStatus(c:Context,id:String,m:Map<String,Int>){val o=JSONObject();m.forEach{(k,v)->o.put(k,v)};p(c).edit().putString("s."+id,o.toString()).apply()}
 /** Aviso del código maestro: una vez leído no vuelve a salir para este juego. */
 fun hintSeen(c:Context,id:String)=p(c).getBoolean("mm."+id,false)
 fun hintDone(c:Context,id:String){p(c).edit().putBoolean("mm."+id,true).apply()}
}
