package app.cirilo
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/** Identidad del juego en ejecución. id = SHA-1 de la ROM completa (ya descomprimida): distingue regiones, revisiones y hacks, así que los trucos de una edición nunca se aplican a otra. */
class GameInfo(val id:String,val plat:Int,val code:String,val title:String)
object GameId{
 fun of(rom:ByteArray,name:String):GameInfo{
  val gba=Roms.ext(name)=="gba"
  val sha=MessageDigest.getInstance("SHA-1").digest(rom).joinToString(""){"%02x".format(it)}
  // código de producto de la cabecera (solo informativo): GBA 0xAC..0xAF; GB/GBC 0x13F..0x142
  val o=if(gba)0xAC else 0x13F
  val code=if(rom.size>o+4)String(rom,o,4,Charsets.ISO_8859_1).filter{it in ' '..'~'}.trim() else ""
  return GameInfo(sha,if(gba)CheatCodes.GBA else CheatCodes.GB,code,name.substringBeforeLast('.'))}
}

/** Un truco guardado. code se conserva exactamente como lo escribió el usuario. det = modo resuelto en Auto detect (ordinal de CheatFormat; 0 = lo detecta mGBA). */
data class Cheat(val id:String,val name:String,val format:CheatFormat,val code:String,val enabled:Boolean=false,val det:Int=0,val label:String=""){
 /** Modo que se envía al núcleo. */
 val mode get()=if(format==CheatFormat.AUTO)det else format.ordinal
}

/** Persistencia: SharedPreferences «cheats»; una entrada por ROM (clave g.<sha1>) con la lista completa en JSON. Sobrevive a cierres de la app. */
object CheatStore{
 private fun p(c:Context)=c.getSharedPreferences("cheats",0)
 fun list(c:Context,g:String):MutableList<Cheat>{
  val out=ArrayList<Cheat>();val s=p(c).getString("g."+g,null)?:return out
  try{val a=JSONArray(s);for(i in 0 until a.length()){val o=a.getJSONObject(i)
   out+=Cheat(o.getString("id"),o.getString("name"),CheatFormat.of(o.optInt("fmt",0)),o.getString("code"),o.optBoolean("on",false),o.optInt("det",0),o.optString("label",""))}}catch(e:Exception){}
  return out}
 fun save(c:Context,g:GameInfo,l:List<Cheat>){
  val a=JSONArray();l.forEach{a.put(JSONObject().put("id",it.id).put("name",it.name).put("fmt",it.format.ordinal).put("code",it.code).put("on",it.enabled).put("det",it.det).put("label",it.label))}
  p(c).edit().putString("g."+g.id,a.toString()).putString("t."+g.id,g.title+(if(g.code.isNotEmpty())" ["+g.code+"]" else "")).commit()}
 fun newId()=java.util.UUID.randomUUID().toString()
 /** (modo, texto) de los trucos activos de este juego, listos para el núcleo. */
 fun active(c:Context,g:GameInfo)=list(c,g.id).filter{it.enabled}.map{Pair(it.mode,CheatCodes.transportOf(it.code))}
}
