package app.cirilo
import android.Manifest
import android.animation.*
import android.app.*
import android.content.ClipData
import android.content.Intent
import android.content.res.ColorStateList
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.graphics.drawable.*
import android.net.Uri
import android.os.*
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.*
import android.view.*
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.*
import java.io.File
import android.widget.*
/** Menú principal: lista de juegos con buscador (círculo que se expande), ordenar, filtros y botón + para añadir juegos. */
class LibraryActivity:Activity(){
 private lateinit var lv:AbsListView;private lateinit var lvL:ListView;private lateinit var gv:GridView;private var grid=false;private var modeSet:Boolean?=null;private var coverFor="";private lateinit var title:TextView;private lateinit var head:FrameLayout;private lateinit var pill:LinearLayout
 private lateinit var et:EditText;private lateinit var sortB:ImageView;private lateinit var moreB:ImageView;private lateinit var lpP:FrameLayout.LayoutParams
 private lateinit var root:FrameLayout;private lateinit var anchor:View;private var lx=0f;private var ly=0f
 private var folders=listOf<Folder>();private var items=listOf<Any>();private var selMode=false;private var fade=false;private var cur="";private var iconFor="";private val sel=LinkedHashSet<String>();private val imgCache=HashMap<String,Bitmap?>()
 private var games=listOf<Game>();private var shown=listOf<Game>();private var open=false;private var swallow=false;private var filling=false;private var dn=1f
 private val P by lazy{getSharedPreferences("lib",0)}
 private fun dp(x:Int)=(x*dn).toInt()
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun ss(k:String)=(P.getString(k,"")?:"").split(",").filter{it.isNotEmpty()}.toSet()
 private val PN=listOf("GB","GBC","GBA")
 private val LN=mapOf("en" to "Inglés","es" to "Español","fr" to "Francés","de" to "Alemán","it" to "Italiano","ja" to "Japonés","nl" to "Neerlandés","pt" to "Portugués")
 private val SORTS=listOf(Triple("name","Nombre",listOf("A → Z","Z → A")),Triple("added","Fecha de añadido",listOf("Más reciente","Más antiguo")),
  Triple("played","Última vez jugado",listOf("Más reciente","Más antiguo")),Triple("release","Fecha de lanzamiento (sin datos aún)",listOf("Más reciente","Más antiguo")),
  Triple("file","Nombre de archivo",listOf("A → Z","Z → A")),Triple("plat","Plataforma",listOf("GB → GBC → GBA","GBA → GBC → GB")))
 override fun onCreate(b:Bundle?){
  super.onCreate(b);dn=resources.displayMetrics.density
  root=FrameLayout(this);root.setBackgroundColor(0xFF303030.toInt());anchor=View(this);val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  head=FrameLayout(this).apply{setBackgroundColor(0xFF212121.toInt());setPadding(dp(16),0,dp(12),0)}
  title=TextView(this).apply{setTextColor(-1);textSize=22f;gravity=Gravity.CENTER_VERTICAL}
  head.addView(title,FrameLayout.LayoutParams(-2,dp(64),Gravity.START))
  sortB=ImageView(this).apply{setImageResource(R.drawable.ic_sort);setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{sortSheet()}}
  head.addView(sortB,FrameLayout.LayoutParams(dp(48),dp(48),Gravity.END or Gravity.CENTER_VERTICAL))
  moreB=ImageView(this).apply{setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10));visibility=View.GONE;setOnClickListener{menuSel()}}
  head.addView(moreB,FrameLayout.LayoutParams(dp(48),dp(48),Gravity.END or Gravity.CENTER_VERTICAL))
  pill=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;background=GradientDrawable().apply{setColor(-1);cornerRadius=dp(20).toFloat()};setOnClickListener{if(!open)anim(true)}}
  et=EditText(this).apply{hint="Buscar juego";textSize=16f;setSingleLine();setTextColor(0xFF212121.toInt());setHintTextColor(0xFF757575.toInt());background=null;alpha=0f;imeOptions=EditorInfo.IME_ACTION_SEARCH
   addTextChangedListener(object:TextWatcher{override fun afterTextChanged(s:Editable?){refresh()};override fun beforeTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){};override fun onTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){}})
   setOnEditorActionListener{_,_,_->hideKb();true}}
  pill.addView(ImageView(this).apply{setImageResource(R.drawable.ic_search);setPadding(dp(16),dp(8),dp(16),dp(8))},LinearLayout.LayoutParams(dp(56),dp(40)))
  pill.addView(et,LinearLayout.LayoutParams(0,-2,1f))
  lpP=FrameLayout.LayoutParams(dp(60),dp(40),Gravity.END or Gravity.CENTER_VERTICAL).apply{rightMargin=dp(52)};head.addView(pill,lpP)
  lvL=ListView(this).apply{divider=ColorDrawable(0xFF444444.toInt());dividerHeight=2};lv=lvL
  gv=GridView(this).apply{setPadding(dp(8),dp(8),dp(8),dp(8));clipToPadding=false;horizontalSpacing=dp(8);verticalSpacing=dp(8);stretchMode=GridView.STRETCH_COLUMN_WIDTH;selector=ColorDrawable(0);numColumns=3;visibility=View.GONE
   addOnLayoutChangeListener{_,l,_,r,_,ol,_,orr,_->if(r-l!=orr-ol)cols()}}
  col.addView(head);col.addView(lvL,LinearLayout.LayoutParams(-1,0,1f));col.addView(gv,LinearLayout.LayoutParams(-1,0,1f));root.addView(col);root.addView(anchor,FrameLayout.LayoutParams(1,1))
  val fab=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());elevation=8*dn
   background=RippleDrawable(ColorStateList.valueOf(0x66FFFFFF),GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xFF80CBC4.toInt())},GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(-1)})}
  root.addView(fab,FrameLayout.LayoutParams(dp(56),dp(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,dp(24),dp(24))})
  fab.scaleX=0f;fab.scaleY=0f;fab.animate().scaleX(1f).scaleY(1f).setStartDelay(250).setDuration(450).setInterpolator(OvershootInterpolator(3f)).start()
  fab.setOnTouchListener{v,e->when(e.actionMasked){
   MotionEvent.ACTION_DOWN->v.animate().scaleX(.86f).scaleY(.86f).translationZ(dp(6).toFloat()).setStartDelay(0).setDuration(90).setInterpolator(null).start()
   MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->v.animate().scaleX(1f).scaleY(1f).translationZ(0f).setStartDelay(0).setDuration(320).setInterpolator(OvershootInterpolator(3.5f)).start()};false}
  fab.setOnClickListener{fab.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);fab.animate().rotation(45f).setDuration(180).start();PopupMenu(this,fab).apply{setOnDismissListener{fab.animate().rotation(0f).setDuration(180).start()};menu.add(0,1,0,"Añadir juego");menu.add(0,2,0,"Añadir carpeta");menu.add(0,3,0,"Escanear dispositivo");menu.add(0,4,0,"Personalización")
   setOnMenuItemClickListener{when(it.itemId){
    1->startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),1)
    2->startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),2)
    4->startActivity(Intent(this@LibraryActivity,PersonalizationActivity::class.java))
    else->scanAll()};true}}.show()}
  listOf<AbsListView>(lvL,gv).forEach{v->
  val gd=GestureDetector(this,object:GestureDetector.SimpleOnGestureListener(){override fun onLongPress(e:MotionEvent){if(v.pointToPosition(e.x.toInt(),e.y.toInt())==AdapterView.INVALID_POSITION)ctx(e.rawX,e.rawY,games.isNotEmpty())}})
  v.setOnTouchListener{_,e->lx=e.rawX;ly=e.rawY;gd.onTouchEvent(e);false}
  v.setOnItemClickListener{_,_,i,_->when(val x=items[i]){
   is Game->if(selMode)tog(x.u) else startActivity(Intent(this,GameActivity::class.java).putExtra("u",x.u).putExtra("n",x.n))
   is Folder->if(selMode)t("Arrastra los juegos hasta la carpeta") else{cur=x.id;refresh()}
   else->{cur="";refresh()}}}
  v.setOnItemLongClickListener{_,v,i,_->when(val x=items[i]){
   is Game->if(!selMode){selMode=true;fade=true;sel.add(x.u);v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);refresh();ctx(lx,ly,true)} else if(x.u in sel)startDrag(v) else tog(x.u)
   is Folder->if(!selMode)folderSheet(x)
   else->{}};true}
  v.setOnDragListener{_,e->if(e.action==DragEvent.ACTION_DRAG_LOCATION){if(e.y<dp(90))v.smoothScrollBy(-dp(26),0) else if(e.y>v.height-dp(90))v.smoothScrollBy(dp(26),0)};true}
  }
  setContentView(root)}
 override fun onResume(){super.onResume();applyMode();refresh()}
 override fun onTrimMemory(l:Int){super.onTrimMemory(l);Covers.trim()}
 /** Cambia solo la presentación: ambas vistas usan el mismo adaptador y los mismos datos. */
 private fun applyMode(){val g=P.getString("view","list")=="grid";grid=g;lv=if(g)gv else lvL
  if(modeSet!=g){modeSet=g;lvL.visibility=if(g)View.GONE else View.VISIBLE;gv.visibility=if(g)View.VISIBLE else View.GONE;lvL.adapter=if(g)null else ad;gv.adapter=if(g)ad else null;if(g)cols()}}
 /** 3 columnas en móviles (≈360 dp), 2 si no cabe, más en pantallas grandes. */
 private fun cols(){val w=if(gv.width>0)gv.width else resources.displayMetrics.widthPixels;val n=((w/dn-16)/118).toInt().coerceIn(2,8);if(gv.numColumns!=n)gv.numColumns=n}
 private fun cellW():Int{val n=maxOf(gv.numColumns,1);return maxOf((gv.width-gv.paddingLeft-gv.paddingRight-(n-1)*dp(8))/n,dp(60))}
 private fun hideKb(){(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken,0)}
 /** Círculo ⇄ barra: el ancho de la píldora se anima; el título y el botón de ordenar se desvanecen. */
 private fun anim(to:Boolean){open=to;val w=head.width-head.paddingLeft-head.paddingRight
  if(!to){title.visibility=View.VISIBLE;sortB.visibility=View.VISIBLE;hideKb();et.clearFocus()}
  ValueAnimator.ofFloat(if(to)0f else 1f,if(to)1f else 0f).apply{duration=250
   addUpdateListener{val f=it.animatedValue as Float;lpP.width=(dp(60)+(w-dp(60))*f).toInt();lpP.rightMargin=(dp(52)*(1-f)).toInt();pill.layoutParams=lpP;title.alpha=1-f;sortB.alpha=1-f;et.alpha=f}
   addListener(object:AnimatorListenerAdapter(){override fun onAnimationEnd(a:Animator){if(to){title.visibility=View.INVISIBLE;sortB.visibility=View.INVISIBLE};refresh()}});start()}
  if(to){et.requestFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et,0)}}
 override fun dispatchTouchEvent(ev:MotionEvent):Boolean{
  if(swallow){if(ev.action==MotionEvent.ACTION_UP||ev.action==MotionEvent.ACTION_CANCEL)swallow=false;return true}
  if(open&&ev.action==MotionEvent.ACTION_DOWN){val r=Rect();pill.getGlobalVisibleRect(r);if(!r.contains(ev.rawX.toInt(),ev.rawY.toInt())){anim(false);swallow=true;return true}}
  return super.dispatchTouchEvent(ev)}
 override fun onBackPressed(){if(open)anim(false) else if(selMode){selMode=false;sel.clear();refresh()} else if(cur.isNotEmpty()){cur="";refresh()} else super.onBackPressed()}

 // ---- lista con carpetas, selección y arrastre ----
 private val ad=object:BaseAdapter(){
  override fun getCount()=items.size;override fun getItem(i:Int):Any=items[i];override fun getItemId(i:Int)=i.toLong()
  override fun getViewTypeCount()=3
  override fun getItemViewType(i:Int)=if(!grid)0 else if(items[i] is Game)1 else 2
  override fun getView(i:Int,cv:View?,pr:ViewGroup?):View{val c=this@LibraryActivity;val x=items[i]
   if(grid)return cell(i,cv)
   val r=LinearLayout(c);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(12),dp(12),dp(12))
   when(x){
    is Game->{r.addView(TextView(c).apply{text=(if(x.fav)"★ " else "")+x.title;textSize=17f;setTextColor(-1)},LinearLayout.LayoutParams(0,-2,1f))
     val on=x.u in sel;if(on)r.setBackgroundColor(0x3380CBC4)
     val slot=FrameLayout(c);r.addView(slot,LinearLayout.LayoutParams(dp(30),dp(22))) // el espacio de la casilla se reserva siempre: nada se mueve al seleccionar
     if(selMode)slot.addView(TextView(c).apply{text=if(on)"✓" else "";textSize=15f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt())
      background=GradientDrawable().apply{cornerRadius=dp(5).toFloat();if(on)setColor(0xFF80CBC4.toInt()) else{setColor(0);setStroke(dp(2),0xFFAAAAAA.toInt())}}
      setOnClickListener{tog(x.u)};if(fade){alpha=0f;animate().alpha(1f).setDuration(220).start()}},FrameLayout.LayoutParams(dp(22),dp(22),Gravity.END))}
    is Folder->{r.setBackgroundColor(0xFF383838.toInt());r.setOnDragListener(dl(x.id))
     r.addView(if(x.icon=="img")ImageView(c).apply{setImageBitmap(imgCache.getOrPut(x.id){BitmapFactory.decodeFile(File(filesDir,"icons/"+x.id+".png").path)})} else TextView(c).apply{text=x.icon;textSize=26f;gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(44),dp(44)).apply{rightMargin=dp(14)})
     val tc=LinearLayout(c);tc.orientation=LinearLayout.VERTICAL;tc.addView(TextView(c).apply{text=x.name;textSize=18f;setTextColor(-1)})
     tc.addView(TextView(c).apply{text=games.count{g->g.fo==x.id}.toString()+" juegos";textSize=13f;setTextColor(0xFF9E9E9E.toInt())});r.addView(tc,LinearLayout.LayoutParams(0,-2,1f))}
    else->{r.setBackgroundColor(0xFF383838.toInt());r.setOnDragListener(dl(""));r.addView(TextView(c).apply{text="↑  Lista principal (suelta aquí para sacar)";textSize=16f;setTextColor(0xFF80CBC4.toInt())})}}
   return r}}

 /** Tarjeta de la cuadrícula: marco de tamaño fijo (cw×cw) con la imagen completa (fitCenter) y el nombre en un máximo de 2 líneas. Las carpetas usan un mosaico distinto. */
 private fun cell(i:Int,cv:View?):View{val c=this;val x=items[i];val cw=cellW();val nh=dp(46)
  val card=(cv as? LinearLayout)?:LinearLayout(c).apply{orientation=LinearLayout.VERTICAL
   val fr=FrameLayout(c);addView(fr,LinearLayout.LayoutParams(-1,cw))
   fr.addView(ImageView(c).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setPadding(dp(3),dp(3),dp(3),dp(3))},FrameLayout.LayoutParams(-1,-1))
   fr.addView(TextView(c).apply{textSize=40f;gravity=Gravity.CENTER},FrameLayout.LayoutParams(-1,-1))
   fr.addView(TextView(c).apply{textSize=15f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt())},FrameLayout.LayoutParams(dp(24),dp(24),Gravity.END or Gravity.TOP).apply{setMargins(0,dp(4),dp(4),0)})
   fr.addView(TextView(c).apply{textSize=12f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());setPadding(dp(8),0,dp(8),0);background=GradientDrawable().apply{setColor(0xFF80CBC4.toInt());cornerRadius=dp(10).toFloat()}},FrameLayout.LayoutParams(-2,dp(20),Gravity.END or Gravity.BOTTOM).apply{setMargins(0,0,dp(4),dp(4))})
   addView(TextView(c).apply{textSize=12f;setTextColor(-1);maxLines=2;minLines=2;ellipsize=TextUtils.TruncateAt.END;gravity=Gravity.CENTER_HORIZONTAL;setPadding(dp(2),dp(4),dp(2),0)},LinearLayout.LayoutParams(-1,nh))}
  card.layoutParams=AbsListView.LayoutParams(-1,cw+nh)
  val fr=card.getChildAt(0) as FrameLayout;val iv=fr.getChildAt(0) as ImageView;val big=fr.getChildAt(1) as TextView;val chk=fr.getChildAt(2) as TextView;val cnt=fr.getChildAt(3) as TextView;val nm=card.getChildAt(1) as TextView
  chk.visibility=View.GONE;cnt.visibility=View.GONE;chk.setOnClickListener(null);chk.isClickable=false;card.setOnDragListener(null);card.setBackgroundColor(0)
  when(x){
   is Game->{val on=x.u in sel;fr.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(8).toFloat();if(on)setStroke(dp(3),0xFF80CBC4.toInt())}
    big.visibility=View.GONE;iv.visibility=View.VISIBLE;nm.text=(if(x.fav)"★ " else "")+x.title;nm.setTextColor(-1)
    Covers.bind(iv,x,cw,cw)
    if(selMode){chk.visibility=View.VISIBLE;chk.text=if(on)"✓" else "";chk.isClickable=true;chk.setOnClickListener{tog(x.u)}
     chk.background=GradientDrawable().apply{cornerRadius=dp(6).toFloat();if(on)setColor(0xFF80CBC4.toInt()) else{setColor(0x88000000.toInt());setStroke(dp(2),0xFFDDDDDD.toInt())}}
     if(fade){chk.alpha=0f;chk.animate().alpha(1f).setDuration(220).start()} else chk.alpha=1f}}
   is Folder->{fr.setBackgroundColor(0xFF383838.toInt());card.setOnDragListener(dl(x.id));iv.tag=null;nm.text=x.name;nm.setTextColor(-1)
    if(x.icon=="img"){big.visibility=View.GONE;iv.visibility=View.VISIBLE;iv.setImageBitmap(imgCache.getOrPut(x.id){BitmapFactory.decodeFile(File(filesDir,"icons/"+x.id+".png").path)})} else{iv.visibility=View.GONE;big.visibility=View.VISIBLE;big.text=x.icon}
    cnt.visibility=View.VISIBLE;cnt.text=games.count{g->g.fo==x.id}.toString()}
   else->{fr.setBackgroundColor(0xFF383838.toInt());card.setOnDragListener(dl(""));iv.visibility=View.GONE;big.visibility=View.VISIBLE;big.text="↑";nm.text="Lista principal";nm.setTextColor(0xFF80CBC4.toInt())}}
  return card}
 private fun tog(u:String){if(!sel.add(u))sel.remove(u);refresh()}
 private fun startDrag(v:View){val chip=TextView(this).apply{text="🎮  "+sel.size;textSize=18f;setTextColor(0xFF212121.toInt());setPadding(dp(16),dp(10),dp(16),dp(10));background=GradientDrawable().apply{setColor(0xFF80CBC4.toInt());cornerRadius=dp(20).toFloat()}}
  chip.measure(0,0);chip.layout(0,0,chip.measuredWidth,chip.measuredHeight)
  v.startDragAndDrop(ClipData.newPlainText("cirilo","x"),View.DragShadowBuilder(chip),null,0);v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)}
 /** Destino de arrastre (carpeta o «Lista principal»): se agranda al pasar por encima y rebota al soltar. */
 private fun dl(fid:String)=View.OnDragListener{v,e->when(e.action){
  DragEvent.ACTION_DRAG_STARTED->e.clipDescription?.label=="cirilo"
  DragEvent.ACTION_DRAG_ENTERED->{v.animate().scaleX(1.05f).scaleY(1.05f).setDuration(120).start();v.setBackgroundColor(0xFF2E5E58.toInt());v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);true}
  DragEvent.ACTION_DRAG_EXITED->{v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();v.setBackgroundColor(0xFF383838.toInt());true}
  DragEvent.ACTION_DROP->{val n=sel.size;v.animate().scaleX(1.25f).scaleY(1.25f).setDuration(110).withEndAction{v.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(3f)).setDuration(260).withEndAction{moveSel(fid);t(n.toString()+(if(n==1)" juego movido" else " juegos movidos"))}.start()}.start();true}
  else->true}}
 private fun moveSel(fid:String){Lib.upd(this,games.filter{it.u in sel}.map{it.copy(fo=fid)});sel.clear();selMode=false;refresh()}
 private fun confirm(m:String,ok:()->Unit){AlertDialog.Builder(this).setMessage(m).setPositiveButton("Aceptar"){_,_->ok()}.setNegativeButton("Cancelar",null).show()}
 private fun ask(ti:String,init:String,ok:(String)->Unit){val e=EditText(this).apply{setText(init);setSingleLine()}
  AlertDialog.Builder(this).setTitle(ti).setView(e).setPositiveButton("Aceptar"){_,_->val s=e.text.toString().trim();if(s.isNotEmpty())ok(s)}.setNegativeButton("Cancelar",null).show()}
 private fun fin(m:String){selMode=false;sel.clear();refresh();t(m)}
 private fun delFile(g:Game):Boolean=try{if(g.u.startsWith("/"))File(g.u).delete() else DocumentsContract.deleteDocument(contentResolver,Uri.parse(g.u))}catch(e:Exception){false}
 private fun delSaves(g:Game){val b=g.n.substringBeforeLast('.');File(getExternalFilesDir("saves"),b+".sav").delete()
  getExternalFilesDir("states")?.listFiles()?.filter{it.name.matches(Regex(Regex.escape(b)+"\\.\\d\\.state"))}?.forEach{it.delete()}}
 private fun where(g:Game):String=if(g.u.startsWith("/"))g.u else try{val id=DocumentsContract.getDocumentId(Uri.parse(g.u));if(id.startsWith("primary:"))"Almacenamiento interno/"+id.removePrefix("primary:") else id.replace(":","/")}catch(e:Exception){g.u}
 /** Menú que salta justo donde se mantiene presionado. Sin juegos: solo «Crear carpeta». Sin selección, las opciones que la necesitan salen apagadas. */
 private fun ctx(x:Float,y:Float,all:Boolean){val loc=IntArray(2);root.getLocationOnScreen(loc);anchor.x=x-loc[0];anchor.y=y-loc[1]
  PopupMenu(this,anchor).apply{
   if(all)listOf("Borrar archivo","Borrar archivo de guardado","Borrar de la lista","Crear carpeta con el juego adentro","Crear carpeta sin el juego","Mostrar ubicación del juego","Mover a carpeta...","Carátula...").forEachIndexed{i,s->menu.add(0,i,0,s)} else menu.add(0,4,0,"Crear carpeta")
   if(all&&sel.isEmpty())listOf(0,1,2,3,5,6,7).forEach{menu.findItem(it).isEnabled=false}
   if(all&&sel.size>1)menu.findItem(7).isEnabled=false
   setOnMenuItemClickListener{act(it.itemId);true}}.show()}
 private fun menuSel(){PopupMenu(this,moreB).apply{listOf("Borrar archivo","Borrar archivo de guardado","Borrar de la lista","Crear carpeta con el juego adentro","Crear carpeta sin el juego","Mostrar ubicación del juego","Mover a carpeta...","Carátula...").forEachIndexed{i,s->menu.add(0,i,0,s)}
  if(sel.size>1)menu.findItem(7).isEnabled=false
  setOnMenuItemClickListener{act(it.itemId);true}}.show()}
 private fun act(i:Int){val gs=games.filter{it.u in sel};if(gs.isEmpty()&&i!=4)return
  val k=if(gs.size==1)"«"+gs[0].title+"»" else gs.size.toString()+" juegos"
  when(i){
   0->confirm("¿Borrar del dispositivo el archivo de "+k+"? No se puede deshacer."){var bad=0;gs.forEach{if(delFile(it))Lib.del(this,it.u) else bad++};fin(if(bad>0)bad.toString()+" no se pudieron borrar (sin permiso de escritura)" else "Archivos borrados")}
   1->confirm("¿Borrar la partida guardada y los estados guardados de "+k+"? No se puede deshacer."){gs.forEach{delSaves(it)};fin("Guardados borrados")}
   2->confirm("¿Quitar "+k+" de la lista? Los archivos no se borran."){gs.forEach{Lib.del(this,it.u)};fin("Quitado de la lista")}
   3->ask("Nombre de la carpeta",""){nm->moveSel(Lib.newFolder(this,nm).id);t("Carpeta «"+nm+"» creada")}
   4->ask("Nombre de la carpeta",""){nm->Lib.newFolder(this,nm);fin("Carpeta «"+nm+"» creada")}
   5->AlertDialog.Builder(this).setTitle("Ubicación").setMessage(gs.joinToString("\n\n"){it.title+"\n"+where(it)}).setPositiveButton("Cerrar",null).show()
   7->coverSheet(gs[0])
   else->Sheet.show(this,"Mover a",listOf("Lista principal")+folders.map{it.name},null,{j->moveSel(if(j==0)"" else folders[j-1].id)},{})}}
/** Carátula de un juego: cambiar, quitar la personalizada, volver a la automática o buscar de nuevo. */
 private fun coverSheet(g:Game){val cu=Covers.hasCustom(this,g);val on=Covers.customOn(this,g);val o=ArrayList<String>();val a=ArrayList<()->Unit>()
  o+=if(cu)"Cambiar carátula" else "Elegir carátula de la galería";a+={coverFor=g.u;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"),6)}
  if(cu&&on){o+="Volver a la carátula automática";a+={Covers.useAuto(this,g);fin("Se usará la carátula automática")}}
  if(cu&&!on){o+="Usar mi carátula personalizada";a+={Covers.useCustom(this,g);fin("Carátula personalizada activada")}}
  if(cu){o+="Eliminar carátula personalizada";a+={confirm("¿Eliminar la carátula personalizada de «"+g.title+"»?"){Covers.removeCustom(this,g);fin("Carátula eliminada")}}}
  o+="Buscar de nuevo la carátula";a+={Covers.research(this,g);fin("Buscando carátula...")}
  Sheet.show(this,g.title,o,null,{i->a[i]()},{})}
 private fun folderSheet(f:Folder){Sheet.show(this,f.name,listOf("Renombrar","Cambiar icono","Eliminar carpeta"),null,{k->when(k){
  0->ask("Renombrar",f.name){nn->Lib.saveFolders(this,folders.map{x->if(x.id==f.id)x.copy(name=nn) else x});refresh()}
  1->iconSheet(f)
  else->confirm("¿Eliminar la carpeta «"+f.name+"»? Los juegos vuelven a la lista principal."){Lib.upd(this,games.filter{g->g.fo==f.id}.map{g->g.copy(fo="")});Lib.saveFolders(this,folders.filter{x->x.id!=f.id});if(cur==f.id)cur="";refresh()}}},{})}
 private val EMO=listOf("📁","🎮","⭐","🔥","💧","🌿","⚡","🐉","👾","🕹️","🏆","❤️","💎","🌙","☀️","🎵","🧩","⚔️","🛡️","👻","🍄","🐾","🚀","🌊")
 private fun iconSheet(f:Folder){val d=Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setPadding(dp(16),dp(16),dp(16),dp(16));col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  col.addView(TextView(this).apply{text="Imagen de la galería...";textSize=17f;setTextColor(0xFF80CBC4.toInt());setPadding(dp(8),dp(8),dp(8),dp(12));setOnClickListener{d.dismiss();iconFor=f.id
   startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"),5)}})
  EMO.chunked(6).forEach{rw->val r=LinearLayout(this);rw.forEach{em->r.addView(TextView(this).apply{text=em;textSize=28f;gravity=Gravity.CENTER
   setOnClickListener{d.dismiss();Lib.saveFolders(this@LibraryActivity,folders.map{x->if(x.id==f.id)x.copy(icon=em) else x});refresh()}},LinearLayout.LayoutParams(0,dp(52),1f))};col.addView(r)}
  d.setContentView(col);d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout((resources.displayMetrics.widthPixels*0.9).toInt(),-2)};d.show()}
 // ---- ordenar y filtrar ----
 private fun tc(f:(Game)->Long,recent:Boolean)=Comparator<Game>{a,b->val x=f(a);val y=f(b);when{x==0L&&y==0L->0;x==0L->1;y==0L->-1;recent->y.compareTo(x);else->x.compareTo(y)}}
 private fun cmp():Comparator<Game>{val d=P.getInt("sd",0);val byName=compareBy<Game>{it.title.lowercase().trimStart{c->!c.isLetterOrDigit()}}
  return when(P.getString("sk","name")){
   "added"->tc({it.added},d==0).then(byName);"played"->tc({it.played},d==0).then(byName);"release"->tc({it.year.toLong()},d==0).then(byName)
   "file"->if(d==0)compareBy<Game>{it.n.lowercase()} else compareByDescending<Game>{it.n.lowercase()}
   "plat"->(if(d==0)compareBy<Game>{it.p} else compareByDescending<Game>{it.p}).then(byName)
   else->if(d==0)byName else byName.reversed()}}
 private fun pass(g:Game,q:String):Boolean{
  val fp=ss("fplat");if(fp.isNotEmpty()&&PN[g.p.coerceIn(0,2)] !in fp)return false
  val fr=ss("freg");if(fr.isNotEmpty()&&g.reg.split(",").none{it in fr})return false
  val fl=ss("flang");if(fl.isNotEmpty()&&g.lang.split(",").none{it in fl})return false
  val fg=ss("fgen");if(fg.isNotEmpty()&&g.genre !in fg)return false
  if(P.getBoolean("ffav",false)&&!g.fav)return false
  val pl=P.getInt("fplay",0);if((pl==1&&g.played==0L)||(pl==2&&g.played!=0L))return false
  val of=P.getInt("foff",0);val off=Roms.official(g.n);if((of==1&&!off)||(of==2&&off))return false
  return q.isEmpty()||g.n.lowercase().contains(q)}
 private fun filtersOn()=listOf("fplat","freg","flang","fgen").any{ss(it).isNotEmpty()}||P.getBoolean("ffav",false)||P.getInt("fplay",0)!=0||P.getInt("foff",0)!=0
 private fun refresh(){games=Lib.all(this);folders=Lib.folders(this);val q=et.text.toString().trim().lowercase()
  val flat=q.isNotEmpty()||filtersOn() // con búsqueda o filtros se muestran todos los juegos, sin carpetas
  if(cur.isNotEmpty()&&folders.none{it.id==cur})cur=""
  val gl=games.filter{pass(it,q)&&(flat||it.fo==cur)}.sortedWith(cmp());val li=ArrayList<Any>()
  if(!flat){if(cur.isNotEmpty())li+="up" else folders.sortedBy{it.name.lowercase()}.forEach{li+=it}}
  li.addAll(gl);items=li;shown=gl
  sel.retainAll(games.map{it.u}.toSet());if(selMode&&sel.isEmpty())selMode=false
  val fn=folders.firstOrNull{it.id==cur}?.name
  title.text=if(selMode)""+sel.size+" seleccionados" else if(flat)"Juegos ("+gl.size+" de "+games.size+")" else if(fn!=null)fn+" ("+gl.size+")" else "Juegos ("+games.count{it.fo.isEmpty()}+")"
  if(!open)sortB.visibility=if(selMode)View.INVISIBLE else View.VISIBLE;moreB.visibility=if(selMode)View.VISIBLE else View.GONE;pill.visibility=if(selMode)View.GONE else View.VISIBLE
  ad.notifyDataSetChanged();lv.post{fade=false}
  (pill.background as GradientDrawable).setColor(if(!open&&q.isNotEmpty())0xFF80CBC4.toInt() else -1)
  val need=games.filter{it.p<0}
  if(need.isNotEmpty()&&!filling){filling=true;Thread{Lib.upd(this,need.map{Roms.meta(this,it)});runOnUiThread{filling=false;refresh()}}.start()}}
 private fun sortSheet(){
  val d=Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setPadding(0,dp(12),0,dp(12));col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  val box=FrameLayout(this);box.setPadding(dp(12),dp(12),dp(12),dp(12));box.addView(ScrollView(this).apply{addView(col)})
  d.setContentView(box);d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout(-1,-2);setGravity(Gravity.BOTTOM)}
  fun h(s:String)=TextView(this).apply{text=s;textSize=14f;setTextColor(0xFF80CBC4.toInt());setPadding(dp(24),dp(14),dp(24),dp(4))}
  fun lang(c:String)=LN[c]?:c.uppercase()
  lateinit var fill:()->Unit
  fun row(label:String,sum:String,click:()->Unit){val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(dp(24),dp(10),dp(24),dp(10))
   r.addView(TextView(this).apply{text=label;textSize=17f;setTextColor(-1)});r.addView(TextView(this).apply{text=sum;textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
   r.setOnClickListener{click()};col.addView(r)}
  fun multi(tt:String,k:String,labels:List<String>,vals:List<String>){if(vals.isEmpty()){t("Sin datos todavía");return}
   val cur=ss(k).toMutableSet();AlertDialog.Builder(this).setTitle(tt).setMultiChoiceItems(labels.toTypedArray(),BooleanArray(vals.size){vals[it] in cur}){_,i,on->if(on)cur+=vals[i] else cur-=vals[i]}
    .setPositiveButton("Aceptar"){_,_->P.edit().putString(k,cur.joinToString(",")).apply();refresh();fill()}.setNegativeButton("Cancelar",null).show()}
  fun single(tt:String,k:String,labels:List<String>){AlertDialog.Builder(this).setTitle(tt).setSingleChoiceItems(labels.toTypedArray(),P.getInt(k,0)){dl,i->P.edit().putInt(k,i).apply();dl.dismiss();refresh();fill()}.show()}
  fun sum(k:String,m:(String)->String):String{val s=ss(k);return if(s.isEmpty())"Todos" else s.joinToString(", "){m(it)}}
  fill={col.removeAllViews();col.addView(h("ORDENAR POR"))
   val cur=P.getString("sk","name");val dir=P.getInt("sd",0)
   SORTS.forEach{(k,lab,chips)->val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(dp(24),dp(8),dp(24),dp(4))
    r.addView(TextView(this).apply{text=lab;textSize=17f;setTextColor(-1)});val cr=LinearLayout(this)
    chips.forEachIndexed{i,c->val sel=cur==k&&dir==i
     cr.addView(TextView(this).apply{text=c;textSize=13f;gravity=Gravity.CENTER;setPadding(dp(8),dp(9),dp(8),dp(9));setTextColor(if(sel)0xFF212121.toInt() else -1)
      background=GradientDrawable().apply{setColor(if(sel)0xFF80CBC4.toInt() else 0xFF3A3A3A.toInt());cornerRadius=dp(16).toFloat()}
      setOnClickListener{P.edit().putString("sk",k).putInt("sd",i).apply();refresh();fill()}},LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(0,dp(6),dp(6),0)})}
    r.addView(cr);col.addView(r)}
   col.addView(h("FILTROS (independientes del orden)"))
   row("Plataforma",sum("fplat"){it},{multi("Plataforma","fplat",PN,PN)})
   row("Región",sum("freg"){it},{multi("Región","freg",listOf("USA","Europe","Japan"),listOf("USA","Europe","Japan"))})
   val ls=games.flatMap{it.lang.split(",")}.filter{it.isNotEmpty()}.distinct().sorted()
   row("Idioma",sum("flang"){lang(it)},{multi("Idioma","flang",ls.map{lang(it)},ls)})
   val gs=games.map{it.genre}.filter{it.isNotEmpty()}.distinct().sorted()
   row("Género",if(gs.isEmpty())"Sin datos todavía" else sum("fgen"){it},{multi("Género","fgen",gs,gs)})
   row("Favoritos",if(P.getBoolean("ffav",false))"Solo favoritos" else "Todos",{P.edit().putBoolean("ffav",!P.getBoolean("ffav",false)).apply();refresh();fill()})
   row("Jugados / Nunca jugados",listOf("Todos","Jugados","Nunca jugados")[P.getInt("fplay",0)],{single("Jugados / Nunca jugados","fplay",listOf("Todos","Jugados","Nunca jugados"))})
   row("ROM Hacks / Oficiales",listOf("Todos","Oficiales (aprox.)","ROM Hacks (aprox.)")[P.getInt("foff",0)],{single("ROM Hacks / Oficiales","foff",listOf("Todos","Oficiales (aprox.)","ROM Hacks (aprox.)"))})
   if(filtersOn())row("Quitar todos los filtros","",{P.edit().remove("fplat").remove("freg").remove("flang").remove("fgen").remove("ffav").remove("fplay").remove("foff").apply();refresh();fill()})}
  fill();d.show()}
 // ---- añadir juegos ----
 private fun done(n:Int){refresh();t(n.toString()+" juegos añadidos")}
 private fun scanAll(){
  if(Build.VERSION.SDK_INT>=30){if(!Environment.isExternalStorageManager()){t("Concede «Acceso a todos los archivos» y vuelve a pulsar Escanear")
   startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+packageName)));return}}
  else if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),4);return}
  t("Escaneando...");Thread{val n=Lib.add(this,Roms.scanDevice());runOnUiThread{done(n)}}.start()}
 override fun onRequestPermissionsResult(rq:Int,p:Array<String>,r:IntArray){if(rq==4&&r.firstOrNull()==PackageManager.PERMISSION_GRANTED)scanAll()}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){
  if(rs!=RESULT_OK||d==null)return
  if(rq==1){val us=ArrayList<Uri>();d.clipData?.let{for(i in 0 until it.itemCount)us+=it.getItemAt(i).uri};d.data?.let{us+=it}
   val gs=us.mapNotNull{u->try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)}catch(e:Exception){}
    val nm=contentResolver.query(u,null,null,null,null)?.use{if(it.moveToFirst())it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null}
    if(nm!=null&&Roms.ext(nm) in Roms.EXT)Game(nm,u.toString()) else null}
   Thread{val n=Lib.add(this,gs);runOnUiThread{done(n)}}.start()}
  if(rq==6){val u=d.data?:return;val g=games.firstOrNull{it.u==coverFor}?:return
   Thread{val ok=Covers.setCustom(this,g,u);runOnUiThread{if(ok)fin("Carátula guardada") else t("No se pudo usar la imagen")}}.start()}
  if(rq==5){val u=d.data?:return;try{val bm=contentResolver.openInputStream(u)!!.use{BitmapFactory.decodeStream(it)};val z=minOf(bm.width,bm.height)
   val sq=Bitmap.createScaledBitmap(Bitmap.createBitmap(bm,(bm.width-z)/2,(bm.height-z)/2,z,z),128,128,true);File(filesDir,"icons").mkdirs()
   File(filesDir,"icons/"+iconFor+".png").outputStream().use{sq.compress(Bitmap.CompressFormat.PNG,100,it)};imgCache.remove(iconFor)
   Lib.saveFolders(this,folders.map{x->if(x.id==iconFor)x.copy(icon="img") else x});refresh()}catch(e:Exception){t("No se pudo usar la imagen")}}
  if(rq==2){val u=d.data?:return;try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)}catch(e:Exception){}
   t("Buscando juegos...");Thread{val n=Lib.add(this,Roms.scanTree(this,u));runOnUiThread{done(n)}}.start()}}
}
