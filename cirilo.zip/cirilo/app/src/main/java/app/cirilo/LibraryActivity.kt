package app.cirilo
import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.*
import android.net.Uri
import android.os.*
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.*
import android.widget.*
/** Menú principal: lista de juegos y botón + (añadir juego, añadir carpeta, escanear dispositivo). */
class LibraryActivity:Activity(){
 private lateinit var lv:ListView;private lateinit var title:TextView;private var games=mutableListOf<Game>()
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 override fun onCreate(b:Bundle?){
  super.onCreate(b);val d=resources.displayMetrics.density;fun dp(x:Int)=(x*d).toInt()
  val root=FrameLayout(this);root.setBackgroundColor(0xFF303030.toInt())
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  title=TextView(this).apply{setTextColor(-1);textSize=22f;setPadding(dp(16),dp(16),dp(16),dp(16));setBackgroundColor(0xFF212121.toInt())}
  lv=ListView(this).apply{divider=ColorDrawable(0xFF444444.toInt());dividerHeight=2}
  col.addView(title);col.addView(lv,LinearLayout.LayoutParams(-1,0,1f));root.addView(col)
  val fab=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());elevation=8*d
   background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xFF80CBC4.toInt())}}
  root.addView(fab,FrameLayout.LayoutParams(dp(56),dp(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,dp(24),dp(24))})
  fab.setOnClickListener{PopupMenu(this,fab).apply{menu.add(0,1,0,"Añadir juego");menu.add(0,2,0,"Añadir carpeta");menu.add(0,3,0,"Escanear dispositivo")
   setOnMenuItemClickListener{when(it.itemId){
    1->startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true),1)
    2->startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),2)
    else->scanAll()};true}}.show()}
  lv.setOnItemClickListener{_,_,i,_->startActivity(Intent(this,GameActivity::class.java).putExtra("u",games[i].u).putExtra("n",games[i].n))}
  lv.setOnItemLongClickListener{_,_,i,_->AlertDialog.Builder(this).setTitle(games[i].title).setPositiveButton("Quitar de la lista"){_,_->games.removeAt(i);Lib.save(this,games);refresh()}.setNegativeButton("Cancelar",null).show();true}
  setContentView(root)}
 override fun onResume(){super.onResume();refresh()}
 private fun refresh(){games=Lib.all(this);title.text="Juegos ("+games.size+")"
  lv.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,games.map{it.title})}
 private fun done(n:Int){refresh();t(n.toString()+" juegos añadidos")}
 private fun scanAll(){
  if(Build.VERSION.SDK_INT>=30){if(!Environment.isExternalStorageManager()){t("Concede «Acceso a todos los archivos» y vuelve a pulsar Escanear")
   startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+packageName)));return}}
  else if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),4);return}
  t("Escaneando...");Thread{val n=Lib.add(this,Roms.scanDevice());runOnUiThread{done(n)}}.start()}
 override fun onRequestPermissionsResult(rq:Int,p:Array<String>,r:IntArray){if(rq==4&&r.firstOrNull()==PackageManager.PERMISSION_GRANTED)scanAll()}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){
  if(rs!=RESULT_OK||d==null)return
  if(rq==1){val us=ArrayList<Uri>();d.clipData?.let{for(i in 0 until it.itemCount)us+=it.getItemAt(i).uri};d.data?.let{us+=it}
   done(Lib.add(this,us.mapNotNull{u->try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(e:Exception){}
    val nm=contentResolver.query(u,null,null,null,null)?.use{if(it.moveToFirst())it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null}
    if(nm!=null&&Roms.ext(nm) in Roms.EXT)Game(nm,u.toString()) else null}))}
  if(rq==2){val u=d.data?:return;try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(e:Exception){}
   t("Buscando juegos...");Thread{val n=Lib.add(this,Roms.scanTree(this,u));runOnUiThread{done(n)}}.start()}}
}
