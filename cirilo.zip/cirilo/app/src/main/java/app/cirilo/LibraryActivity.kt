package app.cirilo
import android.Manifest
import android.animation.*
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.graphics.drawable.*
import android.net.Uri
import android.os.*
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.*
import android.view.*
import android.view.inputmethod.*
import android.widget.*
/** Menú principal: lista de juegos con buscador (círculo que se expande), ordenar, filtros y botón + para añadir juegos. */
class LibraryActivity:Activity(){
 private lateinit var lv:ListView;private lateinit var title:TextView;private lateinit var head:FrameLayout;private lateinit var pill:LinearLayout
 private lateinit var et:EditText;private lateinit var sortB:ImageView;private lateinit var lpP:FrameLayout.LayoutParams
 private var games=listOf<Game>();private var shown=listOf<Game>();private var open=false;private var swallow=false;private var filling=false;private var dn=1f
 private val P by lazy{getSharedPreferences("lib",0)}
 private fun dp(x:Int)=(x*dn).toInt()
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun ss(k:String)=(P.getString(k,"")?:"").split(",").filter{it.isNotEmpty()}.toSet()
 private val PN=listOf("GB","GBC","GBA")
 private val LN=mapOf("en" to "Inglés","es" to "Español","fr" to "Francés","de" to "Alemán","it" to "Italiano","ja" to "Japonés","nl" to "Neerlandés","pt" to "Portugués")
 private val SORTS=listOf(Triple("name","Nombre",listOf("A → Z","Z → A")),Triple("added","Fecha de añadido",listOf("Más reciente","Más antiguo")),
  Triple("played","Última vez jugado",listOf("Más reciente","Más antiguo")),Triple("release","Fecha de lanzamiento (sin datos aún)",listOf("Más reciente","Más antiguo")),
  Triple("file","Nombre de archivo",listOf("A → Z","Z → A")),Triple("plat","Plataforma",listOf("GB → GBC → GBA","GBA → GBC → GB")))
 override fun onCreate(b:Bundle?){
  super.onCreate(b);dn=resources.displayMetrics.density
  val root=FrameLayout(this);root.setBackgroundColor(0xFF303030.toInt());val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  head=FrameLayout(this).apply{setBackgroundColor(0xFF212121.toInt());setPadding(dp(16),0,dp(12),0)}
  title=TextView(this).apply{setTextColor(-1);textSize=22f;gravity=Gravity.CENTER_VERTICAL}
  head.addView(title,FrameLayout.LayoutParams(-2,dp(64),Gravity.START))
  sortB=ImageView(this).apply{setImageResource(R.drawable.ic_sort);setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{sortSheet()}}
  head.addView(sortB,FrameLayout.LayoutParams(dp(48),dp(48),Gravity.END or Gravity.CENTER_VERTICAL))
  pill=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;background=GradientDrawable().apply{setColor(-1);cornerRadius=dp(24).toFloat()};setOnClickListener{if(!open)anim(true)}}
  et=EditText(this).apply{hint="Buscar juego";setSingleLine();setTextColor(0xFF212121.toInt());setHintTextColor(0xFF757575.toInt());background=null;alpha=0f;imeOptions=EditorInfo.IME_ACTION_SEARCH
   addTextChangedListener(object:TextWatcher{override fun afterTextChanged(s:Editable?){refresh()};override fun beforeTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){};override fun onTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){}})
   setOnEditorActionListener{_,_,_->hideKb();true}}
  pill.addView(ImageView(this).apply{setImageResource(R.drawable.ic_search);setPadding(dp(12),dp(12),dp(12),dp(12))},LinearLayout.LayoutParams(dp(48),dp(48)))
  pill.addView(et,LinearLayout.LayoutParams(0,-2,1f))
  lpP=FrameLayout.LayoutParams(dp(48),dp(48),Gravity.END or Gravity.CENTER_VERTICAL).apply{rightMargin=dp(52)};head.addView(pill,lpP)
  lv=ListView(this).apply{divider=ColorDrawable(0xFF444444.toInt());dividerHeight=2}
  col.addView(head);col.addView(lv,LinearLayout.LayoutParams(-1,0,1f));root.addView(col)
  val fab=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());elevation=8*dn
   background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xFF80CBC4.toInt())}}
  root.addView(fab,FrameLayout.LayoutParams(dp(56),dp(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,dp(24),dp(24))})
  fab.setOnClickListener{PopupMenu(this,fab).apply{menu.add(0,1,0,"Añadir juego");menu.add(0,2,0,"Añadir carpeta");menu.add(0,3,0,"Escanear dispositivo")
   setOnMenuItemClickListener{when(it.itemId){
    1->startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true),1)
    2->startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),2)
    else->scanAll()};true}}.show()}
  lv.setOnItemClickListener{_,_,i,_->startActivity(Intent(this,GameActivity::class.java).putExtra("u",shown[i].u).putExtra("n",shown[i].n))}
  lv.setOnItemLongClickListener{_,_,i,_->val g=shown[i]
   Sheet.show(this,g.title,listOf(if(g.fav)"Quitar de favoritos" else "Añadir a favoritos","Quitar de la lista"),null,{k->if(k==0)Lib.upd(this,listOf(g.copy(fav=!g.fav))) else Lib.del(this,g.u);refresh()},{});true}
  setContentView(root)}
 override fun onResume(){super.onResume();refresh()}
 private fun hideKb(){(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken,0)}
 /** Círculo ⇄ barra: el ancho de la píldora se anima; el título y el botón de ordenar se desvanecen. */
 private fun anim(to:Boolean){open=to;val w=head.width-head.paddingLeft-head.paddingRight
  if(!to){title.visibility=View.VISIBLE;sortB.visibility=View.VISIBLE;hideKb();et.clearFocus()}
  ValueAnimator.ofFloat(if(to)0f else 1f,if(to)1f else 0f).apply{duration=250
   addUpdateListener{val f=it.animatedValue as Float;lpP.width=(dp(48)+(w-dp(48))*f).toInt();lpP.rightMargin=(dp(52)*(1-f)).toInt();pill.layoutParams=lpP;title.alpha=1-f;sortB.alpha=1-f;et.alpha=f}
   addListener(object:AnimatorListenerAdapter(){override fun onAnimationEnd(a:Animator){if(to){title.visibility=View.INVISIBLE;sortB.visibility=View.INVISIBLE};refresh()}});start()}
  if(to){et.requestFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et,0)}}
 override fun dispatchTouchEvent(ev:MotionEvent):Boolean{
  if(swallow){if(ev.action==MotionEvent.ACTION_UP||ev.action==MotionEvent.ACTION_CANCEL)swallow=false;return true}
  if(open&&ev.action==MotionEvent.ACTION_DOWN){val r=Rect();pill.getGlobalVisibleRect(r);if(!r.contains(ev.rawX.toInt(),ev.rawY.toInt())){anim(false);swallow=true;return true}}
  return super.dispatchTouchEvent(ev)}
 override fun onBackPressed(){if(open)anim(false) else super.onBackPressed()}
 // ---- ordenar y filtrar ----
 private fun tc(f:(Game)->Long,recent:Boolean)=Comparator<Game>{a,b->val x=f(a);val y=f(b);when{x==0L&&y==0L->0;x==0L->1;y==0L->-1;recent->y.compareTo(x);else->x.compareTo(y)}}
 private fun cmp():Comparator<Game>{val d=P.getInt("sd",0);val byName=compareBy<Game>{it.title.lowercase().trimStart{c->!c.isLetterOrDigit()}}
  return when(P.getString("sk","name")){
   "added"->tc({it.added},d==0).then(byName);"played"->tc({it.played},d==0).then(byName);"release"->tc({it.year.toLong()},d==0).then(byName)
   "file"->if(d==0)compareBy<Game>{it.n.lowercase()} else compareByDescending<Game>{it.n.lowercase()}
   "plat"->(if(d==0)compareBy<Game>{it.p} else compareByDescending<Game>{it.p}).then(byName)
   else->if(d==0)byName else byName.reversed()}}
 private fun pass(g:Game,q:String):Boolean{
  val fp=ss("fplat");if(fp.isNotEmpty()&&PN[g.p.coerceIn(0,2)] !in fp)return false
  val fr=ss("freg");if(fr.isNotEmpty()&&g.reg.split(",").none{it in fr})return false
  val fl=ss("flang");if(fl.isNotEmpty()&&g.lang.split(",").none{it in fl})return false
  val fg=ss("fgen");if(fg.isNotEmpty()&&g.genre !in fg)return false
  if(P.getBoolean("ffav",false)&&!g.fav)return false
  val pl=P.getInt("fplay",0);if((pl==1&&g.played==0L)||(pl==2&&g.played!=0L))return false
  val of=P.getInt("foff",0);val off=Roms.official(g.n);if((of==1&&!off)||(of==2&&off))return false
  return q.isEmpty()||g.n.lowercase().contains(q)}
 private fun filtersOn()=listOf("fplat","freg","flang","fgen").any{ss(it).isNotEmpty()}||P.getBoolean("ffav",false)||P.getInt("fplay",0)!=0||P.getInt("foff",0)!=0
 private fun refresh(){games=Lib.all(this);val q=et.text.toString().trim().lowercase()
  shown=games.filter{pass(it,q)}.sortedWith(cmp())
  title.text=if(q.isNotEmpty()||filtersOn())"Juegos ("+shown.size+" de "+games.size+")" else "Juegos ("+games.size+")"
  lv.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,shown.map{(if(it.fav)"★ " else "")+it.title})
  (pill.background as GradientDrawable).setColor(if(!open&&q.isNotEmpty())0xFF80CBC4.toInt() else -1)
  val need=games.filter{it.p<0} // juegos de versiones anteriores: calcula su plataforma, región e idioma una vez
  if(need.isNotEmpty()&&!filling){filling=true;Thread{Lib.upd(this,need.map{Roms.meta(this,it)});runOnUiThread{filling=false;refresh()}}.start()}}
 private fun sortSheet(){
  val d=Dialog(this);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL;col.setPadding(0,dp(12),0,dp(12));col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  val box=FrameLayout(this);box.setPadding(dp(12),dp(12),dp(12),dp(12));box.addView(ScrollView(this).apply{addView(col)})
  d.setContentView(box);d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout(-1,-2);setGravity(Gravity.BOTTOM)}
  fun h(s:String)=TextView(this).apply{text=s;textSize=14f;setTextColor(0xFF80CBC4.toInt());setPadding(dp(24),dp(14),dp(24),dp(4))}
  fun lang(c:String)=LN[c]?:c.uppercase()
  lateinit var fill:()->Unit
  fun row(label:String,sum:String,click:()->Unit){val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(dp(24),dp(10),dp(24),dp(10))
   r.addView(TextView(this).apply{text=label;textSize=17f;setTextColor(-1)});r.addView(TextView(this).apply{text=sum;textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
   r.setOnClickListener{click()};col.addView(r)}
  fun multi(tt:String,k:String,labels:List<String>,vals:List<String>){if(vals.isEmpty()){t("Sin datos todavía");return}
   val cur=ss(k).toMutableSet();AlertDialog.Builder(this).setTitle(tt).setMultiChoiceItems(labels.toTypedArray(),BooleanArray(vals.size){vals[it] in cur}){_,i,on->if(on)cur+=vals[i] else cur-=vals[i]}
    .setPositiveButton("Aceptar"){_,_->P.edit().putString(k,cur.joinToString(",")).apply();refresh();fill()}.setNegativeButton("Cancelar",null).show()}
  fun single(tt:String,k:String,labels:List<String>){AlertDialog.Builder(this).setTitle(tt).setSingleChoiceItems(labels.toTypedArray(),P.getInt(k,0)){dl,i->P.edit().putInt(k,i).apply();dl.dismiss();refresh();fill()}.show()}
  fun sum(k:String,m:(String)->String):String{val s=ss(k);return if(s.isEmpty())"Todos" else s.joinToString(", "){m(it)}}
  fill={col.removeAllViews();col.addView(h("ORDENAR POR"))
   val cur=P.getString("sk","name");val dir=P.getInt("sd",0)
   SORTS.forEach{(k,lab,chips)->val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(dp(24),dp(8),dp(24),dp(4))
    r.addView(TextView(this).apply{text=lab;textSize=17f;setTextColor(-1)});val cr=LinearLayout(this)
    chips.forEachIndexed{i,c->val sel=cur==k&&dir==i
     cr.addView(TextView(this).apply{text=c;textSize=13f;gravity=Gravity.CENTER;setPadding(dp(8),dp(9),dp(8),dp(9));setTextColor(if(sel)0xFF212121.toInt() else -1)
      background=GradientDrawable().apply{setColor(if(sel)0xFF80CBC4.toInt() else 0xFF3A3A3A.toInt());cornerRadius=dp(16).toFloat()}
      setOnClickListener{P.edit().putString("sk",k).putInt("sd",i).apply();refresh();fill()}},LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(0,dp(6),dp(6),0)})}
    r.addView(cr);col.addView(r)}
   col.addView(h("FILTROS (independientes del orden)"))
   row("Plataforma",sum("fplat"){it},{multi("Plataforma","fplat",PN,PN)})
   row("Región",sum("freg"){it},{multi("Región","freg",listOf("USA","Europe","Japan"),listOf("USA","Europe","Japan"))})
   val ls=games.flatMap{it.lang.split(",")}.filter{it.isNotEmpty()}.distinct().sorted()
   row("Idioma",sum("flang"){lang(it)},{multi("Idioma","flang",ls.map{lang(it)},ls)})
   val gs=games.map{it.genre}.filter{it.isNotEmpty()}.distinct().sorted()
   row("Género",if(gs.isEmpty())"Sin datos todavía" else sum("fgen"){it},{multi("Género","fgen",gs,gs)})
   row("Favoritos",if(P.getBoolean("ffav",false))"Solo favoritos" else "Todos",{P.edit().putBoolean("ffav",!P.getBoolean("ffav",false)).apply();refresh();fill()})
   row("Jugados / Nunca jugados",listOf("Todos","Jugados","Nunca jugados")[P.getInt("fplay",0)],{single("Jugados / Nunca jugados","fplay",listOf("Todos","Jugados","Nunca jugados"))})
   row("ROM Hacks / Oficiales",listOf("Todos","Oficiales (aprox.)","ROM Hacks (aprox.)")[P.getInt("foff",0)],{single("ROM Hacks / Oficiales","foff",listOf("Todos","Oficiales (aprox.)","ROM Hacks (aprox.)"))})
   if(filtersOn())row("Quitar todos los filtros","",{P.edit().remove("fplat").remove("freg").remove("flang").remove("fgen").remove("ffav").remove("fplay").remove("foff").apply();refresh();fill()})}
  fill();d.show()}
 // ---- añadir juegos ----
 private fun done(n:Int){refresh();t(n.toString()+" juegos añadidos")}
 private fun scanAll(){
  if(Build.VERSION.SDK_INT>=30){if(!Environment.isExternalStorageManager()){t("Concede «Acceso a todos los archivos» y vuelve a pulsar Escanear")
   startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+packageName)));return}}
  else if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),4);return}
  t("Escaneando...");Thread{val n=Lib.add(this,Roms.scanDevice());runOnUiThread{done(n)}}.start()}
 override fun onRequestPermissionsResult(rq:Int,p:Array<String>,r:IntArray){if(rq==4&&r.firstOrNull()==PackageManager.PERMISSION_GRANTED)scanAll()}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){
  if(rs!=RESULT_OK||d==null)return
  if(rq==1){val us=ArrayList<Uri>();d.clipData?.let{for(i in 0 until it.itemCount)us+=it.getItemAt(i).uri};d.data?.let{us+=it}
   val gs=us.mapNotNull{u->try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(e:Exception){}
    val nm=contentResolver.query(u,null,null,null,null)?.use{if(it.moveToFirst())it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null}
    if(nm!=null&&Roms.ext(nm) in Roms.EXT)Game(nm,u.toString()) else null}
   Thread{val n=Lib.add(this,gs);runOnUiThread{done(n)}}.start()}
  if(rq==2){val u=d.data?:return;try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(e:Exception){}
   t("Buscando juegos...");Thread{val n=Lib.add(this,Roms.scanTree(this,u));runOnUiThread{done(n)}}.start()}}
}
