package app.cirilo
import android.app.Application
/** Carga el color de acento antes de que se cree ninguna pantalla. */
class App:Application(){override fun onCreate(){super.onCreate();Accent.load(this)
 // Perfil PGO (solo lo usa la build «perfil»; en la normal no hace nada): dónde escribe LLVM los contadores. %m = un solo archivo por binario, y las sesiones se mezclan.
 try{val d=java.io.File(filesDir,"pgo");d.mkdirs();android.system.Os.setenv("LLVM_PROFILE_FILE",d.absolutePath+"/cirilo-%m.profraw",true)}catch(e:Exception){}}}
