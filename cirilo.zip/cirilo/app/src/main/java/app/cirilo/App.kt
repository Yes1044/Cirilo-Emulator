package app.cirilo
import android.app.Application
/** Carga el color de acento antes de que se cree ninguna pantalla. */
class App:Application(){override fun onCreate(){super.onCreate();Accent.load(this)}}
