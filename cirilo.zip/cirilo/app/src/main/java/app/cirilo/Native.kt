package app.cirilo
/** Puente JNI. Hay dos consolas (instancia 0 y 1; la 1 solo se usa en Link local). `act` = la que se ve y se oye. */
object Native{
 init{System.loadLibrary("cirilo")}
 /** Instancia que se dibuja y suena (GLView y Emu la leen en cada fotograma). */
 @JvmField @Volatile var act=0
 /** true = hay cable: el hilo de la consola 0 avanza las dos (run(0) y luego run(1)); la 1 no tiene hilo propio. Lo pone GameActivity tras linkStart()==1. */
 @JvmField @Volatile var lnk=false
 external fun load(i:Int,rom:ByteArray,name:String):Boolean
 external fun unload(i:Int)
 external fun run(i:Int)
 external fun info(i:Int):DoubleArray
 external fun frame(i:Int,b:java.nio.ByteBuffer):Int
 external fun audio(i:Int,a:ShortArray):Int
 external fun reset(i:Int)
 external fun saveState(i:Int):ByteArray?
 external fun loadState(i:Int,b:ByteArray):Boolean
 external fun last(i:Int,b:java.nio.ByteBuffer):Int
 external fun setSkip(i:Int,n:Int)
 external fun keys(i:Int,k:Int)
 external fun getSave(i:Int):ByteArray?
 external fun setSave(i:Int,b:ByteArray)
 /** Trucos (cirilo_cheats.c): [líneas aceptadas o error<0, versión GameShark detectada]. -9999 = el núcleo no trae el módulo. Usa la primera consola abierta (lo llama el editor de trucos). */
 external fun cheatCheck(mode:Int,text:String):IntArray
 /** Puntuaciones de mGBA {GS cifrado, AR v3 cifrado, GS sin cifrar, AR sin cifrar} para una línea «8+8»; null si no aplica. */
 external fun cheatProbe(line:String):IntArray?
 /** Sustituye todos los trucos activos de la consola i por estos (uno por truco, con su formato). Devuelve el estado de cada uno. No reinicia el juego. */
 external fun cheatApply(i:Int,modes:IntArray,texts:Array<String>):IntArray
 /** Conecta el cable entre las dos consolas (con ambas paradas): 1 = conectado; 0 = este núcleo no trae el módulo del cable (corren sin comunicarse); -2 = falta una consola; <0 = error. */
 external fun linkStart():Int
 /** Desconecta el cable. Siempre antes de descargar una de las dos consolas, con ambas paradas. */
 external fun linkStop()
 /** Sin efecto con el cable sin hilos; se mantiene por si algún día hay un hilo por consola. */
 external fun linkInterrupt(on:Boolean)
 external fun linked():Boolean
 /** Último error de dlopen (por qué no cargó un núcleo). */
 external fun lastError():String
}
