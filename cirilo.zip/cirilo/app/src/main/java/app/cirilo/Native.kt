package app.cirilo
/** Puente JNI. Hay dos consolas (instancia 0 y 1; la 1 solo se usa en Link local). `act` = la que se ve y se oye. */
object Native{
 init{System.loadLibrary("cirilo")}
 /** Instancia que se dibuja y suena (GLView y Emu la leen en cada fotograma). */
 @JvmField @Volatile var act=0
 /** true = hay cable entre las dos consolas (cada una corre en su propio hilo y el cable las sincroniza; GBA o GB/GBC). Lo pone GameActivity tras linkStart()==1. */
 @JvmField @Volatile var lnk=false
 external fun load(i:Int,rom:ByteArray,name:String):Boolean
 external fun unload(i:Int)
 external fun run(i:Int)
 external fun info(i:Int):DoubleArray
 external fun frame(i:Int,b:java.nio.ByteBuffer):Int
 external fun audio(i:Int,a:ShortArray):Int
 external fun reset(i:Int)
 external fun saveState(i:Int):ByteArray?
 external fun loadState(i:Int,b:ByteArray):Boolean
 external fun last(i:Int,b:java.nio.ByteBuffer):Int
 external fun setSkip(i:Int,n:Int)
 external fun keys(i:Int,k:Int)
 external fun getSave(i:Int):ByteArray?
 external fun setSave(i:Int,b:ByteArray)
 /** Trucos (cirilo_cheats.c): [líneas aceptadas o error<0, versión GameShark detectada]. -9999 = el núcleo no trae el módulo. Usa la primera consola abierta (lo llama el editor de trucos). */
 external fun cheatCheck(mode:Int,text:String):IntArray
 /** Puntuaciones de mGBA {GS cifrado, AR v3 cifrado, GS sin cifrar, AR sin cifrar} para una línea «8+8»; null si no aplica. */
 external fun cheatProbe(line:String):IntArray?
 /** Sustituye todos los trucos activos de la consola i por estos (uno por truco, con su formato). Devuelve el estado de cada uno. No reinicia el juego. */
 external fun cheatApply(i:Int,modes:IntArray,texts:Array<String>):IntArray
 /** Conecta el cable entre las dos consolas (con ambas paradas): 1 = conectado; 0 = este núcleo no trae el módulo del cable (corren sin comunicarse); -2 = falta una consola; <0 = error. */
 external fun linkStart():Int
 /** Desconecta el cable. Siempre antes de descargar una de las dos consolas, con ambas paradas. */
 external fun linkStop()
 /** on=true al pausar (con los hilos aún en marcha): suelta a la consola que espera a la otra para que su hilo pueda terminar; se vuelve a poner en false cuando los hilos ya se unieron. */
 external fun linkInterrupt(on:Boolean)
 /** true = buen momento para guardar los estados de las dos consolas (GB/GBC: sin transferencia en curso). Con ambas paradas. */
 external fun linkIdle():Boolean
 /** ANTES de cargar el estado de una consola (paradas, con cable): GBA suelta el cable de las dos; GB/GBC no hace nada. */
 external fun linkCut()
 /** DESPUÉS de cargar (paradas, con cable): GBA vuelve a conectar las dos consolas; GB/GBC reinicia el lockstep. */
 external fun linkResync()
 external fun linked():Boolean
 /** Último error de dlopen (por qué no cargó un núcleo). */
 /** Contadores del cable desde la última lectura (diagnóstico). */
 external fun linkDbg():String
 /** Reparto del tiempo en el núcleo desde la última lectura (cirilo_prof.c): «cpu% i v a o». Vacío si el núcleo no trae el medidor. */
 external fun profDbg():String
 /** Contadores del JIT desde la última lectura («jit nat X% ej N»); vacío si está apagado. */
 external fun jitDbg():String
 /** Núcleo de CPU en el que se está ejecutando el hilo que llama. */
 external fun cpu():Int
 /** Vuelca el perfil PGO del núcleo i a disco (build «perfil»). 0 = ok, -1 = núcleo no cargado, -2 = núcleo normal (no instrumentado). */
 external fun pgoDump(i:Int):Int
 /** Ajustes avanzados de la consola i para la próxima carga: BIOS real, saltar intro del BIOS, hack de velocidad, tipo de guardado (0 auto, 1 EEPROM, 2 SRAM, 3 Flash 64K, 4 Flash 128K, 5 ninguno), mosaico y carpeta con los BIOS. */
 external fun advConfig(i:Int,useBios:Boolean,skipBios:Boolean,idle:Boolean,saveType:Int,mosaic:Boolean,sgbBorders:Boolean,gbSave:Int,gbcSave:Int,dir:String)
 /** JIT experimental de la CPU de GBA para la próxima carga (solo arm64; en el resto se ignora). */
 external fun jitConfig(i:Int,mode:Int) // 0 apagado, 1 normal, 2 diagnóstico A (solo despachador), 3 diagnóstico B (nativo sin memoria)
 external fun lastError():String
 /** Carpeta de las bibliotecas nativas de la app: los núcleos se abren por ruta absoluta. */
 external fun libDir(d:String)
}
