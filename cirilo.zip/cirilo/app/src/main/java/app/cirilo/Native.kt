package app.cirilo
object Native{
 init{System.loadLibrary("cirilo")}
 external fun load(rom:ByteArray,name:String):Boolean
 external fun unload()
 external fun run()
 external fun info():DoubleArray
 external fun frame(b:java.nio.ByteBuffer):Int
 external fun audio(a:ShortArray):Int
 external fun reset()
 external fun saveState():ByteArray?
 external fun loadState(b:ByteArray):Boolean
 external fun last(b:java.nio.ByteBuffer):Int
 external fun setSkip(n:Int)
 external fun keys(k:Int)
 external fun getSave():ByteArray?
 external fun setSave(b:ByteArray)
 /** Trucos (cirilo_cheats.c): [líneas aceptadas o error<0, versión GameShark detectada]. -9999 = el núcleo no trae el módulo. */
 external fun cheatCheck(mode:Int,text:String):IntArray
 /** Puntuaciones de mGBA {GS cifrado, AR v3 cifrado, GS sin cifrar, AR sin cifrar} para una línea «8+8»; null si no aplica. */
 external fun cheatProbe(line:String):IntArray?
 /** Sustituye todos los trucos activos del núcleo por estos (uno por truco, con su formato). Devuelve el estado de cada uno. No reinicia el juego. */
 external fun cheatApply(modes:IntArray,texts:Array<String>):IntArray
}
