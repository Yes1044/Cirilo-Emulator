package app.cirilo
object Native{
 init{System.loadLibrary("cirilo")}
 external fun load(rom:ByteArray,name:String):Boolean
 external fun unload()
 external fun run()
 external fun info():DoubleArray
 external fun frame(b:java.nio.ByteBuffer):Int
 external fun audio(a:ShortArray):Int
 external fun reset()
 external fun saveState():ByteArray?
 external fun loadState(b:ByteArray):Boolean
 external fun setSkip(n:Int)
 external fun keys(k:Int)
 external fun getSave():ByteArray?
 external fun setSave(b:ByteArray)
 external fun cheats(c:Array<String>)
}
