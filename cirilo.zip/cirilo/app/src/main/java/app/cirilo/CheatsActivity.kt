package app.cirilo
import android.app.*
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

/** Pantalla «Trucos» del juego en ejecución: lista con casilla de activación y ⋮ por fila (editar, duplicar, eliminar con «Deshacer»), buscador cuando hay muchos, avisos (trucos que mGBA no pudo aplicar, código maestro, trucos desactivados en Ajustes),
 *  ⋮ de la cabecera (importar, exportar, activar/desactivar todos) y botón +. Los cambios se guardan al instante; GameActivity los aplica al núcleo al volver. */
class CheatsActivity:Activity(){
 private lateinit var g:GameInfo;private lateinit var body:LinearLayout;private lateinit var root:FrameLayout
 private lateinit var titleV:TextView;private lateinit var pill:LinearLayout;private lateinit var et:EditText;private lateinit var searchB:ImageView
 private lateinit var bar:LinearLayout;private lateinit var barT:TextView
 private var list=mutableListOf<Cheat>();private var dn=1f;private var q="";private var searching=false
 private var undo:(()->Unit)?=null;private val hd=Handler(Looper.getMainLooper());private val hideBar=Runnable{bar.visibility=View.GONE;undo=null}
 private val seen=HashMap<String,Int>();private var saved=mapOf<String,Int>()
 private fun dp(x:Int)=(x*dn).toInt()
 private val accent get()=Accent.color;private val gray=0xFF9E9E9E.toInt();private val errC=0xFFEF5350.toInt()
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 companion object{
  const val SAVE=31;const val MIN_SEARCH=8
  fun intent(a:Activity,g:GameInfo)=Intent(a,CheatsActivity::class.java).putExtra("gid",g.id).putExtra("plat",g.plat).putExtra("code",g.code).putExtra("title",g.title)
  fun info(i:Intent)=GameInfo(i.getStringExtra("gid")?:"",i.getIntExtra("plat",0),i.getStringExtra("code")?:"",i.getStringExtra("title")?:"")
 }
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density;g=info(intent)
  root=FrameLayout(this);root.setBackgroundColor(0xFF303030.toInt());val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  val head=LinearLayout(this);head.gravity=Gravity.CENTER_VERTICAL;head.setBackgroundColor(0xFF212121.toInt());head.setPadding(dp(16),0,dp(8),0)
  titleV=TextView(this).apply{text="Trucos";setTextColor(-1);textSize=22f;setPadding(0,dp(16),0,dp(16))}
  head.addView(titleV,LinearLayout.LayoutParams(0,-2,1f))
  // buscador: la misma píldora blanca de la biblioteca, que sustituye al título
  pill=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;background=GradientDrawable().apply{setColor(-1);cornerRadius=dp(20).toFloat()};visibility=View.GONE}
  pill.setPadding(dp(15),0,dp(4),0)
  pill.addView(ImageView(this).apply{setImageResource(R.drawable.ic_search)},LinearLayout.LayoutParams(dp(24),dp(24)))
  et=EditText(this).apply{hint="Buscar truco";textSize=16f;setSingleLine();setTextColor(0xFF212121.toInt());setHintTextColor(0xFF757575.toInt());background=null;imeOptions=EditorInfo.IME_ACTION_SEARCH
   addTextChangedListener(object:TextWatcher{override fun afterTextChanged(s:Editable?){q=s?.toString()?:"";render()};override fun beforeTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){};override fun onTextChanged(a:CharSequence?,x:Int,y:Int,z:Int){}})
   setOnEditorActionListener{_,_,_->hideKb();true}}
  pill.addView(et,LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(4)})
  pill.addView(ImageView(this).apply{setImageResource(R.drawable.ic_close);setPadding(dp(8),dp(8),dp(8),dp(8));setOnClickListener{closeSearch()}},LinearLayout.LayoutParams(dp(40),dp(40)))
  head.addView(pill,LinearLayout.LayoutParams(0,dp(40),1f))
  searchB=ImageView(this).apply{setImageResource(R.drawable.ic_search);setColorFilter(-1);setPadding(dp(10),dp(10),dp(10),dp(10));visibility=View.GONE;setOnClickListener{openSearch()}}
  head.addView(searchB,LinearLayout.LayoutParams(dp(48),dp(48)))
  val more=ImageView(this).apply{setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10))};head.addView(more,LinearLayout.LayoutParams(dp(48),dp(48)))
  more.setOnClickListener{headMenu(more)}
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL;body.setPadding(0,0,0,dp(96))
  col.addView(head);col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));root.addView(col)
  val fab=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());elevation=8*dn
   background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(accent)}}
  root.addView(fab,FrameLayout.LayoutParams(dp(56),dp(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,dp(24),dp(24))})
  fab.setOnClickListener{startActivity(CheatEditActivity.intent(this,g,null))}
  // barra «Truco eliminado · DESHACER»
  bar=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL;visibility=View.GONE;elevation=10*dn;setPadding(dp(16),0,dp(4),0)
   background=GradientDrawable().apply{setColor(0xFF212121.toInt());cornerRadius=dp(4).toFloat();setStroke(dp(1),0xFF444444.toInt())}}
  barT=TextView(this).apply{textSize=15f;setTextColor(-1)};bar.addView(barT,LinearLayout.LayoutParams(-2,-2))
  bar.addView(TextView(this).apply{text="DESHACER";textSize=14f;setTextColor(accent);typeface=Typeface.DEFAULT_BOLD;setPadding(dp(16),dp(14),dp(12),dp(14))
   setOnClickListener{val u=undo;hd.removeCallbacks(hideBar);bar.visibility=View.GONE;undo=null;u?.invoke()}})
  root.addView(bar,FrameLayout.LayoutParams(-2,dp(48),Gravity.BOTTOM or Gravity.START).apply{setMargins(dp(16),0,dp(96),dp(24))})
  setContentView(root)}
 override fun onResume(){super.onResume();list=CheatStore.list(this,g.id);saved=CheatStore.status(this,g.id);seen.clear();render()}
 override fun onBackPressed(){if(searching)closeSearch() else super.onBackPressed()}
 private fun hideKb(){(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken,0)}
 private fun openSearch(){searching=true;titleV.visibility=View.GONE;searchB.visibility=View.GONE;pill.visibility=View.VISIBLE;et.requestFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et,0)}
 private fun closeSearch(){searching=false;hideKb();et.setText("");q="";pill.visibility=View.GONE;titleV.visibility=View.VISIBLE;render()}
 private fun save(){CheatStore.save(this,g,list);render()}

 // ---- menú de la cabecera ----
 private fun shown():List<Cheat> = if(q.isBlank())list else list.filter{it.name.contains(q.trim(),true)}
 private fun headMenu(a:View){val f=q.isNotBlank()
  PopupMenu(this,a).apply{menu.add(0,0,0,"Importar trucos");menu.add(0,1,0,"Exportar trucos");menu.add(0,2,0,if(f)"Activar los mostrados" else "Activar todos");menu.add(0,3,0,if(f)"Desactivar los mostrados" else "Desactivar todos")
   setOnMenuItemClickListener{when(it.itemId){0->startActivity(CheatImportActivity.intent(this@CheatsActivity,g));1->export();2->enableAll(true);else->enableAll(false)};true}}.show()}
 /** Activar varios a la vez puede provocar conflictos: se pide confirmación. Desactivar no. Con búsqueda activa solo afecta a los que se ven. */
 private fun enableAll(on:Boolean){val ids=shown().filter{it.enabled!=on}.map{it.id}.toSet()
  if(ids.isEmpty()){toast(if(on)"Ya están todos activados" else "Ya están todos desactivados");return}
  val go={list=list.map{if(it.id in ids)it.copy(enabled=on) else it}.toMutableList();save()}
  if(on&&ids.size>1)Ui.confirm(this,"Activar varios trucos a la vez puede provocar conflictos: dos trucos que escriben en la misma dirección, o códigos que no se llevan bien.\n\n¿Activar los "+ids.size+" trucos?",go) else go()}
 private fun export(){if(list.isEmpty()){toast("No hay trucos que exportar");return}
  Sheet.show(this,"Exportar trucos",listOf("Guardar un archivo de respaldo","Compartir como texto"),listOf("Conserva formatos y estados; se puede importar de nuevo","Lista legible con nombre y códigos, para otros emuladores o para enviar"),{i->
   if(i==0){val n=g.title.replace(Regex("[\\\\/:*?\"<>|]"),"_").trim().ifEmpty{"juego"}
    try{startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,n+" - trucos.json"),SAVE)}catch(e:Exception){toast("No se pudo abrir el selector de archivos")}}
   else{val t=CheatImport.toText(list.map{Pair(it.name,it.code)})
    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,t).putExtra(Intent.EXTRA_SUBJECT,"Trucos de "+g.title),"Compartir trucos"))}},{})}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){super.onActivityResult(rq,rs,d);if(rq!=SAVE||rs!=RESULT_OK)return;val u=d?.data?:return
  val json=CheatStore.pack(this,g.id);if(json==null){toast("No hay trucos que exportar");return}
  try{contentResolver.openOutputStream(u,"wt")!!.use{it.write(json.toByteArray())};toast("Respaldo guardado")}catch(e:Exception){toast("No se pudo guardar el archivo")}}

 // ---- lista ----
 private fun div(){body.addView(View(this).apply{setBackgroundColor(0xFF444444.toInt())},LinearLayout.LayoutParams(-1,2))}
 private fun banner(t:String,act:String,go:()->Unit){
  val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setBackgroundColor(0xFF262626.toInt());r.setPadding(dp(16),dp(8),dp(4),dp(8))
  r.addView(TextView(this).apply{text=t;textSize=14f;setTextColor(0xFFBBBBBB.toInt())},LinearLayout.LayoutParams(0,-2,1f))
  r.addView(TextView(this).apply{text=act;textSize=14f;setTextColor(accent);typeface=Typeface.DEFAULT_BOLD;setPadding(dp(12),dp(10),dp(12),dp(10));setOnClickListener{go()}})
  body.addView(r);div()}
 /** Código maestro (solo GBA, y solo como pista: ver CheatCodes.isMaster). */
 private fun masterBanner(){if(g.plat!=CheatCodes.GBA)return
  if(!list.any{it.enabled&&CheatCodes.needsMaster(g.plat,it.mode)&&!CheatCodes.isMaster(it.name,it.mode,it.code)})return
  val ms=list.filter{CheatCodes.isMaster(it.name,it.mode,it.code)}
  if(ms.isEmpty()){if(CheatStore.hintSeen(this,g.id))return
   banner("Algunos códigos de GBA no hacen nada sin su código maestro. Si un truco no responde, añade el «Master Code» de este juego como otro truco.","ENTENDIDO"){CheatStore.hintDone(this,g.id);render()}}
  else if(ms.none{it.enabled})banner("El código maestro «"+ms[0].name+"» está desactivado. Sin él, los demás trucos pueden no hacer nada.","ACTIVAR"){val ids=ms.map{it.id}.toSet();list=list.map{if(it.id in ids)it.copy(enabled=true) else it}.toMutableList();save()}}
 private fun render(){body.removeAllViews()
  searchB.visibility=if(!searching&&list.size>=MIN_SEARCH)View.VISIBLE else View.GONE
  if(!getSharedPreferences("c",0).getBoolean("cheats",true))banner("Los trucos están desactivados en Ajustes: no se aplican en el juego.","ACTIVAR"){getSharedPreferences("c",0).edit().putBoolean("cheats",true).apply();render()}
  masterBanner()
  if(list.isEmpty()){empty();return}
  val rows=shown()
  if(rows.isEmpty()){body.addView(TextView(this).apply{text="Ningún truco coincide con «"+q.trim()+"»";setTextColor(gray);textSize=16f;gravity=Gravity.CENTER;setPadding(dp(32),dp(64),dp(32),0)},LinearLayout.LayoutParams(-1,-2));return}
  rows.forEach{row(it);div()}}
 private fun empty(){val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.gravity=Gravity.CENTER_HORIZONTAL;c.setPadding(dp(32),dp(96),dp(32),0)
  c.addView(TextView(this).apply{text="No hay trucos para este juego.";setTextColor(gray);textSize=16f;gravity=Gravity.CENTER})
  c.addView(TextView(this).apply{text="Pulsa + para escribir uno, o pega una lista entera desde el portapapeles o un archivo.";setTextColor(gray);textSize=14f;gravity=Gravity.CENTER;setPadding(0,dp(8),0,dp(8))})
  c.addView(TextView(this).apply{text="IMPORTAR TRUCOS";setTextColor(accent);textSize=14f;typeface=Typeface.DEFAULT_BOLD;setPadding(dp(16),dp(12),dp(16),dp(12));setOnClickListener{startActivity(CheatImportActivity.intent(this@CheatsActivity,g))}})
  body.addView(c)}
 /** Motivo por el que mGBA no puede aplicar un truco activo, o null. Se comprueba con el propio núcleo (el mismo constructor que usa cheatApply); si el núcleo no responde se usa lo guardado la última vez que se aplicó. */
 private fun warn(c:Cheat):String?{if(!c.enabled)return null
  val r=seen.getOrPut(c.mode.toString()+"|"+c.text){Native.cheatCheck(c.mode,c.text)[0]}
  val v=if(r==-9000||r==-9999)(saved[c.id]?:0) else r
  return if(v<0)CheatCodes.explain(v,c.fmtName) else null}
 private fun row(c:Cheat){val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(12),0,dp(12))
  r.background=RippleDrawable(ColorStateList.valueOf(0x22FFFFFF),null,ColorDrawable(-1))
  val tx=LinearLayout(this);tx.orientation=LinearLayout.VERTICAL
  tx.addView(TextView(this).apply{text=c.name;textSize=18f;setTextColor(-1)})
  val sub=c.shown+(if(c.lines>1)" · "+c.lines+" líneas" else "")+(if(CheatCodes.isMaster(c.name,c.mode,c.code))" · código maestro" else "")
  tx.addView(TextView(this).apply{text=sub;textSize=13f;setTextColor(gray)})
  val w=warn(c);if(w!=null)tx.addView(TextView(this).apply{text=w;textSize=13f;setTextColor(errC);setPadding(0,dp(2),0,0)})
  r.addView(tx,LinearLayout.LayoutParams(0,-2,1f))
  r.addView(CheckBox(this).apply{isChecked=c.enabled;buttonTintList=ColorStateList.valueOf(accent);isClickable=false;isFocusable=false})
  r.addView(ImageView(this).apply{setImageResource(R.drawable.ic_more);setColorFilter(gray);setPadding(dp(12),dp(12),dp(12),dp(12));setOnClickListener{rowMenu(c)}},LinearLayout.LayoutParams(dp(48),dp(48)))
  r.setOnClickListener{val i=list.indexOfFirst{it.id==c.id};if(i>=0){list[i]=c.copy(enabled=!c.enabled);save()}}
  r.setOnLongClickListener{rowMenu(c);true}
  body.addView(r)}
 private fun rowMenu(c:Cheat){Sheet.show(this,c.name,listOf("Editar","Duplicar","Eliminar"),null,{k->when(k){
   0->startActivity(CheatEditActivity.intent(this,g,c.id))
   1->{val i=list.indexOfFirst{it.id==c.id};list.add(i+1,c.copy(id=CheatStore.newId(),name=c.name+" (copia)",enabled=false));save()}
   else->remove(c)}},{})}
 /** Se elimina al instante y se ofrece «Deshacer» durante 6 s (sin diálogo de confirmación). */
 private fun remove(c:Cheat){val i=list.indexOfFirst{it.id==c.id};if(i<0)return;list.removeAt(i);save()
  undo={val l=CheatStore.list(this,g.id);l.add(minOf(i,l.size),c);list=l;save()}
  barT.text="Truco eliminado";bar.visibility=View.VISIBLE;hd.removeCallbacks(hideBar);hd.postDelayed(hideBar,6000)}
}
