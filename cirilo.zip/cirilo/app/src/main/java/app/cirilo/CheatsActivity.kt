package app.cirilo
import android.app.*
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.*
import android.os.Bundle
import android.view.*
import android.widget.*

/** Pantalla «Cheats» del juego en ejecución: lista con casilla de activación, ⋮ (activar/desactivar todos), pulsación larga (editar/eliminar) y botón +. Los cambios se guardan al instante; GameActivity los aplica al núcleo al volver. */
class CheatsActivity:Activity(){
 private lateinit var g:GameInfo;private lateinit var body:LinearLayout;private var list=mutableListOf<Cheat>();private var dn=1f
 private fun dp(x:Int)=(x*dn).toInt()
 private val accent=0xFF80CBC4.toInt()
 companion object{
  fun intent(a:Activity,g:GameInfo)=Intent(a,CheatsActivity::class.java).putExtra("gid",g.id).putExtra("plat",g.plat).putExtra("code",g.code).putExtra("title",g.title)
  fun info(i:Intent)=GameInfo(i.getStringExtra("gid")?:"",i.getIntExtra("plat",0),i.getStringExtra("code")?:"",i.getStringExtra("title")?:"")
 }
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density;g=info(intent)
  val root=FrameLayout(this);root.setBackgroundColor(0xFF303030.toInt());val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  val head=LinearLayout(this);head.gravity=Gravity.CENTER_VERTICAL;head.setBackgroundColor(0xFF212121.toInt());head.setPadding(dp(16),0,dp(8),0)
  head.addView(TextView(this).apply{text="Cheats";setTextColor(-1);textSize=22f;setPadding(0,dp(16),0,dp(16))},LinearLayout.LayoutParams(0,-2,1f))
  val more=ImageView(this).apply{setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10))};head.addView(more,LinearLayout.LayoutParams(dp(48),dp(48)))
  more.setOnClickListener{PopupMenu(this,more).apply{menu.add(0,0,0,"Activar todos");menu.add(0,1,0,"Desactivar todos");setOnMenuItemClickListener{all(it.itemId==0);true}}.show()}
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL
  col.addView(head);col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));root.addView(col)
  val fab=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());elevation=8*dn
   background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(accent)}}
  root.addView(fab,FrameLayout.LayoutParams(dp(56),dp(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,dp(24),dp(24))})
  fab.setOnClickListener{startActivity(CheatEditActivity.intent(this,g,null))}
  setContentView(root)}
 override fun onResume(){super.onResume();list=CheatStore.list(this,g.id);render()}
 private fun save(){CheatStore.save(this,g,list);render()}
 private fun all(on:Boolean){if(list.isEmpty())return;list=list.map{it.copy(enabled=on)}.toMutableList();save()}
 private fun render(){body.removeAllViews()
  if(list.isEmpty()){body.addView(TextView(this).apply{text="No hay cheats para este juego.\nPulsa + para añadir uno.";setTextColor(0xFF9E9E9E.toInt());textSize=16f;gravity=Gravity.CENTER;setPadding(dp(32),dp(96),dp(32),0)},LinearLayout.LayoutParams(-1,-2));return}
  list.forEachIndexed{i,c->val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(14),dp(16),dp(14))
   val tx=LinearLayout(this);tx.orientation=LinearLayout.VERTICAL
   tx.addView(TextView(this).apply{text=c.name;textSize=18f;setTextColor(-1)})
   val sub=if(c.format==CheatFormat.AUTO)"Auto detect"+(if(c.label.isNotEmpty())" → "+c.label else "") else c.format.label
   tx.addView(TextView(this).apply{text=sub;textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
   r.addView(tx,LinearLayout.LayoutParams(0,-2,1f))
   val cb=CheckBox(this).apply{isChecked=c.enabled;buttonTintList=ColorStateList.valueOf(accent);isClickable=false;isFocusable=false}
   r.addView(cb)
   r.setOnClickListener{list[i]=c.copy(enabled=!c.enabled);save()}
   r.setOnLongClickListener{Sheet.show(this,c.name,listOf("Editar","Eliminar"),null,{k->
    if(k==0)startActivity(CheatEditActivity.intent(this,g,c.id)) else Ui.confirm(this,"¿Eliminar el cheat «"+c.name+"»?"){list.removeAll{it.id==c.id};save()}},{});true}
   body.addView(r);body.addView(View(this).apply{setBackgroundColor(0xFF444444.toInt())},LinearLayout.LayoutParams(-1,2))}}
}
