package app.cirilo
import android.app.*
import android.graphics.drawable.*
import android.view.*
import android.widget.*

/** Cuadro pequeño de «Cambiar de consola» (Link local): las dos consolas con la que se ve marcada. Abajo y centrado, con el mismo estilo que `Sheet` y el color de acento.
 *  Tocar la otra consola llama a onPick(k); tocar la marcada, «Cancelar» o fuera cierra con onCancel. */
object ConsolePicker{
 fun show(a:Activity,cur:Int,names:List<String>,onPick:(Int)->Unit,onCancel:()->Unit){
  val dn=a.resources.displayMetrics.density;fun dp(x:Int)=(x*dn).toInt()
  val acc=Accent.color
  val d=Dialog(a);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val col=LinearLayout(a);col.orientation=LinearLayout.VERTICAL;col.setPadding(0,dp(14),0,dp(8))
  col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  col.addView(TextView(a).apply{text="Cambiar de consola";textSize=20f;setTextColor(-1);setPadding(dp(24),dp(8),dp(24),dp(10));tvs+=this})
  val tvs=ArrayList<TextView>() // para medir el texto más largo y dar el mismo ancho que `Sheet`
  var done=false
  fun close(f:()->Unit){if(done)return;done=true;d.dismiss();f()}
  names.forEachIndexed{i,nm->
   val r=LinearLayout(a);r.orientation=LinearLayout.HORIZONTAL;r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(24),dp(12),dp(24),dp(12))
   val on=i==cur
   // círculo de selección: aro de acento con punto dentro si es la consola que se ve; aro gris si no
   val radio=FrameLayout(a)
   radio.background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0);setStroke(dp(2),if(on)acc else 0xFF8A8A8A.toInt())}
   if(on)radio.addView(View(a).apply{background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(acc)}},FrameLayout.LayoutParams(dp(10),dp(10),Gravity.CENTER))
   r.addView(radio,LinearLayout.LayoutParams(dp(22),dp(22)).apply{rightMargin=dp(18)})
   val tx=LinearLayout(a);tx.orientation=LinearLayout.VERTICAL
   tx.addView(TextView(a).apply{text=nm;textSize=18f;setTextColor(-1);tvs+=this})
   tx.addView(TextView(a).apply{text="Consola "+(i+1);textSize=13f;setTextColor(0xFF9E9E9E.toInt())})
   r.addView(tx)
   r.setOnClickListener{close{if(on)onCancel() else onPick(i)}};col.addView(r)}
  col.addView(TextView(a).apply{text="Cancelar";textSize=16f;setTextColor(acc);gravity=Gravity.CENTER;setPadding(dp(24),dp(14),dp(24),dp(14));setOnClickListener{close(onCancel)}})
  val box=FrameLayout(a);box.setPadding(dp(12),dp(12),dp(12),dp(12));box.addView(ScrollView(a).apply{addView(col)})
  d.setContentView(box);d.setOnCancelListener{close(onCancel)}
  d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout(Sheet.width(a,(tvs.maxOfOrNull{it.paint.measureText(it.text.toString())}?:0f)+42*dn),-2);setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)}
  d.show()}
}
