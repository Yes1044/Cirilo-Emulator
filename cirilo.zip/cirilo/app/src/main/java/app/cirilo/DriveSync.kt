package app.cirilo
import android.app.Activity
import android.app.job.*
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import org.json.*
import java.io.*
import java.net.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
/** Sincroniza los .sav con Google Drive (carpeta «Cirilo» → «GBA» y «GB y GBC», un archivo por juego). Permiso drive.file: solo ve lo que crea Cirilo.
 *  Por archivo se guarda lo último sincronizado (fecha local|fecha en Drive, preferencias «gdsync»): si solo cambió un lado se copia al otro; si cambiaron los dos gana el más reciente
 *  y el perdedor se guarda antes en saves_backup (nunca se pierde un guardado). Sin internet se programa un trabajo que se ejecuta cuando vuelve la red.
 *  Todo el código de Google va aquí: sin Google Play Services la opción queda desactivada y el resto de la app no cambia. */
object DriveSync{
 enum class Res{OK,NET,AUTH,OFF,ERR}
 private class AuthEx:Exception()
 private class RF(val id:String,val name:String,val lm:Long,val md5:String)
 private const val API="https://www.googleapis.com/drive/v3";private const val UP="https://www.googleapis.com/upload/drive/v3";private const val FOLDER="application/vnd.google-apps.folder"
 /** Motivo del último fallo al conectar (para mostrarlo en pantalla). */
 @Volatile var lastErr=""
 private fun why(e:Throwable):String{lastErr=if(e is ApiException)"código "+e.statusCode+": "+(e.message?:"") else e.javaClass.simpleName+": "+(e.message?:"");return lastErr}
 private val lock=Any();@Volatile private var last=0L
 fun available(c:Context)=try{GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(c)==ConnectionResult.SUCCESS}catch(e:Throwable){false}
 private fun req()=AuthorizationRequest.builder().setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.file"))).build()
 // ---- permiso (desde Ajustes, con pantalla) ----
 /** needUi: Google necesita mostrar su pantalla de permiso; ok: ya concedido (correo o ""); err: falló. */
 fun authorize(a:Activity,needUi:(android.content.IntentSender)->Unit,ok:(String)->Unit,err:()->Unit){
  try{Identity.getAuthorizationClient(a).authorize(req()).addOnSuccessListener{r->
    if(r.hasResolution()){val pi=r.pendingIntent;if(pi!=null)needUi(pi.intentSender) else err()} else ok(r.toGoogleSignInAccount()?.email?:"")}
   .addOnFailureListener{why(it);err()}}catch(e:Throwable){why(e);err()}}
 fun fromIntent(a:Activity,d:Intent?):String?=try{Identity.getAuthorizationClient(a).getAuthorizationResultFromIntent(d).toGoogleSignInAccount()?.email?:""}catch(e:Throwable){why(e);null}
 /** Token en segundo plano; si Google pide pantalla (permiso retirado) → AuthEx. */
 private fun token(c:Context):String{val r=Tasks.await(Identity.getAuthorizationClient(c).authorize(req()));return if(r.hasResolution())throw AuthEx() else r.accessToken?:throw AuthEx()}
 // ---- HTTP ----
 private fun call(tok:String,method:String,url:String,body:ByteArray?=null,ct:String="application/json"):ByteArray{
  val h=URL(url).openConnection() as HttpURLConnection;h.connectTimeout=10000;h.readTimeout=30000;h.setRequestProperty("Authorization","Bearer "+tok)
  if(method=="PATCH"){h.requestMethod="POST";h.setRequestProperty("X-HTTP-Method-Override","PATCH")}else h.requestMethod=method
  if(body!=null){h.doOutput=true;h.setRequestProperty("Content-Type",ct);h.outputStream.use{it.write(body)}}
  val code=h.responseCode;val b=(if(code>=400)h.errorStream else h.inputStream)?.use{it.readBytes()}?:ByteArray(0);h.disconnect()
  if(code==401)throw AuthEx();if(code>=500||code==429)throw IOException("HTTP "+code);if(code>=400)throw IllegalStateException("HTTP "+code+" "+String(b));return b}
 private fun js(b:ByteArray)=JSONObject(String(b))
 private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
 private fun fmt(t:Long):String=SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US).apply{timeZone=TimeZone.getTimeZone("UTC")}.format(Date(t))
 private fun ts(s:String):Long=try{SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US).apply{timeZone=TimeZone.getTimeZone("UTC")}.parse(s)!!.time}catch(e:Exception){try{SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US).apply{timeZone=TimeZone.getTimeZone("UTC")}.parse(s)!!.time}catch(x:Exception){0L}}
 private fun md5(b:ByteArray)=MessageDigest.getInstance("MD5").digest(b).joinToString(""){"%02x".format(it)}
 // ---- Drive ----
 private fun folder(tok:String,name:String,parent:String?):String{
  val q="mimeType='"+FOLDER+"' and name='"+name+"' and trashed=false"+(if(parent!=null)" and '"+parent+"' in parents" else "")
  val a=js(call(tok,"GET",API+"/files?fields=files(id)&q="+enc(q))).getJSONArray("files");if(a.length()>0)return a.getJSONObject(0).getString("id")
  val md=JSONObject().put("name",name).put("mimeType",FOLDER);if(parent!=null)md.put("parents",JSONArray().put(parent))
  return js(call(tok,"POST",API+"/files?fields=id",md.toString().toByteArray())).getString("id")}
 private fun remote(tok:String,fid:String):Map<String,RF>{val m=HashMap<String,RF>();var pt:String?=null
  do{val r=js(call(tok,"GET",API+"/files?pageSize=1000&fields="+enc("nextPageToken,files(id,name,modifiedTime,md5Checksum)")+"&q="+enc("'"+fid+"' in parents and trashed=false")+(if(pt!=null)"&pageToken="+enc(pt) else "")))
   val a=r.getJSONArray("files");for(i in 0 until a.length()){val o=a.getJSONObject(i);val n=o.getString("name");if(!n.endsWith(".sav",true))continue
    val b=n.substringBeforeLast('.');m.putIfAbsent(b.lowercase(),RF(o.getString("id"),b,ts(o.optString("modifiedTime","")),o.optString("md5Checksum","")))}
   pt=r.optString("nextPageToken","").ifEmpty{null}}while(pt!=null);return m}
 private fun download(tok:String,id:String)=call(tok,"GET",API+"/files/"+id+"?alt=media")
 private fun upload(tok:String,fid:String,ex:RF?,name:String,b:ByteArray,lm:Long):RF{val x=put(tok,fid,ex?.id,name+".sav",b,lm,"application/octet-stream",null);return RF(x.id,name,x.lm,x.md5)}
 /** Crea (exId == null) o reemplaza un archivo en la carpeta fid. props = propiedades propias de la app (para los trucos: sha = SHA-1 de la ROM). */
 private fun put(tok:String,fid:String,exId:String?,file:String,b:ByteArray,lm:Long,mime:String,props:JSONObject?):RF{
  val md=JSONObject().put("name",file).put("modifiedTime",fmt(lm));if(exId==null)md.put("parents",JSONArray().put(fid));if(props!=null)md.put("appProperties",props)
  val bd="cirilo"+System.nanoTime();val o=ByteArrayOutputStream()
  o.write(("--"+bd+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+md.toString()+"\r\n--"+bd+"\r\nContent-Type: "+mime+"\r\n\r\n").toByteArray());o.write(b);o.write(("\r\n--"+bd+"--").toByteArray())
  val r=js(call(tok,if(exId!=null)"PATCH" else "POST",UP+"/files"+(if(exId!=null)"/"+exId else "")+"?uploadType=multipart&fields=id,modifiedTime,md5Checksum",o.toByteArray(),"multipart/related; boundary="+bd))
  return RF(r.getString("id"),file,ts(r.getString("modifiedTime")),r.optString("md5Checksum",""))}
 // ---- sincronización ----
 private fun backup(c:Context,s:SaveSync.Src,name:String,b:ByteArray){try{val f=File(c.getExternalFilesDir("saves_backup"),s.key+"/"+name+"."+System.currentTimeMillis()+".sav");f.parentFile?.mkdirs();f.writeBytes(b)}catch(e:Exception){}}
 private fun one(c:Context,tok:String,root:String,s:SaveSync.Src,only:Set<String>?){
  val loc=SaveSync.storeList(c,s)?:return
  val fid=folder(tok,if(s==SaveSync.Src.BOY)"GBA" else "GB y GBC",root);val rem=remote(tok,fid)
  val bp=c.getSharedPreferences("gdsync",0);val done=HashMap<String,Long>() // clave → fecha en Drive tras sincronizar
  for(k in (loc.keys+rem.keys)){if(only!=null&&k !in only)continue
   val l=loc[k];val r=rem[k];val name=l?.name?:r!!.name;val bs=bp.getString(s.key+":"+k,null)?.split("|")
   val b0=bs?.getOrNull(0)?.toLongOrNull();val b1=bs?.getOrNull(1)?.toLongOrNull()
   var act=0 // 1 subir, 2 bajar, 3 conflicto
   if(l!=null&&r==null)act=1
   else if(l==null&&r!=null){if(SaveSync.canStore(c,s,k))act=2}
   else if(l!=null&&r!=null){val lc=b0==null||b0!=l.lm;val rc=b1==null||b1!=r.lm
    if(lc||rc){val lb=SaveSync.storeRead(c,s,k,name)
     if(lb!=null&&r.md5.isNotEmpty()&&md5(lb)==r.md5)done[k]=r.lm // mismo contenido
     else act=if(lc&&!rc)1 else if(!lc&&rc)2 else 3}}
   if(act==3)act=if(l!!.lm>=r!!.lm)1 else 2
   if(act==1){val lb=SaveSync.storeRead(c,s,k,name)?:continue;if(lb.isEmpty())continue
    if(r!=null&&bs!=null&&b0!=null&&b1!=null&&r.lm!=b1)backup(c,s,name,download(tok,r.id)) // Drive también cambió: se conserva su versión
    else if(r!=null&&bs==null)backup(c,s,name,download(tok,r.id))
    done[k]=upload(tok,fid,r,name,lb,l!!.lm).lm}
   else if(act==2){val rb=download(tok,r!!.id);if(rb.isEmpty())continue
    if(l!=null)SaveSync.storeRead(c,s,k,name)?.let{if(!it.contentEquals(rb)&&(bs==null||b0!=l.lm))backup(c,s,name,it)}
    if(SaveSync.storeWrite(c,s,k,name,rb))done[k]=r.lm}}
  if(done.isNotEmpty()){val fresh=SaveSync.storeList(c,s)?:return;val ed=bp.edit()
   done.forEach{(k,rl)->ed.putString(s.key+":"+k,(fresh[k]?.lm?:0L).toString()+"|"+rl)};ed.apply()}}
 // ---- trucos: Cirilo/Trucos, un «<juego>.trucos.json» por ROM. La ROM se identifica por su SHA-1 (propiedad de archivo «sha»), no por el nombre. Mismas reglas de conflicto que los guardados; el perdedor va a cheats_backup. ----
 private class RC(val id:String,val lm:Long,val md5:String)
 private fun remoteCheats(tok:String,fid:String):Map<String,RC>{val m=HashMap<String,RC>();var pt:String?=null
  do{val r=js(call(tok,"GET",API+"/files?pageSize=1000&fields="+enc("nextPageToken,files(id,modifiedTime,md5Checksum,appProperties)")+"&q="+enc("'"+fid+"' in parents and trashed=false")+(if(pt!=null)"&pageToken="+enc(pt) else "")))
   val a=r.getJSONArray("files");for(i in 0 until a.length()){val o=a.getJSONObject(i);val sha=o.optJSONObject("appProperties")?.optString("sha","")?:"";if(sha.isEmpty())continue
    m.putIfAbsent(sha,RC(o.getString("id"),ts(o.optString("modifiedTime","")),o.optString("md5Checksum","")))}
   pt=r.optString("nextPageToken","").ifEmpty{null}}while(pt!=null);return m}
 private fun backupCheats(c:Context,sha:String,b:ByteArray){try{val f=File(c.getExternalFilesDir("cheats_backup"),sha+"."+System.currentTimeMillis()+".json");f.parentFile?.mkdirs();f.writeBytes(b)}catch(e:Exception){}}
 /** ids = juegos (SHA-1) a sincronizar; null = todos los locales y los de Drive. */
 private fun cheats(c:Context,tok:String,root:String,ids:Set<String>?){
  val fid=folder(tok,"Trucos",root);val rem=remoteCheats(tok,fid);val bp=c.getSharedPreferences("gdsync",0);val ed=bp.edit()
  for(id in (CheatStore.ids(c)+rem.keys).toSet()){if(ids!=null&&id !in ids)continue
   val hasL=CheatStore.has(c,id);val lm=CheatStore.stamp(c,id);val r=rem[id];val key="cheats:"+id
   val bs=bp.getString(key,null)?.split("|");val b0=bs?.getOrNull(0)?.toLongOrNull();val b1=bs?.getOrNull(1)?.toLongOrNull()
   val lj=if(hasL)CheatStore.pack(c,id) else null
   var act=0 // 1 subir, 2 bajar
   if(lj!=null&&r==null){act=1}
   else if(lj==null&&r!=null){act=2}
   else if(lj!=null&&r!=null){val lc=b0==null||b0!=lm;val rc=b1==null||b1!=r.lm
    if(lc||rc){if(r.md5.isNotEmpty()&&md5(lj.toByteArray())==r.md5)ed.putString(key,lm.toString()+"|"+r.lm) // mismo contenido
     else act=if(lc&&!rc)1 else if(!lc&&rc)2 else if(lm>=r.lm)1 else 2}}
   if(act==1&&lj!=null){
    if(r==null&&CheatStore.unpack(lj)?.cheats?.isEmpty()!=false)continue // un conjunto vacío que nunca se subió no se sube
    if(r!=null&&(bs==null||(b1!=null&&r.lm!=b1)))backupCheats(c,id,download(tok,r.id)) // en Drive hay algo que no es lo último sincronizado: se conserva
    val t=CheatStore.title(c,id).replace(Regex("[\\\\/:*?\"<>|]"),"_").trim().ifEmpty{id.take(8)}
    val up=put(tok,fid,r?.id,t+".trucos.json",lj.toByteArray(),lm,"application/json",JSONObject().put("sha",id))
    ed.putString(key,lm.toString()+"|"+up.lm)}
   else if(act==2&&r!=null){val rb=download(tok,r.id);if(rb.isEmpty())continue
    if(lj!=null&&(bs==null||b0!=lm))backupCheats(c,id,lj.toByteArray())
    if(CheatStore.restore(c,String(rb),r.lm))ed.putString(key,r.lm.toString()+"|"+r.lm)}}
  ed.apply()}
 /** only = claves (nombre en minúsculas) a sincronizar; src = solo esa app. Llamar fuera del hilo principal. */
 fun syncNow(c:Context,only:Set<String>?=null,src:SaveSync.Src?=null,cheatIds:Set<String>?=null,saves:Boolean=true):Res=synchronized(lock){
  val p=c.getSharedPreferences("c",0);if(!p.getBoolean("gd",false)||!available(c))return Res.OFF
  try{val tok=token(c);val root=folder(tok,"Cirilo",null)
   if(saves)for(s in SaveSync.Src.values()){if(src==null||s==src)one(c,tok,root,s,only)}
   // trucos: todos en la sincronización completa; solo los de ese juego si se indica cheatIds
   if(p.getBoolean("gd_cheats",true)&&(cheatIds!=null||(only==null&&saves)))try{cheats(c,tok,root,cheatIds)}catch(e:AuthEx){throw e}catch(e:IOException){throw e}catch(e:Exception){android.util.Log.w("DriveSync",e)}
   p.edit().putBoolean("gd_auth",false).apply();cancel(c);Res.OK}
  catch(e:AuthEx){p.edit().putBoolean("gd_auth",true).apply();Res.AUTH}
  catch(e:IOException){schedule(c);Res.NET}
  catch(e:Exception){android.util.Log.w("DriveSync",e);Res.ERR}}
 /** En segundo plano. Las sincronizaciones completas se limitan a una cada 20 s. */
 fun async(c:Context,only:Set<String>?=null,src:SaveSync.Src?=null,cheatIds:Set<String>?=null,saves:Boolean=true){val a=c.applicationContext
  if(only==null&&cheatIds==null){val n=System.currentTimeMillis();if(n-last<20000)return;last=n}
  if(!a.getSharedPreferences("c",0).getBoolean("gd",false))return
  Thread{syncNow(a,only,src,cheatIds,saves)}.start()}
 // ---- cola sin internet: trabajo del sistema que espera a que haya red (sobrevive a reinicios) ----
 private const val JOB=4242
 fun schedule(c:Context){try{(c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).schedule(JobInfo.Builder(JOB,ComponentName(c,SyncJob::class.java)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).build())}catch(e:Exception){}}
 fun cancel(c:Context){try{(c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(JOB)}catch(e:Exception){}}
}
class SyncJob:JobService(){
 override fun onStartJob(p:JobParameters):Boolean{val c=applicationContext;Thread{val r=DriveSync.syncNow(c);jobFinished(p,r==DriveSync.Res.NET)}.start();return true}
 override fun onStopJob(p:JobParameters)=true
}
