package app.cirilo
import android.media.*
import java.io.File
/** Bucle de emulación sincronizado por el audio (la escritura bloqueante marca el ritmo). */
class Emu{
 @Volatile private var on=false;private var th:Thread?=null;private var sav:File?=null;private var sr=32768;private var loaded=false
 fun start(rom:ByteArray,name:String,save:File,cheats:List<String> = emptyList()){
  pause();if(loaded)Native.unload();loaded=Native.load(rom,name);if(!loaded)return
  sav=save;if(save.exists())Native.setSave(save.readBytes());Native.cheats(cheats.toTypedArray());sr=Native.info()[0].toInt();resume()}
 fun resume(){
  if(!loaded||on)return;on=true
  th=Thread{
   val cm=AudioFormat.CHANNEL_OUT_STEREO;val en=AudioFormat.ENCODING_PCM_16BIT
   val at=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
    .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(en).setChannelMask(cm).build())
    .setBufferSizeInBytes(AudioTrack.getMinBufferSize(sr,cm,en)*2).build()
   at.play();val b=ShortArray(16384)
   while(on){Native.run();val n=Native.audio(b);if(n>0)at.write(b,0,n)}
   at.stop();at.release()}.also{it.start()}}
 fun pause(){on=false;th?.join();th=null;if(loaded)Native.getSave()?.let{sav?.writeBytes(it)}}
}
