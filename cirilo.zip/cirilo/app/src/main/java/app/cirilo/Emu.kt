package app.cirilo
import android.media.*
import android.os.Process
import java.io.File
import java.util.concurrent.locks.LockSupport
/** Bucle de emulación sincronizado por el audio. Salto de fotogramas automático (hasta 3) y avance rápido (x4, sin sonido). */
class Emu{
 @Volatile private var on=false;private var th:Thread?=null;private var sav:File?=null;private var sr=32768;private var loaded=false
 private val q=java.util.concurrent.ConcurrentLinkedQueue<()->Unit>();fun post(f:()->Unit){q.add(f)}
 @Volatile var fps=0;@Volatile var ms=0.0;@Volatile var skip=0;@Volatile var ff=false;@Volatile var maxSkip=2;@Volatile var rate=48000;@Volatile var vol=100;var onFrame:(()->Unit)?=null
 @Synchronized fun start(rom:ByteArray,name:String,save:File,cheats:List<String> = emptyList()):Boolean{
  pause();if(loaded)Native.unload();loaded=Native.load(rom,name);if(!loaded)return false
  sav=save;if(save.exists())Native.setSave(save.readBytes());Native.cheats(cheats.toTypedArray());sr=Native.info()[0].toInt();resume();return true}
 @Synchronized fun stop(){pause();if(loaded){Native.unload();loaded=false}}
 @Synchronized fun resume(){
  if(!loaded||on)return;on=true
  th=Thread{
   Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);val R=rate;val g=vol/100f
   val cm=AudioFormat.CHANNEL_OUT_STEREO;val en=AudioFormat.ENCODING_PCM_16BIT
   val at=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
    .setAudioFormat(AudioFormat.Builder().setSampleRate(R).setEncoding(en).setChannelMask(cm).build())
    .setBufferSizeInBytes(maxOf(AudioTrack.getMinBufferSize(R,cm,en)*2,R/10*4)).build()
   at.play();val b=ShortArray(16384);val target=1e9/Native.info()[1]
   val per=R/Native.info()[1];var carry=0.0;val ob=ShortArray(4096) // el núcleo cambia su ritmo de audio según el juego: cada fotograma se reajusta a 48000 Hz fijos
   var s=0;Native.setSkip(0);skip=0;var acc=0L;var cnt=0;var n=0;var t0=System.nanoTime()
   while(on){
    val sp=if(ff)4 else 1
    while(true){(q.poll()?:break)()};val a=System.nanoTime();Native.run();val d=System.nanoTime()-a;acc+=d;cnt++;n++
    val k=Native.audio(b)
    if(!ff){val nIn=k/2;carry+=per;val nOut=carry.toInt();carry-=nOut
     if(nIn<2)java.util.Arrays.fill(ob,0,nOut*2,0.toShort()) else{val st=(nIn-1).toDouble()/nOut
      for(i in 0 until nOut){val p=i*st;val j=p.toInt();val f=(p-j).toFloat();val j2=minOf(j+1,nIn-1)
       ob[2*i]=((b[2*j]+(b[2*j2]-b[2*j])*f)*g).toInt().toShort();ob[2*i+1]=((b[2*j+1]+(b[2*j2+1]-b[2*j+1])*f)*g).toInt().toShort()}}
     at.write(ob,0,nOut*2)}else{val w=(target/sp).toLong()-d;if(w>0)LockSupport.parkNanos(w)}
    onFrame?.invoke()
    if(cnt==30){val avg=acc/cnt;acc=0;cnt=0;val tg=target/sp
     if(avg>tg*0.95&&s<maxSkip){s++;Native.setSkip(s)}else if(avg<tg*0.5&&s>0){s--;Native.setSkip(s)};skip=s;ms=avg/1e6}
    val t=System.nanoTime();if(t-t0>=1_000_000_000L){fps=n;n=0;t0=t}}
   at.stop();at.release()}.also{it.start()}}
 @Synchronized fun pause(){on=false;th?.join();th=null;if(loaded)Native.getSave()?.let{try{sav?.writeBytes(it)}catch(e:Exception){}}}
}
