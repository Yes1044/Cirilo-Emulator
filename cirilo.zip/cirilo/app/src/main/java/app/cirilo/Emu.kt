package app.cirilo
import android.media.*
import android.os.Build
import android.os.Process
import java.io.File
import java.util.concurrent.locks.LockSupport
/** Bucle de emulación con velocidad fija: manda un reloj monótono (System.nanoTime), no el audio. Cada fotograma dura exactamente 1/fps del núcleo (59,7275 en GB, GBC y GBA: 4194304/70224 y 16777216/280896) dividido por la velocidad del avance rápido
 *  (×8 = 477,82 fps), y nunca se recupera el tiempo perdido (si un fotograma llega tarde se reanuda el reloj, no se corre para alcanzarlo). Si el móvil no da la velocidad pedida, va lo más rápido que puede.
 *  El audio se adapta al reloj: cada fotograma aporta per/sp muestras, corregidas ±0,5 % según lo que quede en el búfer, así que la deriva entre relojes se absorbe en el sonido y no en los fps.
 *  El salto de fotogramas (auto, hasta «Saltos de fotogramas máximos») solo omite el dibujo de algunos fotogramas: la emulación y el ritmo no cambian. */
class Emu{
 @Volatile private var on=false;private var th:Thread?=null;private var sav:File?=null;private var sr=32768;private var loaded=false
 private val q=java.util.concurrent.ConcurrentLinkedQueue<()->Unit>();fun post(f:()->Unit){q.add(f)}
 @Volatile var fps=0.0;@Volatile var ms=0.0;@Volatile var skip=0;@Volatile var ff=false;@Volatile var ffSpeed=4.0;@Volatile var maxSkip=2;@Volatile var rate=48000;@Volatile var vol=100;var onFrame:(()->Unit)?=null
 @Synchronized fun start(rom:ByteArray,name:String,save:File ):Boolean{
  pause();if(loaded)Native.unload();loaded=Native.load(rom,name);if(!loaded)return false
  sav=save;if(save.exists())Native.setSave(save.readBytes());sr=Native.info()[0].toInt();resume();return true}
 /** Guarda el estado actual en f (el hilo debe estar pausado). */
 @Synchronized fun snap(f:File){if(!loaded)return;Native.saveState()?.let{try{f.writeBytes(it)}catch(e:Exception){}}}
 @Synchronized fun stop(){pause();if(loaded){Native.unload();loaded=false}}
 @Synchronized fun resume(){
  if(!loaded||on)return;on=true
  th=Thread{
   Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);val R=rate;val g=vol/100f
   val cm=AudioFormat.CHANNEL_OUT_STEREO;val en=AudioFormat.ENCODING_PCM_16BIT
   val at=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
    .setAudioFormat(AudioFormat.Builder().setSampleRate(R).setEncoding(en).setChannelMask(cm).build())
    .setBufferSizeInBytes(maxOf(AudioTrack.getMinBufferSize(R,cm,en)*2,R/10*4)).build()
   at.play();val b=ShortArray(16384);val target=1e9/Native.info()[1] // duración de un fotograma a velocidad 1 (59,7275 fps)
   val per=R/Native.info()[1];var carry=0.0;val ob=ShortArray(16384) // el núcleo cambia su ritmo de audio según el juego: cada fotograma se reajusta a 48000 Hz fijos
   // colchón de audio: ~3 fotogramas de silencio de salida; después el reloj lo mantiene y la corrección de abajo absorbe la deriva
   val buf=per*3;var written=0L;run{val z=buf.toInt();at.write(ShortArray(z*2),0,z*2);written+=z}
   var adj=1.0;var lastU=0;var lastSp=1.0;var next=System.nanoTime()
   var s=0;Native.setSkip(0);skip=0;var acc=0L;var cnt=0;var n=0;var t0=System.nanoTime()
   while(on){
    val sp=if(ff)ffSpeed else 1.0
    if(sp!=lastSp){lastSp=sp;next=System.nanoTime()} // al cambiar de velocidad se reinicia el reloj
    while(true){(q.poll()?:break)()};val a=System.nanoTime();Native.run();val d=System.nanoTime()-a;acc+=d;cnt++;n++
    val k=Native.audio(b)
    // el audio suena siempre, también en avance rápido/lento: cada fotograma aporta per/sp muestras (a más velocidad, menos; el tono sube o baja igual que la velocidad). El ritmo del bucle lo marca el reloj (ver arriba); escribir en AudioTrack solo frena si el búfer se llena.
    val nIn=k/2;carry+=per/sp*adj;val nOut=carry.toInt();carry-=nOut
    if(nOut>0){
     if(nIn<2)java.util.Arrays.fill(ob,0,nOut*2,0.toShort())
     else if(nIn>nOut){val st=nIn.toDouble()/nOut // acelerado: se promedia cada tramo para no meter ruido (aliasing)
      for(i in 0 until nOut){val lo=(i*st).toInt();val hi=minOf(maxOf(((i+1)*st).toInt(),lo+1),nIn);var sl=0;var sr2=0;for(j in lo until hi){sl+=b[2*j];sr2+=b[2*j+1]};val cn=hi-lo
       ob[2*i]=(sl*g/cn).toInt().toShort();ob[2*i+1]=(sr2*g/cn).toInt().toShort()}}
     else{val st=(nIn-1).toDouble()/nOut
      for(i in 0 until nOut){val p=i*st;val j=p.toInt();val f=(p-j).toFloat();val j2=minOf(j+1,nIn-1)
       ob[2*i]=((b[2*j]+(b[2*j2]-b[2*j])*f)*g).toInt().toShort();ob[2*i+1]=((b[2*j+1]+(b[2*j2+1]-b[2*j+1])*f)*g).toInt().toShort()}}
     at.write(ob,0,nOut*2);written+=nOut}
    if(n%4==0){val head=at.playbackHeadPosition.toLong() and 0xFFFFFFFFL;val fill=((written-head)-buf)/buf // >0: sobra colchón
     adj=1.0-0.005*fill.coerceIn(-1.0,1.0)
     if(Build.VERSION.SDK_INT>=24){val u=at.underrunCount;if(u!=lastU){lastU=u;val z=(per*2).toInt();at.write(ShortArray(z*2),0,z*2);written+=z}}} // si el audio llegó a cortarse, se rehace el colchón con silencio (sin correr más)
    onFrame?.invoke()
    if(cnt==30){val avg=acc/cnt;acc=0;cnt=0;val tg=target/sp
     if(avg>tg*0.95&&s<maxSkip){s++;Native.setSkip(s)}else if(avg<tg*0.5&&s>0){s--;Native.setSkip(s)};skip=s;ms=avg/1e6}
    val t=System.nanoTime();if(t-t0>=1_000_000_000L){fps=n*1e9/(t-t0);n=0;t0=t}
    next+=(target/sp).toLong();var w=next-System.nanoTime() // ritmo fijo: dormir hasta el instante exacto del siguiente fotograma
    if(w<0)next=System.nanoTime() else while(w>0){LockSupport.parkNanos(w);w=next-System.nanoTime()}}
   at.stop();at.release()}.also{it.start()}}
 @Synchronized fun pause(){on=false;th?.join();th=null;if(loaded)Native.getSave()?.let{try{sav?.writeBytes(it)}catch(e:Exception){}}}
}
