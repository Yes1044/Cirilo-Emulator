package app.cirilo
import android.media.*
import android.os.Process
import java.io.File
/** Bucle de emulación sincronizado por el audio. Si el celular va justo, sube solo el salto de fotogramas (hasta 3). */
class Emu{
 @Volatile private var on=false;private var th:Thread?=null;private var sav:File?=null;private var sr=32768;private var loaded=false
 @Volatile var fps=0;@Volatile var skip=0;var onFrame:(()->Unit)?=null
 @Synchronized fun start(rom:ByteArray,name:String,save:File,cheats:List<String> = emptyList()){
  pause();if(loaded)Native.unload();loaded=Native.load(rom,name);if(!loaded)return
  sav=save;if(save.exists())Native.setSave(save.readBytes());Native.cheats(cheats.toTypedArray());sr=Native.info()[0].toInt();resume()}
 @Synchronized fun resume(){
  if(!loaded||on)return;on=true
  th=Thread{
   Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
   val cm=AudioFormat.CHANNEL_OUT_STEREO;val en=AudioFormat.ENCODING_PCM_16BIT
   val at=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
    .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(en).setChannelMask(cm).build())
    .setBufferSizeInBytes(maxOf(AudioTrack.getMinBufferSize(sr,cm,en)*2,sr/10*4)).build()
   at.play();val b=ShortArray(16384);val target=1e9/Native.info()[1]
   var s=0;Native.setSkip(0);skip=0;var acc=0L;var cnt=0;var n=0;var t0=System.nanoTime()
   while(on){
    val a=System.nanoTime();Native.run();acc+=System.nanoTime()-a;cnt++;n++
    val k=Native.audio(b);if(k>0)at.write(b,0,k);onFrame?.invoke()
    if(cnt==30){val avg=acc/cnt;acc=0;cnt=0 // muy lento: salta más; muy holgado: salta menos
     if(avg>target*0.95&&s<3){s++;Native.setSkip(s)}else if(avg<target*0.5&&s>0){s--;Native.setSkip(s)};skip=s}
    val t=System.nanoTime();if(t-t0>=1_000_000_000L){fps=n;n=0;t0=t}}
   at.stop();at.release()}.also{it.start()}}
 @Synchronized fun pause(){on=false;th?.join();th=null;if(loaded)Native.getSave()?.let{sav?.writeBytes(it)}}
}
