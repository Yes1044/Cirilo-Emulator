package app.cirilo
import android.media.*
import android.os.Build
import android.os.Process
import java.io.File
import java.util.concurrent.locks.LockSupport
/** Bucle de emulación con velocidad fija: manda un reloj monótono (System.nanoTime), no el audio. Cada fotograma dura exactamente 1/fps del núcleo (59,7275 en GB, GBC y GBA: 4194304/70224 y 16777216/280896) dividido por la velocidad del avance rápido
 *  (×8 = 477,82 fps), y nunca se recupera el tiempo perdido (si un fotograma llega tarde se reanuda el reloj, no se corre para alcanzarlo). Si el móvil no da la velocidad pedida, va lo más rápido que puede.
 *  El audio se adapta al reloj: cada fotograma aporta per/sp muestras, corregidas ±0,5 % según lo que quede en el búfer, así que la deriva entre relojes se absorbe en el sonido y no en los fps.
 *  El salto de fotogramas (auto, hasta «Saltos de fotogramas máximos») solo omite el dibujo de algunos fotogramas: la emulación y el ritmo no cambian. */
class Emu(val inst:Int=0){
 @Volatile private var on=false;private var th:Thread?=null;private var sav:File?=null;private var sr=32768;private var loaded=false
 private val q=java.util.concurrent.ConcurrentLinkedQueue<()->Unit>();fun post(f:()->Unit){q.add(f)}
 @Volatile var aud="";@Volatile var prof="";@Volatile var fps=0.0;@Volatile var ms=0.0;@Volatile var skip=0;@Volatile var ff=false;@Volatile var ffSpeed=4.0;@Volatile var maxSkip=2;@Volatile var dynSkip=true;@Volatile var rate=48000;@Volatile var vol=100;var onFrame:(()->Unit)?=null
 /** run=false: carga la ROM pero no arranca el hilo (Link local: primero se conecta el cable y luego se reanudan las dos consolas, cada una en su propio hilo). */
 @Synchronized fun start(rom:ByteArray,name:String,save:File,run:Boolean=true):Boolean{
  pause();if(loaded)Native.unload(inst);loaded=Native.load(inst,rom,name);if(!loaded)return false
  sav=save;if(save.exists())Native.setSave(inst,save.readBytes());sr=Native.info(inst)[0].toInt();if(run)resume();return true}
 /** Guarda el estado actual en f (el hilo debe estar pausado). */
 @Synchronized fun snap(f:File){if(!loaded)return;Native.saveState(inst)?.let{try{f.writeBytes(it)}catch(e:Exception){}}}
 @Synchronized fun stop(){pause();if(loaded){Native.unload(inst);loaded=false}}
 /** Primera fase de una pausa: pide al hilo que termine (sin esperarlo). Con Link local se piden las dos y luego se llama a pause() en cada una, para que ninguna espere a la otra. */
 fun halt(){on=false}
 @Synchronized fun resume(){
  if(!loaded||on)return;on=true // cada consola corre en su propio hilo, también con cable (el cable las sincroniza durmiendo a la que va adelantada)
  th=Thread{
   Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);val R=rate;val g=vol/100f
   val cm=AudioFormat.CHANNEL_OUT_STEREO;val en=AudioFormat.ENCODING_PCM_16BIT
   val b=ShortArray(16384);val target=1e9/Native.info(inst)[1] // duración de un fotograma a velocidad 1 (59,7275 fps)
   val per=R/Native.info(inst)[1];var carry=0.0;val ob=ShortArray(16384) // el núcleo cambia su ritmo de audio según el juego: cada fotograma se reajusta a 48000 Hz fijos
   // colchón de audio: ~3 fotogramas de silencio de salida; después el reloj lo mantiene y la corrección de abajo absorbe la deriva
   val buf=per*3;var written=0L;var at:AudioTrack?=null;var lastU=0
   // solo suena la consola que se está viendo (Native.act): la otra (Link local) corre igual, pero su audio se descarta
   fun open(){val a=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).build())
    .setAudioFormat(AudioFormat.Builder().setSampleRate(R).setEncoding(en).setChannelMask(cm).build())
    .setBufferSizeInBytes(maxOf(AudioTrack.getMinBufferSize(R,cm,en)*2,R/10*4)).build()
    a.play();val z=buf.toInt();a.write(ShortArray(z*2),0,z*2);written=z.toLong();lastU=0;at=a}
   var adj=1.0;var lastSp=1.0;var next=System.nanoTime()
   // Con cable cada vuelta entrega un número de muestras distinto (la consola va adelantada o no respecto al fin de la vuelta): se meten en un colchón (ring) y se consumen a ritmo constante, con una corrección lenta (±5%) que mantiene el nivel
   val RN=16384;val RM=RN-1;val ring=ShortArray(RN*2);var wc=0L;var rp=0.0;var emaIn=0.0;var lastAct=-1;var amin=1 shl 30;var amax=0;var asum=0L;var acnt=0
   var s=0;Native.setSkip(inst,0);skip=0;var ap0=-1;val HID=9 // HID: la consola que no se ve apenas dibuja (1 de cada 10 fotogramas): no cambia la emulación ni el cable, solo ahorra el vídeo
   var acc=0L;var cnt=0;var n=0;var t0=System.nanoTime();var pw=t0;var pA=0L;var pM=0L;var pG=0L;var coreMask=0 // pw/pA/pM/pG: medidor de la parte de Kotlin del bucle (ver «prof»)
   while(on){
    val sp=if(ff)ffSpeed else 1.0
    // Salto dinámico: con avance rápido el tope de saltos sube con la velocidad (×8 → 7, ×16 → 15: se dibuja ~1 de cada «velocidad» fotogramas, o sea ~60 cuadros por segundo reales). Desactivado o a velocidad normal/lenta: vale «Saltos de fotogramas máximos».
    val lim=if(dynSkip&&sp>1.0)maxOf(maxSkip,Math.ceil(sp).toInt()-1) else maxSkip;if(s>lim){s=lim;skip=s}
    if(sp!=lastSp){lastSp=sp;next=System.nanoTime()} // al cambiar de velocidad se reinicia el reloj
    while(true){(q.poll()?:break)()};val a=System.nanoTime();Native.run(inst);val L=Native.lnk;val t1=System.nanoTime();coreMask=coreMask or (1 shl (Native.cpu() and 31));val d=t1-a;acc+=d;cnt++;n++
    // cada hilo recoge el audio de su consola; solo suena la que se ve (Native.act) y el de la otra se descarta
    val k=Native.audio(inst,b)
    val ac=Native.act==inst
    if(ac&&at==null){open();rp=wc.toDouble()} else if(!ac&&at!=null){at?.stop();at?.release();at=null}
    val tr=at;val t2=System.nanoTime();pA+=t2-t1
    // el audio suena siempre, también en avance rápido/lento: cada fotograma aporta per/sp muestras (a más velocidad, menos; el tono sube o baja igual que la velocidad). El ritmo del bucle lo marca el reloj (ver arriba); escribir en AudioTrack solo frena si el búfer se llena.
    val nIn=k/2;carry+=per/sp*adj;val nOut=carry.toInt();carry-=nOut
    if(L&&tr!=null){
     if(Native.act!=lastAct){lastAct=Native.act;rp=wc.toDouble()} // al cambiar de consola se descarta el colchón de la otra
     for(i in 0 until nIn){val ix=((wc and RM.toLong()).toInt())*2;ring[ix]=b[2*i];ring[ix+1]=b[2*i+1];wc++}
     // la tasa de audio del núcleo no es fija (mGBA la cambia según el juego: 32768, 65536…): se mide como media móvil lenta de lo que entrega por vuelta
     if(nIn>0)emaIn=if(emaIn==0.0)nIn.toDouble() else emaIn+(nIn-emaIn)*0.02
     val nom=maxOf(emaIn,1.0);val lvl=wc-rp
     if(lvl>RN-4)rp=wc-nom // desbordado: se resincroniza
     val st=(nom/(per/sp))*(1.0+(((lvl-nom)/nom)*0.05).coerceIn(-0.05,0.05)) // muestras de entrada por muestra de salida
     for(i in 0 until nOut){
      if(rp>wc-1.0)rp=maxOf(wc-1.0,0.0)
      val j=rp.toLong();val f=(rp-j).toFloat();val a0=((j and RM.toLong()).toInt())*2;val a1=(((j+1).coerceAtMost(wc-1) and RM.toLong()).toInt())*2
      ob[2*i]=((ring[a0]+(ring[a1]-ring[a0])*f)*g).toInt().toShort();ob[2*i+1]=((ring[a0+1]+(ring[a1+1]-ring[a0+1])*f)*g).toInt().toShort()
      rp+=st}
     if(nOut>0){tr.write(ob,0,nOut*2);written+=nOut}
     asum+=nIn;acnt++;if(nIn<amin)amin=nIn;if(nIn>amax)amax=nIn
     if(acnt==30){aud="a"+(asum/acnt)+" "+amin+"-"+amax+" n"+(lvl.toInt());asum=0;acnt=0;amin=1 shl 30;amax=0}
    } else if(tr!=null&&nOut>0){
     if(nIn<2)java.util.Arrays.fill(ob,0,nOut*2,0.toShort())
     else if(nIn>nOut){val st=nIn.toDouble()/nOut // acelerado: se promedia cada tramo para no meter ruido (aliasing)
      for(i in 0 until nOut){val lo=(i*st).toInt();val hi=minOf(maxOf(((i+1)*st).toInt(),lo+1),nIn);var sl=0;var sr2=0;for(j in lo until hi){sl+=b[2*j];sr2+=b[2*j+1]};val cn=hi-lo
       ob[2*i]=(sl*g/cn).toInt().toShort();ob[2*i+1]=(sr2*g/cn).toInt().toShort()}}
     else{val st=(nIn-1).toDouble()/nOut
      for(i in 0 until nOut){val p=i*st;val j=p.toInt();val f=(p-j).toFloat();val j2=minOf(j+1,nIn-1)
       ob[2*i]=((b[2*j]+(b[2*j2]-b[2*j])*f)*g).toInt().toShort();ob[2*i+1]=((b[2*j+1]+(b[2*j2+1]-b[2*j+1])*f)*g).toInt().toShort()}}
     tr.write(ob,0,nOut*2);written+=nOut}
    if(tr!=null&&n%4==0){val head=tr.playbackHeadPosition.toLong() and 0xFFFFFFFFL;val fill=((written-head)-buf)/buf // >0: sobra colchón
     adj=1.0-0.005*fill.coerceIn(-1.0,1.0)
     if(Build.VERSION.SDK_INT>=24){val u=tr.underrunCount;if(u!=lastU){lastU=u;val z=(per*2).toInt();tr.write(ShortArray(z*2),0,z*2);written+=z}}} // si el audio llegó a cortarse, se rehace el colchón con silencio (sin correr más)
    val t3=System.nanoTime();pM+=t3-t2;onFrame?.invoke();pG+=System.nanoTime()-t3
    if(cnt==30){val nw=System.nanoTime();prof="lap%.2f run%.2f aud%.2f mix%.2f gl%.2f core%s".format((nw-pw)/30e6,acc/30e6,pA/30e6,pM/30e6,pG/30e6,(0..31).filter{coreMask and (1 shl it)!=0}.joinToString(","));coreMask=0;pw=nw;pA=0;pM=0;pG=0;val avg=acc/cnt;acc=0;cnt=0;val tg=target/sp
     if(avg>tg*0.95&&s<lim){s=minOf(lim,s+(if(lim>maxSkip)1+(s shr 1) else 1))}else if(avg<tg*0.5&&s>0){s--};skip=s;ms=avg/1e6}
    val want=if(L&&Native.act!=inst)HID else s;if(want!=ap0){Native.setSkip(inst,want);ap0=want} // con cable, la consola que no se ve dibuja poco
    val t=System.nanoTime();if(t-t0>=1_000_000_000L){fps=n*1e9/(t-t0);n=0;t0=t}
    next+=(target/sp).toLong();var w=next-System.nanoTime() // ritmo fijo: dormir hasta el instante exacto del siguiente fotograma
    if(w<0)next=System.nanoTime() else while(w>0){LockSupport.parkNanos(w);w=next-System.nanoTime()}}
   at?.stop();at?.release()}.also{it.start()}}
 @Synchronized fun pause(){on=false;th?.join();th=null;if(loaded)Native.getSave(inst)?.let{try{sav?.writeBytes(it)}catch(e:Exception){}}}
}
