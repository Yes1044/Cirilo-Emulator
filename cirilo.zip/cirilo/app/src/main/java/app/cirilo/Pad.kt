package app.cirilo
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import kotlin.math.*
/** Dibujo de cada tipo de control (lo usan el juego, el editor y los iconos del catálogo). */
object CtlDraw{
 private val p=Paint(Paint.ANTI_ALIAS_FLAG)
 val ACT=setOf("qload","qsave","ff","shot")
 fun pill(t:String)=t=="start"||t=="select"||t=="l"||t=="r"||t=="turbol"||t=="turbor"
 fun label(t:String)=when(t){"a","turboa"->"A";"b","turbob"->"B";"ab"->"AB";"lr"->"LR";"la"->"LA";"lb"->"LB";"ra"->"RA";"rb"->"RB";"l","turbol"->"L";"r","turbor"->"R"
  "start"->"START";"select"->"SEL";"up"->"^";"down"->"v";"left"->"<";"right"->">";"qload"->"QL";"qsave"->"QS";"ff"->"FF";"shot"->"SS";else->""}
 private fun al(c:Int,a:Int)=(c and 0xFFFFFF) or ((((c ushr 24)*a)/255) shl 24)
 fun draw(cv:Canvas,t:String,cx:Float,cy:Float,r:Float,rot:Float,a:Int,st:Int,down:Boolean){
  cv.save();cv.rotate(rot,cx,cy)
  val col=if(t.startsWith("turbo"))0xFFE53935.toInt() else if(t in ACT)0xFF80CBC4.toInt() else -1
  val fill=if(down)0x77FFFFFF else if(st==1)0x44FFFFFF else 0x22000000
  p.strokeWidth=max(2f,r*.09f);val sh=Path()
  if(t=="dpad"){val w=r*.36f;sh.addRoundRect(RectF(cx-r,cy-w,cx+r,cy+w),w*.6f,w*.6f,Path.Direction.CW)
   val v=Path();v.addRoundRect(RectF(cx-w,cy-r,cx+w,cy+r),w*.6f,w*.6f,Path.Direction.CW);sh.op(v,Path.Op.UNION)}
  else if(pill(t))sh.addRoundRect(RectF(cx-1.3f*r,cy-.55f*r,cx+1.3f*r,cy+.55f*r),.55f*r,.55f*r,Path.Direction.CW) else sh.addCircle(cx,cy,r,Path.Direction.CW)
  p.style=Paint.Style.FILL;p.color=al(fill,a);cv.drawPath(sh,p)
  p.style=Paint.Style.STROKE;p.color=al(col,a);cv.drawPath(sh,p)
  p.style=Paint.Style.FILL;p.color=al(col,a);p.textAlign=Paint.Align.CENTER
  if(t=="dpad"){for(k in 0..3){cv.save();cv.rotate(90f*k,cx,cy);val tr=Path();tr.moveTo(cx,cy-r*.82f);tr.lineTo(cx-r*.16f,cy-r*.58f);tr.lineTo(cx+r*.16f,cy-r*.58f);tr.close();cv.drawPath(tr,p);cv.restore()}}
  else{val s=label(t);p.textSize=when{pill(t)->r*.5f;s.length>1->r*.75f;else->r*.95f};cv.drawText(s,cx,cy+p.textSize*.35f,p)}
  cv.restore()}
}
/** Pruebas de contacto en coordenadas locales del control (respeta la rotación). */
object Hit{
 private fun loc(k:Ctl,x:Float,y:Float,w:Float,h:Float):FloatArray{val a=Math.toRadians(-k.r.toDouble());val dx=x-k.x*w;val dy=y-k.y*h
  return floatArrayOf((dx*cos(a)-dy*sin(a)).toFloat(),(dx*sin(a)+dy*cos(a)).toFloat())}
 fun test(k:Ctl,x:Float,y:Float,w:Float,h:Float):Boolean{val r=k.s*min(w,h)/2f;val q=loc(k,x,y,w,h)
  return when{k.t=="dpad"->abs(q[0])<r*1.1f&&abs(q[1])<r*1.1f;CtlDraw.pill(k.t)->abs(q[0])<r*1.4f&&abs(q[1])<r*.65f;else->q[0]*q[0]+q[1]*q[1]<(r*1.1f)*(r*1.1f)}}
 /** Direcciones del D-Pad (8 sentidos): bits de libretro IZQ 64, DER 128, ARRIBA 16, ABAJO 32. */
 fun dir(k:Ctl,x:Float,y:Float,w:Float,h:Float):Int{val r=k.s*min(w,h)/2f;val q=loc(k,x,y,w,h);val t=r*.28f;var m=0
  if(q[0]<-t)m=m or 64;if(q[0]>t)m=m or 128;if(q[1]<-t)m=m or 16;if(q[1]>t)m=m or 32;return m}
}
/** Controles táctiles según el layout activo. on = máscara de entradas; act = acciones del emulador (nunca van a la máscara). */
class Pad(c:Context,val on:(Int)->Unit,val act:(String,Boolean)->Unit):View(c){
 var list:List<Ctl> = emptyList();set(v){field=v;pressed.clear();dirMask=0;on(0);invalidate()}
 private val pressed=LinkedHashSet<Ctl>();private var dirMask=0;private var phase=true;private val hd=Handler(Looper.getMainLooper())
 private fun turbo()=pressed.any{it.t.startsWith("turbo")}
 private val tick=object:Runnable{override fun run(){phase=!phase;emit();if(turbo())hd.postDelayed(this,33)}} // autofire ~15 Hz
 private fun emit(){var m=dirMask;for(k in pressed){if(k.t=="dpad")continue;val b=Layouts.mask(k.t);m=m or(if(k.t.startsWith("turbo")){if(phase)b else 0}else b)};on(m)}
 private fun edge(k:Ctl,down:Boolean){when(k.t){"qload","qsave","shot"->if(down)act(k.t,true);"ff"->if(k.m==1)act("ffhold",down) else if(down)act("ff",true)}}
 override fun onDraw(cv:Canvas){for(k in list){if(k.t=="screen"||!k.v)continue;CtlDraw.draw(cv,k.t,k.x*width,k.y*height,k.s*min(width,height)/2f,k.r,(k.o*255).toInt(),k.st,k in pressed)}}
 override fun onTouchEvent(e:MotionEvent):Boolean{
  val up=e.actionMasked==MotionEvent.ACTION_UP||e.actionMasked==MotionEvent.ACTION_CANCEL
  val ns=LinkedHashSet<Ctl>();var dm=0;val w=width.toFloat();val h=height.toFloat()
  if(!up)for(i in 0 until e.pointerCount){if(e.actionMasked==MotionEvent.ACTION_POINTER_UP&&i==e.actionIndex)continue
   for(k in list.asReversed()){if(k.t=="screen")continue // el control de más arriba se queda el toque
    if(Hit.test(k,e.getX(i),e.getY(i),w,h)){ns.add(k);if(k.t=="dpad")dm=dm or Hit.dir(k,e.getX(i),e.getY(i),w,h);break}}}
  for(k in ns)if(k !in pressed)edge(k,true)
  for(k in pressed)if(k !in ns)edge(k,false)
  val had=turbo();pressed.clear();pressed.addAll(ns);dirMask=dm
  if(!had&&turbo()){phase=true;hd.postDelayed(tick,33)}
  emit();invalidate();return true}
}
