package app.cirilo
import android.content.Context
import android.graphics.*
import android.view.*
/** Controles táctiles. Bits = ids de joypad de libretro: B0 SELECT2 START3 ARRIBA4 ABAJO5 IZQ6 DER7 A8 L10 R11. */
class Pad(c:Context,val on:(Int)->Unit):View(c){
 private class B(val t:String,val bit:Int,val x:Float,val y:Float,val r:Float)
 private val bs=listOf(B("^",4,.22f,.70f,.07f),B("v",5,.22f,.88f,.07f),B("<",6,.10f,.79f,.07f),B(">",7,.34f,.79f,.07f),
  B("A",8,.88f,.74f,.09f),B("B",0,.70f,.84f,.09f),B("L",10,.12f,.60f,.07f),B("R",11,.88f,.60f,.07f),B("SEL",2,.36f,.95f,.06f),B("STA",3,.64f,.95f,.06f))
 private val p=Paint(Paint.ANTI_ALIAS_FLAG);private var m=0
 override fun onDraw(c:Canvas){for(b in bs){val d=minOf(width,height)*b.r*1.4f
  p.style=Paint.Style.FILL;p.color=if((m shr b.bit) and 1==1)0x88FFFFFF.toInt() else 0x33000000;c.drawCircle(b.x*width,b.y*height,d,p)
  p.color=0xCCFFFFFF.toInt();p.textAlign=Paint.Align.CENTER;p.textSize=d*.7f;c.drawText(b.t,b.x*width,b.y*height+d*.25f,p)}}
 override fun onTouchEvent(e:MotionEvent):Boolean{
  var n=0
  if(e.actionMasked!=MotionEvent.ACTION_UP&&e.actionMasked!=MotionEvent.ACTION_CANCEL)for(i in 0 until e.pointerCount){
   if(e.actionMasked==MotionEvent.ACTION_POINTER_UP&&i==e.actionIndex)continue
   for(b in bs){val d=minOf(width,height)*b.r*1.4f;val dx=e.getX(i)-b.x*width;val dy=e.getY(i)-b.y*height;if(dx*dx+dy*dy<d*d*1.6f)n=n or(1 shl b.bit)}}
  if(n!=m){m=n;on(n);invalidate()};return true}
}
