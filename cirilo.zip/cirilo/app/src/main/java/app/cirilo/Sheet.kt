package app.cirilo
import android.app.*
import android.graphics.drawable.*
import android.view.*
import android.widget.*
/** Hoja de opciones inferior (estilo del menú de My Boy!). subs = texto pequeño bajo cada opción.
 *  Abajo y centrada en horizontal; el ancho sale del texto más largo (ver `width`), no de esquina a esquina. */
object Sheet{
 /** Ancho de la ventana: ~2,5 veces el texto más largo, nunca menos de 280 dp (ni de lo que pide el texto con sus márgenes) ni más que la pantalla menos un pequeño margen. Incluye los 12 dp de aire de cada lado. */
 fun width(a:Activity,widest:Float):Int{
  val dn=a.resources.displayMetrics.density;val sw=a.resources.displayMetrics.widthPixels
  val need=widest+48*dn+24*dn // texto + márgenes internos + aire exterior
  val w=maxOf(2.5f*widest+24*dn,280*dn+24*dn,need)
  return minOf(w,sw-12*dn).toInt()}
 fun show(a:Activity,title:String?,items:List<String>,subs:List<String?>?,onPick:(Int)->Unit,onCancel:()->Unit){
  val dn=a.resources.displayMetrics.density;fun dp(x:Int)=(x*dn).toInt()
  val d=Dialog(a);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val tvs=ArrayList<TextView>() // para medir el texto más largo
  val col=LinearLayout(a);col.orientation=LinearLayout.VERTICAL;col.setPadding(0,dp(12),0,dp(12))
  col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  title?.let{col.addView(TextView(a).apply{text=it;textSize=20f;setTextColor(-1);setPadding(dp(24),dp(12),dp(24),dp(8));tvs+=this})}
  items.forEachIndexed{i,s->val r=LinearLayout(a);r.orientation=LinearLayout.VERTICAL;r.setPadding(dp(24),dp(15),dp(24),dp(15))
   r.addView(TextView(a).apply{text=s;textSize=18f;setTextColor(-1);tvs+=this})
   subs?.get(i)?.let{r.addView(TextView(a).apply{text=it;textSize=13f;setTextColor(0xFF9E9E9E.toInt());tvs+=this})}
   r.setOnClickListener{d.dismiss();onPick(i)};col.addView(r)}
  val widest=tvs.maxOfOrNull{it.paint.measureText(it.text.toString())}?:0f
  val box=FrameLayout(a);box.setPadding(dp(12),dp(12),dp(12),dp(12));box.addView(ScrollView(a).apply{addView(col)})
  d.setContentView(box);d.setOnCancelListener{onCancel()}
  d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout(width(a,widest),-2);setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)}
  d.show()}
}
