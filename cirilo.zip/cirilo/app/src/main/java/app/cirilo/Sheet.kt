package app.cirilo
import android.app.*
import android.graphics.drawable.*
import android.view.*
import android.widget.*
/** Hoja de opciones inferior (estilo del menú de My Boy!). subs = texto pequeño bajo cada opción. */
object Sheet{
 fun show(a:Activity,title:String?,items:List<String>,subs:List<String>?,onPick:(Int)->Unit,onCancel:()->Unit){
  val dn=a.resources.displayMetrics.density;fun dp(x:Int)=(x*dn).toInt()
  val d=Dialog(a);d.requestWindowFeature(Window.FEATURE_NO_TITLE)
  val col=LinearLayout(a);col.orientation=LinearLayout.VERTICAL;col.setPadding(0,dp(12),0,dp(12))
  col.background=GradientDrawable().apply{setColor(0xFF262626.toInt());cornerRadius=dp(28).toFloat()}
  title?.let{col.addView(TextView(a).apply{text=it;textSize=20f;setTextColor(-1);setPadding(dp(24),dp(12),dp(24),dp(8))})}
  items.forEachIndexed{i,s->val r=LinearLayout(a);r.orientation=LinearLayout.VERTICAL;r.setPadding(dp(24),dp(15),dp(24),dp(15))
   r.addView(TextView(a).apply{text=s;textSize=18f;setTextColor(-1)})
   subs?.get(i)?.let{r.addView(TextView(a).apply{text=it;textSize=13f;setTextColor(0xFF9E9E9E.toInt())})}
   r.setOnClickListener{d.dismiss();onPick(i)};col.addView(r)}
  val box=FrameLayout(a);box.setPadding(dp(12),dp(12),dp(12),dp(12));box.addView(ScrollView(a).apply{addView(col)})
  d.setContentView(box);d.setOnCancelListener{onCancel()}
  d.window?.apply{setBackgroundDrawable(ColorDrawable(0));setLayout(-1,-2);setGravity(Gravity.BOTTOM)}
  d.show()}
}
