package app.cirilo
import android.content.ComponentName
import android.content.Context
import android.os.IBinder
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Looper
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
/** Acceso a Android/data mediante Shizuku. Las llamadas que tocan archivos son bloqueantes: úsalas fuera del hilo principal (en el principal solo funcionan si el servicio ya estaba conectado). */
object Shell{
 const val PKG="moe.shizuku.privileged.api"
 @Volatile private var svc:IShell?=null
 private val lock=Any();private var latch=CountDownLatch(0)
 private val conn=object:ServiceConnection{
  override fun onServiceConnected(n:ComponentName?,b:IBinder?){svc=if(b!=null&&b.pingBinder())IShell.Stub.asInterface(b) else null;latch.countDown()}
  override fun onServiceDisconnected(n:ComponentName?){svc=null}}
 fun installed(c:Context)=try{c.packageManager.getPackageInfo(PKG,0);true}catch(e:Exception){false}
 /** Shizuku está iniciada. */
 fun running()=try{Shizuku.pingBinder()}catch(e:Throwable){false}
 /** Shizuku iniciada y Cirilo tiene su permiso. */
 fun granted()=try{Shizuku.pingBinder()&&Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED}catch(e:Throwable){false}
 /** El usuario denegó el permiso «para siempre»: ya no se puede volver a pedir desde la app. */
 fun denied()=try{Shizuku.pingBinder()&&Shizuku.shouldShowRequestPermissionRationale()}catch(e:Throwable){false}
 /** Pide el permiso de Shizuku; f recibe el resultado (hilo principal). */
 fun ask(code:Int,f:(Boolean)->Unit){try{lateinit var l:Shizuku.OnRequestPermissionResultListener
   l=Shizuku.OnRequestPermissionResultListener{rc,gr->if(rc==code){Shizuku.removeRequestPermissionResultListener(l);f(gr==PackageManager.PERMISSION_GRANTED)}}
   Shizuku.addRequestPermissionResultListener(l);Shizuku.requestPermission(code)}catch(e:Throwable){f(false)}}
 private fun conn(c:Context):IShell?{
  svc?.let{if(it.asBinder().isBinderAlive)return it}
  if(!granted()||Looper.myLooper()==Looper.getMainLooper())return null // en el hilo principal no se puede esperar la conexión
  synchronized(lock){svc?.let{if(it.asBinder().isBinderAlive)return it}
   latch=CountDownLatch(1)
   try{Shizuku.bindUserService(Shizuku.UserServiceArgs(ComponentName(c.packageName,ShellService::class.java.name)).daemon(false).processNameSuffix("sh").version(1),conn)}catch(e:Throwable){return null}
   latch.await(8,TimeUnit.SECONDS);return svc}}
 fun list(c:Context,dir:String):List<Pair<String,Long>> = try{conn(c)?.list(dir)?.mapNotNull{val a=it.split('\t');if(a.size==2)a[0] to (a[1].toLongOrNull()?:0L) else null}}catch(e:Throwable){null}?:emptyList()
 fun read(c:Context,path:String):ByteArray? = try{conn(c)?.read(path)}catch(e:Throwable){null}
 fun write(c:Context,path:String,data:ByteArray):Boolean = try{conn(c)?.write(path,data)==true}catch(e:Throwable){false}
 fun delete(c:Context,path:String):Boolean = try{conn(c)?.delete(path)==true}catch(e:Throwable){false}
 fun isDir(c:Context,path:String):Boolean = try{conn(c)?.isDir(path)==true}catch(e:Throwable){false}
}
