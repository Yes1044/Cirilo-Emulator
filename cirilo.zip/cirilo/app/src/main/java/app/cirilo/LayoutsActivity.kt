package app.cirilo
import android.app.*
import android.content.Intent
import android.graphics.drawable.*
import android.os.Bundle
import android.view.*
import android.widget.*
/** Administrador de layouts: lista con indicador del activo, lápiz (editar), ⋮ (renombrar, duplicar, eliminar) y botón +. */
class LayoutsActivity:Activity(){
 private lateinit var st:Store;private lateinit var body:LinearLayout;private var dn=1f
 private fun dp(x:Int)=(x*dn).toInt()
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density
  val root=FrameLayout(this);root.setBackgroundColor(0xFF303030.toInt());val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  val head=LinearLayout(this);head.gravity=Gravity.CENTER_VERTICAL;head.setBackgroundColor(0xFF212121.toInt());head.setPadding(dp(16),0,dp(8),0)
  head.addView(TextView(this).apply{text="Layouts";setTextColor(-1);textSize=22f;setPadding(0,dp(16),0,dp(16))},LinearLayout.LayoutParams(0,-2,1f))
  head.addView(ImageView(this).apply{setImageResource(R.drawable.ic_edit);setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{startActivity(Intent(this@LayoutsActivity,LayoutEditorActivity::class.java).putExtra("id",st.active))}},LinearLayout.LayoutParams(dp(48),dp(48)))
  val more=ImageView(this).apply{setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10))};head.addView(more,LinearLayout.LayoutParams(dp(48),dp(48)))
  more.setOnClickListener{PopupMenu(this,more).apply{menu.add(0,0,0,"Renombrar");menu.add(0,1,0,"Duplicar");menu.add(0,2,0,"Eliminar");setOnMenuItemClickListener{act(it.itemId);true}}.show()}
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL
  col.addView(head);col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));root.addView(col)
  val fab=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());elevation=8*dn
   background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xFF80CBC4.toInt())}}
  root.addView(fab,FrameLayout.LayoutParams(dp(56),dp(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,dp(24),dp(24))})
  fab.setOnClickListener{Ui.ask(this,"Nombre del layout",""){n->st.list.add(Lay("l"+System.currentTimeMillis().toString(36),n,Layouts.factory(false),Layouts.factory(true)));Layouts.save(this,st);render()}}
  setContentView(root)}
 override fun onResume(){super.onResume();st=Layouts.load(this);render()}
 private fun render(){body.removeAllViews()
  st.list.forEach{l->val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(16),dp(16),dp(16))
   r.addView(TextView(this).apply{text=l.name;textSize=18f;setTextColor(-1)},LinearLayout.LayoutParams(0,-2,1f))
   val ring=GradientDrawable().apply{shape=GradientDrawable.OVAL;setStroke(dp(3),0xFF80CBC4.toInt());setColor(0)}
   val dot=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(0xFF80CBC4.toInt())}
   val ind=View(this);ind.background=if(l.id==st.active)LayerDrawable(arrayOf(ring,dot)).apply{setLayerInset(1,dp(6),dp(6),dp(6),dp(6))} else ring
   r.addView(ind,LinearLayout.LayoutParams(dp(26),dp(26)))
   r.setOnClickListener{st.active=l.id;Layouts.save(this,st);render()};body.addView(r)
   body.addView(View(this).apply{setBackgroundColor(0xFF444444.toInt())},LinearLayout.LayoutParams(-1,2))}}
 private fun act(i:Int){val l=st.cur()
  when(i){
   0->Ui.ask(this,"Renombrar",l.name){n->st.list[st.list.indexOf(l)]=l.copy(name=n);Layouts.save(this,st);render()}
   1->{st.list.add(l.copy(id="l"+System.currentTimeMillis().toString(36),name=l.name+" (copia)"));Layouts.save(this,st);render()}
   else->if(st.list.size<=1)t("Debe existir al menos un layout") else Ui.confirm(this,"¿Eliminar el layout «"+l.name+"»?"){st.list.remove(l);st.active=st.list[0].id;Layouts.save(this,st);render()}}}
}
