package app.cirilo
import android.app.*
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.*
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.*
import android.widget.*
import java.util.zip.ZipInputStream
/** Administrador de layouts: pestañas GBA y GB/GBC (cada consola tiene su layout activo), lista con indicador del activo, lápiz (editar), ⋮ (renombrar, duplicar, eliminar, copiar a la otra consola, importar, exportar) y botón +. */
class LayoutsActivity:Activity(){
 private lateinit var st:Store;private lateinit var body:LinearLayout;private var dn=1f;private var tab=LSys.GBA
 private val tabT=HashMap<String,TextView>();private val tabU=HashMap<String,View>();private var exportLay:Lay?=null
 private fun dp(x:Int)=(x*dn).toInt()
 private fun t(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun newId(k:Int=0)="l"+System.currentTimeMillis().toString(36)+(if(k>0)k.toString() else "")
 override fun onCreate(b:Bundle?){super.onCreate(b);dn=resources.displayMetrics.density
  val root=FrameLayout(this);root.setBackgroundColor(0xFF303030.toInt());val col=LinearLayout(this);col.orientation=LinearLayout.VERTICAL
  val head=LinearLayout(this);head.gravity=Gravity.CENTER_VERTICAL;head.setBackgroundColor(0xFF212121.toInt());head.setPadding(dp(16),0,dp(8),0)
  head.addView(TextView(this).apply{text="Layouts";setTextColor(-1);textSize=22f;setPadding(0,dp(16),0,dp(16))},LinearLayout.LayoutParams(0,-2,1f))
  head.addView(ImageView(this).apply{setImageResource(R.drawable.ic_edit);setPadding(dp(10),dp(10),dp(10),dp(10));setOnClickListener{startActivity(Intent(this@LayoutsActivity,LayoutEditorActivity::class.java).putExtra("id",st.cur(tab).id))}},LinearLayout.LayoutParams(dp(48),dp(48)))
  val more=ImageView(this).apply{setImageResource(R.drawable.ic_more);setPadding(dp(10),dp(10),dp(10),dp(10))};head.addView(more,LinearLayout.LayoutParams(dp(48),dp(48)))
  more.setOnClickListener{PopupMenu(this,more).apply{menu.add(0,0,0,"Renombrar");menu.add(0,1,0,"Duplicar");menu.add(0,2,0,"Eliminar");menu.add(0,3,0,"Copiar a "+LSys.name(LSys.other(tab)))
   menu.add(0,4,0,"Importar...");menu.add(0,5,0,"Exportar layout");setOnMenuItemClickListener{act(it.itemId);true}}.show()}
  val tabs=LinearLayout(this);tabs.setBackgroundColor(0xFF212121.toInt())
  tabs.addView(tabV(LSys.GBA,"GBA"),LinearLayout.LayoutParams(0,dp(44),1f));tabs.addView(tabV(LSys.GB,"GB / GBC"),LinearLayout.LayoutParams(0,dp(44),1f))
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL
  col.addView(head);col.addView(tabs);col.addView(ScrollView(this).apply{addView(body)},LinearLayout.LayoutParams(-1,0,1f));root.addView(col)
  val fab=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(0xFF212121.toInt());elevation=8*dn
   background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Accent.color)}}
  root.addView(fab,FrameLayout.LayoutParams(dp(56),dp(56),Gravity.BOTTOM or Gravity.END).apply{setMargins(0,0,dp(24),dp(24))})
  fab.setOnClickListener{Ui.ask(this,"Nombre del layout",""){n->st.list.add(Lay(newId(),n,Layouts.factory(false,tab),Layouts.factory(true,tab),tab));Layouts.save(this,st);render()}}
  setContentView(root)}
 private fun tabV(sys:String,label:String):View{val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL
  val tx=TextView(this).apply{text=label;textSize=15f;gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD)};val u=View(this)
  c.addView(tx,LinearLayout.LayoutParams(-1,0,1f));c.addView(u,LinearLayout.LayoutParams(-1,dp(3)))
  tabT[sys]=tx;tabU[sys]=u;c.setOnClickListener{tab=sys;render()};return c}
 override fun onResume(){super.onResume();st=Layouts.load(this);render()}
 private fun render(){body.removeAllViews()
  for(s in listOf(LSys.GBA,LSys.GB)){val on=s==tab;tabT[s]?.setTextColor(if(on)Accent.color else 0xFF9E9E9E.toInt());tabU[s]?.setBackgroundColor(if(on)Accent.color else 0)}
  val sel=st.cur(tab).id
  st.of(tab).forEach{l->val r=LinearLayout(this);r.gravity=Gravity.CENTER_VERTICAL;r.setPadding(dp(16),dp(16),dp(16),dp(16))
   r.addView(TextView(this).apply{text=l.name;textSize=18f;setTextColor(-1)},LinearLayout.LayoutParams(0,-2,1f))
   val ring=GradientDrawable().apply{shape=GradientDrawable.OVAL;setStroke(dp(3),Accent.color);setColor(0)}
   val dot=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Accent.color)}
   val ind=View(this);ind.background=if(l.id==sel)LayerDrawable(arrayOf(ring,dot)).apply{setLayerInset(1,dp(6),dp(6),dp(6),dp(6))} else ring
   r.addView(ind,LinearLayout.LayoutParams(dp(26),dp(26)))
   r.setOnClickListener{st.setActive(tab,l.id);Layouts.save(this,st);render()};body.addView(r)
   body.addView(View(this).apply{setBackgroundColor(0xFF444444.toInt())},LinearLayout.LayoutParams(-1,2))}}
 private fun act(i:Int){val l=st.cur(tab)
  when(i){
   0->Ui.ask(this,"Renombrar",l.name){n->st.list[st.list.indexOf(l)]=l.copy(name=n);Layouts.save(this,st);render()}
   1->{st.list.add(l.copy(id=newId(),name=l.name+" (copia)"));Layouts.save(this,st);render()}
   2->if(st.of(tab).size<=1)t("Debe existir al menos un layout de "+LSys.name(tab)) else Ui.confirm(this,"¿Eliminar el layout «"+l.name+"»?"){st.list.remove(l);st.setActive(tab,st.of(tab)[0].id);Layouts.save(this,st);render()}
   3->{val o=LSys.other(tab);val c=LSys.convert(l,o).copy(id=newId());st.list.add(c);Layouts.save(this,st)
    t("Copiado a "+LSys.name(o)+(if(o==LSys.GB)" (sin L ni R)" else ": los gatillos L y R se añaden desde el editor"))}
   4->Sheet.show(this,"Importar a "+LSys.name(tab),listOf("De My Boy!","De My OldBoy!","Archivo de layout de Cirilo"),
     listOf("Elige layouts.xml y los demás .xml de la carpeta, o un .zip","Elige layouts.xml y los demás .xml de la carpeta, o un .zip","Un layout exportado desde Cirilo (se convierte si es de la otra consola)"),
     {k->pick(if(k==2)RQ_CIR else if(k==0)RQ_MB else RQ_OB,k!=2)},{})
   else->{exportLay=l;try{startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,l.name+" - layout.json"),RQ_SAVE)}catch(e:Exception){t("No se pudo abrir el selector de archivos")}}}}
 private fun pick(rq:Int,multi:Boolean){try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,multi),rq)}catch(e:Exception){t("No se pudo abrir el selector de archivos")}}
 override fun onActivityResult(rq:Int,rs:Int,d:Intent?){super.onActivityResult(rq,rs,d);if(rs!=RESULT_OK||d==null)return
  when(rq){
   RQ_SAVE->{val u=d.data?:return;val l=exportLay?:return
    try{contentResolver.openOutputStream(u,"wt")!!.use{it.write(Layouts.export(l).toByteArray())};t("Layout guardado")}catch(e:Exception){t("No se pudo guardar el archivo")}}
   RQ_MB,RQ_OB->importBoy(uris(d),if(rq==RQ_MB)"My Boy!" else "My OldBoy!")
   RQ_CIR->importCirilo(uris(d))}}
 private fun uris(d:Intent):List<Uri>{val o=ArrayList<Uri>();d.clipData?.let{c->for(i in 0 until c.itemCount)o.add(c.getItemAt(i).uri)};if(o.isEmpty())d.data?.let{o.add(it)};return o}
 private fun nameOf(u:Uri):String{try{contentResolver.query(u,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{q->if(q.moveToFirst())return q.getString(0)?:""}}catch(e:Exception){};return u.lastPathSegment?.substringAfterLast('/')?:""}
 private fun readZip(u:Uri,out:MutableMap<String,String>){contentResolver.openInputStream(u)!!.use{ins->val z=ZipInputStream(ins)
  while(true){val e=z.nextEntry?:break;if(!e.isDirectory&&e.name.endsWith(".xml",true))out[e.name.substringAfterLast('/')]=String(z.readBytes(),Charsets.UTF_8).removePrefix("\uFEFF")}}}
 /** My Boy! / My OldBoy!: se leen los .xml elegidos (o los de un .zip), se ofrecen los perfiles y se convierten a la consola de la pestaña actual. */
 private fun importBoy(us:List<Uri>,app:String){
  val files=LinkedHashMap<String,String>()
  try{for(u in us){val n=nameOf(u)
    if(n.endsWith(".zip",true))readZip(u,files) else if(n.endsWith(".xml",true))files[n]=contentResolver.openInputStream(u)!!.use{String(it.readBytes(),Charsets.UTF_8)}.removePrefix("\uFEFF")}}
  catch(e:Exception){t("No se pudieron leer los archivos");return}
  val ps=LayoutImport.profiles(files)
  if(ps.isEmpty()){AlertDialog.Builder(this).setMessage("No se encontró ningún layout de "+app+" en lo elegido. Hacen falta los archivos «<nombre>-<ancho>x<alto>.xml» (y layouts.xml para la lista de nombres).").setPositiveButton("Aceptar",null).show();return}
  val on=BooleanArray(ps.size){true}
  AlertDialog.Builder(this).setTitle("Layouts de "+app+" a importar").setMultiChoiceItems(ps.map{it.name}.toTypedArray(),on){_,i,c->on[i]=c}
   .setPositiveButton("Importar"){_,_->doImport(ps.filterIndexed{i,_->on[i]},app)}.setNegativeButton("Cancelar",null).show()}
 private fun doImport(ps:List<LayoutImport.Profile>,app:String){
  if(ps.isEmpty())return
  val dm=resources.displayMetrics;val msg=ArrayList<String>();var k=0
  for(p in ps){val r=LayoutImport.convert(p,tab,dm.widthPixels,dm.heightPixels){land->Layouts.factory(land,tab)}
   st.list.add(Lay(newId(++k),p.name+" ("+app+")",r.p,r.l,tab))
   r.notes.forEach{msg.add((if(ps.size>1)p.name+": " else "")+it)}}
  Layouts.save(this,st);render()
  AlertDialog.Builder(this).setTitle(if(k==1)"1 layout importado" else k.toString()+" layouts importados")
   .setMessage(if(msg.isEmpty())"Todos los controles tenían equivalente en Cirilo." else msg.joinToString("\n\n")).setPositiveButton("Aceptar",null).show()}
 private fun importCirilo(us:List<Uri>){val u=us.firstOrNull()?:return
  val l=try{Layouts.parse(contentResolver.openInputStream(u)!!.use{String(it.readBytes(),Charsets.UTF_8)}.removePrefix("\uFEFF"))}catch(e:Exception){null}
  if(l==null){t("Ese archivo no es un layout de Cirilo");return}
  val x=if(l.sys!=tab)LSys.convert(l,tab) else l;st.list.add(x);Layouts.save(this,st);render()
  t("Layout importado"+(if(l.sys!=tab)" (era de "+LSys.name(l.sys)+(if(tab==LSys.GB)", sin L ni R" else "")+")" else ""))}
 companion object{private const val RQ_SAVE=1;private const val RQ_MB=2;private const val RQ_OB=3;private const val RQ_CIR=4}
}
