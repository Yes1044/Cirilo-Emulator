package app.cirilo
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract as DC
import org.json.*
import java.io.*
import java.util.zip.*
/** p: 0 GB, 1 GBC, 2 GBA (-1 = sin calcular). reg/lang: listas separadas por coma. year/genre quedan vacíos hasta tener una base de datos. */
data class Game(val n:String,val u:String,val p:Int=-1,val reg:String="",val lang:String="",val added:Long=0,val played:Long=0,val fav:Boolean=false,val year:Int=0,val genre:String=""){val title get()=n.substringBeforeLast('.')}
/** Acceso a ROMs: rutas de archivo (escaneo global), URIs de Android (selector/carpetas) y .zip (extrae la primera ROM). */
object Roms{
 val ROM=setOf("gb","gbc","gba");val EXT=ROM+"zip"
 fun ext(n:String)=n.substringAfterLast('.',"").lowercase()
 private fun rd(i:InputStream,lim:Int):ByteArray{if(lim==Int.MAX_VALUE)return i.readBytes();val b=ByteArray(lim);var n=0;while(n<lim){val r=i.read(b,n,lim-n);if(r<0)break;n+=r};return b.copyOf(n)}
 fun load(c:Context,u:String,name:String,lim:Int=Int.MAX_VALUE):Pair<String,ByteArray>?{
  val i:InputStream=(if(u.startsWith("/"))FileInputStream(u) else c.contentResolver.openInputStream(Uri.parse(u)))?:return null
  i.use{if(ext(name)!="zip")return Pair(name,rd(it,lim))
   val z=ZipInputStream(it)
   while(true){val e=z.nextEntry?:return null;if(!e.isDirectory&&ext(e.name) in ROM)return Pair(e.name.substringAfterLast('/'),rd(z,lim))}}
 }
 fun scanTree(c:Context,tree:Uri):List<Game>{
  val out=ArrayList<Game>()
  fun walk(id:String){
   c.contentResolver.query(DC.buildChildDocumentsUriUsingTree(tree,id),arrayOf(DC.Document.COLUMN_DOCUMENT_ID,DC.Document.COLUMN_DISPLAY_NAME,DC.Document.COLUMN_MIME_TYPE),null,null,null)?.use{q->
    while(q.moveToNext()){val did=q.getString(0);val nm=q.getString(1)?:continue
     if(q.getString(2)==DC.Document.MIME_TYPE_DIR)walk(did) else if(ext(nm) in EXT)out+=Game(nm,DC.buildDocumentUriUsingTree(tree,did).toString())}}}
  walk(DC.getTreeDocumentId(tree));return out}
 fun scanDevice():List<Game>{
  val out=ArrayList<Game>()
  Environment.getExternalStorageDirectory().walkTopDown().onEnter{it.name!="Android"&&!it.name.startsWith(".")}.forEach{f->
   if(f.isFile){val e=ext(f.name);if(e in ROM||(e=="zip"&&hasRom(f)))out+=Game(f.name,f.absolutePath)}}
  return out}
 private fun hasRom(f:File)=try{ZipFile(f).use{z->z.entries().asSequence().any{ext(it.name) in ROM}}}catch(e:Exception){false}
 /** Aproximación: un nombre con etiqueta de región entre paréntesis suele ser un volcado oficial. Con una base de datos CRC32 sería exacto. */
 private val OFF=Regex("\\([^)]*\\b(?:USA|Europe|Japan|World|Spain|Germany|France|Italy|UK|Australia|Korea|China|Netherlands|Sweden|Brazil|Asia|Taiwan|Canada)\\b[^)]*\\)")
 fun official(n:String)=OFF.containsMatchIn(n)
 /** Plataforma, región e idioma: del encabezado (GBA 0xAF, GBC 0x142, GB 0x14A) y de las etiquetas del nombre, p. ej. (Spain) o (En,Fr,De). */
 fun meta(c:Context,g:Game):Game{
  val r=try{load(c,g.u,g.n,0x150)}catch(e:Exception){null}
  val h=r?.second?:ByteArray(0);val e=ext(r?.first?:g.n)
  var p=when(e){"gba"->2;"gbc"->1;"gb"->0;else->-1}
  val cgb=h.size>0x143&&(h[0x143].toInt() and 0xFF).let{it==0x80||it==0xC0}
  if(p==0&&cgb)p=1
  if(p<0)p=if(h.size>0xB2&&(h[0xB2].toInt() and 0xFF)==0x96)2 else if(cgb)1 else 0
  val rg=LinkedHashSet<String>();val lg=LinkedHashSet<String>()
  fun dst(ch:Char){when(ch){'J'->{rg+="Japan";lg+="ja"};'E'->{rg+="USA";lg+="en"};'P'->{rg+="Europe";lg+="en"};'D'->{rg+="Europe";lg+="de"};'F'->{rg+="Europe";lg+="fr"};'I'->{rg+="Europe";lg+="it"};'S'->{rg+="Europe";lg+="es"};else->{}}}
  if(p==2&&h.size>0xB0){dst(h[0xAF].toInt().toChar())}
  else if(p==1&&cgb&&h.size>0x142&&(0x13F..0x142).all{h[it].toInt().toChar() in 'A'..'Z'}){dst(h[0x142].toInt().toChar())}
  else if(p<2&&h.size>0x14A&&h[0x14A].toInt()==0){rg+="Japan"}
  Regex("\\(([^)]*)\\)").findAll(g.n).forEach{m->val t=m.groupValues[1]
   if(Regex("[A-Z][a-z](,[A-Z][a-z])*").matches(t))t.split(",").forEach{lg+=it.lowercase()}
   t.split(",").map{it.trim()}.forEach{w->when(w){"USA"->{rg+="USA";lg+="en"};"Europe","UK","Netherlands","Sweden"->{rg+="Europe"};"Spain"->{rg+="Europe";lg+="es"};"Germany"->{rg+="Europe";lg+="de"};"France"->{rg+="Europe";lg+="fr"};"Italy"->{rg+="Europe";lg+="it"};"Japan"->{rg+="Japan";lg+="ja"};"World"->{rg+="USA";rg+="Europe";rg+="Japan"};else->{}}}}
  return g.copy(p=p,reg=rg.joinToString(","),lang=lg.joinToString(","))}
}
object Lib{
 private fun sp(c:Context)=c.getSharedPreferences("lib",0)
 fun all(c:Context):MutableList<Game>{val a=JSONArray(sp(c).getString("g","[]"));return MutableList(a.length()){val o=a.getJSONObject(it)
  Game(o.getString("n"),o.getString("u"),o.optInt("p",-1),o.optString("r",""),o.optString("l",""),o.optLong("a",0),o.optLong("t",0),o.optBoolean("f",false),o.optInt("y",0),o.optString("g",""))}}
 fun save(c:Context,l:List<Game>){val a=JSONArray();l.forEach{a.put(JSONObject().put("n",it.n).put("u",it.u).put("p",it.p).put("r",it.reg).put("l",it.lang).put("a",it.added).put("t",it.played).put("f",it.fav).put("y",it.year).put("g",it.genre))};sp(c).edit().putString("g",a.toString()).apply()}
 @Synchronized fun add(c:Context,n:List<Game>):Int{val l=all(c);val have=l.map{it.u}.toSet();val now=System.currentTimeMillis()
  val nw=n.filter{it.u !in have}.distinctBy{it.u}.map{Roms.meta(c,it.copy(added=now))};l+=nw;save(c,l);return nw.size}
 @Synchronized fun upd(c:Context,gs:List<Game>){val m=gs.associateBy{it.u};save(c,all(c).map{m[it.u]?:it})}
 @Synchronized fun del(c:Context,u:String){save(c,all(c).filter{it.u!=u})}
}
