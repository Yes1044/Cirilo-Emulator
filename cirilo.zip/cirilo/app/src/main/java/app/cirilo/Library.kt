package app.cirilo
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract as DC
import org.json.*
import java.io.*
import java.util.zip.*
/** p: 0 GB, 1 GBC, 2 GBA (-1 = sin calcular). reg/lang: listas separadas por coma. year/genre quedan vacíos hasta tener una base de datos. */
data class Game(val n:String,val u:String,val p:Int=-1,val reg:String="",val lang:String="",val added:Long=0,val played:Long=0,val fav:Boolean=false,val year:Int=0,val genre:String="",val fo:String=""){val title get()=n.substringBeforeLast('.')}
/** Acceso a ROMs: rutas de archivo (escaneo global), URIs de Android (selector/carpetas) y .zip (extrae la primera ROM). */
object Roms{
 val ROM=setOf("gb","gbc","gba");val EXT=ROM+"zip"
 fun ext(n:String)=n.substringAfterLast('.',"").lowercase()
 private fun rd(i:InputStream,lim:Int):ByteArray{if(lim==Int.MAX_VALUE)return i.readBytes();val b=ByteArray(lim);var n=0;while(n<lim){val r=i.read(b,n,lim-n);if(r<0)break;n+=r};return b.copyOf(n)}
 /** Resultado del último parche (para avisar al usuario): null = no había parche o está desactivado. Solo se rellena al cargar la ROM entera. */
 @Volatile var patchMsg:String?=null
 /** Carga la ROM. Con la ROM entera (lim = todo) y Ajustes → Misceláneo → «Parches de ROM» activo, aplica en memoria el .ips/.ups que corresponda. */
 fun load(c:Context,u:String,name:String,lim:Int=Int.MAX_VALUE):Pair<String,ByteArray>?{
  val r=raw(c,u,name,lim)?:return null
  if(lim!=Int.MAX_VALUE)return r
  patchMsg=null
  if(!c.getSharedPreferences("c",0).getBoolean("patch",true))return r
  val p=try{findPatch(c,u,name)}catch(e:Exception){null}?:return r
  return try{val o=Patch.apply(r.second,p.second);patchMsg="Parche aplicado: "+p.first;Pair(r.first,o)}
  catch(e:Exception){patchMsg="No se pudo aplicar "+p.first+": "+(e.message?:"error");r}}
 private const val PMAX=64 shl 20
 private fun readAll(c:Context,u:String):ByteArray?{
  val i:InputStream=(if(u.startsWith("/"))FileInputStream(u) else c.contentResolver.openInputStream(Uri.parse(u)))?:return null
  return i.use{val b=it.readBytes();if(b.size>PMAX)null else b}}
 private fun isPatchExt(n:String,base:String)=n.substringBeforeLast('.')==base&&Patch.isPatch(n) // base idéntica (distingue mayúsculas); la extensión da igual
 /** Busca el parche de una ROM: 1) el que el usuario eligió a mano con el selector (guardado por nombre base), 2) un .ips/.ups con el mismo nombre base junto a la ROM
  *  (ruta de archivo o carpeta añadida con «Añadir carpeta»). Devuelve (nombre del parche, bytes). */
 private fun findPatch(c:Context,u:String,name:String):Pair<String,ByteArray>?{
  val base=name.substringBeforeLast('.')
  Lib.patchFor(c,base)?.let{pu->val b=try{readAll(c,pu)}catch(e:Exception){null};if(b!=null){val n=try{c.contentResolver.query(Uri.parse(pu),arrayOf(DC.Document.COLUMN_DISPLAY_NAME),null,null,null)?.use{q->if(q.moveToFirst())q.getString(0) else null}}catch(e:Exception){null}
   return Pair(n?:"parche",b)}}
  if(u.startsWith("/")){
   val f=File(u).parentFile?.listFiles()?.firstOrNull{it.isFile&&isPatchExt(it.name,base)}?:return null
   val b=readAll(c,f.absolutePath)?:return null;return Pair(f.name,b)}
  val du=Uri.parse(u)
  if(!DC.isDocumentUri(c,du))return null
  try{DC.getTreeDocumentId(du)}catch(e:Exception){return null} // un archivo suelto del selector no da acceso a su carpeta: ahí vale el parche elegido a mano
  val pid=parentId(c,du)?:return null
  c.contentResolver.query(DC.buildChildDocumentsUriUsingTree(du,pid),arrayOf(DC.Document.COLUMN_DOCUMENT_ID,DC.Document.COLUMN_DISPLAY_NAME),null,null,null)?.use{q->
   while(q.moveToNext()){val nm=q.getString(1)?:continue
    if(isPatchExt(nm,base)){val b=readAll(c,DC.buildDocumentUriUsingTree(du,q.getString(0)).toString())?:return null;return Pair(nm,b)}}}
  return null}
 /** Id de la carpeta que contiene el documento (de una carpeta añadida con el selector de árbol). */
 private fun parentId(c:Context,du:Uri):String?{
  if(android.os.Build.VERSION.SDK_INT>=26){try{val l=DC.findDocumentPath(c.contentResolver,du)?.path;if(l!=null&&l.size>=2)return l[l.size-2]}catch(e:Exception){}}
  val id=try{DC.getDocumentId(du)}catch(e:Exception){return null};return if(id.contains('/'))id.substringBeforeLast('/') else null}
 private fun raw(c:Context,u:String,name:String,lim:Int):Pair<String,ByteArray>?{
  val i:InputStream=(if(u.startsWith("/"))FileInputStream(u) else c.contentResolver.openInputStream(Uri.parse(u)))?:return null
  i.use{if(ext(name)!="zip")return Pair(name,rd(it,lim))
   val z=ZipInputStream(it)
   while(true){val e=z.nextEntry?:return null;if(!e.isDirectory&&ext(e.name) in ROM)return Pair(e.name.substringAfterLast('/'),rd(z,lim))}}
 }
 fun scanTree(c:Context,tree:Uri):List<Game>{
  val out=ArrayList<Game>()
  fun walk(id:String){
   c.contentResolver.query(DC.buildChildDocumentsUriUsingTree(tree,id),arrayOf(DC.Document.COLUMN_DOCUMENT_ID,DC.Document.COLUMN_DISPLAY_NAME,DC.Document.COLUMN_MIME_TYPE),null,null,null)?.use{q->
    while(q.moveToNext()){val did=q.getString(0);val nm=q.getString(1)?:continue
     if(q.getString(2)==DC.Document.MIME_TYPE_DIR)walk(did) else if(ext(nm) in EXT)out+=Game(nm,DC.buildDocumentUriUsingTree(tree,did).toString())}}}
  walk(DC.getTreeDocumentId(tree));return out}
 fun scanDevice():List<Game>{
  val out=ArrayList<Game>()
  Environment.getExternalStorageDirectory().walkTopDown().onEnter{it.name!="Android"&&!it.name.startsWith(".")}.forEach{f->
   if(f.isFile){val e=ext(f.name);if(e in ROM||(e=="zip"&&hasRom(f)))out+=Game(f.name,f.absolutePath)}}
  return out}
 private fun hasRom(f:File)=try{ZipFile(f).use{z->z.entries().asSequence().any{ext(it.name) in ROM}}}catch(e:Exception){false}
 /** Aproximación: un nombre con etiqueta de región entre paréntesis suele ser un volcado oficial. Con una base de datos CRC32 sería exacto. */
 private val OFF=Regex("\\([^)]*\\b(?:USA|Europe|Japan|World|Spain|Germany|France|Italy|UK|Australia|Korea|China|Netherlands|Sweden|Brazil|Asia|Taiwan|Canada)\\b[^)]*\\)")
 fun official(n:String)=OFF.containsMatchIn(n)
 /** Plataforma, región e idioma: del encabezado (GBA 0xAF, GBC 0x142, GB 0x14A) y de las etiquetas del nombre, p. ej. (Spain) o (En,Fr,De). */
 fun meta(c:Context,g:Game):Game{
  val r=try{load(c,g.u,g.n,0x150)}catch(e:Exception){null}
  val h=r?.second?:ByteArray(0);val e=ext(r?.first?:g.n)
  var p=when(e){"gba"->2;"gbc"->1;"gb"->0;else->-1}
  val cgb=h.size>0x143&&(h[0x143].toInt() and 0xFF).let{it==0x80||it==0xC0}
  if(p==0&&cgb)p=1
  if(p<0)p=if(h.size>0xB2&&(h[0xB2].toInt() and 0xFF)==0x96)2 else if(cgb)1 else 0
  val rg=LinkedHashSet<String>();val lg=LinkedHashSet<String>()
  fun dst(ch:Char){when(ch){'J'->{rg+="Japan";lg+="ja"};'E'->{rg+="USA";lg+="en"};'P'->{rg+="Europe";lg+="en"};'D'->{rg+="Europe";lg+="de"};'F'->{rg+="Europe";lg+="fr"};'I'->{rg+="Europe";lg+="it"};'S'->{rg+="Europe";lg+="es"};else->{}}}
  if(p==2&&h.size>0xB0){dst(h[0xAF].toInt().toChar())}
  else if(p==1&&cgb&&h.size>0x142&&(0x13F..0x142).all{h[it].toInt().toChar() in 'A'..'Z'}){dst(h[0x142].toInt().toChar())}
  else if(p<2&&h.size>0x14A&&h[0x14A].toInt()==0){rg+="Japan"}
  Regex("\\(([^)]*)\\)").findAll(g.n).forEach{m->val t=m.groupValues[1]
   if(Regex("[A-Z][a-z](,[A-Z][a-z])*").matches(t))t.split(",").forEach{lg+=it.lowercase()}
   t.split(",").map{it.trim()}.forEach{w->when(w){"USA"->{rg+="USA";lg+="en"};"Europe","UK","Netherlands","Sweden"->{rg+="Europe"};"Spain"->{rg+="Europe";lg+="es"};"Germany"->{rg+="Europe";lg+="de"};"France"->{rg+="Europe";lg+="fr"};"Italy"->{rg+="Europe";lg+="it"};"Japan"->{rg+="Japan";lg+="ja"};"World"->{rg+="USA";rg+="Europe";rg+="Japan"};else->{}}}}
  return g.copy(p=p,reg=rg.joinToString(","),lang=lg.joinToString(","))}
}
/** Carpeta virtual del menú. icon: un emoji, o "img" si tiene imagen propia (filesDir/icons/id.png). */
data class Folder(val id:String,val name:String,val icon:String="📁")
object Lib{
 private fun sp(c:Context)=c.getSharedPreferences("lib",0)
 fun all(c:Context):MutableList<Game>{val a=JSONArray(sp(c).getString("g","[]"));return MutableList(a.length()){val o=a.getJSONObject(it)
  Game(o.getString("n"),o.getString("u"),o.optInt("p",-1),o.optString("r",""),o.optString("l",""),o.optLong("a",0),o.optLong("t",0),o.optBoolean("f",false),o.optInt("y",0),o.optString("g",""),o.optString("o",""))}}
 fun save(c:Context,l:List<Game>){val a=JSONArray();l.forEach{a.put(JSONObject().put("n",it.n).put("u",it.u).put("p",it.p).put("r",it.reg).put("l",it.lang).put("a",it.added).put("t",it.played).put("f",it.fav).put("y",it.year).put("g",it.genre).put("o",it.fo))};sp(c).edit().putString("g",a.toString()).apply()}
 /** Parches elegidos a mano con el selector de archivos: nombre base del juego → URI del parche (se aplican aunque el juego no se añadiera como carpeta). */
 @Synchronized private fun pt(c:Context)=try{JSONObject(sp(c).getString("pt","{}"))}catch(e:Exception){JSONObject()}
 fun patchFor(c:Context,base:String):String?=pt(c).optString(base,"").ifEmpty{null}
 @Synchronized fun setPatch(c:Context,base:String,u:String){val o=pt(c);o.put(base,u);sp(c).edit().putString("pt",o.toString()).apply()}
 fun add(c:Context,n:List<Game>):Int=addG(c,n).size
 /** Igual que add, pero devuelve los juegos realmente nuevos. */
 @Synchronized fun addG(c:Context,n:List<Game>):List<Game>{val l=all(c);val have=l.map{it.u}.toSet();val now=System.currentTimeMillis()
  val nw=n.filter{it.u !in have}.distinctBy{it.u}.map{Roms.meta(c,it.copy(added=now))};l+=nw;save(c,l);return nw}
 @Synchronized fun upd(c:Context,gs:List<Game>){val m=gs.associateBy{it.u};save(c,all(c).map{m[it.u]?:it})}
 @Synchronized fun del(c:Context,u:String){save(c,all(c).filter{it.u!=u})}
 fun folders(c:Context):MutableList<Folder>{val a=JSONArray(sp(c).getString("f","[]"));return MutableList(a.length()){val o=a.getJSONObject(it);Folder(o.getString("i"),o.getString("n"),o.optString("c","📁"))}}
 fun saveFolders(c:Context,l:List<Folder>){val a=JSONArray();l.forEach{a.put(JSONObject().put("i",it.id).put("n",it.name).put("c",it.icon))};sp(c).edit().putString("f",a.toString()).apply()}
 @Synchronized fun newFolder(c:Context,n:String):Folder{val f=Folder("f"+System.currentTimeMillis().toString(36),n);val l=folders(c);l+=f;saveFolders(c,l);return f}
}
