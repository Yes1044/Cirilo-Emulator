package app.cirilo
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract as DC
import org.json.*
import java.io.*
import java.util.zip.*
class Game(val n:String,val u:String){val title get()=n.substringBeforeLast('.')}
/** Acceso a ROMs: rutas de archivo (escaneo global), URIs de Android (selector/carpetas) y .zip (extrae la primera ROM). */
object Roms{
 val ROM=setOf("gb","gbc","gba");val EXT=ROM+"zip"
 fun ext(n:String)=n.substringAfterLast('.',"").lowercase()
 fun load(c:Context,u:String,name:String):Pair<String,ByteArray>?{
  val i:InputStream=(if(u.startsWith("/"))FileInputStream(u) else c.contentResolver.openInputStream(Uri.parse(u)))?:return null
  i.use{if(ext(name)!="zip")return Pair(name,it.readBytes())
   val z=ZipInputStream(it)
   while(true){val e=z.nextEntry?:return null;if(!e.isDirectory&&ext(e.name) in ROM)return Pair(e.name.substringAfterLast('/'),z.readBytes())}}
 }
 fun scanTree(c:Context,tree:Uri):List<Game>{
  val out=ArrayList<Game>()
  fun walk(id:String){
   c.contentResolver.query(DC.buildChildDocumentsUriUsingTree(tree,id),arrayOf(DC.Document.COLUMN_DOCUMENT_ID,DC.Document.COLUMN_DISPLAY_NAME,DC.Document.COLUMN_MIME_TYPE),null,null,null)?.use{q->
    while(q.moveToNext()){val did=q.getString(0);val nm=q.getString(1)?:continue
     if(q.getString(2)==DC.Document.MIME_TYPE_DIR)walk(did) else if(ext(nm) in EXT)out+=Game(nm,DC.buildDocumentUriUsingTree(tree,did).toString())}}}
  walk(DC.getTreeDocumentId(tree));return out}
 fun scanDevice():List<Game>{
  val out=ArrayList<Game>()
  Environment.getExternalStorageDirectory().walkTopDown().onEnter{it.name!="Android"&&!it.name.startsWith(".")}.forEach{f->
   if(f.isFile){val e=ext(f.name);if(e in ROM||(e=="zip"&&hasRom(f)))out+=Game(f.name,f.absolutePath)}}
  return out}
 private fun hasRom(f:File)=try{ZipFile(f).use{z->z.entries().asSequence().any{ext(it.name) in ROM}}}catch(e:Exception){false}
}
object Lib{
 private fun sp(c:Context)=c.getSharedPreferences("lib",0)
 fun all(c:Context):MutableList<Game>{val a=JSONArray(sp(c).getString("g","[]"));return MutableList(a.length()){val o=a.getJSONObject(it);Game(o.getString("n"),o.getString("u"))}}
 fun save(c:Context,l:List<Game>){val a=JSONArray();l.forEach{a.put(JSONObject().put("n",it.n).put("u",it.u))};sp(c).edit().putString("g",a.toString()).apply()}
 @Synchronized fun add(c:Context,n:List<Game>):Int{val l=all(c);val have=l.map{it.u}.toSet();val nw=n.filter{it.u !in have}.distinctBy{it.u};l+=nw;l.sortBy{it.title.lowercase()};save(c,l);return nw.size}
}
