package com.fastemulator.gba;

import java.nio.ByteBuffer;

/** Réplica de la clase JNI Link de My Boy (ver Console.java). */
public final class Link {
    static { System.loadLibrary("gba"); }

    private static final Link INSTANCE = new Link();
    public static Link get() { return INSTANCE; }
    private Link() {}

    public static native ByteBuffer allocateBuffer(int size);
    public static native void deallocateBuffer(ByteBuffer b);
    public static native int patch(ByteBuffer rom, int len, byte[] patch);

    private native long nativeOpenConsole(String id, int n);
    private native void nativeCloseConsole(Console c);

    public native void loadBios(byte[] bios);
    public native String loadRom(ByteBuffer rom, int len);
    public native void runFrame(boolean flag);
    public native void unloadRom(String id);

    /** Abre una consola sobre una ROM ya cargada con loadRom(). null si el núcleo no la creó. */
    public Console open(String id, int n) {
        long h = nativeOpenConsole(id, n);
        return h == 0L ? null : new Console(h, this);
    }
    public void close(Console c) { nativeCloseConsole(c); }
}
