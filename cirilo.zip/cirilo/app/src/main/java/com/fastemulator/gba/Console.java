package com.fastemulator.gba;

import java.nio.Buffer;

/**
 * Réplica de la clase JNI de My Boy. libgba.so exporta Java_com_fastemulator_gba_Console_* , así que
 * el paquete, el nombre y las firmas de los métodos nativos deben ser EXACTAMENTE estos.
 * El nombre del campo nativeConsole también (el código nativo lo busca por nombre).
 */
public final class Console {
    public interface GameSaveListener { void onGameSaved(boolean ok); }

    static {
        System.loadLibrary("gba");
        nativeInitIds();
    }

    private long nativeConsole;
    final Link link;

    Console(long nativeConsole, Link link) {
        this.nativeConsole = nativeConsole;
        this.link = link;
    }

    private static native void nativeInitIds();
    public static native void setGameSaveListener(GameSaveListener l);

    public native int addCheat(String a, String b, boolean c);
    public native void clearCheats();
    public native void enableCheat(int i, boolean on);
    public native void enableRumble(boolean on);
    public native void enableSound(boolean on);
    public native int getAudioSamples(short[] out, int n);
    public native byte[] getRomCode();
    public native String getRomHash();
    public native boolean getRumblePattern(long[] p);
    public native void loadBattery(String path);
    public native int loadState(String path);
    public native int loadStateFromMemory(byte[] b);
    public native void reset(boolean hard);
    public native void saveBattery();
    public native int saveState(String path);
    public native byte[] saveStateToMemory();
    public native void setGyroValue(int v);
    public native void setKeys(int keys);
    public native void setOption(String k, String v);
    public native void setScreenBuffer(Buffer b);
    public native void setSolarValue(int v);
    public native void setTiltValue(int x, int y);

    long handle() { return nativeConsole; }
}
