cmake_minimum_required(VERSION 3.22)
project(cirilo CXX)
add_library(cirilo SHARED jni.cpp)
target_link_libraries(cirilo dl log)
