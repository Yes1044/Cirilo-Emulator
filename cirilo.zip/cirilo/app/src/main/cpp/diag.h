// Diagnóstico avanzado del JIT (Cirilo). Se ejecuta DENTRO del teléfono, sobre la partida abierta y con el emulador parado: guarda el estado, y con ESE MISMO estado ejecuta la misma escena varias veces
// con configuraciones distintas del JIT (apagado, solo despachador, nativo sin memoria, completo, sin memoria en línea, con PUSH/POP, sin filtro de ganancia), intercaladas en varias vueltas para
// que la temperatura y la frecuencia afecten a todas por igual, y mide el tiempo de CPU del hilo (no el reloj de pared), los contadores de hardware (si Android los deja leer) y los del propio JIT.
// Con eso escribe un informe con el reparto del coste y un veredicto de dónde se pierde el tiempo. Al terminar devuelve el emulador al estado y al modo en que estaba.
// Este archivo no depende de JNI ni de libretro: jni.cpp le pasa las funciones del núcleo (y las pruebas locales, las suyas).
#pragma once
#include <vector>
#include <string>
#include <functional>
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <cerrno>
#include <cmath>
#include <ctime>
#include <set>
#include <sched.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <linux/perf_event.h>

struct DiagIf {
 std::function<void()> run;                       // un fotograma (retro_run)
 std::function<size_t()> ssz;                     // tamaño del estado
 std::function<bool(void*,size_t)> ser;           // guarda el estado
 std::function<bool(const void*,size_t)> unser;   // lo carga
 std::function<void(int)> jset;                   // modo del JIT (vacía la caché): 0 apagado, 1 normal, 2 solo despachador, 3 nativo sin memoria
 std::function<void(int)> jdiag;                  // interruptores de diagnóstico (cirilo_jit_diag), antes de jset
 std::function<void(uint64_t*)> jread;            // contadores de diagnóstico del JIT (cirilo_jit_diag_read)
 std::function<int(uint32_t*)> jstats;            // cirilo_jit_stats
 std::function<void(uint64_t*)> pcum;             // medidor de CPU acumulado: [0] bucle, [1] eventos, [2] vídeo, [3] audio (ticks)
 std::function<uint64_t()> pfreq;                 // ticks por segundo del medidor
 std::function<void()> beforeFrame;               // p. ej. vaciar el búfer de audio
 std::function<uint64_t()> frameHash;             // hash de la última imagen
 int origMode=0;                                  // modo del JIT con el que estaba el juego
 bool hasJit=false;                               // el núcleo trae el JIT
 int frames=300,warm=90,rounds=4;                 // fotogramas medidos, de calentamiento y vueltas por configuración
 bool quick=false;                                // solo apagado / completo / completo con tiempos
 bool allClusters=true;                           // repetir en el núcleo de CPU más rápido y en el más lento
};

namespace diag {
static inline double cpuUs(){timespec t;clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t);return t.tv_sec*1e6+t.tv_nsec/1e3;}
static inline uint64_t fnv(const void*p,size_t n,uint64_t h=1469598103934665603ull){const uint8_t*b=(const uint8_t*)p;for(size_t i=0;i<n;i++){h^=b[i];h*=1099511628211ull;}return h;}
static long rdFile(const char*path){long v=-1;if(FILE*f=fopen(path,"r")){if(fscanf(f,"%ld",&v)!=1)v=-1;fclose(f);}return v;}

// ---- contadores de hardware (perf_event_open sobre el propio hilo; Android suele prohibirlo: entonces se dice por qué) ----
struct Perf{
 enum{CYC,INS,BRM,L1IM,L1DM,LLCM,N};
 int fd[N];bool ok=false;int err=0;
 static int open1(uint32_t type,uint64_t cfg){perf_event_attr a;memset(&a,0,sizeof a);a.type=type;a.size=sizeof a;a.config=cfg;a.disabled=1;a.exclude_kernel=1;a.exclude_hv=1;
  return (int)syscall(__NR_perf_event_open,&a,0,-1,-1,0);}
 void init(){for(int i=0;i<N;i++)fd[i]=-1;
  fd[CYC]=open1(PERF_TYPE_HARDWARE,PERF_COUNT_HW_CPU_CYCLES);if(fd[CYC]<0){err=errno;return;}
  fd[INS]=open1(PERF_TYPE_HARDWARE,PERF_COUNT_HW_INSTRUCTIONS);
  fd[BRM]=open1(PERF_TYPE_HARDWARE,PERF_COUNT_HW_BRANCH_MISSES);
  fd[L1IM]=open1(PERF_TYPE_HW_CACHE,PERF_COUNT_HW_CACHE_L1I|(PERF_COUNT_HW_CACHE_OP_READ<<8)|((uint64_t)PERF_COUNT_HW_CACHE_RESULT_MISS<<16));
  fd[L1DM]=open1(PERF_TYPE_HW_CACHE,PERF_COUNT_HW_CACHE_L1D|(PERF_COUNT_HW_CACHE_OP_READ<<8)|((uint64_t)PERF_COUNT_HW_CACHE_RESULT_MISS<<16));
  fd[LLCM]=open1(PERF_TYPE_HARDWARE,PERF_COUNT_HW_CACHE_MISSES);
  ok=true;}
 void start(){if(!ok)return;for(int i=0;i<N;i++)if(fd[i]>=0){ioctl(fd[i],PERF_EVENT_IOC_RESET,0);ioctl(fd[i],PERF_EVENT_IOC_ENABLE,0);}}
 void stop(double*v){for(int i=0;i<N;i++)v[i]=-1;if(!ok)return;for(int i=0;i<N;i++)if(fd[i]>=0){ioctl(fd[i],PERF_EVENT_IOC_DISABLE,0);uint64_t x=0;if(read(fd[i],&x,8)==8)v[i]=(double)x;}}
 void close_(){for(int i=0;i<N;i++)if(fd[i]>=0){close(fd[i]);fd[i]=-1;}ok=false;}
};

struct Cfg{const char*name;const char*desc;int mode,flags;};
static const Cfg CFGS[]={
 {"intérprete","JIT apagado (referencia)",0,0},
 {"solo despachador","bloques y búsqueda, sin código nativo",2,0},
 {"nativo sin memoria","código nativo solo para aritmética y saltos",3,0},
 {"completo","como se usa en el juego",1,0},
 {"sin memoria en línea","accesos IWRAM/EWRAM por funciones de C",1,1},
 {"con PUSH/POP nativos","PUSH/POP/LDM/STM traducidos (ya no es lo normal)",1,2},
 {"sin filtro de ganancia","todo tramo posible va a nativo",1,4},
 {"completo + tiempos","igual que completo, midiendo dentro de las funciones de C",1,8},
 {"sin encadenado","los bloques nativos no saltan directamente entre sí",1,16},
 {"solo despachador + gancho","sin código nativo; el código frío en el bucle apretado, solo los saltos tomados consultan",2,32},
 {"completo + gancho","como completo, pero el código frío va en el bucle apretado (sin bloques)",1,32},
};
enum{C_OFF,C_A,C_B,C_FULL,C_NOINL,C_NOSTEP,C_NOGATE,C_TIME,C_NOCHAIN,C_AH,C_HOOK,C_N};

struct Res{
 std::vector<float> all;        // todas las muestras (us de CPU del hilo por fotograma)
 std::vector<float> best;       // por fotograma, el mínimo entre vueltas
 double split[4]={0,0,0,0};     // ticks: bucle, eventos totales, vídeo, audio (sumados)
 double ctr[9]={0};             // contadores del JIT (suma)
 double st[32]={0};             // cirilo_jit_stats (diferencias, suma)
 double perf[Perf::N]={0,0,0,0,0,0};bool perfOk=false;
 double warmUs=0;int warmN=0;   // tiempo de CPU de los fotogramas de calentamiento (incluye traducir)
 std::set<std::pair<uint64_t,uint64_t>> hashes;
 double mhzMin=1e9,mhzMax=0;
 int nf=0,rounds=0;
 uint64_t codeWords=0;
};
static double med(std::vector<float> v){if(v.empty())return 0;size_t m=v.size()/2;std::nth_element(v.begin(),v.begin()+m,v.end());return v[m];}
static double pct(std::vector<float> v,double p){if(v.empty())return 0;size_t m=(size_t)((v.size()-1)*p);std::nth_element(v.begin(),v.begin()+m,v.end());return v[m];}

struct ClusterRun{int cpu;long maxMhz;Res r[C_N];bool done[C_N];};

static std::string line(const char*fmt,...)__attribute__((format(printf,1,2)));
static std::string line(const char*fmt,...){char b[600];va_list ap;va_start(ap,fmt);vsnprintf(b,sizeof b,fmt,ap);va_end(ap);return b;}

// Núcleos de CPU del teléfono agrupados por frecuencia máxima: devuelve el más rápido y el más lento (o uno solo si no se puede leer / son iguales).
static std::vector<std::pair<int,long>> clusters(){
 int n=(int)sysconf(_SC_NPROCESSORS_CONF);if(n<1)n=1;if(n>64)n=64;std::vector<std::pair<int,long>> all;
 for(int c=0;c<n;c++){char p[96];snprintf(p,sizeof p,"/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq",c);long k=rdFile(p);if(k>0)all.push_back({c,k/1000});}
 std::vector<std::pair<int,long>> out;if(all.empty())return out;
 auto hi=*std::max_element(all.begin(),all.end(),[](auto&a,auto&b){return a.second<b.second;});
 auto lo=*std::min_element(all.begin(),all.end(),[](auto&a,auto&b){return a.second<b.second;});
 out.push_back(hi);if(lo.second!=hi.second)out.push_back(lo);return out;}

static void setAff(int cpu,cpu_set_t*old,bool*had){if(old&&had)*had=sched_getaffinity(0,sizeof *old,old)==0;cpu_set_t s;CPU_ZERO(&s);CPU_SET(cpu,&s);sched_setaffinity(0,sizeof s,&s);}

// Ejecuta una configuración: estado -> calentamiento -> medida. Acumula en r.
static void runOne(DiagIf&d,const std::vector<char>&S0,const Cfg&c,Res&r,Perf&pf,int cpu,uint64_t tickF,bool firstRound,int roundIdx){
 d.jdiag(c.flags);d.jset(c.mode);d.unser(S0.data(),S0.size());
 double w0=cpuUs();for(int i=0;i<d.warm;i++){if(d.beforeFrame)d.beforeFrame();d.run();}double w1=cpuUs();
 r.warmUs+=w1-w0;r.warmN+=d.warm;
 uint64_t cc[4]={0,0,0,0},c0[4]={0,0,0,0};uint32_t s0[32]={0},s1[32]={0};uint64_t jr[9]={0};
 if(d.pcum)d.pcum(c0);if(d.hasJit&&c.mode){d.jstats(s0);d.jread(jr);} // lectura que pone a cero los contadores de diagnóstico
 char pth[96];snprintf(pth,sizeof pth,"/sys/devices/system/cpu/cpu%d/cpufreq/scaling_cur_freq",cpu);long f0=rdFile(pth);
 if(r.best.size()<(size_t)d.frames)r.best.assign(d.frames,1e30f);
 pf.start();
 for(int i=0;i<d.frames;i++){if(d.beforeFrame)d.beforeFrame();double a=cpuUs();d.run();double b=cpuUs();float t=(float)(b-a);r.all.push_back(t);if(t<r.best[i])r.best[i]=t;}
 double pv[Perf::N];pf.stop(pv);
 long f1=rdFile(pth);
 if(d.pcum){d.pcum(cc);for(int q=0;q<4;q++)r.split[q]+=(double)(cc[q]-c0[q]);}
 if(d.hasJit&&c.mode){d.jstats(s1);for(int q=0;q<32;q++)r.st[q]+=(double)(uint32_t)(s1[q]-s0[q]);d.jread(jr);for(int q=0;q<8;q++)r.ctr[q]+=(double)jr[q];r.codeWords=jr[6];}
 if(pf.ok&&pv[0]>=0){r.perfOk=true;for(int q=0;q<Perf::N;q++)if(pv[q]>=0)r.perf[q]+=pv[q];}
 for(long f:{f0,f1})if(f>0){double m=f/1000.0;r.mhzMin=std::min(r.mhzMin,m);r.mhzMax=std::max(r.mhzMax,m);}
 // identidad: imagen y estado final
 std::vector<char> st(d.ssz());uint64_t sh=0;if(d.ser(st.data(),st.size()))sh=fnv(st.data(),st.size());
 r.hashes.insert({d.frameHash?d.frameHash():0,sh});
 r.nf+=d.frames;r.rounds++;(void)tickF;(void)firstRound;(void)roundIdx;}

// Informe completo. progress: 0..1000. cancel: true para abortar (devuelve lo que haya).
static std::string run(DiagIf&d,std::atomic<int>*progress,std::atomic<bool>*cancel){
 std::string out;
 if(!d.hasJit){return "Este núcleo no trae el JIT (no es arm64 o es una build sin él): no hay nada que diagnosticar.\n";}
 size_t zs=d.ssz();std::vector<char> S0(zs);if(!zs||!d.ser(S0.data(),zs))return "No se pudo guardar el estado del juego: ¿hay un juego abierto?\n";
 uint64_t tickF=d.pfreq?d.pfreq():0;
 Perf pf;pf.init();
 std::vector<std::pair<int,long>> cl;if(d.allClusters)cl=clusters();
 std::vector<ClusterRun> runs;
 if(cl.empty()){ClusterRun cr;cr.cpu=-1;cr.maxMhz=0;memset(cr.done,0,sizeof cr.done);runs.push_back(cr);}
 for(auto&c:cl){ClusterRun cr;cr.cpu=c.first;cr.maxMhz=c.second;memset(cr.done,0,sizeof cr.done);runs.push_back(cr);}
 std::vector<int> cfgs;if(d.quick)cfgs={C_OFF,C_FULL,C_TIME};else for(int i=0;i<C_N;i++)cfgs.push_back(i);
 int total=(int)(runs.size()*cfgs.size()*d.rounds),doneN=0;
 cpu_set_t oldAff;bool hadAff=false;
 for(auto&cr:runs){
  if(cr.cpu>=0){setAff(cr.cpu,&oldAff,&hadAff);sched_yield();}
  for(int rd=0;rd<d.rounds&&!(cancel&&cancel->load());rd++){
   for(size_t k=0;k<cfgs.size();k++){int ci=cfgs[(k+rd)%cfgs.size()]; // el orden rota en cada vuelta
    if(cancel&&cancel->load())break;
    runOne(d,S0,CFGS[ci],cr.r[ci],pf,cr.cpu>=0?cr.cpu:0,tickF,rd==0,rd);cr.done[ci]=true;
    if(progress)progress->store(1000*(++doneN)/std::max(1,total));}}
  if(cr.cpu>=0&&hadAff)sched_setaffinity(0,sizeof oldAff,&oldAff);}
 pf.close_();
 // devolver el juego a como estaba
 d.jdiag(0);d.jset(d.origMode);d.unser(S0.data(),S0.size());
 if(progress)progress->store(1000);

 // ---------------------------------------------------------------- informe
 out+="=== Diagnóstico del JIT de Cirilo ===\n";
 out+=line("Misma escena para todas las configuraciones: %d fotogramas medidos tras %d de calentamiento, %d vueltas intercaladas. Tiempo = CPU del hilo del emulador (no reloj de pared).\n",d.frames,d.warm,d.rounds);
 out+=line("Contadores de hardware: %s\n",pf.err?line("NO disponibles (perf_event_open: errno %d%s)",pf.err,pf.err==13||pf.err==1?" = Android no lo permite a las apps":"").c_str():"disponibles");
 bool anyDiverge=false,anyNondet=false;
 for(auto&cr:runs){
  Res*R=cr.r;
  if(!cr.done[C_OFF]||R[C_OFF].all.empty()){continue;}
  double fps=59.7275;
  out+="\n";
  if(cr.cpu>=0)out+=line("--- Núcleo de CPU %d (máx %ld MHz); frecuencia observada %.0f-%.0f MHz ---\n",cr.cpu,cr.maxMhz,R[C_OFF].mhzMin<1e8?R[C_OFF].mhzMin:0.0,R[C_OFF].mhzMax);
  else out+="--- Núcleo de CPU del sistema (no se pudo fijar) ---\n";
  double base=med(R[C_OFF].all);
  out+="configuración             | us/fot (típico) | x tiempo real | vs intérprete | mejor caso | bucle CPU | vídeo | audio | otros\n";
  for(int ci=0;ci<C_N;ci++){if(!cr.done[ci]||R[ci].all.empty())continue;Res&r=R[ci];
   double m=med(r.all),bs=0;for(float v:r.best)bs+=v;bs/=std::max<size_t>(1,r.best.size());
   double f=tickF?1e6/tickF:0,n=std::max(1,r.nf);double loop=r.split[0]*f/n,vid=r.split[2]*f/n,aud=r.split[3]*f/n,oth=(r.split[1]-r.split[2]-r.split[3])*f/n;if(oth<0)oth=0;
   out+=line("%-25s | %15.0f | %13.1f | %+12.1f%% | %10.0f | %9.0f | %5.0f | %5.0f | %5.0f\n",CFGS[ci].name,m,1e6/m/fps,100.0*(m-base)/base,bs,loop,vid,aud,oth);
   // identidad
   if(r.hashes.size()>1)anyNondet=true;}
  // ¿mismo resultado en todas las configuraciones?
  {std::set<std::pair<uint64_t,uint64_t>> u;for(int ci=0;ci<C_N;ci++)if(cr.done[ci]&&!R[ci].hashes.empty())u.insert(*R[ci].hashes.begin());
   bool bad=false;for(int ci=0;ci<C_N;ci++)if(cr.done[ci]&&R[ci].hashes.size()==1&&u.size()>1&&*R[ci].hashes.begin()!=*R[C_OFF].hashes.begin())bad=true;
   if(bad&&R[C_OFF].hashes.size()==1)anyDiverge=true;}
  // contadores del JIT (completo)
  if(cr.done[C_FULL]&&!R[C_FULL].all.empty()){Res&r=R[C_FULL];double n=std::max(1,r.nf);
   double runsN=r.st[12]/n,natI=r.st[14]/n,instrB=r.st[2]/n,interp=r.st[3]/n,mem=r.ctr[2]/n,stp=r.ctr[3]/n,callM=r.ctr[0]/n,callS=r.ctr[1]/n;
   out+=line("\nJIT completo, por fotograma: %.0f instr. originales (%.0f%% por código nativo, %.0f por el intérprete suelto), %.0f entradas a código nativo (%.1f instr. cada una), %.0f entradas a bloques sin nativo.\n",instrB+interp,100.0*natI/std::max(1.0,instrB+interp),interp,runsN,runsN?natI/runsN:0,r.st[18]/n);
   out+=line("  accesos a memoria nativos %.0f/fot, de ellos por función de C %.0f (%.0f%% resueltos en línea); PUSH/POP/LDM/STM %.0f/fot (todos por C: %.0f); código nativo en uso %.0f palabras (%.1f KB; L1I típica 32 KB); bloques nativos creados %.0f\n",
    mem,callM,mem>0?100.0*(1-callM/mem):0.0,stp,callS,(double)r.codeWords,r.codeWords*4/1024.0,r.ctr[7]);
   out+=line("  bloques creados/fot %.2f, vaciados %.3f, invalidaciones %.2f, avisos SMC %.1f\n",r.st[0]/n,r.st[5]/n,r.st[4]/n,r.st[6]/n);
   {double th=r.st[26]/n,ar=r.st[25]/n,ai=r.st[24]/n,fr=280896.0,rest=fr-th-ar;if(rest<0)rest=0;double ti=instrB+interp;
    out+=line("  Reparto de ciclos emulados por fotograma (de %.0f): Thumb %.0f (%.0f%%), ARM %.0f (%.0f%%), resto (reposo/halt, DMA, eventos) %.0f (%.0f%%).\n",fr,th,100*th/fr,ar,100*ar/fr,rest,100*rest/fr);
    out+=line("  Instrucciones por fotograma: Thumb %.0f, ARM %.0f (%.0f%% del total). El JIT solo traduce Thumb: lo ARM corre igual que en el intérprete, así que limita lo que puede ganar.\n",ti,ai,100*ai/std::max(1.0,ti+ai));
    if(ar>th)out+=line("  Aviso: se gastan más ciclos en ARM que en Thumb. Aunque el código Thumb fuera gratis, el JIT solo podría tocar la minoría del trabajo.\n");}}
  // tiempos dentro del JIT (config con tiempos)
  double nsCall=-1,nsNat=-1,natShare=-1;
  if(cr.done[C_TIME]&&!R[C_TIME].all.empty()&&tickF){Res&r=R[C_TIME];double n=std::max(1,r.nf),f=1e9/tickF;double calls=(r.ctr[0]+r.ctr[1])/n;
   double helperNs=r.ctr[4]*f/n,natNs=r.ctr[5]*f/n; // por fotograma
   if(calls>0)nsCall=helperNs/calls; // incluye el coste del propio medidor (2 lecturas de contador)
   double nI=r.st[14]/n;if(nI>0)nsNat=(natNs-helperNs)/nI;natShare=natNs/1000.0;
   out+=line("  tiempo dentro del código nativo (con sus llamadas a C): %.0f us/fot; de ello en funciones de C: %.0f us (%.0f llamadas/fot, %.0f ns cada una incluyendo ~40 ns del propio medidor); resto (código nativo puro): %.0f us = %.1f ns por instr. original nativa\n",
    natNs/1000,helperNs/1000,calls,nsCall,(natNs-helperNs)/1000,nsNat);}
  // intérprete: ns por instrucción original
  double nsInt=-1;{Res&r=R[C_FULL];Res&o=R[C_OFF];double f=tickF?1e6/tickF:0;
   if(cr.done[C_FULL]&&!r.all.empty()&&tickF){double n=std::max(1,r.nf);double ins=(r.st[2]+r.st[3])/n;if(ins>0)nsInt=o.split[0]*f/std::max(1,o.nf)*1000.0/ins;}}
  if(nsInt>0)out+=line("  el intérprete gasta ~%.1f ns por instrucción original (bucle de CPU / instrucciones, mismas instrucciones en ambas configuraciones)\n",nsInt);
  // contadores de hardware
  if(pf.ok){
   out+="\nContadores de hardware por fotograma (solo espacio de usuario):\n";out+="configuración             | ciclos(M) | instr(M) | IPC  | fallos salto(k) | fallos L1I(k) | fallos L1D(k) | fallos LLC(k)\n";
   for(int ci=0;ci<C_N;ci++){if(!cr.done[ci]||!R[ci].perfOk)continue;Res&r=R[ci];double n=std::max(1,r.nf);auto*p=r.perf;
    out+=line("%-25s | %9.2f | %8.2f | %4.2f | %15.1f | %13.1f | %13.1f | %13.1f\n",CFGS[ci].name,p[0]/n/1e6,p[1]/n/1e6,p[0]>0?p[1]/p[0]:0.0,p[2]/n/1e3,p[3]/n/1e3,p[4]/n/1e3,p[5]/n/1e3);}}
  // ---- veredicto ----
  out+="\nVEREDICTO";if(cr.cpu>=0)out+=line(" (núcleo %d)",cr.cpu);out+=":\n";
  Res&o=R[C_OFF];double f=tickF?1e6/tickF:0;auto L=[&](int ci){return cr.done[ci]&&R[ci].nf?R[ci].split[0]*f/R[ci].nf:-1.0;};
  double Lo=L(C_OFF),La=L(C_A),Lb=L(C_B),Lf=L(C_FULL);double Tm=med(o.all),Tf=cr.done[C_FULL]?med(R[C_FULL].all):-1;
  if(Tf<0){out+="  (sin datos del modo completo)\n";continue;}
  double delta=Tf-Tm;
  if(delta<-0.03*Tm)out+=line("  El JIT completo GANA: %.1f%% menos tiempo de CPU que el intérprete en esta escena.\n",-100.0*delta/Tm);
  else if(delta<0.03*Tm)out+=line("  El JIT completo EMPATA con el intérprete (%+.1f%%): no compensa.\n",100.0*delta/Tm);
  else out+=line("  El JIT completo PIERDE: %+.1f%% de tiempo de CPU frente al intérprete (%.0f us más por fotograma).\n",100.0*delta/Tm,delta);
  if(Lo>0&&La>0&&Lb>0&&Lf>0){
   double dDis=La-Lo,dPure=Lb-La,dMem=Lf-Lb;double pos=std::max(0.0,dDis)+std::max(0.0,dPure)+std::max(0.0,dMem);
   out+=line("  Desglose del bucle de CPU frente al intérprete (us/fot): despachador %+.0f | código nativo sin memoria %+.0f | accesos y PUSH/POP %+.0f  (total %+.0f)\n",dDis,dPure,dMem,Lf-Lo);
   if(Lf>Lo*1.02){
    const char*who;double w;
    if(dDis>=dPure&&dDis>=dMem){who="DESPACHADOR";w=dDis;}else if(dPure>=dMem){who="ENTRADA/SALIDA DEL CÓDIGO NATIVO";w=dPure;}else{who="ACCESOS A MEMORIA Y PUSH/POP";w=dMem;}
    out+=line("  Mayor pérdida: %s (%+.0f us/fot, %.0f%% de lo que se pierde).\n",who,w,pos>0?100.0*w/pos:0.0);
    if(who[0]=='D'){double e=R[C_A].nf?(R[C_A].st[12]+R[C_A].st[18])/R[C_A].nf:0;out+=line("    Cada fotograma hace %.0f entradas a bloques; el despachador cuesta ~%.0f ns por entrada. Los bloques son demasiado cortos para amortizarlo: hay que encadenar o fusionar bloques.\n",R[C_FULL].st[18]/std::max(1,R[C_FULL].nf)+R[C_FULL].st[12]/std::max(1,R[C_FULL].nf),e>0?dDis*1000/e:0.0);}
    if(who[0]=='E'){double e=R[C_B].nf?R[C_B].st[12]/R[C_B].nf:0;out+=line("    %.0f entradas nativas por fotograma: ~%.0f ns por entrada (margen, prólogo/epílogo y estado de banderines) frente a unas pocas instrucciones ahorradas cada una.\n",e,e>0?dPure*1000/e:0.0);}
    if(who[0]=='A'){out+=line("    Llamadas a C por fotograma: %.0f accesos + %.0f PUSH/POP.%s\n",R[C_FULL].ctr[0]/std::max(1,R[C_FULL].nf),R[C_FULL].ctr[1]/std::max(1,R[C_FULL].nf),nsCall>0?line(" Cada una cuesta ~%.0f ns (con ~40 ns de medidor): ese es el precio de salir del código nativo.",nsCall).c_str():"");out+="\n";}}
   // efecto de cada mejora
   if(cr.done[C_NOINL]&&!R[C_NOINL].all.empty()){double t=med(R[C_NOINL].all);out+=line("  Memoria en línea: %s (%+.1f%% frente a llamar a C siempre).\n",t>Tf*1.01?"AYUDA":t<Tf*0.99?"ESTORBA":"no cambia nada",100.0*(Tf-t)/t);}
   if(cr.done[C_NOSTEP]&&!R[C_NOSTEP].all.empty()){double t=med(R[C_NOSTEP].all);out+=line("  PUSH/POP/LDM/STM nativos: %s (%+.1f%%).\n",t<Tf*0.99?"AYUDAN":t>Tf*1.01?"ESTORBAN":"no cambian nada",100.0*(t-Tf)/Tf);}
   if(cr.done[C_NOCHAIN]&&!R[C_NOCHAIN].all.empty()){double t=med(R[C_NOCHAIN].all);double hp=(R[C_FULL].st[22]+R[C_FULL].st[23])/std::max(1,R[C_FULL].nf);out+=line("  Encadenado de bloques nativos: %s (%+.1f%% frente a volver siempre al despachador; %.0f saltos directos por fotograma).\n",t>Tf*1.01?"AYUDA":t<Tf*0.99?"ESTORBA":"no cambia nada",100.0*(t-Tf)/Tf,hp);}
   if(cr.done[C_HOOK]&&!R[C_HOOK].all.empty()){double t=med(R[C_HOOK].all);out+=line("  Gancho en saltos tomados (el código frío sin agrupar en bloques): %s (%+.1f%% frente a agrupar en bloques).\n",t<Tf*0.99?"AYUDA":t>Tf*1.01?"ESTORBA":"no cambia nada",100.0*(t-Tf)/Tf);}
   if(cr.done[C_AH]&&cr.done[C_A]&&!R[C_AH].all.empty()&&!R[C_A].all.empty()&&Tm>0){double ta=med(R[C_A].all),th=med(R[C_AH].all);out+=line("  Suelo del despachador (sin una sola instrucción nativa): %+.1f%% con bloques, %+.1f%% con gancho, frente al intérprete.\n",100.0*(ta-Tm)/Tm,100.0*(th-Tm)/Tm);}
   if(cr.done[C_NOGATE]&&!R[C_NOGATE].all.empty()){double t=med(R[C_NOGATE].all);out+=line("  Filtro de ganancia (cjWorth): %s (%+.1f%% frente a dejar todo nativo).\n",t>Tf*1.01?"AYUDA":t<Tf*0.99?"ESTORBA (dejar todo nativo es más rápido)":"no cambia nada",100.0*(Tf-t)/t);}}
  if(nsNat>0&&nsInt>0)out+=line("  Código nativo puro: %.1f ns por instrucción original frente a %.1f ns del intérprete: %s.\n",nsNat,nsInt,nsNat<nsInt*0.8?"el código nativo SÍ es más rápido por instrucción":nsNat<nsInt*1.1?"prácticamente igual por instrucción (el JIT no puede ganar por esta vía)":"MÁS LENTO por instrucción (código mal generado o penalizaciones de la CPU)");
  // hardware
  if(pf.ok&&R[C_OFF].perfOk&&R[C_FULL].perfOk){auto&po=R[C_OFF].perf;auto&pj=R[C_FULL].perf;double no=std::max(1,R[C_OFF].nf),nj=std::max(1,R[C_FULL].nf);
   double ipcO=po[0]>0?po[1]/po[0]:0,ipcJ=pj[0]>0?pj[1]/pj[0]:0;
   out+=line("  Hardware: ciclos %+.1f%%, instrucciones de CPU %+.1f%%, IPC %.2f -> %.2f; fallos de salto %+.0f%%, fallos L1I %+.0f%%, fallos L1D %+.0f%%.\n",
    100.0*(pj[0]/nj-po[0]/no)/(po[0]/no),100.0*(pj[1]/nj-po[1]/no)/(po[1]/no),ipcO,ipcJ,po[2]>0?100.0*(pj[2]/nj-po[2]/no)/(po[2]/no):0.0,po[3]>0?100.0*(pj[3]/nj-po[3]/no)/(po[3]/no):0.0,po[4]>0?100.0*(pj[4]/nj-po[4]/no)/(po[4]/no):0.0);
   if(pj[1]/nj>po[1]/no*1.05)out+="    -> El JIT EJECUTA MÁS instrucciones de CPU que el intérprete: el cuello de botella es la cantidad de código (instrucciones), no las cachés.\n";
   else if(ipcJ<ipcO*0.85)out+="    -> El JIT ejecuta parecidas instrucciones pero con peor IPC: la CPU se detiene más (saltos indirectos, cachés o dependencias).\n";
   if(po[3]>0&&pj[3]/nj>po[3]/no*1.5)out+="    -> Fallos de caché de instrucciones muy superiores: el código nativo (más el despachador) no cabe en L1I.\n";
   if(po[2]>0&&pj[2]/nj>po[2]/no*1.3)out+="    -> Más fallos de predicción de saltos: llamadas/retornos indirectos del código nativo.\n";}
  // calentamiento
  if(R[C_FULL].warmN&&R[C_FULL].nf){double w=R[C_FULL].warmUs/R[C_FULL].warmN,s=R[C_FULL].all.empty()?0:med(R[C_FULL].all);if(w>s*1.1)out+=line("  Calentamiento: los primeros %d fotogramas cuestan %.0f us de media frente a %.0f en régimen: traducir bloques cuesta ~%.0f ms en total.\n",d.warm,w,s,(w-s)*d.warm/1000.0);}
  // ruido
  if(R[C_OFF].mhzMax>0&&R[C_OFF].mhzMin<1e8&&R[C_OFF].mhzMax>R[C_OFF].mhzMin*1.15)out+=line("  Aviso: la frecuencia de la CPU varió entre %.0f y %.0f MHz durante la prueba (térmica/ahorro): hay ruido de medida; las vueltas intercaladas lo reparten por igual.\n",R[C_OFF].mhzMin,R[C_OFF].mhzMax);
  {double vo=pct(R[C_OFF].all,0.9)/std::max(1.0,med(R[C_OFF].all));if(vo>1.5)out+=line("  Aviso: el intérprete tiene mucha dispersión (p90 = %.1f x mediana): la escena cambia mucho de un fotograma a otro.\n",vo);}
 }
 out+="\nIdentidad: ";
 if(anyDiverge)out+="¡DIVERGENCIA! Con el mismo estado de partida alguna configuración del JIT acabó en una imagen/estado distinto al del intérprete: es un fallo del JIT.\n";
 else if(anyNondet)out+="la escena no es determinista (RTC, azar o temporizadores reales): la comparación de imagen/estado no es concluyente. Las medidas de tiempo siguen valiendo.\n";
 else out+="OK: todas las configuraciones acabaron con la misma imagen y el mismo estado que el intérprete.\n";
 out+="Al terminar, el juego volvió al estado y al modo de JIT en que estaba.\n";
 return out;}
}
