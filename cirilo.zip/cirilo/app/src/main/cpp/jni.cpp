// Frontend libretro mínimo: carga libmgba_libretro.so con dlopen y expone lo justo a Kotlin.
#include <jni.h>
#include <dlfcn.h>
#include <cstring>
#include <vector>
#include <mutex>
#include <atomic>
#include <algorithm>
#include <cstdio>
#include "libretro.h"
static void(*p_init)();static void(*p_run)();static bool(*p_load)(const retro_game_info*);static void(*p_unload)();
static void(*p_senv)(retro_environment_t);static void(*p_svid)(retro_video_refresh_t);static void(*p_sasb)(retro_audio_sample_batch_t);static void(*p_sas)(retro_audio_sample_t);
static void(*p_sip)(retro_input_poll_t);static void(*p_sis)(retro_input_state_t);static void(*p_av)(retro_system_av_info*);
static void*(*p_mem)(unsigned);static size_t(*p_msz)(unsigned);static void(*p_cr)();static void(*p_cs)(unsigned,bool,const char*);
static std::mutex mu;static std::vector<char> frame,rom;static std::vector<int16_t> aud;static unsigned fw,fh;static std::atomic<int> K{0};static bool up=false;
static int fskip=0;static bool upd=false;static char sk[8];
static bool env(unsigned c,void*d){
 if(c==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return *(retro_pixel_format*)d==RETRO_PIXEL_FORMAT_RGB565;
 if(c==RETRO_ENVIRONMENT_GET_CAN_DUPE){*(bool*)d=true;return true;}
 if(c==RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE){*(bool*)d=upd;upd=false;return true;}
 if(c==RETRO_ENVIRONMENT_GET_VARIABLE){retro_variable*v=(retro_variable*)d;
  if(!strcmp(v->key,"mgba_frameskip")){snprintf(sk,8,"%d",fskip);v->value=sk;return true;}
  if(!strcmp(v->key,"mgba_idle_optimization")){v->value="Remove Known";return true;}}
 return false;}
static void vid(const void*d,unsigned w,unsigned h,size_t pitch){if(!d)return;std::lock_guard<std::mutex>l(mu);fw=w;fh=h;frame.resize(w*h*2);for(unsigned y=0;y<h;y++)memcpy(&frame[y*w*2],(const char*)d+y*pitch,w*2);}
static size_t asb(const int16_t*d,size_t n){std::lock_guard<std::mutex>l(mu);aud.insert(aud.end(),d,d+n*2);return n;}
static void as1(int16_t l,int16_t r){std::lock_guard<std::mutex>l2(mu);aud.push_back(l);aud.push_back(r);}
static void ip(){}
static int16_t is(unsigned port,unsigned dev,unsigned,unsigned id){return(port==0&&dev==RETRO_DEVICE_JOYPAD&&id<16)?((K>>id)&1):0;}
#define J(r,n) extern "C" JNIEXPORT r JNICALL Java_app_cirilo_Native_##n
#define SY(v,n) *(void**)&v=dlsym(h,n)
J(jboolean,load)(JNIEnv*e,jobject,jbyteArray b,jstring nm){
 if(!up){void*h=dlopen("libmgba_libretro.so",RTLD_NOW);if(!h)return 0;
  SY(p_init,"retro_init");SY(p_run,"retro_run");SY(p_load,"retro_load_game");SY(p_unload,"retro_unload_game");
  SY(p_senv,"retro_set_environment");SY(p_svid,"retro_set_video_refresh");SY(p_sasb,"retro_set_audio_sample_batch");SY(p_sas,"retro_set_audio_sample");
  SY(p_sip,"retro_set_input_poll");SY(p_sis,"retro_set_input_state");SY(p_av,"retro_get_system_av_info");
  SY(p_mem,"retro_get_memory_data");SY(p_msz,"retro_get_memory_size");SY(p_cr,"retro_cheat_reset");SY(p_cs,"retro_cheat_set");
  p_senv(env);p_init();p_svid(vid);p_sasb(asb);p_sas(as1);p_sip(ip);p_sis(is);up=true;}
 jsize n=e->GetArrayLength(b);rom.resize(n);e->GetByteArrayRegion(b,0,n,(jbyte*)rom.data());
 const char*c=e->GetStringUTFChars(nm,0);static char path[512];strncpy(path,c,511);e->ReleaseStringUTFChars(nm,c);
 retro_game_info g={path,rom.data(),rom.size(),nullptr};{std::lock_guard<std::mutex>l(mu);frame.clear();aud.clear();fw=fh=0;}
 return p_load(&g);}
J(void,unload)(JNIEnv*,jobject){if(up)p_unload();}
J(void,run)(JNIEnv*,jobject){p_run();}
J(jdoubleArray,info)(JNIEnv*e,jobject){retro_system_av_info a;p_av(&a);jdouble v[2]={a.timing.sample_rate,a.timing.fps};jdoubleArray r=e->NewDoubleArray(2);e->SetDoubleArrayRegion(r,0,2,v);return r;}
J(jint,frame)(JNIEnv*e,jobject,jobject bb){std::lock_guard<std::mutex>l(mu);if(!fw||frame.empty())return 0;if((jlong)frame.size()>e->GetDirectBufferCapacity(bb))return 0;memcpy(e->GetDirectBufferAddress(bb),frame.data(),frame.size());int r=(fw<<16)|fh;fw=0;return r;}
J(jint,audio)(JNIEnv*e,jobject,jshortArray a){std::lock_guard<std::mutex>l(mu);jsize n=std::min<size_t>(aud.size(),e->GetArrayLength(a));e->SetShortArrayRegion(a,0,n,aud.data());aud.erase(aud.begin(),aud.begin()+n);return n;}
J(void,setSkip)(JNIEnv*,jobject,jint n){fskip=n;upd=true;}
J(void,keys)(JNIEnv*,jobject,jint k){K=k;}
J(jbyteArray,getSave)(JNIEnv*e,jobject){void*m=p_mem(RETRO_MEMORY_SAVE_RAM);size_t s=p_msz(RETRO_MEMORY_SAVE_RAM);if(!m||!s)return nullptr;jbyteArray r=e->NewByteArray(s);e->SetByteArrayRegion(r,0,s,(jbyte*)m);return r;}
J(void,setSave)(JNIEnv*e,jobject,jbyteArray b){void*m=p_mem(RETRO_MEMORY_SAVE_RAM);size_t s=p_msz(RETRO_MEMORY_SAVE_RAM);jsize n=e->GetArrayLength(b);if(m&&s)e->GetByteArrayRegion(b,0,std::min<size_t>(s,n),(jbyte*)m);}
// mGBA ignora "enabled" en retro_cheat_set: se reinicia y solo se envían los códigos activos. Varias líneas de un truco se unen con '+'.
J(void,cheats)(JNIEnv*e,jobject,jobjectArray a){p_cr();jsize n=e->GetArrayLength(a);for(jsize i=0;i<n;i++){jstring s=(jstring)e->GetObjectArrayElement(a,i);const char*c=e->GetStringUTFChars(s,0);p_cs(i,true,c);e->ReleaseStringUTFChars(s,c);}}
