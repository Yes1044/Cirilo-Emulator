// Frontend libretro mínimo: carga libmgba_libretro.so (instancia 0) y libmgba2_libretro.so (instancia 1, para Link local) con dlopen y expone lo justo a Kotlin.
// Cada .so tiene sus propias variables globales, así que son dos consolas totalmente independientes; el cable entre ellas (si el núcleo trae tools/cirilo_link.c) se une con linkStart().
#include <jni.h>
#include <dlfcn.h>
#include <cstring>
#include <vector>
#include <mutex>
#include <atomic>
#include <algorithm>
#include <cstdio>
#include <cstdint>
#include <chrono>
#include <sched.h>
#include "libretro.h"
struct I{
 void*h=nullptr;bool up=false,loaded=false;
 void(*init)()=nullptr;void(*run)()=nullptr;bool(*load)(const retro_game_info*)=nullptr;void(*unload)()=nullptr;
 void(*senv)(retro_environment_t)=nullptr;void(*svid)(retro_video_refresh_t)=nullptr;void(*sasb)(retro_audio_sample_batch_t)=nullptr;void(*sas)(retro_audio_sample_t)=nullptr;
 void(*sip)(retro_input_poll_t)=nullptr;void(*sis)(retro_input_state_t)=nullptr;void(*av)(retro_system_av_info*)=nullptr;
 void*(*mem)(unsigned)=nullptr;size_t(*msz)(unsigned)=nullptr;
 // API de trucos tipada (tools/cirilo_cheats.c, añadida al núcleo en el workflow). Si el núcleo no la trae, valen null y la app lo avisa.
 int(*cc)(int,const char*,int*)=nullptr;int(*ca)(int,const int*,const char**,int*)=nullptr;int(*cp)(const char*,int*)=nullptr;
 size_t(*ssz)()=nullptr;bool(*ser)(void*,size_t)=nullptr;bool(*unser)(const void*,size_t)=nullptr;void(*reset)()=nullptr;
 // API del cable (tools/cirilo_link.c, opcional): crear/destruir el coordinador compartido, conectar/desconectar esta consola y soltar a quien espera mientras se pausa.
 int(*ldbg)(char*,int)=nullptr;void(*ptake)(uint64_t*)=nullptr;void*(*lcreate)()=nullptr;int(*lattach)(void*,int)=nullptr;void(*ldetach)(void*,int)=nullptr;void(*ldestroy)(void*)=nullptr;void(*lintr)(void*,int)=nullptr;int(*lidle)(void*)=nullptr;void(*lresync)(void*,int)=nullptr;
 std::mutex mu;std::vector<char> frame,rom;std::vector<int16_t> aud;unsigned fw=0,fh=0,lw=0,lh=0;std::atomic<int> K{0};
 void(*aset)(int,int,int,int)=nullptr;void(*apost)()=nullptr; // ajustes avanzados (tools/cirilo_adv.c, opcional)
 int useBios=1,skipBios=0,idle=1,saveT=0,mosaic=1,sgbB=0,gbS=0,gbcS=0;char sysdir[512]={0}; // se rellenan desde Kotlin (advConfig) antes de cargar el juego
 int fskip=0;bool upd=false;char sk[8]={0};char path[512]={0};
};
static I G[2];static void*lk=nullptr;static char lerr[600]={0};static char ldir[400]={0};
static const char*LIB[2]={"libmgba_libretro.so","libmgba2_libretro.so"};
// los callbacks de libretro no llevan contexto: uno por instancia (plantilla con el número)
template<int N> static bool env_t(unsigned c,void*d){I&s=G[N];
 if(c==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return *(retro_pixel_format*)d==RETRO_PIXEL_FORMAT_RGB565;
 if(c==RETRO_ENVIRONMENT_GET_CAN_DUPE){*(bool*)d=true;return true;}
 if(c==RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY){if(!s.sysdir[0])return false;*(const char**)d=s.sysdir;return true;} // aquí están gba_bios.bin, gbc_bios.bin y gb_bios.bin que eligió el usuario
 if(c==RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE){*(bool*)d=s.upd;s.upd=false;return true;}
 if(c==RETRO_ENVIRONMENT_GET_VARIABLE){retro_variable*v=(retro_variable*)d;
  if(!strcmp(v->key,"mgba_frameskip")){snprintf(s.sk,8,"%d",s.fskip);v->value=s.sk;return true;}
  if(!strcmp(v->key,"mgba_use_bios")){v->value=s.useBios?"ON":"OFF";return true;}
  if(!strcmp(v->key,"mgba_skip_bios")){v->value=s.skipBios?"ON":"OFF";return true;}
  if(!strcmp(v->key,"mgba_sgb_borders")){v->value=s.sgbB?"ON":"OFF";return true;}
  if(!strcmp(v->key,"mgba_idle_optimization")){v->value=s.idle?"Detect and Remove":"Don't Remove";return true;}}
 return false;}
template<int N> static void vid_t(const void*d,unsigned w,unsigned h,size_t pitch){if(!d)return;I&s=G[N];std::lock_guard<std::mutex>l(s.mu);s.fw=w;s.fh=h;s.lw=w;s.lh=h;s.frame.resize(w*h*2);for(unsigned y=0;y<h;y++)memcpy(&s.frame[y*w*2],(const char*)d+y*pitch,w*2);}
template<int N> static size_t asb_t(const int16_t*d,size_t n){I&s=G[N];std::lock_guard<std::mutex>l(s.mu);s.aud.insert(s.aud.end(),d,d+n*2);return n;}
template<int N> static void as1_t(int16_t l,int16_t r){I&s=G[N];std::lock_guard<std::mutex>l2(s.mu);s.aud.push_back(l);s.aud.push_back(r);}
static void ip(){}
template<int N> static int16_t is_t(unsigned port,unsigned dev,unsigned,unsigned id){return(port==0&&dev==RETRO_DEVICE_JOYPAD&&id<16)?((G[N].K>>id)&1):0;}
template<int N> static void wire(){I&s=G[N];s.senv(env_t<N>);s.init();s.svid(vid_t<N>);s.sasb(asb_t<N>);s.sas(as1_t<N>);s.sip(ip);s.sis(is_t<N>);}
#define J(r,n) extern "C" JNIEXPORT r JNICALL Java_app_cirilo_Native_##n
#define SY(v,n) *(void**)&s.v=dlsym(s.h,n)
#define GI I&s=G[i&1]
static int firstLoaded(){return G[0].loaded?0:(G[1].loaded?1:0);}
J(jboolean,load)(JNIEnv*e,jobject,jint i,jbyteArray b,jstring nm){GI;
 if(!s.up){char pa[512];snprintf(pa,sizeof pa,"%s/%s",ldir,LIB[i&1]);s.h=ldir[0]?dlopen(pa,RTLD_NOW):nullptr;char e1[300]={0};if(!s.h){const char*d=dlerror();snprintf(e1,sizeof e1,"%s",d?d:"");}
  if(!s.h)s.h=dlopen(LIB[i&1],RTLD_NOW);if(!s.h){const char*d=dlerror();snprintf(lerr,sizeof lerr,"[ruta] %s | [nombre] %s",e1,d?d:"dlopen falló");return 0;}
  SY(init,"retro_init");SY(run,"retro_run");SY(load,"retro_load_game");SY(unload,"retro_unload_game");
  SY(senv,"retro_set_environment");SY(svid,"retro_set_video_refresh");SY(sasb,"retro_set_audio_sample_batch");SY(sas,"retro_set_audio_sample");
  SY(sip,"retro_set_input_poll");SY(sis,"retro_set_input_state");SY(av,"retro_get_system_av_info");
  SY(ssz,"retro_serialize_size");SY(ser,"retro_serialize");SY(unser,"retro_unserialize");SY(reset,"retro_reset");SY(mem,"retro_get_memory_data");SY(msz,"retro_get_memory_size");SY(cc,"cirilo_cheat_check");SY(ca,"cirilo_cheat_apply");SY(cp,"cirilo_cheat_probe");
  SY(lcreate,"cirilo_link_create");SY(lattach,"cirilo_link_attach");SY(ldetach,"cirilo_link_detach");SY(ldestroy,"cirilo_link_destroy");SY(lintr,"cirilo_link_interrupt");SY(lidle,"cirilo_link_idle");SY(lresync,"cirilo_link_resync");SY(ldbg,"cirilo_link_dbg");SY(ptake,"cirilo_prof_take");SY(aset,"cirilo_adv_set");SY(apost,"cirilo_adv_post");
  if(i&1)wire<1>();else wire<0>();s.up=true;}
 jsize n=e->GetArrayLength(b);s.rom.resize(n);e->GetByteArrayRegion(b,0,n,(jbyte*)s.rom.data());
 const char*c=e->GetStringUTFChars(nm,0);strncpy(s.path,c,511);e->ReleaseStringUTFChars(nm,c);
 retro_game_info g={s.path,s.rom.data(),s.rom.size(),nullptr};{std::lock_guard<std::mutex>l(s.mu);s.frame.clear();s.aud.clear();s.fw=s.fh=0;}
 if(s.aset)s.aset(s.saveT,s.mosaic,s.gbS,s.gbcS);
 s.loaded=s.load(&g);if(s.loaded&&s.apost)s.apost();return s.loaded;}
// Ajustes avanzados de la consola i (valen para la próxima carga). saveT: 0 auto, 1 EEPROM, 2 SRAM, 3 Flash 64K, 4 Flash 128K, 5 ninguno.
J(void,advConfig)(JNIEnv*e,jobject,jint i,jboolean useBios,jboolean skipBios,jboolean idle,jint saveT,jboolean mosaic,jboolean sgbB,jint gbS,jint gbcS,jstring dir){GI;s.sgbB=sgbB;s.gbS=gbS;s.gbcS=gbcS;s.useBios=useBios;s.skipBios=skipBios;s.idle=idle;s.saveT=saveT;s.mosaic=mosaic;
 const char*c=e->GetStringUTFChars(dir,0);snprintf(s.sysdir,sizeof s.sysdir,"%s",c);e->ReleaseStringUTFChars(dir,c);}
J(void,unload)(JNIEnv*,jobject,jint i){GI;if(s.up&&s.loaded){s.unload();s.loaded=false;}}
J(void,run)(JNIEnv*,jobject,jint i){GI;s.run();}
J(jdoubleArray,info)(JNIEnv*e,jobject,jint i){GI;retro_system_av_info a;s.av(&a);jdouble v[2]={a.timing.sample_rate,a.timing.fps};jdoubleArray r=e->NewDoubleArray(2);e->SetDoubleArrayRegion(r,0,2,v);return r;}
J(jint,frame)(JNIEnv*e,jobject,jint i,jobject bb){GI;std::lock_guard<std::mutex>l(s.mu);if(!s.fw||s.frame.empty())return 0;if((jlong)s.frame.size()>e->GetDirectBufferCapacity(bb))return 0;memcpy(e->GetDirectBufferAddress(bb),s.frame.data(),s.frame.size());int r=(s.fw<<16)|s.fh;s.fw=0;return r;}
J(jint,audio)(JNIEnv*e,jobject,jint i,jshortArray a){GI;std::lock_guard<std::mutex>l(s.mu);jsize n=std::min<size_t>(s.aud.size(),e->GetArrayLength(a));e->SetShortArrayRegion(a,0,n,s.aud.data());s.aud.erase(s.aud.begin(),s.aud.begin()+n);return n;}
J(void,reset)(JNIEnv*,jobject,jint i){GI;if(s.loaded)s.reset();}
J(jbyteArray,saveState)(JNIEnv*e,jobject,jint i){GI;if(!s.loaded)return nullptr;size_t z=s.ssz();if(!z)return nullptr;std::vector<char> v(z);if(!s.ser(v.data(),z))return nullptr;jbyteArray r=e->NewByteArray(z);e->SetByteArrayRegion(r,0,z,(jbyte*)v.data());return r;}
J(jboolean,loadState)(JNIEnv*e,jobject,jint i,jbyteArray b){GI;if(!s.loaded)return 0;jsize n=e->GetArrayLength(b);std::vector<char> v(n);e->GetByteArrayRegion(b,0,n,(jbyte*)v.data());return s.unser(v.data(),n);}
J(jint,last)(JNIEnv*e,jobject,jint i,jobject bb){GI;std::lock_guard<std::mutex>l(s.mu);if(s.frame.empty()||!s.lw||(jlong)s.frame.size()>e->GetDirectBufferCapacity(bb))return 0;memcpy(e->GetDirectBufferAddress(bb),s.frame.data(),s.frame.size());return(s.lw<<16)|s.lh;}
J(void,setSkip)(JNIEnv*,jobject,jint i,jint n){GI;s.fskip=n;s.upd=true;}
J(void,keys)(JNIEnv*,jobject,jint i,jint k){GI;s.K=k;}
J(jbyteArray,getSave)(JNIEnv*e,jobject,jint i){GI;if(!s.loaded)return nullptr;void*m=s.mem(RETRO_MEMORY_SAVE_RAM);size_t z=s.msz(RETRO_MEMORY_SAVE_RAM);if(!m||!z)return nullptr;jbyteArray r=e->NewByteArray(z);e->SetByteArrayRegion(r,0,z,(jbyte*)m);return r;}
J(void,setSave)(JNIEnv*e,jobject,jint i,jbyteArray b){GI;if(!s.loaded)return;void*m=s.mem(RETRO_MEMORY_SAVE_RAM);size_t z=s.msz(RETRO_MEMORY_SAVE_RAM);jsize n=e->GetArrayLength(b);if(m&&z)e->GetByteArrayRegion(b,0,std::min<size_t>(z,n),(jbyte*)m);}
// ---- trucos. -9999 = el núcleo no incluye cirilo_cheats.c. Estas llamadas solo se hacen con el emulador parado o desde su hilo (entre fotogramas). cheatCheck/cheatProbe (editor de trucos) usan la primera consola abierta. ----
J(jintArray,cheatCheck)(JNIEnv*e,jobject,jint mode,jstring t){I&s=G[firstLoaded()];int info[1]={0};int r=-9999;if(s.up&&s.cc){const char*c=e->GetStringUTFChars(t,0);r=s.cc(mode,c,info);e->ReleaseStringUTFChars(t,c);}
 jint v[2]={r,info[0]};jintArray a=e->NewIntArray(2);e->SetIntArrayRegion(a,0,2,v);return a;}
J(jintArray,cheatProbe)(JNIEnv*e,jobject,jstring t){I&s=G[firstLoaded()];int sc[4]={0,0,0,0};if(!s.up||!s.cp)return nullptr;const char*c=e->GetStringUTFChars(t,0);int r=s.cp(c,sc);e->ReleaseStringUTFChars(t,c);if(r!=0)return nullptr;
 jintArray a=e->NewIntArray(4);e->SetIntArrayRegion(a,0,4,sc);return a;}
J(jintArray,cheatApply)(JNIEnv*e,jobject,jint i,jintArray modes,jobjectArray texts){GI;jsize n=e->GetArrayLength(texts);std::vector<jint> m(n);std::vector<int> st(n,-9999);std::vector<const char*> t(n);std::vector<jstring> js(n);
 if(n)e->GetIntArrayRegion(modes,0,n,m.data());for(jsize k=0;k<n;k++){js[k]=(jstring)e->GetObjectArrayElement(texts,k);t[k]=e->GetStringUTFChars(js[k],0);}
 if(s.up&&s.loaded&&s.ca)s.ca(n,(const int*)m.data(),t.data(),st.data());
 for(jsize k=0;k<n;k++){e->ReleaseStringUTFChars(js[k],t[k]);e->DeleteLocalRef(js[k]);}
 jintArray a=e->NewIntArray(n);if(n)e->SetIntArrayRegion(a,0,n,(const jint*)st.data());return a;}
// ---- cable ----
// linkStart: 1 = cable conectado (cada consola se avanza desde su propio hilo con run(i) y el lockstep las sincroniza); 0 = sin cable (el núcleo no trae el módulo o el juego no es GBA: corren sin comunicarse, cada una en su hilo); -2 = falta una consola; -1/-3 = error. Con las dos paradas.
J(jint,linkStart)(JNIEnv*,jobject){if(!G[0].loaded||!G[1].loaded)return -2;if(lk)return 1;
 if(!G[0].lcreate||!G[0].lattach||!G[1].lattach)return 0;
 lk=G[0].lcreate();if(!lk)return -1;
 int bad=0;for(int k=0;k<2&&!bad;k++){int r=G[k].lattach(lk,k);if(r!=0){bad=r;for(int j=0;j<k;j++)if(G[j].ldetach)G[j].ldetach(lk,j);}}
 if(bad){if(G[0].ldestroy)G[0].ldestroy(lk);lk=nullptr;return bad==1?0:-3;}
 return 1;}
// linkStop: desconecta y destruye el cable. Siempre antes de descargar una de las dos consolas, con las dos paradas.
J(void,linkStop)(JNIEnv*,jobject){if(!lk)return;for(int k=0;k<2;k++)if(G[k].loaded&&G[k].ldetach)G[k].ldetach(lk,k);if(G[0].ldestroy)G[0].ldestroy(lk);lk=nullptr;}
// linkInterrupt(true): se está pausando; quien espere a la otra consola dentro de retro_run sale de la espera y no vuelve a esperar hasta linkInterrupt(false) (se llama con los hilos aún en marcha).
J(void,linkInterrupt)(JNIEnv*,jobject,jboolean on){if(!lk)return;for(int k=0;k<2;k++)if(G[k].lintr)G[k].lintr(lk,on?1:0);}
// linkIdle: true = buen momento para guardar los estados de las dos consolas (GB/GBC: sin transferencia en curso; GBA o sin cable: siempre). Con las dos paradas.
J(jboolean,linkIdle)(JNIEnv*,jobject){if(!lk||!G[0].lidle)return JNI_TRUE;return G[0].lidle(lk)?JNI_TRUE:JNI_FALSE;}
// linkResync: tras cargar el estado en las dos consolas (paradas): reinicia el lockstep de GB/GBC (en GBA no hace nada).
J(void,linkResync)(JNIEnv*,jobject){if(!lk)return;for(int k=0;k<2;k++)if(G[k].loaded&&G[k].lresync)G[k].lresync(lk,k);}
J(jboolean,linked)(JNIEnv*,jobject){return lk!=nullptr;}
J(void,libDir)(JNIEnv*e,jobject,jstring d){const char*c=e->GetStringUTFChars(d,0);snprintf(ldir,sizeof ldir,"%s",c);e->ReleaseStringUTFChars(d,c);}
// Volcado del perfil PGO (solo existe en la build «perfil»): -1 = núcleo no cargado, -2 = este núcleo no es el instrumentado, 0 = ok.
J(jint,pgoDump)(JNIEnv*,jobject,jint i){GI;if(!s.up||!s.h)return -1;int(*f)()=(int(*)())dlsym(s.h,"cirilo_pgo_dump");return f?f():-2;}
J(jstring,linkDbg)(JNIEnv*e,jobject){char b[96]={0};if(lk&&G[0].ldbg)G[0].ldbg(b,sizeof b);return e->NewStringUTF(b);}
J(jstring,lastError)(JNIEnv*e,jobject){return e->NewStringUTF(lerr);}
// ---- medidor de CPU (tools/cirilo_prof.c): reparto del tiempo dentro del bucle del núcleo, sumando las dos consolas. Devuelve "" si el núcleo no lo trae o aún no hay datos.
// cpu = % del tiempo real que pasa dentro de runLoop (el resto es JNI, audio de Kotlin y esperas); i/v/a/o = % de ese tiempo en instrucciones, dibujo de vídeo, audio de mGBA y otros eventos (DMA, temporizadores, interrupciones...).
J(jstring,profDbg)(JNIEnv*e,jobject){uint64_t wall=0;long long st=0,ev=0,vi=0,au=0;
 for(int k=0;k<2;k++)if(G[k].up&&G[k].ptake){uint64_t o[5]={0,0,0,0,0};G[k].ptake(o);if(o[0]>wall)wall=o[0];st+=(long long)o[1];ev+=(long long)o[2];vi+=(long long)o[3];au+=(long long)o[4];}
 char b[96]={0};long long tot=st+ev;
 if(wall&&tot>0){long long ot=ev-vi-au;if(ot<0)ot=0;snprintf(b,sizeof b,"cpu%d%% i%d v%d a%d o%d",(int)(tot*100/(long long)wall),(int)(st*100/tot),(int)(vi*100/tot),(int)(au*100/tot),(int)(ot*100/tot));}
 return e->NewStringUTF(b);}
// Núcleo de la CPU en el que corre el hilo que llama (para ver si el sistema lo deja en un núcleo lento).
J(jint,cpu)(JNIEnv*,jobject){return sched_getcpu();}
