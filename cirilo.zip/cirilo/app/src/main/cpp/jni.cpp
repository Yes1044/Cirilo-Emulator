// Frontend libretro mínimo: carga libmgba_libretro.so (instancia 0) y libmgba2_libretro.so (instancia 1, para Link local) con dlopen y expone lo justo a Kotlin.
// Cada .so tiene sus propias variables globales, así que son dos consolas totalmente independientes; el cable entre ellas (si el núcleo trae tools/cirilo_link.c) se une con linkStart().
#include <jni.h>
#include <dlfcn.h>
#include <cstring>
#include <vector>
#include <mutex>
#include <atomic>
#include <algorithm>
#include <cstdio>
#include <string>
#include <cstdint>
#include <chrono>
#include <sched.h>
#include "libretro.h"
// Registro de rendimiento por fotograma (opcional, Opciones → Avanzado): un registro por llamada a retro_run, en un anillo de memoria. d[]: instr. en bloques, instr. interpretadas, instr. nativas,
// entradas sin código nativo, ejecuciones nativas, bloques creados, vaciados, invalidaciones, avisos SMC, palabras de código emitidas, PC final (los contadores del JIT son las diferencias entre fotogramas).
struct PRec{uint32_t us,ms;uint16_t core,mhz;uint32_t d[11];uint32_t p[4];}; // mhz = frecuencia actual de ese núcleo de CPU (0 si Android no deja leerla)
static std::atomic<bool> g_plog{false};
static uint64_t nowUs(){return (uint64_t)std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
struct I{
 void*h=nullptr;bool up=false,loaded=false;
 void(*init)()=nullptr;void(*run)()=nullptr;bool(*load)(const retro_game_info*)=nullptr;void(*unload)()=nullptr;
 void(*senv)(retro_environment_t)=nullptr;void(*svid)(retro_video_refresh_t)=nullptr;void(*sasb)(retro_audio_sample_batch_t)=nullptr;void(*sas)(retro_audio_sample_t)=nullptr;
 void(*sip)(retro_input_poll_t)=nullptr;void(*sis)(retro_input_state_t)=nullptr;void(*av)(retro_system_av_info*)=nullptr;
 void*(*mem)(unsigned)=nullptr;size_t(*msz)(unsigned)=nullptr;
 // API de trucos tipada (tools/cirilo_cheats.c, añadida al núcleo en el workflow). Si el núcleo no la trae, valen null y la app lo avisa.
 int(*cc)(int,const char*,int*)=nullptr;int(*ca)(int,const int*,const char**,int*)=nullptr;int(*cp)(const char*,int*)=nullptr;
 size_t(*ssz)()=nullptr;bool(*ser)(void*,size_t)=nullptr;bool(*unser)(const void*,size_t)=nullptr;void(*reset)()=nullptr;
 // API del cable (tools/cirilo_link.c, opcional): crear/destruir el coordinador compartido, conectar/desconectar esta consola y soltar a quien espera mientras se pausa.
 int(*ldbg)(char*,int)=nullptr;void(*ptake)(uint64_t*)=nullptr;void(*pcum)(uint64_t*)=nullptr;uint64_t(*pfreq)()=nullptr;uint64_t ppc[4]={0};void*(*lcreate)()=nullptr;int(*lattach)(void*,int)=nullptr;void(*ldetach)(void*,int)=nullptr;void(*ldestroy)(void*)=nullptr;void(*lintr)(void*,int)=nullptr;int(*lidle)(void*)=nullptr;void(*lcut)(void*)=nullptr;void(*lresync)(void*,int)=nullptr;
 std::mutex mu;std::vector<char> frame,rom;std::vector<int16_t> aud;unsigned fw=0,fh=0,lw=0,lh=0;std::atomic<int> K{0};
 void(*aset)(int,int,int,int)=nullptr;void(*apost)()=nullptr;void(*jset)(int)=nullptr;int(*jstats)(uint32_t*)=nullptr;uint32_t jprev[24]={0};int jit=0; // jset: JIT de la CPU GBA (tools/cirilo_jit_arm.inc, opcional) // ajustes avanzados (tools/cirilo_adv.c, opcional)
 int useBios=1,skipBios=0,idle=1,saveT=0,mosaic=1,sgbB=0,gbS=0,gbcS=0;char sysdir[512]={0}; // se rellenan desde Kotlin (advConfig) antes de cargar el juego
 int fskip=0;bool upd=false;char sk[8]={0};char path[512]={0};
 std::vector<PRec> pr;uint64_t pn=0,pt0=0,pfT=0;uint16_t pfM=0;uint32_t pprev[32]={0}; // registro de rendimiento
};
static I G[2];static void*lk=nullptr;static char lerr[600]={0};static char ldir[400]={0};
static const char*LIB[2]={"libmgba_libretro.so","libmgba2_libretro.so"};
// los callbacks de libretro no llevan contexto: uno por instancia (plantilla con el número)
template<int N> static bool env_t(unsigned c,void*d){I&s=G[N];
 if(c==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return *(retro_pixel_format*)d==RETRO_PIXEL_FORMAT_RGB565;
 if(c==RETRO_ENVIRONMENT_GET_CAN_DUPE){*(bool*)d=true;return true;}
 if(c==RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY){if(!s.sysdir[0])return false;*(const char**)d=s.sysdir;return true;} // aquí están gba_bios.bin, gbc_bios.bin y gb_bios.bin que eligió el usuario
 if(c==RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE){*(bool*)d=s.upd;s.upd=false;return true;}
 if(c==RETRO_ENVIRONMENT_GET_VARIABLE){retro_variable*v=(retro_variable*)d;
  if(!strcmp(v->key,"mgba_frameskip")){snprintf(s.sk,8,"%d",s.fskip);v->value=s.sk;return true;}
  if(!strcmp(v->key,"mgba_use_bios")){v->value=s.useBios?"ON":"OFF";return true;}
  if(!strcmp(v->key,"mgba_skip_bios")){v->value=s.skipBios?"ON":"OFF";return true;}
  if(!strcmp(v->key,"mgba_sgb_borders")){v->value=s.sgbB?"ON":"OFF";return true;}
  if(!strcmp(v->key,"mgba_idle_optimization")){v->value=s.idle?"Detect and Remove":"Don't Remove";return true;}}
 return false;}
template<int N> static void vid_t(const void*d,unsigned w,unsigned h,size_t pitch){if(!d)return;I&s=G[N];std::lock_guard<std::mutex>l(s.mu);s.fw=w;s.fh=h;s.lw=w;s.lh=h;s.frame.resize(w*h*2);for(unsigned y=0;y<h;y++)memcpy(&s.frame[y*w*2],(const char*)d+y*pitch,w*2);}
template<int N> static size_t asb_t(const int16_t*d,size_t n){I&s=G[N];std::lock_guard<std::mutex>l(s.mu);s.aud.insert(s.aud.end(),d,d+n*2);return n;}
template<int N> static void as1_t(int16_t l,int16_t r){I&s=G[N];std::lock_guard<std::mutex>l2(s.mu);s.aud.push_back(l);s.aud.push_back(r);}
static void ip(){}
template<int N> static int16_t is_t(unsigned port,unsigned dev,unsigned,unsigned id){return(port==0&&dev==RETRO_DEVICE_JOYPAD&&id<16)?((G[N].K>>id)&1):0;}
template<int N> static void wire(){I&s=G[N];s.senv(env_t<N>);s.init();s.svid(vid_t<N>);s.sasb(asb_t<N>);s.sas(as1_t<N>);s.sip(ip);s.sis(is_t<N>);}
#define J(r,n) extern "C" JNIEXPORT r JNICALL Java_app_cirilo_Native_##n
#define SY(v,n) *(void**)&s.v=dlsym(s.h,n)
#define GI I&s=G[i&1]
static int firstLoaded(){return G[0].loaded?0:(G[1].loaded?1:0);}
J(jboolean,nLoad)(JNIEnv*e,jobject,jint i,jbyteArray b,jstring nm){GI;
 if(!s.up){char pa[512];snprintf(pa,sizeof pa,"%s/%s",ldir,LIB[i&1]);s.h=ldir[0]?dlopen(pa,RTLD_NOW):nullptr;char e1[300]={0};if(!s.h){const char*d=dlerror();snprintf(e1,sizeof e1,"%s",d?d:"");}
  if(!s.h)s.h=dlopen(LIB[i&1],RTLD_NOW);if(!s.h){const char*d=dlerror();snprintf(lerr,sizeof lerr,"[ruta] %s | [nombre] %s",e1,d?d:"dlopen falló");return 0;}
  SY(init,"retro_init");SY(run,"retro_run");SY(load,"retro_load_game");SY(unload,"retro_unload_game");
  SY(senv,"retro_set_environment");SY(svid,"retro_set_video_refresh");SY(sasb,"retro_set_audio_sample_batch");SY(sas,"retro_set_audio_sample");
  SY(sip,"retro_set_input_poll");SY(sis,"retro_set_input_state");SY(av,"retro_get_system_av_info");
  SY(ssz,"retro_serialize_size");SY(ser,"retro_serialize");SY(unser,"retro_unserialize");SY(reset,"retro_reset");SY(mem,"retro_get_memory_data");SY(msz,"retro_get_memory_size");SY(cc,"cirilo_cheat_check");SY(ca,"cirilo_cheat_apply");SY(cp,"cirilo_cheat_probe");
  SY(lcreate,"cirilo_link_create");SY(lattach,"cirilo_link_attach");SY(ldetach,"cirilo_link_detach");SY(ldestroy,"cirilo_link_destroy");SY(lintr,"cirilo_link_interrupt");SY(lidle,"cirilo_link_idle");SY(lcut,"cirilo_link_cut");SY(lresync,"cirilo_link_resync");SY(ldbg,"cirilo_link_dbg");SY(ptake,"cirilo_prof_take");SY(pcum,"cirilo_prof_cumul");SY(pfreq,"cirilo_prof_freq");SY(aset,"cirilo_adv_set");SY(apost,"cirilo_adv_post");SY(jset,"cirilo_jit_set");SY(jstats,"cirilo_jit_stats");
  if(i&1)wire<1>();else wire<0>();s.up=true;}
 jsize n=e->GetArrayLength(b);s.rom.resize(n);e->GetByteArrayRegion(b,0,n,(jbyte*)s.rom.data());
 const char*c=e->GetStringUTFChars(nm,0);strncpy(s.path,c,511);e->ReleaseStringUTFChars(nm,c);
 retro_game_info g={s.path,s.rom.data(),s.rom.size(),nullptr};{std::lock_guard<std::mutex>l(s.mu);s.frame.clear();s.aud.clear();s.fw=s.fh=0;}
 if(s.aset)s.aset(s.saveT,s.mosaic,s.gbS,s.gbcS);
 if(s.jset)s.jset(s.jit); // vacía la caché de bloques y activa o apaga el JIT para este juego
 s.loaded=s.load(&g);if(s.loaded&&s.apost)s.apost();return s.loaded;}
// JIT experimental de la consola i (vale para la próxima carga).
J(void,jitConfig)(JNIEnv*,jobject,jint i,jint mode){GI;s.jit=mode;} // 0 apagado, 1 normal, 2 diagnóstico A (solo despachador), 3 diagnóstico B (nativo sin memoria)
// Ajustes avanzados de la consola i (valen para la próxima carga). saveT: 0 auto, 1 EEPROM, 2 SRAM, 3 Flash 64K, 4 Flash 128K, 5 ninguno.
J(void,advConfig)(JNIEnv*e,jobject,jint i,jboolean useBios,jboolean skipBios,jboolean idle,jint saveT,jboolean mosaic,jboolean sgbB,jint gbS,jint gbcS,jstring dir){GI;s.sgbB=sgbB;s.gbS=gbS;s.gbcS=gbcS;s.useBios=useBios;s.skipBios=skipBios;s.idle=idle;s.saveT=saveT;s.mosaic=mosaic;
 const char*c=e->GetStringUTFChars(dir,0);snprintf(s.sysdir,sizeof s.sysdir,"%s",c);e->ReleaseStringUTFChars(dir,c);}
J(void,nUnload)(JNIEnv*,jobject,jint i){GI;if(s.up&&s.loaded){s.unload();s.loaded=false;}}
J(void,nRun)(JNIEnv*,jobject,jint i){GI;
 if(!g_plog.load(std::memory_order_relaxed)||s.pr.empty()){s.run();return;}
 uint64_t a=nowUs();s.run();uint64_t b=nowUs();
 PRec&r=s.pr[s.pn%s.pr.size()];
 r.us=(uint32_t)(b-a);r.ms=(uint32_t)((a-s.pt0)/1000);int cpu=sched_getcpu();r.core=(uint16_t)cpu;
 if(b-s.pfT>250000){s.pfT=b;s.pfM=0;char pp[96];snprintf(pp,sizeof pp,"/sys/devices/system/cpu/cpu%d/cpufreq/scaling_cur_freq",cpu);if(FILE*ff=fopen(pp,"r")){long kh=0;if(fscanf(ff,"%ld",&kh)==1)s.pfM=(uint16_t)(kh/1000);fclose(ff);}}
 r.mhz=s.pfM;
 // reparto del tiempo de este fotograma (medidor de CPU, si el núcleo lo trae): instrucciones, vídeo, audio y otros eventos, en us
 if(s.pcum&&s.pfreq){uint64_t c[4]={0},f=s.pfreq();if(!f)f=1;s.pcum(c);uint64_t dd[4];for(int q=0;q<4;q++){dd[q]=c[q]>=s.ppc[q]?c[q]-s.ppc[q]:0;s.ppc[q]=c[q];}
  if(s.pn==0){for(int q=0;q<4;q++)dd[q]=0;}
  uint64_t ot=dd[1]>dd[2]+dd[3]?dd[1]-dd[2]-dd[3]:0;
  r.p[0]=(uint32_t)(dd[0]*1000000/f);r.p[1]=(uint32_t)(dd[2]*1000000/f);r.p[2]=(uint32_t)(dd[3]*1000000/f);r.p[3]=(uint32_t)(ot*1000000/f);}
 else{r.p[0]=r.p[1]=r.p[2]=r.p[3]=0;}
 uint32_t o[32]={0};int n=0;if(s.jit&&s.jstats)n=s.jstats(o);
 static const int ix[11]={2,3,14,18,12,0,5,4,6,19,21};
 for(int q=0;q<11;q++){uint32_t v=n>ix[q]?o[ix[q]]:0;if(q==10){r.d[q]=v;continue;}r.d[q]=(s.pn==0)?0:(uint32_t)(v-s.pprev[ix[q]]);s.pprev[ix[q]]=v;}
 s.pn++;}
// Activa (al abrir un juego) o apaga el registro de rendimiento y lo pone a cero.
J(void,plogSet)(JNIEnv*,jobject,jboolean on){g_plog=false;for(int k=0;k<2;k++){G[k].pr.assign(on?32768:0,PRec());G[k].pn=0;G[k].pt0=nowUs();}g_plog=on;}
// CSV del registro: resumen (mediana, p99, tirones = fotogramas > 1,5 × mediana, y cómo se diferencian de los normales) y una fila por fotograma.
J(jstring,plogDump)(JNIEnv*e,jobject){
 bool was=g_plog.exchange(false);std::string out;char b[640];
 for(int k=0;k<2;k++){I&s=G[k];if(s.pr.empty()||!s.pn)continue;
  size_t cap=s.pr.size(),cnt=(size_t)std::min<uint64_t>(s.pn,cap),st=s.pn>cap?(size_t)(s.pn%cap):0;
  auto R=[&](size_t j)->const PRec&{return s.pr[(st+j)%cap];};
  std::vector<uint32_t> sv(cnt);for(size_t j=0;j<cnt;j++)sv[j]=R(j).us;std::sort(sv.begin(),sv.end());
  uint32_t med=sv[cnt/2],p99=sv[std::min(cnt-1,cnt*99/100)];
  // Tirón = fotograma que tarda > 1,5x la mediana de sus vecinos del MISMO tipo (con salto de vídeo N, un fotograma de cada N+1 dibuja y cuesta más por diseño; ese no es un tirón)
  size_t per=(size_t)(s.fskip>0?s.fskip+1:1);std::vector<uint8_t> sp(cnt,0);size_t nsp=0;
  for(size_t j=0;j<cnt;j++){uint32_t v[4];int m=0;for(int q=1;q<=2;q++){if(j>=per*q)v[m++]=R(j-per*q).us;if(j+per*q<cnt)v[m++]=R(j+per*q).us;}
   uint32_t lm=med;if(m){std::sort(v,v+m);lm=v[m/2];}if(R(j).us>lm+lm/2){sp[j]=1;nsp++;}}
  double sum[2][9]={};double pp[2][4]={};size_t nn[2]={0,0};size_t cs[2][16]={};
  for(size_t j=0;j<cnt;j++){const PRec&r=R(j);int c=sp[j];nn[c]++;uint32_t tot=r.d[0]+r.d[1];
   sum[c][0]+=r.us;sum[c][1]+=tot;sum[c][2]+=tot?100.0*r.d[2]/tot:0;sum[c][3]+=r.d[3];sum[c][4]+=r.d[4];sum[c][5]+=r.d[5];sum[c][6]+=r.d[6];sum[c][7]+=r.d[7];sum[c][8]+=r.d[8];cs[c][r.core&15]++;for(int q=0;q<4;q++)pp[c][q]+=r.p[q];}
  snprintf(b,sizeof b,"# consola %d | JIT %s | salto de vídeo %d | %zu fotogramas | mediana %u us (x%.1f) | p99 %u us (x%.1f) | tirones (>1,5x sus vecinos del mismo tipo): %zu (%.1f%%)\n",k,s.jit==1?"normal":s.jit==2?"A":s.jit==3?"B":"apagado",s.fskip,cnt,med,1e6/(med?med:1)/59.7275,p99,1e6/(p99?p99:1)/59.7275,nsp,100.0*nsp/cnt);out+=b;
  for(int c=0;c<2;c++){if(!nn[c])continue;double n=(double)nn[c];
   snprintf(b,sizeof b,"# %s (media por fotograma): %.0f us | instr %.0f | nativas %.1f%% | entradas sin nativo %.0f | ejec nativas %.0f | creados %.2f | vaciados %.3f | invalidaciones %.2f | smc %.1f | núcleos:",c?"TIRON ":"normal",sum[c][0]/n,sum[c][1]/n,sum[c][2]/n,sum[c][3]/n,sum[c][4]/n,sum[c][5]/n,sum[c][6]/n,sum[c][7]/n,sum[c][8]/n);out+=b;
   for(int q=0;q<16;q++){if(cs[c][q]){snprintf(b,sizeof b," c%d=%zu",q,cs[c][q]);out+=b;}}out+="\n";
   {double sp4=pp[c][0]+pp[c][1]+pp[c][2]+pp[c][3];double fu=sum[c][0]-sp4;if(fu<0)fu=0; // us por fotograma dentro del bucle del núcleo y fuera de él (JNI, copia de vídeo/audio, esperas)
    snprintf(b,sizeof b,"#   reparto (us por fotograma): instrucciones %.0f | vídeo %.0f | audio %.0f | otros eventos %.0f | fuera del bucle %.0f\n",pp[c][0]/n,pp[c][1]/n,pp[c][2]/n,pp[c][3]/n,fu/n);out+=b;}}
  // Tabla por segundo: si las instrucciones por fotograma son parecidas y los ns por instrucción cambian, la causa es del teléfono (frecuencia, térmica, otros procesos) y no del juego
  out+="# por segundo: seg | fotogramas | real x | us/fotograma | instr/fotograma | ns/instr | MHz | % en núcleo 7 | tirones | creados/fotograma\n";
  for(size_t j=0;j<cnt;){uint32_t sec=R(j).ms/1000;size_t j2=j;double u=0,in=0,mh=0,cr=0;size_t c7=0,t=0,mn=0;
   while(j2<cnt&&R(j2).ms/1000==sec){const PRec&r=R(j2);u+=r.us;in+=r.d[0]+r.d[1];cr+=r.d[5];if(r.mhz){mh+=r.mhz;mn++;}c7+=r.core==7;t+=sp[j2];j2++;}
   double n=(double)(j2-j);snprintf(b,sizeof b,"# %u | %.0f | %.1f | %.0f | %.0f | %.1f | %.0f | %.0f | %zu | %.1f\n",sec,n,n/59.7275,u/n,in/n,in>0?u*1000/in:0.0,mn?mh/mn:0.0,100.0*c7/n,t,cr/n);out+=b;j=j2;}
  out+="consola,ms,us,fps,core,mhz,tiron,instr_total,instr_nativas,nativas_pct,entradas_sin_nativo,ejec_nativas,creados,vaciados,invalidaciones,smc,palabras_codigo,pc,us_instr,us_video,us_audio,us_otros\n";
  for(size_t j=0;j<cnt;j++){const PRec&r=R(j);uint32_t tot=r.d[0]+r.d[1];
   snprintf(b,sizeof b,"%d,%u,%u,%.1f,%u,%u,%d,%u,%u,%.1f,%u,%u,%u,%u,%u,%u,%u,%08x,%u,%u,%u,%u\n",k,r.ms,r.us,1e6/(r.us?r.us:1),r.core,r.mhz,(int)sp[j],tot,r.d[2],tot?100.0*r.d[2]/tot:0.0,r.d[3],r.d[4],r.d[5],r.d[6],r.d[7],r.d[8],r.d[9],r.d[10],r.p[0],r.p[1],r.p[2],r.p[3]);out+=b;}}
 g_plog=was;return e->NewStringUTF(out.c_str());}
J(jdoubleArray,nInfo)(JNIEnv*e,jobject,jint i){GI;retro_system_av_info a;s.av(&a);jdouble v[2]={a.timing.sample_rate,a.timing.fps};jdoubleArray r=e->NewDoubleArray(2);e->SetDoubleArrayRegion(r,0,2,v);return r;}
J(jint,nFrame)(JNIEnv*e,jobject,jint i,jobject bb){GI;std::lock_guard<std::mutex>l(s.mu);if(!s.fw||s.frame.empty())return 0;if((jlong)s.frame.size()>e->GetDirectBufferCapacity(bb))return 0;memcpy(e->GetDirectBufferAddress(bb),s.frame.data(),s.frame.size());int r=(s.fw<<16)|s.fh;s.fw=0;return r;}
J(jint,nAudio)(JNIEnv*e,jobject,jint i,jshortArray a){GI;std::lock_guard<std::mutex>l(s.mu);jsize n=std::min<size_t>(s.aud.size(),e->GetArrayLength(a));e->SetShortArrayRegion(a,0,n,s.aud.data());s.aud.erase(s.aud.begin(),s.aud.begin()+n);return n;}
J(void,nReset)(JNIEnv*,jobject,jint i){GI;if(s.loaded)s.reset();}
J(jbyteArray,nSaveState)(JNIEnv*e,jobject,jint i){GI;if(!s.loaded)return nullptr;size_t z=s.ssz();if(!z)return nullptr;std::vector<char> v(z);if(!s.ser(v.data(),z))return nullptr;jbyteArray r=e->NewByteArray(z);e->SetByteArrayRegion(r,0,z,(jbyte*)v.data());return r;}
J(jboolean,nLoadState)(JNIEnv*e,jobject,jint i,jbyteArray b){GI;if(!s.loaded)return 0;jsize n=e->GetArrayLength(b);std::vector<char> v(n);e->GetByteArrayRegion(b,0,n,(jbyte*)v.data());return s.unser(v.data(),n);}
J(jint,nLast)(JNIEnv*e,jobject,jint i,jobject bb){GI;std::lock_guard<std::mutex>l(s.mu);if(s.frame.empty()||!s.lw||(jlong)s.frame.size()>e->GetDirectBufferCapacity(bb))return 0;memcpy(e->GetDirectBufferAddress(bb),s.frame.data(),s.frame.size());return(s.lw<<16)|s.lh;}
J(void,nSetSkip)(JNIEnv*,jobject,jint i,jint n){GI;s.fskip=n;s.upd=true;}
J(void,nKeys)(JNIEnv*,jobject,jint i,jint k){GI;s.K=k;}
J(jbyteArray,nGetSave)(JNIEnv*e,jobject,jint i){GI;if(!s.loaded)return nullptr;void*m=s.mem(RETRO_MEMORY_SAVE_RAM);size_t z=s.msz(RETRO_MEMORY_SAVE_RAM);if(!m||!z)return nullptr;jbyteArray r=e->NewByteArray(z);e->SetByteArrayRegion(r,0,z,(jbyte*)m);return r;}
J(void,nSetSave)(JNIEnv*e,jobject,jint i,jbyteArray b){GI;if(!s.loaded)return;void*m=s.mem(RETRO_MEMORY_SAVE_RAM);size_t z=s.msz(RETRO_MEMORY_SAVE_RAM);jsize n=e->GetArrayLength(b);if(m&&z)e->GetByteArrayRegion(b,0,std::min<size_t>(z,n),(jbyte*)m);}
// ---- trucos. -9999 = el núcleo no incluye cirilo_cheats.c. Estas llamadas solo se hacen con el emulador parado o desde su hilo (entre fotogramas). cheatCheck/cheatProbe (editor de trucos) usan la primera consola abierta. ----
J(jintArray,cheatCheck)(JNIEnv*e,jobject,jint mode,jstring t){I&s=G[firstLoaded()];int info[1]={0};int r=-9999;if(s.up&&s.cc){const char*c=e->GetStringUTFChars(t,0);r=s.cc(mode,c,info);e->ReleaseStringUTFChars(t,c);}
 jint v[2]={r,info[0]};jintArray a=e->NewIntArray(2);e->SetIntArrayRegion(a,0,2,v);return a;}
J(jintArray,cheatProbe)(JNIEnv*e,jobject,jstring t){I&s=G[firstLoaded()];int sc[4]={0,0,0,0};if(!s.up||!s.cp)return nullptr;const char*c=e->GetStringUTFChars(t,0);int r=s.cp(c,sc);e->ReleaseStringUTFChars(t,c);if(r!=0)return nullptr;
 jintArray a=e->NewIntArray(4);e->SetIntArrayRegion(a,0,4,sc);return a;}
J(jintArray,cheatApply)(JNIEnv*e,jobject,jint i,jintArray modes,jobjectArray texts){GI;jsize n=e->GetArrayLength(texts);std::vector<jint> m(n);std::vector<int> st(n,-9999);std::vector<const char*> t(n);std::vector<jstring> js(n);
 if(n)e->GetIntArrayRegion(modes,0,n,m.data());for(jsize k=0;k<n;k++){js[k]=(jstring)e->GetObjectArrayElement(texts,k);t[k]=e->GetStringUTFChars(js[k],0);}
 if(s.up&&s.loaded&&s.ca)s.ca(n,(const int*)m.data(),t.data(),st.data());
 for(jsize k=0;k<n;k++){e->ReleaseStringUTFChars(js[k],t[k]);e->DeleteLocalRef(js[k]);}
 jintArray a=e->NewIntArray(n);if(n)e->SetIntArrayRegion(a,0,n,(const jint*)st.data());return a;}
// ---- cable ----
// linkStart: 1 = cable conectado (cada consola se avanza desde su propio hilo con run(i) y el lockstep las sincroniza); 0 = sin cable (el núcleo no trae el módulo o el juego no es GBA: corren sin comunicarse, cada una en su hilo); -2 = falta una consola; -1/-3 = error. Con las dos paradas.
J(jint,linkStart)(JNIEnv*,jobject){if(!G[0].loaded||!G[1].loaded)return -2;if(lk)return 1;
 if(!G[0].lcreate||!G[0].lattach||!G[1].lattach)return 0;
 lk=G[0].lcreate();if(!lk)return -1;
 int bad=0;for(int k=0;k<2&&!bad;k++){int r=G[k].lattach(lk,k);if(r!=0){bad=r;for(int j=0;j<k;j++)if(G[j].ldetach)G[j].ldetach(lk,j);}}
 if(bad){if(G[0].ldestroy)G[0].ldestroy(lk);lk=nullptr;return bad==1?0:-3;}
 return 1;}
// linkStop: desconecta y destruye el cable. Siempre antes de descargar una de las dos consolas, con las dos paradas.
J(void,linkStop)(JNIEnv*,jobject){if(!lk)return;for(int k=0;k<2;k++)if(G[k].loaded&&G[k].ldetach)G[k].ldetach(lk,k);if(G[0].ldestroy)G[0].ldestroy(lk);lk=nullptr;}
// linkInterrupt(true): se está pausando; quien espere a la otra consola dentro de retro_run sale de la espera y no vuelve a esperar hasta linkInterrupt(false) (se llama con los hilos aún en marcha).
J(void,linkInterrupt)(JNIEnv*,jobject,jboolean on){if(!lk)return;for(int k=0;k<2;k++)if(G[k].lintr)G[k].lintr(lk,on?1:0);}
// linkIdle: true = buen momento para guardar los estados de las dos consolas (GB/GBC: sin transferencia en curso; GBA o sin cable: siempre). Con las dos paradas.
J(jboolean,linkIdle)(JNIEnv*,jobject){if(!lk||!G[0].lidle)return JNI_TRUE;return G[0].lidle(lk)?JNI_TRUE:JNI_FALSE;}
// linkCut: ANTES de cargar el estado de una sola consola (paradas): GBA suelta el cable de las dos; GB/GBC no hace nada. Después, linkResync.
J(void,linkCut)(JNIEnv*,jobject){if(!lk)return;if(G[0].lcut)G[0].lcut(lk);}
// linkResync: tras cargar el estado en las dos consolas (paradas): reengancha el cable: GBA vuelve a conectar las dos consolas con un coordinador limpio; GB/GBC reinicia el lockstep.
J(void,linkResync)(JNIEnv*,jobject){if(!lk)return;for(int k=0;k<2;k++)if(G[k].loaded&&G[k].lresync)G[k].lresync(lk,k);}
J(jboolean,linked)(JNIEnv*,jobject){return lk!=nullptr;}
J(void,libDir)(JNIEnv*e,jobject,jstring d){const char*c=e->GetStringUTFChars(d,0);snprintf(ldir,sizeof ldir,"%s",c);e->ReleaseStringUTFChars(d,c);}
// Volcado del perfil PGO (solo existe en la build «perfil»): -1 = núcleo no cargado, -2 = este núcleo no es el instrumentado, 0 = ok.
J(jint,pgoDump)(JNIEnv*,jobject,jint i){GI;if(!s.up||!s.h)return -1;int(*f)()=(int(*)())dlsym(s.h,"cirilo_pgo_dump");return f?f():-2;}
J(jstring,linkDbg)(JNIEnv*e,jobject){char b[96]={0};if(lk&&G[0].ldbg)G[0].ldbg(b,sizeof b);return e->NewStringUTF(b);}
J(jstring,lastError)(JNIEnv*e,jobject){return e->NewStringUTF(lerr);}
// ---- medidor de CPU (tools/cirilo_prof.c): reparto del tiempo dentro del bucle del núcleo, sumando las dos consolas. Devuelve "" si el núcleo no lo trae o aún no hay datos.
// cpu = % del tiempo real que pasa dentro de runLoop (el resto es JNI, audio de Kotlin y esperas); i/v/a/o = % de ese tiempo en instrucciones, dibujo de vídeo, audio de mGBA y otros eventos (DMA, temporizadores, interrupciones...).
J(jstring,profDbg)(JNIEnv*e,jobject){uint64_t wall=0;long long st=0,ev=0,vi=0,au=0;
 for(int k=0;k<2;k++)if(G[k].up&&G[k].ptake){uint64_t o[5]={0,0,0,0,0};G[k].ptake(o);if(o[0]>wall)wall=o[0];st+=(long long)o[1];ev+=(long long)o[2];vi+=(long long)o[3];au+=(long long)o[4];}
 char b[96]={0};long long tot=st+ev;
 if(wall&&tot>0){long long ot=ev-vi-au;if(ot<0)ot=0;snprintf(b,sizeof b,"cpu%d%% i%d v%d a%d o%d",(int)(tot*100/(long long)wall),(int)(st*100/tot),(int)(vi*100/tot),(int)(au*100/tot),(int)(ot*100/tot));}
 return e->NewStringUTF(b);}
// Contadores del JIT (cirilo_jit_stats) desde la última lectura, para el panel de FPS: «jit nat X% ej N» = % de las instrucciones ejecutadas por bloques que fueron código nativo y ejecuciones
// de tramos nativos por segundo. Vacío si el JIT está apagado o el núcleo no lo trae. Los contadores son de 32 bits y dan la vuelta: se usa la diferencia sin signo (se lee cada 0,5 s).
J(jstring,jitDbg)(JNIEnv*e,jobject){uint64_t nat=0,blk=0,itp=0,runs=0,pl=0,sm=0,cr=0,fl=0,iv=0;bool any=false,miss=false;
 for(int k=0;k<2;k++)if(G[k].up&&G[k].jit&&!G[k].jstats)miss=true;
 for(int k=0;k<2;k++)if(G[k].up&&G[k].jit&&G[k].jstats){uint32_t o[24]={0};int n=G[k].jstats(o);if(n>=19){any=true;pl+=(uint32_t)(o[18]-G[k].jprev[18]);sm+=(uint32_t)(o[6]-G[k].jprev[6]);cr+=(uint32_t)(o[0]-G[k].jprev[0]);fl+=(uint32_t)(o[5]-G[k].jprev[5]);iv+=(uint32_t)(o[4]-G[k].jprev[4]);nat+=(uint32_t)(o[14]-G[k].jprev[14]);blk+=(uint32_t)(o[2]-G[k].jprev[2]);itp+=(uint32_t)(o[3]-G[k].jprev[3]);runs+=(uint32_t)(o[12]-G[k].jprev[12]);for(int q=0;q<n&&q<24;q++)G[k].jprev[q]=o[q];}}
 char b[112]={0};if(any){uint64_t tot=blk+itp;int md=0;for(int k=0;k<2;k++)if(G[k].up&&G[k].jit)md=G[k].jit;const char*tg=md==2?"jitA":md==3?"jitB":"jit";snprintf(b,sizeof b,"%s nat%d%% ej%dk pl%dk sm%dk iv%dk cr%d fl%d",tg,tot?(int)(nat*100/tot):0,(int)(runs*2/1000),(int)(pl*2/1000),(int)(sm*2/1000),(int)(iv*2/1000),(int)(cr*2),(int)(fl*2));}else if(miss)snprintf(b,sizeof b,"jit: este nucleo NO lo trae");
 return e->NewStringUTF(b);}
// Núcleo de la CPU en el que corre el hilo que llama (para ver si el sistema lo deja en un núcleo lento).
J(jint,cpu)(JNIEnv*,jobject){return sched_getcpu();}
