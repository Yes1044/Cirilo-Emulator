
/* ---- Cirilo: volcado del perfil PGO ---------------------------------------------------------------------------------
 * Solo se añade al final de libretro.c en la build «perfil» del workflow (compilada con -fprofile-instr-generate). Android no cierra
 * los procesos con normalidad, así que el perfil no se escribiría solo: Kotlin llama a esto al cerrar el juego (Native.pgoDump).
 * Escribe (o mezcla con el que ya haya) el .profraw en la ruta de LLVM_PROFILE_FILE (la fija App.kt) y pone los contadores a cero. */
extern int __llvm_profile_write_file(void);
extern void __llvm_profile_reset_counters(void);
int cirilo_pgo_dump(void){int r=__llvm_profile_write_file();__llvm_profile_reset_counters();return r;}
