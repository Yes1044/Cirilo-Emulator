/* Cirilo JIT: simulador MÍNIMO de AArch64, SOLO PARA PRUEBAS (se compila con -DCIRILO_JIT_SIM en los anfitriones que no son arm64, p. ej. el trabajo x86-64 de CI y mis pruebas locales).
 * Ejecuta exactamente las instrucciones que emite cirilo_jit_a64.inc; si encuentra otra, se detiene con un error claro en vez de seguir. Sirve para comprobar la LÓGICA del emisor
 * (banderines, ciclos, vida de banderines) sin hardware arm64; las codificaciones binarias las comprueba la ejecución nativa en el runner arm64. */
static uint32_t* cjCode; /* (se define de verdad en cirilo_jit_arm.inc) */
struct CJSim {
	uint64_t x[32];
	uint64_t sp;
	uint32_t nzcv; /* bits 31:28 */
};
static uint64_t cjSimStack[64]; /* pila simulada: el marco del bloque cabe de sobra */
static int cjSimErr;
static uint32_t cjSimBadOp;
static uint64_t cjSimR(struct CJSim* s, int r) { return r == 31 ? 0 : s->x[r]; }
static void cjSimW(struct CJSim* s, int r, uint64_t v) { if (r != 31) s->x[r] = v; }
static void cjSimFlags(struct CJSim* s, uint32_t res, int c, int v) {
	s->nzcv = ((res >> 31) << 31) | ((res == 0) << 30) | ((uint32_t) c << 29) | ((uint32_t) v << 28);
}
static uint32_t cjSimAddC(struct CJSim* s, uint32_t a, uint32_t b, uint32_t cin, int setf) {
	uint64_t full = (uint64_t) a + b + cin;
	uint32_t r = (uint32_t) full;
	if (setf) {
		int c = (int) (full >> 32), v = (int) ((~(a ^ b) & (a ^ r)) >> 31);
		cjSimFlags(s, r, c, v);
	}
	return r;
}
/* devuelve w0 al hacer ret. Arguentos: x0 = cpu, x1 = ops, x2 = tabla de funciones auxiliares */
static uint32_t cjSimRun(const uint32_t* pc, void* cpu, const void* a1, const void* a2) {
	struct CJSim S;
	memset(&S, 0, sizeof(S));
	S.x[0] = (uint64_t) (uintptr_t) cpu;
	S.x[1] = (uint64_t) (uintptr_t) a1;
	S.x[2] = (uint64_t) (uintptr_t) a2;
	S.sp = (uint64_t) (uintptr_t) (cjSimStack + 64);
	struct CJSim* s = &S;
	for (int steps = 0; steps < 100000; ++steps) {
		uint32_t op = *pc;
		int rd = op & 31, rn = (op >> 5) & 31, rm = (op >> 16) & 31;
		if (op == 0xD65F03C0u) {
			if (s->x[30] == 0) { /* ret del bloque */
				return (uint32_t) s->x[0];
			}
			pc = (const uint32_t*) (uintptr_t) s->x[30]; /* ret de una pieza compartida */
			continue;
		} else if (op == 0xD503201Fu) { /* nop */
		} else if ((op & 0xFFFFFFE0u) == 0xD53B4200u) { /* mrs xt, nzcv */
			cjSimW(s, rd, s->nzcv);
		} else if ((op & 0xFFFFFFE0u) == 0xD51B4200u) { /* msr nzcv, xt */
			s->nzcv = (uint32_t) cjSimR(s, rd) & 0xF0000000u;
		} else if ((op & 0xFF000010u) == 0x54000000u) { /* b.cond */
			int32_t off = (int32_t) (op << 8) >> 13; /* imm19 con signo */
			int cond = op & 15, n = s->nzcv >> 31, z = (s->nzcv >> 30) & 1, c = (s->nzcv >> 29) & 1, v = (s->nzcv >> 28) & 1, t;
			switch (cond >> 1) {
			case 0: t = z; break;
			case 1: t = c; break;
			case 2: t = n; break;
			case 3: t = v; break;
			case 4: t = c && !z; break;
			case 5: t = n == v; break;
			case 6: t = n == v && !z; break;
			default: t = 1; break;
			}
			if ((cond & 1) && cond != 15) t = !t;
			if (t) {
				pc += off;
				continue;
			}
		} else if ((op & 0xFFE00C00u) == 0x1A800000u) { /* csel wd, wn, wm, cond */
			int cond = (op >> 12) & 15, n = s->nzcv >> 31, z = (s->nzcv >> 30) & 1, c = (s->nzcv >> 29) & 1, v = (s->nzcv >> 28) & 1, t;
			switch (cond >> 1) {
			case 0: t = z; break;
			case 1: t = c; break;
			case 2: t = n; break;
			case 3: t = v; break;
			case 4: t = c && !z; break;
			case 5: t = n == v; break;
			case 6: t = n == v && !z; break;
			default: t = 1; break;
			}
			if ((cond & 1) && cond != 15) t = !t;
			cjSimW(s, rd, (uint32_t) cjSimR(s, t ? rn : rm));
		} else if ((op & 0x7F000000u) == 0x37000000u) { /* tbnz xt, #bit, destino */
			int bit = (int) (((op >> 31) << 5) | ((op >> 19) & 31));
			if ((cjSimR(s, rd) >> bit) & 1) {
				pc += (int32_t) (op << 13) >> 18;
				continue;
			}
		} else if ((op & 0xFF000000u) == 0x35000000u) { /* cbnz wt, destino */
			if ((uint32_t) cjSimR(s, rd) != 0) {
				pc += (int32_t) (op << 8) >> 13;
				continue;
			}
		} else if ((op & 0xFC000000u) == 0x94000000u) { /* bl destino */
			s->x[30] = (uint64_t) (uintptr_t) (pc + 1);
			pc += (int32_t) (op << 6) >> 6;
			continue;
		} else if ((op & 0xFFFFFC1Fu) == 0xD61F0000u && cjSimR(s, rn) >= (uint64_t) (uintptr_t) cjCode && cjSimR(s, rn) < (uint64_t) (uintptr_t) (cjCode + CJ_CODE_WORDS)) { /* br a código del JIT (encadenado) */
			pc = (const uint32_t*) (uintptr_t) cjSimR(s, rn);
			continue;
		} else if ((op & 0x7F000000u) == 0x34000000u) { /* cbz wt/xt, destino */
			uint64_t v = cjSimR(s, rd);
			if ((op >> 31) ? v == 0 : (uint32_t) v == 0) {
				pc += (int32_t) (op << 8) >> 13;
				continue;
			}
		} else if ((op & 0xFF000000u) == 0x58000000u) { /* ldr xt, literal */
			cjSimW(s, rd, *(const uint64_t*) (uintptr_t) (pc + ((int32_t) (op << 8) >> 13)));
		} else if ((op & 0xFFFFFC1Fu) == 0xD61F0000u) { /* br xn: salto a una función de C que vuelve a x30 (cola) */
			uint64_t (*fn)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t) = (uint64_t (*)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t)) (uintptr_t) cjSimR(s, rn);
			uint64_t r = fn(s->x[0], s->x[1], s->x[2], s->x[3], s->x[4], s->x[5]);
			uint64_t ret = s->x[30];
			for (int q = 0; q < 18; ++q) {
				s->x[q] = 0xBADBADBAD0000000ull | q;
			}
			s->nzcv = 0x50000000u;
			s->x[0] = r;
			pc = (const uint32_t*) (uintptr_t) ret;
			continue;
		} else if ((op & 0xFFFFFC1Fu) == 0xD63F0000u) { /* blr xn: llama a una función de C con AAPCS64 (hasta 6 argumentos) y estropea lo que una llamada puede estropear */
			uint64_t (*fn)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t) = (uint64_t (*)(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t, uint64_t)) (uintptr_t) cjSimR(s, rn);
			uint64_t r = fn(s->x[0], s->x[1], s->x[2], s->x[3], s->x[4], s->x[5]);
			for (int q = 0; q < 18; ++q) {
				s->x[q] = 0xBADBADBAD0000000ull | q; /* x0-x17 son de la función llamada */
			}
			s->nzcv = 0x50000000u; /* los banderines no se conservan */
			s->x[0] = r;
		} else if ((op & 0xFFC00000u) == 0xA9000000u || (op & 0xFFC00000u) == 0xA9400000u) { /* stp/ldp 64 bits, desplazamiento con signo */
			int rt2 = (op >> 10) & 31;
			int32_t off = ((int32_t) ((op >> 15) & 0x7F) << 25 >> 25) * 8;
			uint64_t* a = (uint64_t*) (uintptr_t) ((rn == 31 ? s->sp : s->x[rn]) + off);
			if (op & 0x00400000u) {
				cjSimW(s, rd, a[0]);
				cjSimW(s, rt2, a[1]);
			} else {
				a[0] = cjSimR(s, rd);
				a[1] = cjSimR(s, rt2);
			}
		} else if ((op & 0xFFC00000u) == 0xF9400000u) { /* ldr xt, [xn, #imm] */
			cjSimW(s, rd, *(uint64_t*) (uintptr_t) ((rn == 31 ? s->sp : cjSimR(s, rn)) + (((op >> 10) & 0xFFF) << 3)));
		} else if ((op & 0xFFC00000u) == 0xF9000000u) { /* str xt, [xn, #imm] */
			*(uint64_t*) (uintptr_t) ((rn == 31 ? s->sp : cjSimR(s, rn)) + (((op >> 10) & 0xFFF) << 3)) = cjSimR(s, rd);
		} else if ((op & 0xFFE0FFE0u) == 0xAA0003E0u) { /* mov xd, xm (orr xd, xzr, xm) */
			cjSimW(s, rd, cjSimR(s, rm));
		} else if ((op & 0xFF000000u) == 0x91000000u || (op & 0xFF000000u) == 0xD1000000u) { /* add/sub xd|sp, xn|sp, #imm (64 bits, sin banderines) */
			uint64_t base = rn == 31 ? s->sp : s->x[rn], imm12 = (op >> 10) & 0xFFF, v = ((op >> 30) & 1) ? base - imm12 : base + imm12;
			if (rd == 31) s->sp = v; else s->x[rd] = v;
		} else if ((op & 0xFC000000u) == 0x14000000u) { /* b */
			pc += (int32_t) (op << 6) >> 6;
			continue;
		} else if ((op & 0xFFC00000u) == 0x39400000u) { /* ldrb wt, [xn, #imm] */
			cjSimW(s, rd, *(uint8_t*) (uintptr_t) (cjSimR(s, rn) + ((op >> 10) & 0xFFF)));
		} else if ((op & 0x3F20FC00u) == 0x38206800u && ((op >> 22) & 3) < 2) { /* ldr/str (w, h, b) wt, [xn, xm] */
			uint64_t a = cjSimR(s, rn) + cjSimR(s, rm);
			int size = op >> 30, ld = (op >> 22) & 1;
			if (ld) {
				cjSimW(s, rd, size == 2 ? *(uint32_t*) (uintptr_t) a : size == 1 ? *(uint16_t*) (uintptr_t) a : *(uint8_t*) (uintptr_t) a);
			} else if (size == 2) {
				*(uint32_t*) (uintptr_t) a = (uint32_t) cjSimR(s, rd);
			} else if (size == 1) {
				*(uint16_t*) (uintptr_t) a = (uint16_t) cjSimR(s, rd);
			} else {
				*(uint8_t*) (uintptr_t) a = (uint8_t) cjSimR(s, rd);
			}
		} else if ((op & 0xFFE00000u) == 0x13800000u) { /* extr wd, wn, wm, #imms (con wn = wm es ROR inmediato) */
			cjSimW(s, rd, (uint32_t) ((((uint64_t) (uint32_t) cjSimR(s, rn) << 32) | (uint32_t) cjSimR(s, rm)) >> ((op >> 10) & 31)));
		} else if ((op & 0xFFE0FC00u) == 0x1AC02C00u) { /* rorv wd, wn, wm */
			uint32_t v = (uint32_t) cjSimR(s, rn), r = cjSimR(s, rm) & 31;
			cjSimW(s, rd, r ? (v >> r) | (v << (32 - r)) : v);
		} else if ((op & 0xFFE0FC00u) == 0xAA008000u) { /* orr xd, xn, xm, lsl #32 */
			cjSimW(s, rd, cjSimR(s, rn) | (cjSimR(s, rm) << 32));
		} else if ((op & 0xFFC00000u) == 0xB9400000u) { /* ldr wt, [xn, #imm] */
			cjSimW(s, rd, *(uint32_t*) (uintptr_t) (cjSimR(s, rn) + (((op >> 10) & 0xFFF) << 2)));
		} else if ((op & 0xFFC00000u) == 0xB9000000u) { /* str wt, [xn, #imm] */
			*(uint32_t*) (uintptr_t) (cjSimR(s, rn) + (((op >> 10) & 0xFFF) << 2)) = (uint32_t) cjSimR(s, rd);
		} else if ((op & 0xFF800000u) == 0x52800000u) { /* movz */
			cjSimW(s, rd, ((op >> 5) & 0xFFFF) << (((op >> 21) & 3) * 16));
		} else if ((op & 0xFF800000u) == 0x72800000u) { /* movk */
			int sh = ((op >> 21) & 3) * 16;
			cjSimW(s, rd, ((uint32_t) cjSimR(s, rd) & ~(0xFFFFu << sh)) | (((op >> 5) & 0xFFFF) << sh));
		} else if ((op & 0x9F000000u) == 0x11000000u) { /* add/sub inmediato */
			uint32_t imm = (op >> 10) & 0xFFF, a = (uint32_t) cjSimR(s, rn);
			int sub = (op >> 30) & 1, setf = (op >> 29) & 1;
			uint32_t r = sub ? cjSimAddC(s, a, ~imm, 1, setf) : cjSimAddC(s, a, imm, 0, setf);
			cjSimW(s, rd, r);
		} else if ((op & 0x9F200000u) == 0x0B000000u) { /* add/sub registro con desplazamiento */
			if (((op >> 22) & 3) != 0 || (op >> 31)) { cjSimErr = 1; return 0xDEAD0001; }
			uint32_t b = (uint32_t) cjSimR(s, rm) << ((op >> 10) & 63), a = (uint32_t) cjSimR(s, rn);
			int sub = (op >> 30) & 1, setf = (op >> 29) & 1;
			uint32_t r = sub ? cjSimAddC(s, a, ~b, 1, setf) : cjSimAddC(s, a, b, 0, setf);
			cjSimW(s, rd, r);
		} else if ((op & 0x1FE0FC00u) == 0x1A000000u && (op >> 31) == 0) { /* adc/sbc */
			uint32_t a = (uint32_t) cjSimR(s, rn), b = (uint32_t) cjSimR(s, rm), cin = (s->nzcv >> 29) & 1;
			int sub = (op >> 30) & 1, setf = (op >> 29) & 1;
			uint32_t r = sub ? cjSimAddC(s, a, ~b, cin, setf) : cjSimAddC(s, a, b, cin, setf);
			cjSimW(s, rd, r);
		} else if ((op & 0x9F000000u) == 0x0A000000u) { /* and/orr/eor/ands (con N: bic/orn/eon/bics) registro */
			if (op >> 31) { cjSimErr = 2; return 0xDEAD0002; }
			uint32_t b = (uint32_t) cjSimR(s, rm), a = (uint32_t) cjSimR(s, rn), sa = (op >> 10) & 63;
			switch ((op >> 22) & 3) { /* tipo de desplazamiento del segundo operando */
			case 0: b <<= sa; break;
			case 1: b >>= sa; break;
			case 2: b = (uint32_t) ((int32_t) b >> sa); break;
			default: b = sa ? (b >> sa) | (b << (32 - sa)) : b; break;
			}
			if ((op >> 21) & 1) b = ~b;
			uint32_t r;
			switch ((op >> 29) & 3) {
			case 0: r = a & b; break;
			case 1: r = a | b; break;
			case 2: r = a ^ b; break;
			default: r = a & b; cjSimFlags(s, r, 0, 0); break;
			}
			cjSimW(s, rd, r);
		} else if ((op & 0x1F800000u) == 0x12000000u && (op >> 31) == 0) { /* lógico con inmediato (32 bits, una sola tanda) */
			if ((op >> 22) & 1) { cjSimErr = 3; return 0xDEAD0003; }
			int immr = (op >> 16) & 63, imms = (op >> 10) & 63, ones = (imms & 31) + 1;
			uint32_t pat = ones == 32 ? 0xFFFFFFFFu : ((1u << ones) - 1);
			uint32_t m = immr ? (pat >> immr) | (pat << (32 - immr)) : pat;
			uint32_t a = (uint32_t) cjSimR(s, rn), r;
			switch ((op >> 29) & 3) {
			case 0: r = a & m; break;
			case 1: r = a | m; break;
			case 2: r = a ^ m; break;
			default: r = a & m; cjSimFlags(s, r, 0, 0); break;
			}
			cjSimW(s, rd, r);
		} else if ((op & 0x7F800000u) == 0x53000000u || (op & 0x7F800000u) == 0x13000000u || (op & 0x7F800000u) == 0x33000000u) { /* ubfm/sbfm/bfm */
			if ((op >> 31) || ((op >> 22) & 1)) { cjSimErr = 4; return 0xDEAD0004; }
			int immr = (op >> 16) & 31, imms = (op >> 10) & 31;
			uint32_t src = (uint32_t) cjSimR(s, rn), dst = (uint32_t) cjSimR(s, rd), r;
			uint32_t kind = op & 0x7F800000u;
			if (imms >= immr) { /* campo de imms-immr+1 bits desde immr */
				int w = imms - immr + 1;
				uint32_t field = (src >> immr) & (w == 32 ? 0xFFFFFFFFu : ((1u << w) - 1));
				if (kind == 0x33000000u) { /* bfxil */
					uint32_t mask = w == 32 ? 0xFFFFFFFFu : ((1u << w) - 1);
					r = (dst & ~mask) | field;
				} else if (kind == 0x13000000u) { /* sbfx */
					r = (uint32_t) ((int32_t) (field << (32 - w)) >> (32 - w));
				} else {
					r = field;
				}
			} else { /* campo de imms+1 bits colocado en el bit 32-immr */
				int w = imms + 1, pos = 32 - immr;
				uint32_t field = src & ((1u << w) - 1), mask = ((1u << w) - 1) << pos;
				if (kind == 0x33000000u) {
					r = (dst & ~mask) | (field << pos);
				} else if (kind == 0x13000000u) {
					r = (uint32_t) ((int32_t) (field << (32 - w)) >> (32 - w)) << pos;
				} else {
					r = field << pos;
				}
			}
			cjSimW(s, rd, r);
		} else if ((op & 0xFFE08000u) == 0x1B000000u) { /* madd (mul) */
			uint32_t ra = (op >> 10) & 31;
			cjSimW(s, rd, (uint32_t) (cjSimR(s, rn) * cjSimR(s, rm) + cjSimR(s, ra)));
		} else {
			cjSimErr = 5; cjSimBadOp = op; fprintf(stderr, "sim: op sin soporte %08X\n", op);
			return 0xDEAD0000u | 5;
		}
		++pc;
	}
	cjSimErr = 6;
	return 0xDEAD0006;
}
