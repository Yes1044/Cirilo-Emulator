/* Cirilo JIT: memoria ejecutable SIN presuponer que RWX está permitido (SELinux endurecido, políticas W^X, ROMs de terceros).
 * Orden de intentos:
 *   1) un mapa anónimo RWX (lo habitual en Android para apps normales);
 *   2) doble mapa del mismo memfd: una vista RW (donde se escribe) y otra RX (donde se ejecuta). Nunca hay una página a la vez escribible y ejecutable.
 * Si ninguno funciona, kind = 0 y quien llama NO debe activar el JIT (cirilo_jit_set deja el intérprete original).
 * Con la doble vista, el código se emite en la dirección RW y se ejecuta en la RX: delta = rw - rx (bytes). Las ramas del código emitido son relativas dentro del
 * mismo búfer, así que valen en las dos vistas. La caché de instrucciones se limpia sobre la dirección RX (la que se ejecuta). */
#ifndef CIRILO_JIT_MEM_H
#define CIRILO_JIT_MEM_H
#include <stddef.h>
#include <stdint.h>
#include <errno.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/syscall.h>

struct CJMem {
	uint8_t* rx; /* dirección desde la que se ejecuta */
	uint8_t* rw; /* dirección en la que se escribe (== rx con RWX) */
	size_t size;
	int fd;
	int kind; /* 0 = sin memoria ejecutable, 1 = RWX, 2 = doble vista */
	int err; /* errno del último intento fallido (diagnóstico) */
};

#ifndef __NR_memfd_create
#if defined(__aarch64__)
#define __NR_memfd_create 279
#elif defined(__x86_64__)
#define __NR_memfd_create 319
#elif defined(__arm__)
#define __NR_memfd_create 385
#endif
#endif

static inline int cjMemFd(size_t size) {
#ifdef __NR_memfd_create
	int fd = (int) syscall(__NR_memfd_create, "cirilo-jit", 1u /* MFD_CLOEXEC */);
	if (fd < 0) {
		return -1;
	}
	if (ftruncate(fd, (off_t) size) != 0) {
		close(fd);
		return -1;
	}
	return fd;
#else
	(void) size;
	errno = ENOSYS;
	return -1;
#endif
}

/* force: 0 = RWX y, si falla, doble vista; 1 = solo RWX; 2 = solo doble vista (pruebas); 3 = nada (pruebas: simula un dispositivo sin memoria ejecutable) */
static inline int cjMemAlloc(struct CJMem* m, size_t size, int force) {
	m->rx = m->rw = NULL; m->size = size; m->fd = -1; m->kind = 0; m->err = 0;
	if (force == 3) {
		m->err = EACCES;
		return 0;
	}
	if (force != 2) {
		void* p = mmap(NULL, size, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
		if (p != MAP_FAILED) {
			m->rx = m->rw = (uint8_t*) p; m->kind = 1;
			return 1;
		}
		m->err = errno;
	}
	if (force != 1) {
		int fd = cjMemFd(size);
		if (fd >= 0) {
			void* w = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
			void* x = w == MAP_FAILED ? MAP_FAILED : mmap(NULL, size, PROT_READ | PROT_EXEC, MAP_SHARED, fd, 0);
			if (w != MAP_FAILED && x != MAP_FAILED) {
				m->rw = (uint8_t*) w; m->rx = (uint8_t*) x; m->fd = fd; m->kind = 2;
				return 1;
			}
			m->err = errno;
			if (w != MAP_FAILED) {
				munmap(w, size);
			}
			close(fd);
		} else {
			m->err = errno;
		}
	}
	return 0;
}

static inline void cjMemFree(struct CJMem* m) {
	if (m->kind == 1) {
		munmap(m->rx, m->size);
	} else if (m->kind == 2) {
		munmap(m->rx, m->size);
		munmap(m->rw, m->size);
		close(m->fd);
	}
	m->rx = m->rw = NULL; m->fd = -1; m->kind = 0;
}
#endif
