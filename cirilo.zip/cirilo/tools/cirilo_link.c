
/* ---- Cirilo: cable de Link local (GBA) entre dos núcleos del mismo proceso ----------------------------------------
 * Se añade al final de libretro.c (como cirilo_cheats.c) y se compila dentro de cada copia del núcleo (libmgba_libretro.so y
 * libmgba2_libretro.so). El motor es el lockstep de mGBA (src/gba/sio/lockstep.c), que está pensado para UN HILO POR CONSOLA:
 * cada consola corre su propio retro_run en su propio hilo (Emu.kt crea un hilo por consola) y el lockstep las mantiene en
 * sincronía durmiendo a la que va adelantada. Aquí solo se implementa el «dormir/despertar» (sleep/wake) con un mutex y una
 * variable de condición por consola, y la espera dentro de cirilo_runframe.
 * Como libretro se compila con DISABLE_THREADING, el Mutex del coordinador de mGBA es un puntero vacío que no bloquea nada:
 * el workflow cambia MutexInit/Lock/Unlock/Deinit de lockstep.c por cirilo_mx_* (más abajo), que sí son pthread_mutex.
 * Orden de bloqueos (sin inversiones): mutex del coordinador -> mutex de la consola. cirilo_runframe espera solo con el de la consola.
 * API (jni.cpp): create (solo .so 0) / attach (en cada .so, con ambas paradas) / detach / destroy / interrupt (suelta a quien espera). */
#include <pthread.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

/* Mutex real para el coordinador (sustituyen a MutexInit/Deinit/Lock/Unlock dentro de lockstep.c; el hueco del Mutex es un void*). */
int cirilo_mx_init(void** m){pthread_mutex_t* p=malloc(sizeof(*p));if(!p){*m=NULL;return -1;}pthread_mutex_init(p,NULL);*m=p;return 0;}
int cirilo_mx_deinit(void** m){if(*m){pthread_mutex_destroy((pthread_mutex_t*)*m);free(*m);*m=NULL;}return 0;}
int cirilo_mx_lock(void** m){return *m?pthread_mutex_lock((pthread_mutex_t*)*m):0;}
int cirilo_mx_unlock(void** m){return *m?pthread_mutex_unlock((pthread_mutex_t*)*m):0;}

#if defined(M_CORE_GBA) || defined(M_CORE_GB)
#include <mgba/core/lockstep.h>
#include <mgba/core/timing.h>
#ifdef M_CORE_GBA
#include <mgba/internal/gba/gba.h>
#include <mgba/internal/gba/sio/lockstep.h>
#endif
#ifdef M_CORE_GB
#include <mgba/internal/gb/gb.h>
#include <mgba/internal/gb/io.h>
#include <mgba/internal/gb/sio/lockstep.h>
#endif

struct CiriloUser{
	struct mLockstepUser d;int slot;
	pthread_mutex_t m;pthread_cond_t c;int asleep; /* asleep: protegido por m */
};
struct CiriloLink{
	int plat;                          /* 0 = sin decidir (se fija en el primer attach), 1 = GBA, 2 = GB/GBC */
#ifdef M_CORE_GBA
	struct GBASIOLockstepCoordinator coord;
	struct GBASIOLockstepDriver drv[2];
#endif
#ifdef M_CORE_GB
	struct GBSIOLockstep gbl;          /* lockstep de GB: la interfaz mLockstep (gbl.d) la implementamos aquí abajo (en mGBA lo hace el MultiplayerController de Qt) */
	struct GBSIOLockstepNode node[2];
	pthread_mutex_t gblk;              /* «lock» del mLockstep: protege awake/posted/waitMask */
	int awake[2];                      /* 1 = el hilo de esa consola puede correr; 0 = dormida (la otra la despertará) */
	int32_t posted[2];                 /* ciclos que la otra consola le ha dado de margen (cyclesPosted de Qt) */
	unsigned waitMask;                 /* bits = esclavas que el maestro espera */
#endif
	struct CiriloUser usr[2];
	struct mCore* core[2];
	bool in[2];
	volatile int intr;                 /* 1 = se está pausando: nadie debe quedarse esperando a la otra consola */
	volatile int fr[2],wt[2],to[2];    /* diagnóstico: fotogramas terminados, esperas y esperas que vencieron el plazo, por consola */
};
static struct CiriloLink* cl_lk=NULL;static int cl_slot=-1;
static int cl_partial=0; /* el último retro_run salió por una pausa a mitad de fotograma: no se enseña (el siguiente continúa el dibujo) */

/* sleep/wake los llama el lockstep con el mutex del coordinador cogido; sleep siempre desde el hilo de la propia consola, wake desde cualquiera. */
static void cl_sleep(struct mLockstepUser* u){struct CiriloUser* x=(struct CiriloUser*)u;pthread_mutex_lock(&x->m);x->asleep=1;pthread_mutex_unlock(&x->m);}
static void cl_wake(struct mLockstepUser* u){struct CiriloUser* x=(struct CiriloUser*)u;pthread_mutex_lock(&x->m);x->asleep=0;pthread_cond_signal(&x->c);pthread_mutex_unlock(&x->m);}
static void cl_zz(struct CiriloLink* l,int s){struct CiriloUser* x=&l->usr[s];pthread_mutex_lock(&x->m);x->asleep=1;pthread_mutex_unlock(&x->m);}
static void cl_up(struct CiriloLink* l,int s){struct CiriloUser* x=&l->usr[s];pthread_mutex_lock(&x->m);x->asleep=0;pthread_cond_signal(&x->c);pthread_mutex_unlock(&x->m);}
static int cl_reqid(struct mLockstepUser* u){return ((struct CiriloUser*)u)->slot;} /* el slot 0 es el jugador 0 (el que lleva el reloj) */

static void cl_abs(struct timespec* t,long ms){clock_gettime(CLOCK_MONOTONIC,t);t->tv_nsec+=ms*1000000L;while(t->tv_nsec>=1000000000L){t->tv_nsec-=1000000000L;t->tv_sec++;}}
/* Espera mientras esta consola esté dormida (esperando a la otra). Devuelve 0 si se interrumpió (pausa). Plazo de 20 ms por vuelta: red de seguridad ante una señal perdida. */
static int cl_wait(struct CiriloLink* l,int s){
	struct CiriloUser* u=&l->usr[s];int waited=0;
	pthread_mutex_lock(&u->m);
	while(u->asleep&&!l->intr){
		struct timespec t;cl_abs(&t,20);if(!waited){waited=1;__sync_fetch_and_add(&l->wt[s],1);}
		if(pthread_cond_timedwait(&u->c,&u->m,&t)!=0)__sync_fetch_and_add(&l->to[s],1);}
	int ok=!l->intr;
	pthread_mutex_unlock(&u->m);return ok;}

void* cirilo_link_create(void){
	struct CiriloLink* l=calloc(1,sizeof(*l));if(!l)return NULL;
	return l;} /* el lockstep concreto (GBA o GB) se inicializa en el primer attach, cuando ya se sabe la plataforma */

/* 0 = conectado; 1 = plataforma no soportada o distinta a la de la otra consola (sin cable); <0 = error. El juego ya debe estar cargado y las dos consolas paradas. Llamar primero con slot 0. */
#ifdef M_CORE_GB
/* mLockstep de GB. Todos los callbacks (salvo unload) los llama el lockstep con gblk cogido. El id que reciben es el id ACTUAL del lockstep (0 = maestro; cambia cuando la otra consola
 * inicia una transferencia), así que se traduce a consola con gbl.players[id]. (El MultiplayerController de Qt lo hace por orden de alta, que no sigue ese cambio de papeles.) */
static struct CiriloLink* gb_l(struct mLockstep* m){return (struct CiriloLink*)m->context;}
static int gb_slot(struct CiriloLink* l,int id){struct GBSIOLockstepNode* n=(id>=0&&id<2)?l->gbl.players[id]:NULL;return n==&l->node[1]?1:0;}
static void gb_lock(struct mLockstep* m){pthread_mutex_lock(&gb_l(m)->gblk);}
static void gb_unlock(struct mLockstep* m){pthread_mutex_unlock(&gb_l(m)->gblk);}
static bool gb_signal(struct mLockstep* m,unsigned mask){struct CiriloLink* l=gb_l(m);int s=gb_slot(l,0);bool woke=false;
	l->waitMask&=~mask;if(!l->waitMask&&l->awake[s]<1){cl_up(l,s);l->awake[s]=1;woke=true;}return woke;}
static bool gb_wait(struct mLockstep* m,unsigned mask){struct CiriloLink* l=gb_l(m);int s=gb_slot(l,0);
	l->waitMask|=mask;if(l->awake[s]>0){cl_zz(l,s);l->awake[s]=0;}return true;} /* siempre true: el lockstep hace abort() si devuelve false */
static void gb_add(struct mLockstep* m,int id,int32_t cycles){struct CiriloLink* l=gb_l(m);if(cycles<0)cycles=0;
	if(!id){int s=gb_slot(l,1);if(!l->gbl.players[1])return;l->posted[s]+=cycles;if(l->awake[s]<1)l->node[s].nextEvent+=l->posted[s];cl_up(l,s);l->awake[s]=1;}
	else l->posted[gb_slot(l,id)]+=cycles;}
static int32_t gb_use(struct mLockstep* m,int id,int32_t cycles){struct CiriloLink* l=gb_l(m);int s=gb_slot(l,id);
	l->posted[s]-=cycles;if(l->posted[s]<=0){cl_zz(l,s);l->awake[s]=0;}return l->posted[s];}
static int32_t gb_unused(struct mLockstep* m,int id){struct CiriloLink* l=gb_l(m);return l->posted[gb_slot(l,id)];}
/* Se llama desde GBSIOLockstepNodeDeinit (reset del juego o desconexión), SIN el lock cogido. Suelta a la otra consola y deja esta limpia. */
static void gb_unload(struct mLockstep* m,int id){struct CiriloLink* l=gb_l(m);pthread_mutex_lock(&l->gblk);
	int me=gb_slot(l,id);
	if(id){int mas=gb_slot(l,0);l->waitMask&=~(1u<<id);if(!l->waitMask&&l->awake[mas]<1){cl_up(l,mas);l->awake[mas]=1;}}
	else{int i;for(i=1;i<l->gbl.d.attached;++i){int s=gb_slot(l,i);l->posted[s]+=l->gbl.players[0]?l->gbl.players[0]->eventDiff:0;
		if(l->awake[s]<1){l->node[s].nextEvent+=l->posted[s];cl_up(l,s);l->awake[s]=1;}}l->waitMask=0;}
	l->posted[me]=0;if(l->awake[me]<1){cl_up(l,me);l->awake[me]=1;}
	pthread_mutex_unlock(&l->gblk);}
#endif

int cirilo_link_attach(void* p,int slot){
	struct CiriloLink* l=p;if(!l||slot<0||slot>1||!core||!core->board)return -1;
	int plat=0;
#ifdef M_CORE_GBA
	if(core->platform(core)==mPLATFORM_GBA)plat=1;
#endif
#ifdef M_CORE_GB
	if(core->platform(core)==mPLATFORM_GB)plat=2;
#endif
	if(!plat)return 1;
	if(l->plat&&l->plat!=plat)return 1;            /* GBA con GB: no hay cable posible */
	struct CiriloUser* u=&l->usr[slot];memset(u,0,sizeof(*u));
	pthread_mutex_init(&u->m,NULL);
	{pthread_condattr_t a;pthread_condattr_init(&a);pthread_condattr_setclock(&a,CLOCK_MONOTONIC);pthread_cond_init(&u->c,&a);pthread_condattr_destroy(&a);}
	u->d.sleep=cl_sleep;u->d.wake=cl_wake;u->d.requestedId=cl_reqid;u->slot=slot;
	l->intr=0;
	if(!l->plat){
		l->plat=plat;
#ifdef M_CORE_GBA
		if(plat==1)GBASIOLockstepCoordinatorInit(&l->coord);
#endif
#ifdef M_CORE_GB
		if(plat==2){mLockstepInit(&l->gbl.d);GBSIOLockstepInit(&l->gbl);pthread_mutex_init(&l->gblk,NULL);
			l->gbl.d.context=l;l->gbl.d.lock=gb_lock;l->gbl.d.unlock=gb_unlock;l->gbl.d.signal=gb_signal;l->gbl.d.wait=gb_wait;
			l->gbl.d.addCycles=gb_add;l->gbl.d.useCycles=gb_use;l->gbl.d.unusedCycles=gb_unused;l->gbl.d.unload=gb_unload;
			l->awake[0]=l->awake[1]=1;l->posted[0]=l->posted[1]=0;l->waitMask=0;}
#endif
	}
#ifdef M_CORE_GBA
	if(plat==1){
		GBASIOLockstepDriverCreate(&l->drv[slot],&u->d);
		GBASIOLockstepCoordinatorAttach(&l->coord,&l->drv[slot]);
		core->setPeripheral(core,mPERIPH_GBA_LINK_PORT,&l->drv[slot].d);}
#endif
#ifdef M_CORE_GB
	if(plat==2){
		struct GB* gb=core->board;
		memset(&l->node[slot],0,sizeof(l->node[slot]));
		GBSIOLockstepNodeCreate(&l->node[slot]);
		if(!GBSIOLockstepAttachNode(&l->gbl,&l->node[slot]))return -1;
		l->awake[slot]=1;l->posted[slot]=0;
		GBSIOSetDriver(&gb->sio,&l->node[slot].d);}
#endif
	l->core[slot]=core;l->in[slot]=true;cl_lk=l;cl_slot=slot;cl_partial=0;return 0;}

void cirilo_link_detach(void* p,int slot){
	struct CiriloLink* l=p;if(!l||slot<0||slot>1||!l->in[slot])return;
	struct mCore* c=l->core[slot];
#ifdef M_CORE_GBA
	if(l->plat==1){struct GBA* gba=c?c->board:NULL;
		if(gba&&gba->sio.driver==&l->drv[slot].d)c->setPeripheral(c,mPERIPH_GBA_LINK_PORT,NULL);
		GBASIOLockstepCoordinatorDetach(&l->coord,&l->drv[slot]);}
#endif
#ifdef M_CORE_GB
	if(l->plat==2){struct GB* gb=c?c->board:NULL;
		if(gb&&gb->sio.driver==&l->node[slot].d)GBSIOSetDriver(&gb->sio,NULL); /* llama a unload y suelta a la otra consola */
		GBSIOLockstepDetachNode(&l->gbl,&l->node[slot]);}
#endif
	l->in[slot]=false;
	pthread_cond_destroy(&l->usr[slot].c);pthread_mutex_destroy(&l->usr[slot].m);
	if(cl_lk==l){cl_lk=NULL;cl_slot=-1;cl_partial=0;}}

void cirilo_link_destroy(void* p){struct CiriloLink* l=p;if(!l)return;
#ifdef M_CORE_GBA
	if(l->plat==1)GBASIOLockstepCoordinatorDeinit(&l->coord);
#endif
#ifdef M_CORE_GB
	if(l->plat==2){mLockstepDeinit(&l->gbl.d);pthread_mutex_destroy(&l->gblk);}
#endif
	free(l);}

/* on=1: se está pausando (los hilos siguen en marcha): suelta a quien espere a la otra consola y hace que no vuelva a esperar hasta que se llame con on=0
 * (después de unir los hilos). La consola que sale lo hace a mitad de fotograma; al reanudar, el lockstep sigue donde estaba (si estaba dormida, vuelve a esperar). */
void cirilo_link_interrupt(void* p,int on){
	struct CiriloLink* l=p;if(!l)return;
	l->intr=on?1:0;
	if(on){int s;for(s=0;s<2;s++)if(l->in[s]){pthread_mutex_lock(&l->usr[s].m);pthread_cond_broadcast(&l->usr[s].c);pthread_mutex_unlock(&l->usr[s].m);}}}

/* Texto de diagnóstico desde la última lectura: fotogramas terminados, esperas al otro (w) y plazos vencidos (t), por consola (0/1) */
int cirilo_link_dbg(char* out,int n){
	struct CiriloLink* l=cl_lk;if(!l){if(n>0)out[0]=0;return 0;}
	int f0=__sync_lock_test_and_set(&l->fr[0],0),f1=__sync_lock_test_and_set(&l->fr[1],0);
	int w0=__sync_lock_test_and_set(&l->wt[0],0),w1=__sync_lock_test_and_set(&l->wt[1],0);
	int t0=__sync_lock_test_and_set(&l->to[0],0),t1=__sync_lock_test_and_set(&l->to[1],0);
	return snprintf(out,n,"f%d/%d w%d/%d t%d/%d",f0,f1,w0,w1,t0,t1);}

/* Sustituye a core->runFrame(core) en retro_run (el workflow lo parchea). Cada consola avanza SOLO la suya, en el hilo que llama; si el lockstep la
 * duerme (espera a la otra), runLoop sale antes de tiempo y aquí se espera hasta que la otra consola la despierte. */
static uint32_t cl_fc(struct CiriloLink* l,struct mCore* c){
#ifdef M_CORE_GBA
	if(l->plat==1)return ((struct GBA*)c->board)->video.frameCounter;
#endif
#ifdef M_CORE_GB
	if(l->plat==2)return ((struct GB*)c->board)->video.frameCounter;
#endif
	return 0;}
void cirilo_runframe(struct mCore* c){
	struct CiriloLink* l=cl_lk;int s=cl_slot;
	if(!l||s<0||c!=l->core[s]){c->runFrame(c);return;}
	uint32_t f0=cl_fc(l,c);cl_partial=0;
	for(;;){
		if(!cl_wait(l,s)){cl_partial=1;return;}
		c->runLoop(c);
		if(cl_fc(l,c)!=f0)break;}
	__sync_fetch_and_add(&l->fr[s],1);}
/* retro_run enseña esto en vez de outputBuffer (el workflow parchea la llamada): NULL = no hay fotograma nuevo (pausa a mitad de fotograma) */
void* cirilo_vbuf(void* b){if(cl_partial){cl_partial=0;return NULL;}return b;}
/* ---- Estados con Link local (las dos consolas paradas) ----
 * GBA: el lockstep guarda y carga su propio estado: siempre es buen momento y no hace falta reiniciarlo.
 * GB/GBC: el lockstep NO se serializa. Solo se puede guardar sin transferencia en curso (cirilo_link_idle) y, tras cargar los dos estados,
 * hay que reiniciarlo (cirilo_link_resync, en cada .so, primero con slot 0). Sin eso las dos consolas se quedan paradas para siempre. */
int cirilo_link_idle(void* p){
	struct CiriloLink* l=p;if(!l)return 1;
#ifdef M_CORE_GB
	if(l->plat==2)return l->gbl.d.transferActive==TRANSFER_IDLE&&!l->gbl.masterClaimed;
#endif
	return 1;}
void cirilo_link_resync(void* p,int slot){
	struct CiriloLink* l=p;if(!l||slot<0||slot>1||!l->in[slot])return;
#ifdef M_CORE_GB
	if(l->plat==2){
		if(slot==0||!l->in[0]){
			l->gbl.d.transferActive=TRANSFER_IDLE;l->gbl.masterClaimed=false;l->gbl.pendingSB[0]=l->gbl.pendingSB[1]=0xFF;l->waitMask=0;
			int s;for(s=0;s<2;s++){l->posted[s]=0;l->awake[s]=1;if(l->in[s]){pthread_mutex_lock(&l->usr[s].m);l->usr[s].asleep=0;pthread_mutex_unlock(&l->usr[s].m);}}}
		struct GB* gb=l->core[slot]->board;
		GBSIOSetDriver(&gb->sio,&l->node[slot].d);} /* deinit (unload) + init: nextEvent/eventDiff a 0 y evento reprogramado */
#else
	(void)slot;
#endif
}
#else
int cirilo_link_idle(void* p){(void)p;return 1;}
void cirilo_link_resync(void* p,int slot){(void)p;(void)slot;}
void cirilo_runframe(struct mCore* c){c->runFrame(c);}
void* cirilo_vbuf(void* b){return b;}
void* cirilo_link_create(void){return NULL;}
#endif
