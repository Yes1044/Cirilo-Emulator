
/* ---- Cirilo: cable de Link local (GBA) entre dos núcleos del mismo proceso ----------------------------------------
 * Se añade al final de libretro.c (como cirilo_cheats.c) y se compila dentro de cada copia del núcleo (libmgba_libretro.so y
 * libmgba2_libretro.so). El motor es el lockstep de mGBA (src/gba/sio/lockstep.c), que está pensado para UN HILO POR CONSOLA:
 * cada consola corre su propio retro_run en su propio hilo (Emu.kt crea un hilo por consola) y el lockstep las mantiene en
 * sincronía durmiendo a la que va adelantada. Aquí solo se implementa el «dormir/despertar» (sleep/wake) con un mutex y una
 * variable de condición por consola, y la espera dentro de cirilo_runframe.
 * Como libretro se compila con DISABLE_THREADING, el Mutex del coordinador de mGBA es un puntero vacío que no bloquea nada:
 * el workflow cambia MutexInit/Lock/Unlock/Deinit de lockstep.c por cirilo_mx_* (más abajo), que sí son pthread_mutex.
 * Orden de bloqueos (sin inversiones): mutex del coordinador -> mutex de la consola. cirilo_runframe espera solo con el de la consola.
 * API (jni.cpp): create (solo .so 0) / attach (en cada .so, con ambas paradas) / detach / destroy / interrupt (suelta a quien espera). */
#include <pthread.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

/* Mutex real para el coordinador (sustituyen a MutexInit/Deinit/Lock/Unlock dentro de lockstep.c; el hueco del Mutex es un void*). */
int cirilo_mx_init(void** m){pthread_mutex_t* p=malloc(sizeof(*p));if(!p){*m=NULL;return -1;}pthread_mutex_init(p,NULL);*m=p;return 0;}
int cirilo_mx_deinit(void** m){if(*m){pthread_mutex_destroy((pthread_mutex_t*)*m);free(*m);*m=NULL;}return 0;}
int cirilo_mx_lock(void** m){return *m?pthread_mutex_lock((pthread_mutex_t*)*m):0;}
int cirilo_mx_unlock(void** m){return *m?pthread_mutex_unlock((pthread_mutex_t*)*m):0;}

#ifdef M_CORE_GBA
#include <mgba/core/lockstep.h>
#include <mgba/core/timing.h>
#include <mgba/internal/gba/sio/lockstep.h>

struct CiriloUser{
	struct mLockstepUser d;int slot;
	pthread_mutex_t m;pthread_cond_t c;int asleep; /* asleep: protegido por m */
};
struct CiriloLink{
	struct GBASIOLockstepCoordinator coord;
	struct GBASIOLockstepDriver drv[2];
	struct CiriloUser usr[2];
	struct mCore* core[2];
	bool in[2];
	volatile int intr;                 /* 1 = se está pausando: nadie debe quedarse esperando a la otra consola */
	volatile int fr[2],wt[2],to[2];    /* diagnóstico: fotogramas terminados, esperas y esperas que vencieron el plazo, por consola */
};
static struct CiriloLink* cl_lk=NULL;static int cl_slot=-1;
static int cl_partial=0; /* el último retro_run salió por una pausa a mitad de fotograma: no se enseña (el siguiente continúa el dibujo) */

/* sleep/wake los llama el lockstep con el mutex del coordinador cogido; sleep siempre desde el hilo de la propia consola, wake desde cualquiera. */
static void cl_sleep(struct mLockstepUser* u){struct CiriloUser* x=(struct CiriloUser*)u;pthread_mutex_lock(&x->m);x->asleep=1;pthread_mutex_unlock(&x->m);}
static void cl_wake(struct mLockstepUser* u){struct CiriloUser* x=(struct CiriloUser*)u;pthread_mutex_lock(&x->m);x->asleep=0;pthread_cond_signal(&x->c);pthread_mutex_unlock(&x->m);}
static int cl_reqid(struct mLockstepUser* u){return ((struct CiriloUser*)u)->slot;} /* el slot 0 es el jugador 0 (el que lleva el reloj) */

static void cl_abs(struct timespec* t,long ms){clock_gettime(CLOCK_MONOTONIC,t);t->tv_nsec+=ms*1000000L;while(t->tv_nsec>=1000000000L){t->tv_nsec-=1000000000L;t->tv_sec++;}}
/* Espera mientras esta consola esté dormida (esperando a la otra). Devuelve 0 si se interrumpió (pausa). Plazo de 20 ms por vuelta: red de seguridad ante una señal perdida. */
static int cl_wait(struct CiriloLink* l,int s){
	struct CiriloUser* u=&l->usr[s];int waited=0;
	pthread_mutex_lock(&u->m);
	while(u->asleep&&!l->intr){
		struct timespec t;cl_abs(&t,20);if(!waited){waited=1;__sync_fetch_and_add(&l->wt[s],1);}
		if(pthread_cond_timedwait(&u->c,&u->m,&t)!=0)__sync_fetch_and_add(&l->to[s],1);}
	int ok=!l->intr;
	pthread_mutex_unlock(&u->m);return ok;}

void* cirilo_link_create(void){
	struct CiriloLink* l=calloc(1,sizeof(*l));if(!l)return NULL;
	GBASIOLockstepCoordinatorInit(&l->coord);return l;}

/* 0 = conectado; 1 = este juego no es GBA (sin cable); <0 = error. El juego ya debe estar cargado. */
int cirilo_link_attach(void* p,int slot){
	struct CiriloLink* l=p;if(!l||slot<0||slot>1||!core||!core->board)return -1;
	if(core->platform(core)!=mPLATFORM_GBA)return 1;
	struct CiriloUser* u=&l->usr[slot];memset(u,0,sizeof(*u));
	pthread_mutex_init(&u->m,NULL);
	{pthread_condattr_t a;pthread_condattr_init(&a);pthread_condattr_setclock(&a,CLOCK_MONOTONIC);pthread_cond_init(&u->c,&a);pthread_condattr_destroy(&a);}
	u->d.sleep=cl_sleep;u->d.wake=cl_wake;u->d.requestedId=cl_reqid;u->slot=slot;
	l->intr=0;
	GBASIOLockstepDriverCreate(&l->drv[slot],&u->d);
	GBASIOLockstepCoordinatorAttach(&l->coord,&l->drv[slot]);
	core->setPeripheral(core,mPERIPH_GBA_LINK_PORT,&l->drv[slot].d);
	l->core[slot]=core;l->in[slot]=true;cl_lk=l;cl_slot=slot;cl_partial=0;return 0;}

void cirilo_link_detach(void* p,int slot){
	struct CiriloLink* l=p;if(!l||slot<0||slot>1||!l->in[slot])return;
	struct mCore* c=l->core[slot];struct GBA* gba=c?c->board:NULL;
	if(gba&&gba->sio.driver==&l->drv[slot].d)c->setPeripheral(c,mPERIPH_GBA_LINK_PORT,NULL);
	GBASIOLockstepCoordinatorDetach(&l->coord,&l->drv[slot]);
	l->in[slot]=false;
	pthread_cond_destroy(&l->usr[slot].c);pthread_mutex_destroy(&l->usr[slot].m);
	if(cl_lk==l){cl_lk=NULL;cl_slot=-1;cl_partial=0;}}

void cirilo_link_destroy(void* p){struct CiriloLink* l=p;if(!l)return;GBASIOLockstepCoordinatorDeinit(&l->coord);free(l);}

/* on=1: se está pausando (los hilos siguen en marcha): suelta a quien espere a la otra consola y hace que no vuelva a esperar hasta que se llame con on=0
 * (después de unir los hilos). La consola que sale lo hace a mitad de fotograma; al reanudar, el lockstep sigue donde estaba (si estaba dormida, vuelve a esperar). */
void cirilo_link_interrupt(void* p,int on){
	struct CiriloLink* l=p;if(!l)return;
	l->intr=on?1:0;
	if(on){int s;for(s=0;s<2;s++)if(l->in[s]){pthread_mutex_lock(&l->usr[s].m);pthread_cond_broadcast(&l->usr[s].c);pthread_mutex_unlock(&l->usr[s].m);}}}

/* Texto de diagnóstico desde la última lectura: fotogramas terminados, esperas al otro (w) y plazos vencidos (t), por consola (0/1) */
int cirilo_link_dbg(char* out,int n){
	struct CiriloLink* l=cl_lk;if(!l){if(n>0)out[0]=0;return 0;}
	int f0=__sync_lock_test_and_set(&l->fr[0],0),f1=__sync_lock_test_and_set(&l->fr[1],0);
	int w0=__sync_lock_test_and_set(&l->wt[0],0),w1=__sync_lock_test_and_set(&l->wt[1],0);
	int t0=__sync_lock_test_and_set(&l->to[0],0),t1=__sync_lock_test_and_set(&l->to[1],0);
	return snprintf(out,n,"f%d/%d w%d/%d t%d/%d",f0,f1,w0,w1,t0,t1);}

/* Sustituye a core->runFrame(core) en retro_run (el workflow lo parchea). Cada consola avanza SOLO la suya, en el hilo que llama; si el lockstep la
 * duerme (espera a la otra), runLoop sale antes de tiempo y aquí se espera hasta que la otra consola la despierte. */
void cirilo_runframe(struct mCore* c){
	struct CiriloLink* l=cl_lk;int s=cl_slot;
	if(!l||s<0||c!=l->core[s]){c->runFrame(c);return;}
	struct GBA* g=c->board;uint32_t f0=g->video.frameCounter;cl_partial=0;
	for(;;){
		if(!cl_wait(l,s)){cl_partial=1;return;}
		c->runLoop(c);
		if(g->video.frameCounter!=f0)break;}
	__sync_fetch_and_add(&l->fr[s],1);}
/* retro_run enseña esto en vez de outputBuffer (el workflow parchea la llamada): NULL = no hay fotograma nuevo (pausa a mitad de fotograma) */
void* cirilo_vbuf(void* b){if(cl_partial){cl_partial=0;return NULL;}return b;}
#else
void cirilo_runframe(struct mCore* c){c->runFrame(c);}
void* cirilo_vbuf(void* b){return b;}
void* cirilo_link_create(void){return NULL;}
#endif
