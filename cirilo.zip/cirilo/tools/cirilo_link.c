
/* ---- Cirilo: cable de Link local (GBA) entre dos núcleos del mismo proceso ----------------------------------------
 * Se añade al final de libretro.c (como cirilo_cheats.c) y se compila dentro de cada copia del núcleo (libmgba_libretro.so y
 * libmgba2_libretro.so). El motor es el lockstep de mGBA (src/gba/sio/lockstep.c), pero SIN hilos: en libretro no hay hilo por
 * consola (DISABLE_THREADING), así que las dos consolas las avanza una sola función (cl_frame) en el hilo del slot 0.
 * sleep()/wake() del lockstep solo marcan «esta consola espera»; el propio lockstep ya saca a la CPU de su bucle (earlyExit).
 * API (jni.cpp): create (solo .so 0) / attach (en cada .so, con ambas paradas) / detach / destroy / interrupt (sin efecto sin hilos). */
#ifdef M_CORE_GBA
#include <mgba/core/lockstep.h>
#include <mgba/core/timing.h>
#include <mgba/internal/gba/sio/lockstep.h>

struct CiriloUser{struct mLockstepUser d;int slot;volatile int asleep;};
struct CiriloLink{
	struct GBASIOLockstepCoordinator coord;
	struct GBASIOLockstepDriver drv[2];
	struct CiriloUser usr[2];
	struct mCore* core[2];
	mColor* vbuf[2];   /* el búfer de vídeo de cada núcleo (outputBuffer de su libretro.c) */
	mColor* snap[2];   /* copia del fotograma terminado: una consola puede adelantarse al fotograma siguiente mientras la otra termina el suyo */
	bool in[2];
};
static struct CiriloLink* cl_lk=NULL;static int cl_slot=-1;

static void cl_sleep(struct mLockstepUser* u){((struct CiriloUser*)u)->asleep=1;}
static void cl_wake(struct mLockstepUser* u){((struct CiriloUser*)u)->asleep=0;}
static int cl_reqid(struct mLockstepUser* u){return ((struct CiriloUser*)u)->slot;} /* el slot 0 es el jugador 0 (el que lleva el reloj) */

void* cirilo_link_create(void){
	struct CiriloLink* l=calloc(1,sizeof(*l));if(!l)return NULL;
	GBASIOLockstepCoordinatorInit(&l->coord);return l;}

/* 0 = conectado; 1 = este juego no es GBA (sin cable); <0 = error. El juego ya debe estar cargado. */
int cirilo_link_attach(void* p,int slot){
	struct CiriloLink* l=p;if(!l||slot<0||slot>1||!core||!core->board)return -1;
	if(core->platform(core)!=mPLATFORM_GBA)return 1;
	l->snap[slot]=malloc(VIDEO_BUFF_SIZE);if(!l->snap[slot])return -2;
	struct CiriloUser* u=&l->usr[slot];memset(u,0,sizeof(*u));
	u->d.sleep=cl_sleep;u->d.wake=cl_wake;u->d.requestedId=cl_reqid;u->slot=slot;
	GBASIOLockstepDriverCreate(&l->drv[slot],&u->d);
	GBASIOLockstepCoordinatorAttach(&l->coord,&l->drv[slot]);
	core->setPeripheral(core,mPERIPH_GBA_LINK_PORT,&l->drv[slot].d);
	l->core[slot]=core;l->vbuf[slot]=outputBuffer;l->in[slot]=true;cl_lk=l;cl_slot=slot;return 0;}

void cirilo_link_detach(void* p,int slot){
	struct CiriloLink* l=p;if(!l||slot<0||slot>1||!l->in[slot])return;
	struct mCore* c=l->core[slot];struct GBA* gba=c?c->board:NULL;
	if(gba&&gba->sio.driver==&l->drv[slot].d)c->setPeripheral(c,mPERIPH_GBA_LINK_PORT,NULL);
	GBASIOLockstepCoordinatorDetach(&l->coord,&l->drv[slot]);
	l->in[slot]=false;free(l->snap[slot]);l->snap[slot]=NULL;
	if(cl_lk==l){cl_lk=NULL;cl_slot=-1;}}

void cirilo_link_destroy(void* p){struct CiriloLink* l=p;if(!l)return;GBASIOLockstepCoordinatorDeinit(&l->coord);free(l);}
void cirilo_link_interrupt(void* p,int on){(void)p;(void)on;} /* sin hilos nadie espera dentro de retro_run: no hace falta soltar a nadie */

/* Avanza las dos consolas hasta que cada una termine un fotograma. Siempre corre la que va por detrás en el tiempo compartido y no duerme;
 * si la que falta duerme (espera a la otra), avanza la que ya terminó (solo unos ciclos: el lockstep las mantiene a ≤4096 ciclos). */
static void cl_frame(struct CiriloLink* l){
	uint32_t f0[2];int32_t t0[2];int done[2]={0,0};int s,it;
	for(s=0;s<2;s++){struct GBA* g=l->core[s]->board;f0[s]=g->video.frameCounter;t0[s]=mTimingCurrentTime(&g->timing);}
	for(it=0;!(done[0]&&done[1])&&it<400000;it++){
		int pick=-1,pass;int32_t best=0;
		for(pass=0;pass<2&&pick<0;pass++)for(s=0;s<2;s++){
			if(l->usr[s].asleep||(pass==0&&done[s]))continue;
			struct GBA* g=l->core[s]->board;int32_t t=mTimingCurrentTime(&g->timing)-t0[s];
			if(pick<0||t-best<0){pick=s;best=t;}}
		if(pick<0)break; /* las dos esperan: no debería pasar; se sale para no colgar la app */
		struct mCore* c=l->core[pick];c->runLoop(c);
		struct GBA* g=c->board;
		if(!done[pick]&&g->video.frameCounter!=f0[pick]){done[pick]=1;memcpy(l->snap[pick],l->vbuf[pick],VIDEO_BUFF_SIZE);}}
	for(s=0;s<2;s++)if(done[s])memcpy(l->vbuf[s],l->snap[s],VIDEO_BUFF_SIZE); /* cada una enseña su fotograma terminado, no el que lleva a medias */
}

/* Sustituye a core->runFrame(core) en retro_run (el workflow lo parchea). Con cable, el slot 0 corre las dos y el slot 1 solo saca lo suyo
 * (por eso el hilo de Kotlin llama a run(0) y luego a run(1)). */
void cirilo_runframe(struct mCore* c){
	if(!cl_lk||cl_slot<0||c!=cl_lk->core[cl_slot]){c->runFrame(c);return;}
	if(cl_slot==0)cl_frame(cl_lk);}
#else
void cirilo_runframe(struct mCore* c){c->runFrame(c);}
void* cirilo_link_create(void){return NULL;}
#endif
