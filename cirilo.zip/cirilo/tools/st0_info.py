#!/usr/bin/env python3
"""Muestra lo que se sabe de un estado .st0 de My Boy! / My OldBoy! (ver README, «Estados .st0»).
Uso: python3 tools/st0_info.py "Juego.st0"
Solo lee; no convierte nada. Los campos de GBA son deducciones coherentes con un único estado real (Pokémon Esmeralda): PC en Thumb, LR impar, SP en IWRAM, BG0..3CNT con valores típicos de Esmeralda."""
import gzip, struct, sys

d = gzip.open(sys.argv[1]).read()
magic = d[:8].decode('ascii', 'replace')
ver = struct.unpack('>I', d[8:12])[0]
print(f"{len(d)} bytes descomprimidos · magia {magic!r} · versión {ver}")
if magic == 'GBASTATE':
    print("título:", d[12:24].decode('ascii', 'replace').rstrip('\0 '), "· código:", d[24:28].decode('ascii', 'replace'))
    w = lambda o: struct.unpack('>I', d[o:o + 4])[0]  # enteros de 32 bits, big-endian
    names = [f"r{i}" for i in range(13)] + ["sp", "lr", "pc"]
    print("CPU (deducido): r0..r15 desde 0x20, CPSR en 0x60")
    for i, n in enumerate(names):
        print(f"  {n:>3} = {w(0x20 + 4 * i):08x}")
    cpsr = w(0x60)
    print(f"  cpsr = {cpsr:08x}  (modo {cpsr & 0x1f:02x}, {'Thumb' if cpsr & 0x20 else 'ARM'})")
    io = 0x8d0  # los registros de vídeo están en su orden natural desde aquí, en little-endian (hasta BLDY, +0x54)
    h = lambda off: struct.unpack('<H', d[io + off:io + off + 2])[0]
    print(f"E/S de vídeo desde 0x{io:x}: DISPCNT={h(0):04x} DISPSTAT={h(4):04x} BG0..3CNT={h(8):04x} {h(10):04x} {h(12):04x} {h(14):04x} BLDCNT={h(0x50):04x}")
elif magic == 'GBCSTATE':
    print("título (cabecera 0x134 del cartucho, 16 bytes):", d[12:28])
else:
    print("no es un estado de My Boy! / My OldBoy!")
