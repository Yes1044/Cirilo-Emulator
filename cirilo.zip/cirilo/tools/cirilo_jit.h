/* Cirilo JIT (Fase 1): declaraciones compartidas. Se copia a include/mgba/internal/gba/ (lo incluyen memory.c y cirilo_fast.h) y lo implementa cirilo_jit_arm.inc dentro de src/arm/arm.c.
 * Las macros CIRILO_JIT_IW/EW van tras CADA escritura a IWRAM/EWRAM del núcleo (CPU, STM, DMA, trucos): consultan un mapa de trozos de 256 bytes que contienen código ya
 * traducido (una lectura y una comparación) y solo si hay código avisan a cirilo_jit_smc, que tira los bloques afectados. Con el JIT apagado el mapa está a cero. */
#ifndef CIRILO_JIT_H
#define CIRILO_JIT_H
#include <stdint.h>
/* [0..127] = IWRAM (32 KB / 256), [128..1151] = EWRAM (256 KB / 256) */
extern uint8_t cirilo_jit_gran[1152];
extern int cirilo_jit_on;
void cirilo_jit_smc(int ewram, uint32_t offset, uint32_t size);
void cirilo_jit_flush(void);
void cirilo_jit_reset(uint32_t romSize);
void cirilo_jit_patch(uint32_t address);
#define CIRILO_JIT_IW(off, sz) do { if (cirilo_jit_gran[(off) >> 8]) cirilo_jit_smc(0, (off), (sz)); } while (0)
#define CIRILO_JIT_EW(off, sz) do { if (cirilo_jit_gran[128 + ((off) >> 8)]) cirilo_jit_smc(1, (off), (sz)); } while (0)
#endif
