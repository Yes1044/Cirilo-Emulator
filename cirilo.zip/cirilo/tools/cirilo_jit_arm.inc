/* Cirilo JIT, FASE 1: esqueleto SIN código nativo. Se incluye dentro de src/arm/arm.c (justo antes de ARMRunLoop) para ver ARMStep/ThumbStep, _armTable y conditionLut.
 *
 * Qué hace: cuando un punto del programa se ejecuta varias veces («caliente»), se guarda un BLOQUE (opcodes desde ese punto hasta el siguiente salto, máx. CJ_MAXN
 * instrucciones, modo ARM o Thumb como parte de la identidad) en una caché con límite. Ejecutar un bloque = lo mismo que ARMStep/ThumbStep, instrucción a instrucción y con
 * los mismos ciclos, pero la captación de la instrucción que entra en el pipeline sale de la copia guardada en vez de leer la memoria. Si esa copia estuviera vieja
 * (código automodificable sin invalidar), el resultado diferiría del intérprete y jit_cmp lo detectaría: así se prueba la INVALIDACIÓN (SMC), el pipeline, los ciclos exactos
 * y la salida del bloque en cada instrucción, antes de generar una sola instrucción nativa (Fase 2).
 *
 * Reglas que se mantienen para el JIT real:
 *  - Cada instrucción comprueba cycles >= nextEvent al terminar (el intérprete también: muchas escrituras a E/S ponen nextEvent = cycles para forzar la salida).
 *  - Los bloques solo cubren ROM, IWRAM y EWRAM; nunca cruzan una página de 4 KB. La ROM no se vigila (solo se vacía si un truco la parchea); IWRAM/EWRAM sí (mapa por trozos de 256 B).
 *  - Un trozo que se invalida más de CJ_BAN veces se prohíbe (se interpreta siempre) para no repetir traducir/tirar.
 *  - Al entrar se comprueba que prefetch[0..1] coinciden con la copia; si no, se interpreta. */
#include <mgba/internal/gba/cirilo_jit.h>
#include <string.h>
#if defined(__aarch64__) && !defined(CIRILO_JIT_SIM)
#include <sys/mman.h>
#include <signal.h>
#include <setjmp.h>
#include "cirilo_jit_mem.h" /* memoria ejecutable sin presuponer RWX (doble vista RW/RX si hace falta) */
#define CJ_NATIVE_HOST 1 /* ejecuta de verdad el código que emite */
#elif defined(CIRILO_JIT_SIM)
#define CJ_NATIVE_HOST 2 /* lo ejecuta el simulador de pruebas */
#else
#define CJ_NATIVE_HOST 0 /* otro anfitrión: sin código nativo, solo la Fase 1 */
#endif

#define CJ_EXPORT __attribute__((visibility("default")))
#define CJ_MAXN 24
#define CJ_POOL_WORDS (1 << 18) /* 1 MB de bloques */
#define CJ_TAB 4096
#define CJ_RAMMAX 2048
#define CJ_HOT 3
#define CJ_BAN 48
#define CJ_MINK 2 /* un tramo nativo necesita al menos 2 instrucciones (p. ej. cmp + bcond) para compensar la llamada */
#define CJ_CODE_WORDS (1 << 18) /* 1 MB de código nativo */
/* FASE 2c (que el JIT no pierda contra el intérprete). Dos modos de compilación:
 *  - Núcleo de pruebas de CI (-DCIRILO_JIT_TEST): se mantiene el comportamiento de las fases anteriores. Todos los bloques (también los ARM y los Thumb sin código nativo) se ejecutan con la
 *    captación leída de la copia, así que un fallo de invalidación se nota; se cuentan todos los contadores; y el filtro de ganancia está APAGADO para que se pruebe todo el código nativo.
 *  - Núcleo de la app: solo hay bloques Thumb; un bloque sin código nativo (o lo que queda de uno tras su tramo nativo) se ejecuta con ThumbStep tal cual, que es exacto siempre porque es
 *    el propio intérprete; el modo ARM usa el bucle original sin consultar la caché; y solo se deja código nativo donde la ganancia estimada compensa el costo de entrar y salir. */
#ifdef CIRILO_JIT_TEST
static int cjCopyModeV = 1; /* pruebas: cirilo_jit_debug(8) pasa al modo de la app para que el CI también lo ejercite */
#define CJ_COPY_MODE cjCopyModeV
#define CJSTAT(i) (++cjStat[i])
#define CJ_GATE_DEFAULT 0
#else
#define CJ_COPY_MODE 0
#define CJSTAT(i) ((void) 0)
#define CJ_GATE_DEFAULT 1
#endif
/* Estimación en ciclos del anfitrión (a calibrar con los contadores del panel): lo que ahorra una instrucción pura o un salto traducidos frente a ThumbStep, y lo que cuesta entrar y salir
 * del tramo nativo (llamada, decodificar el estado, ThumbWritePC) más cada acceso a memoria (marco de pila + llamada a la función auxiliar, que no es más rápida que el manejador del intérprete). */
#define CJ_GAIN_PURE 8
#define CJ_GAIN_BR 6
#define CJ_COST_ENTRY 28 /* + words/3 del código emitido (≈12 en un tramo típico de 6 instrucciones: el total sigue siendo ≈40 como antes) */
#define CJ_COST_MEM 6

struct CJBlock {
	uint32_t pc;
	uint32_t lo, hi; /* RAM: desplazamiento físico del primer y último byte captados */
	uint16_t n;
	uint8_t thumb, valid, ram, ew;
	struct CJBlock* next; /* cadena del cajón de la tabla: sin expulsiones por colisión */
	uint32_t* code; /* tramo nativo de los k primeros instrucciones (Thumb), o NULL */
	uint16_t k;
	uint8_t p0, tail; /* tramo con memoria: instrucciones puras antes del primer acceso / pendientes al final */
	uint8_t fr; /* el tramo nativo tiene accesos a memoria: lleva su propia contabilidad de ciclos */
	uint8_t bk; /* el tramo nativo acaba en: 0 = instrucciones puras, 1 = Bcond, 2 = salto incondicional */
	uint32_t target; /* destino de ese salto */
	uint32_t op[CJ_MAXN + 2];
};

int cirilo_jit_on = 0;
uint8_t cirilo_jit_gran[1152];
static uint8_t cjBan[1152], cjInv[1152];
static uint16_t cjGcnt[1152]; /* por trozo de 256 B: bloques válidos que lo tocan (cirilo_jit_gran[i] = cjGcnt[i] != 0; sin recorrer la lista de bloques) */
/* Calor: tabla de 2 vías CON etiqueta (la clave completa pc|thumb). Antes el contador se indexaba solo por el hash, así que dos PC que colisionaban se contaban juntos
 * y podían traducir un punto que no era caliente. Un punto es caliente tras CJ_HOT visitas seguidas sin que otro lo expulse. */
static uint32_t cjHeatKey[CJ_TAB];
static uint8_t cjHeatCnt[CJ_TAB];
static inline int cjHeatBump(uint32_t key, uint32_t h) { /* devuelve 1 cuando el punto se vuelve caliente (y reinicia su contador) */
	uint32_t k = key | 0x80000000u, i0 = h, i1 = h ^ 1, v;
	if (cjHeatKey[i0] == k) {
		v = i0;
	} else if (cjHeatKey[i1] == k) {
		v = i1;
	} else {
		v = cjHeatCnt[i0] <= cjHeatCnt[i1] ? i0 : i1;
		cjHeatKey[v] = k;
		cjHeatCnt[v] = 0;
	}
	if (++cjHeatCnt[v] >= CJ_HOT) {
		cjHeatCnt[v] = 0;
		return 1;
	}
	return 0;
}
static uint32_t cjGLo[1152], cjGHi[1152]; /* por trozo con código: rango (desplazamiento físico) que cubren sus bloques; una escritura fuera de él no toca ningún bloque */
static struct CJBlock* cjTab[CJ_TAB];
/* Tabla compacta de acceso rápido (caché de cjTab): una sola línea de caché por entrada, sin recorrer cadenas. Una entrada con clave = pc | thumb es SIEMPRE de un bloque válido (se anula
 * al invalidarlo); info = n de instrucciones del bloque, y el bit 16 marca «sin código nativo» para ejecutarlo sin tocar el bloque. Si hay colisión se cae a la cadena y se vuelve a llenar. */
#define CJ_FAST 4096
struct CJFast {
	uint32_t key, info;
	struct CJBlock* b;
};
static struct CJFast cjFast[CJ_FAST];
static inline uint32_t cjFh(uint32_t pc) {
	return ((pc >> 1) ^ (pc >> 13)) & (CJ_FAST - 1);
}
static struct CJBlock* cjRam[CJ_RAMMAX];
static uint32_t cjRamN, cjPoolUsed, cjRomSize;
static uint32_t cjPool[CJ_POOL_WORDS];
enum { S_CREATED, S_BLOCKS, S_INSTR_BLOCK, S_INSTR_INTERP, S_INVAL, S_FLUSH, S_SMC_CALLS, S_BANNED, S_MIDEXIT, S_PMISS, S_REFUSED, S_NBLOCKS, S_NRUNS, S_NBAIL, S_NINSTR, S_NTAKEN, S_NNOTTAKEN, S_NEARLY, S_PRUNS, S_CWORDS /* palabras de código nativo emitidas */, S_CINSTR /* instrucciones del juego cubiertas por ese código */, S_PC /* PC al salir del último tramo (no acumula) */, S_N };
static uint32_t cjStat[S_N];

#include "cirilo_jit_a64.inc"
#ifdef CIRILO_JIT_SIM
#include "cirilo_jit_a64sim.inc"
#endif
static uint32_t* cjCode; /* dirección de EJECUCIÓN (vista RX) */
static uint32_t* cjCodeCur;
static ptrdiff_t cjDelta; /* bytes: vista de escritura - vista de ejecución (0 con RWX o en el simulador) */
static int cjNativeOn; /* 1 si hay memoria de código, el anfitrión puede ejecutarla y la autoprueba pasó */
static int cjNativeOff; /* pruebas: fuerza el modo de la Fase 1 */
static int cjDiagA; /* diagnóstico (modo 2 de cirilo_jit_set): solo el despachador, ningún bloque lleva código nativo */
static int cjDiagB; /* diagnóstico (modo 3): código nativo solo para aritmética y saltos; el tramo termina antes de la primera carga o guardado */
static int cjGate = CJ_GATE_DEFAULT; /* 1 = solo deja código nativo donde compensa (cjWorth) */
/* Estado del JIT tras cirilo_jit_set: 0 apagado, 1 activo con código nativo, 2 diagnóstico A, -1 no hay memoria ejecutable, -2 la autoprueba de arranque falló, -3 este anfitrión no genera código nativo.
 * Con estado < 0 el JIT queda APAGADO (cirilo_jit_on = 0) y el núcleo usa el intérprete original: nunca el despachador sin código nativo. */
static int cjStatus;
static int cjCut = 1; /* 1 = cortar bloques en la primera instrucción no traducible (pruebas: bit 128 de cirilo_jit_debug lo apaga para comparar cobertura) */
static int cjMemForce; /* pruebas: 3 = simula que no hay memoria ejecutable (cirilo_jit_debug) */
#if CJ_NATIVE_HOST == 1
static struct CJMem cjMem;
#endif
static inline uint32_t* cjW(uint32_t* x) { /* dirección de escritura de una dirección de ejecución */
	return (uint32_t*) ((uint8_t*) x + cjDelta);
}
static inline uint32_t* cjX(uint32_t* w) {
	return (uint32_t*) ((uint8_t*) w - cjDelta);
}
static void cjCodeInit(void) {
	if (cjCode || CJ_NATIVE_HOST == 0) {
		return;
	}
#if CJ_NATIVE_HOST == 1
	if (cjMemAlloc(&cjMem, CJ_CODE_WORDS * 4, 0)) {
		cjCode = (uint32_t*) cjMem.rx;
		cjDelta = cjMem.rw - cjMem.rx;
	}
#else
	static uint32_t simBuf[CJ_CODE_WORDS];
	cjCode = simBuf;
#endif
	cjCodeCur = cjCode;
}
static inline void cjCodeFlush(uint32_t* from, uint32_t* to) {
#if CJ_NATIVE_HOST == 1
	__builtin___clear_cache((char*) from, (char*) to);
#else
	(void) from; (void) to;
#endif
}
/* Funciones auxiliares que llama el código nativo para cargas y guardados Thumb. Reproducen EXACTAMENTE un manejador del intérprete:
 *   currentCycles = 1 + activeSeqCycles16 (esperas de la región de ORIGEN, antes del acceso); acceso (añade sus ciclos); currentCycles += nonseq16 - seq16 (con las esperas de DESPUÉS);
 *   cpu->cycles += currentCycles (sobre el valor que tenga cpu->cycles tras el acceso, por si el acceso lo toca).
 * Antes del acceso dejan PC, pipeline y cpu->cycles como los tendría el intérprete (el acceso puede leer el bus abierto o el reloj). */
#if __has_include(<mgba/internal/gba/cirilo_fast.h>)
#include <mgba/internal/gba/cirilo_fast.h>
#define CJ_LD32(cpu, a, cc) cirilo_ld32(cpu, a, cc)
#define CJ_LD16(cpu, a, cc) cirilo_ld16(cpu, a, cc)
#define CJ_LD8(cpu, a, cc) cirilo_ld8(cpu, a, cc)
#define CJ_ST32(cpu, a, v, cc) cirilo_st32(cpu, a, v, cc)
#define CJ_ST16(cpu, a, v, cc) cirilo_st16(cpu, a, v, cc)
#define CJ_ST8(cpu, a, v, cc) cirilo_st8(cpu, a, v, cc)
#else
#define CJ_LD32(cpu, a, cc) ((cpu)->memory.load32(cpu, a, cc))
#define CJ_LD16(cpu, a, cc) ((cpu)->memory.load16(cpu, a, cc))
#define CJ_LD8(cpu, a, cc) ((cpu)->memory.load8(cpu, a, cc))
#define CJ_ST32(cpu, a, v, cc) ((cpu)->memory.store32(cpu, a, v, cc))
#define CJ_ST16(cpu, a, v, cc) ((cpu)->memory.store16(cpu, a, v, cc))
#define CJ_ST8(cpu, a, v, cc) ((cpu)->memory.store8(cpu, a, v, cc))
#endif
/* jpk = índice de la instrucción en el bloque (5 bits) | instrucciones puras pendientes << 5 | margen que hay que dejar para el siguiente trozo puro << 10. El bloque es cjCurBlock (lo fija el
 * despachador antes de llamar al código nativo). Las pendientes se cobran con las esperas de ANTES del acceso. */
static struct CJBlock* cjCurBlock; /* bloque cuyo tramo nativo se está ejecutando: de él sacan las funciones auxiliares PC y pipeline, y si un guardado lo invalida (código automodificable) hay que salir tras ese guardado */
#define CJ_MEM_PRE \
	const struct CJBlock* cb_ = cjCurBlock; \
	uint32_t j_ = jpk & 31, pend_ = (jpk >> 5) & 31, need_ = jpk >> 10; \
	cpu->gprs[ARM_PC] = (int32_t) (cb_->pc + 2 * j_ + 4); \
	cpu->prefetch[0] = cb_->op[j_ + 1]; \
	cpu->prefetch[1] = cb_->op[j_ + 2]; \
	cpu->cycles += (int32_t) (pend_ * (1u + (uint32_t) cpu->memory.activeSeqCycles16)); \
	int cc = 1 + cpu->memory.activeSeqCycles16;
/* «salir»: el intérprete habría parado (cycles >= nextEvent) o no cabe lo que sigue (need_ instrucciones con las esperas de DESPUÉS del acceso) */
#define CJ_MEM_POST \
	cc += cpu->memory.activeNonseqCycles16 - cpu->memory.activeSeqCycles16; \
	cpu->cycles += cc; \
	uint64_t ex_ = cpu->cycles >= cpu->nextEvent || (need_ && (uint32_t) (cpu->nextEvent - cpu->cycles) <= need_ * (1u + (uint32_t) cpu->memory.activeSeqCycles16));
#define CJ_HELPER_ARGS struct ARMCore* cpu, uint32_t addr, uint32_t jpk, uint32_t value
static uint64_t cjH_ld32(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = CJ_LD32(cpu, addr, &cc); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ld16(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = CJ_LD16(cpu, addr, &cc); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ld8(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = CJ_LD8(cpu, addr, &cc); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ldsb(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = (uint32_t) ARM_SXT_8(CJ_LD8(cpu, addr, &cc)); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ldsh(CJ_HELPER_ARGS) {
	CJ_MEM_PRE
	uint32_t v = addr & 1 ? (uint32_t) ARM_SXT_8(CJ_LD16(cpu, addr, &cc)) : (uint32_t) ARM_SXT_16(CJ_LD16(cpu, addr, &cc));
	CJ_MEM_POST
	(void) value;
	return v | (ex_ << 32);
}
static uint64_t cjH_st32(CJ_HELPER_ARGS) { CJ_MEM_PRE CJ_ST32(cpu, addr, (int32_t) value, &cc); CJ_MEM_POST return (ex_ | (cjCurBlock && !cjCurBlock->valid)) << 32; }
static uint64_t cjH_st16(CJ_HELPER_ARGS) { CJ_MEM_PRE CJ_ST16(cpu, addr, (int16_t) value, &cc); CJ_MEM_POST return (ex_ | (cjCurBlock && !cjCurBlock->valid)) << 32; }
static uint64_t cjH_st8(CJ_HELPER_ARGS) { CJ_MEM_PRE CJ_ST8(cpu, addr, (int8_t) value, &cc); CJ_MEM_POST return (ex_ | (cjCurBlock && !cjCurBlock->valid)) << 32; }
static const void* const cjHelperTab[H_COUNT] = {cjH_ld32, cjH_ld16, cjH_ld8, cjH_ldsb, cjH_ldsh, cjH_st32, cjH_st16, cjH_st8};

static inline uint32_t cjCallNative(const uint32_t* code, struct ARMCore* cpu, const uint32_t* ops, const void* const* tab) {
#if CJ_NATIVE_HOST == 1
	return ((uint32_t (*)(struct ARMCore*, const uint32_t*, const void* const*)) (uintptr_t) code)(cpu, ops, tab);
#elif CJ_NATIVE_HOST == 2
	return cjSimRun(code, cpu, ops, tab);
#else
	(void) code; (void) cpu; (void) ops; (void) tab;
	return 0;
#endif
}

/* Ejecuta un tramo nativo de k instrucciones. El código nativo NO lleva la cuenta de ciclos (los accesos a memoria se la entregan a sus funciones de C): aquí se comprueba el margen
 * inicial (como el intérprete: lo que se ejecuta antes del primer acceso, o todo salvo la última instrucción si no hay accesos, tiene que caber antes del siguiente evento; si no, devuelve 0
 * sin hacer nada) y al terminar se suma una sola vez lo pendiente (tail instrucciones, una menos si el salto se toma: ese lo cuenta el despachador). Con salida temprana (>= 0x100)
 * los ciclos ya están escritos. */
static inline uint32_t cjRunNative(const uint32_t* code, struct ARMCore* cpu, const uint32_t* ops, uint32_t k, uint32_t fr, uint32_t p0, uint32_t tail) {
	uint32_t pre = fr ? p0 : (k >= 2 ? k - 1 : 0);
	if (pre && (uint32_t) (cpu->nextEvent - cpu->cycles) <= pre * ((uint32_t) cpu->memory.activeSeqCycles16 + 1)) {
		return 0;
	}
	uint32_t st = cjCallNative(code, cpu, ops, cjHelperTab);
	if (st < 0x100) {
		uint32_t n = fr ? tail : k; /* los accesos pueden haber cambiado las esperas: el coste es el de ahora */
		cpu->cycles += (int32_t) ((st == 3 ? n - 1 : n) * ((uint32_t) cpu->memory.activeSeqCycles16 + 1));
	}
	return st;
}

CJ_EXPORT int cirilo_jit_stats(uint32_t* out) {
	for (int i = 0; i < S_N; ++i) {
		out[i] = cjStat[i];
	}
	return S_N;
}

/* AUTOPRUEBA DE ARRANQUE (producción). Antes de activar el JIT en un dispositivo se emite y ejecuta código nativo de verdad para secuencias Thumb puras aleatorias (las mismas que
 * traduciría el JIT) y se compara, contra los manejadores del intérprete, registros, CPSR y ciclos. Detecta: codificaciones mal emitidas, caché de instrucciones sin sincronizar
 * (típico del doble mapa RW/RX), memoria ejecutable que no ejecuta. En arm64 se protege con SIGILL/SIGSEGV/SIGBUS: un fallo no tumba la app, solo deja el JIT apagado. */
static int cjTestCorrupt; /* pruebas: fuerza un desacuerdo para comprobar que la autoprueba apaga el JIT */
static uint32_t cjSelfRng(uint32_t* s) {
	*s = *s * 1664525u + 1013904223u;
	uint32_t x = *s;
	x ^= x >> 15;
	x *= 0x2C1B3C6Du;
	x ^= x >> 12;
	return x;
}
static int cjSelfCheckRun(void) {
	static const uint32_t edge[8] = {0, 1, 0x7FFFFFFFu, 0x80000000u, 0xFFFFFFFFu, 0x0000FFFFu, 0x80000001u, 0x00010000u};
	struct ARMCore A, B;
	uint32_t rs = 0x1234567u;
	int bad = 0, tested = 0;
	for (int it = 0; it < 400; ++it) {
		uint32_t n = 2 + cjSelfRng(&rs) % 7, ops[CJ_MAXN + 2], A0 = 0x08000000u + (cjSelfRng(&rs) & 0x7FF0) * 2;
		struct CJInfo inf;
		for (uint32_t j = 0; j < n; ++j) {
			uint32_t op;
			do {
				op = cjSelfRng(&rs) & 0xFFFF;
			} while ((op >= 0xB100 && !(op >= 0xF000 && op < 0xF800)) || !cjThumbInfo(op, &inf) || inf.kind == K_MEM || inf.kind == K_BCOND || inf.kind == K_B || inf.kind == K_BL2);
			ops[j] = op;
		}
		ops[n] = cjSelfRng(&rs) & 0xFFFF;
		ops[n + 1] = cjSelfRng(&rs) & 0xFFFF;
		memset(&A, 0, sizeof(A));
		for (int r = 0; r < 15; ++r) {
			uint32_t v = cjSelfRng(&rs);
			A.gprs[r] = (int32_t) ((v & 3) == 0 ? edge[(v >> 4) & 7] : cjSelfRng(&rs));
		}
		A.cpsr.packed = (cjSelfRng(&rs) & 0xF0000000u) | 0x3F;
		A.memory.activeSeqCycles16 = (int) (cjSelfRng(&rs) % 9);
		A.memory.activeNonseqCycles16 = A.memory.activeSeqCycles16 + (int) (cjSelfRng(&rs) % 6);
		A.cycles = (int32_t) (cjSelfRng(&rs) % 1000);
		A.nextEvent = A.cycles + 100000; /* margen de sobra: aquí solo se comprueba la aritmética */
		B = A;
		uint32_t* end = NULL;
		int bkind = 0;
		uint32_t tgt = 0;
		uint32_t* wcur = cjW(cjCodeCur);
		uint32_t k = cjEmitThumbPrefix(wcur, &end, ops, n, A0, CJ_MINK, &bkind, &tgt);
		if (!k || k > n) {
			continue;
		}
		end = cjX(end);
		cjCodeFlush(cjCodeCur, end);
		for (uint32_t j = 0; j < k; ++j) {
			A.gprs[15] = (int32_t) (A0 + 2 * j + 4);
			_thumbTable[ops[j] >> 6](&A, ops[j]);
		}
		if (cjTestCorrupt) {
			A.gprs[0] ^= 1;
		}
		uint32_t st = cjRunNative(cjCodeCur, &B, ops, k, (uint32_t) cjLastFramed, (uint32_t) cjLastP0, (uint32_t) cjLastTail);
		++tested;
		int ok = st == 1;
		for (int r = 0; r < 15; ++r) {
			ok &= A.gprs[r] == B.gprs[r];
		}
		ok &= A.cpsr.packed == B.cpsr.packed && A.cycles == B.cycles;
		if (!ok) {
			++bad;
		}
	}
	return tested >= 100 ? bad : bad + 1000;
}
#if CJ_NATIVE_HOST == 1
static sigjmp_buf cjGuardJmp;
static __thread volatile sig_atomic_t cjGuardOn;
static struct sigaction cjOldIll, cjOldSegv, cjOldBus;
static void cjGuardHandler(int sig, siginfo_t* si, void* uc) {
	(void) si; (void) uc;
	if (cjGuardOn) {
		cjGuardOn = 0;
		siglongjmp(cjGuardJmp, 1);
	}
	/* no es nuestro: se restaura el manejador anterior; al volver, la instrucción falla otra vez y lo recibe él */
	sigaction(sig, sig == SIGILL ? &cjOldIll : sig == SIGSEGV ? &cjOldSegv : &cjOldBus, NULL);
}
#endif
static int cjSelfCheck(void) { /* 1 = pasa */
#if CJ_NATIVE_HOST == 1
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_sigaction = cjGuardHandler;
	sa.sa_flags = SA_SIGINFO | SA_NODEFER;
	sigemptyset(&sa.sa_mask);
	sigaction(SIGILL, &sa, &cjOldIll);
	sigaction(SIGSEGV, &sa, &cjOldSegv);
	sigaction(SIGBUS, &sa, &cjOldBus);
	int bad;
	if (sigsetjmp(cjGuardJmp, 1) == 0) {
		cjGuardOn = 1;
		bad = cjSelfCheckRun();
		cjGuardOn = 0;
	} else {
		bad = -1; /* señal durante la autoprueba */
	}
	cjGuardOn = 0;
	sigaction(SIGILL, &cjOldIll, NULL);
	sigaction(SIGSEGV, &cjOldSegv, NULL);
	sigaction(SIGBUS, &cjOldBus, NULL);
	return bad == 0;
#else
	return cjSelfCheckRun() == 0;
#endif
}

static void cjClear(int keepBans) {
	memset(cjTab, 0, sizeof(cjTab));
	memset(cjFast, 0, sizeof(cjFast));
	memset(cjHeatKey, 0, sizeof(cjHeatKey));
	memset(cjHeatCnt, 0, sizeof(cjHeatCnt));
	memset(cjGcnt, 0, sizeof(cjGcnt));
	memset(cirilo_jit_gran, 0, sizeof(cirilo_jit_gran));
	if (!keepBans) {
		memset(cjBan, 0, sizeof(cjBan));
		memset(cjInv, 0, sizeof(cjInv));
	}
	cjRamN = 0;
	cjPoolUsed = 0;
	cjCodeCur = cjCode;
}

void cirilo_jit_flush(void) {
	cjClear(0);
}

void cirilo_jit_reset(uint32_t romSize) {
	cjRomSize = romSize;
	cjClear(0);
}

void cirilo_jit_patch(uint32_t address) {
	uint32_t r = address >> 24;
	if (r >= 8 && r <= 0xD && cjPoolUsed) {
		++cjStat[S_FLUSH];
		cjClear(1);
	}
}

/* mode: 0 apagado, 1 JIT normal, 2 = diagnóstico A (solo despachador, sin nativo), 3 = diagnóstico B (nativo sin cargas ni guardados)
 * El JIT solo queda ENCENDIDO (cirilo_jit_on = 1) si hay memoria ejecutable y la autoprueba de arranque pasa (o es el diagnóstico A). En cualquier otro caso el núcleo usa el
 * bucle original de mGBA: ejecutar el despachador sin código nativo solo añade coste. cirilo_jit_status() dice por qué. */
#ifdef CIRILO_JIT_TEST
static int cjStrict; /* pruebas: 1 = regla de producción (el estado decide cirilo_jit_on); 0 = fases antiguas (el despachador corre aunque no haya código nativo) */
#else
#define cjStrict 1
#endif
CJ_EXPORT void cirilo_jit_set(int mode) {
	int on = mode != 0;
	cjDiagA = mode == 2;
	cjDiagB = mode == 3;
	cjClear(0);
	cjStatus = 0;
	cjNativeOn = 0;
	if (on) {
		cjCodeInit();
		int mem = cjCode != NULL && cjMemForce != 3;
		if (CJ_NATIVE_HOST == 0) {
			cjStatus = -3;
		} else if (!mem) {
			cjStatus = -1;
		} else if (cjDiagA) {
			cjStatus = 2;
		} else if (!cjSelfCheck()) {
			cjStatus = -2;
		} else {
			cjStatus = 1;
		}
		cjClear(0); /* la autoprueba usó el búfer de código */
	}
	cjNativeOn = cjStatus == 1 && !cjNativeOff;
	cirilo_jit_on = cjStrict ? (cjStatus > 0) : on;
}
CJ_EXPORT int cirilo_jit_status(void) {
	return cjStatus;
}

#ifdef CIRILO_JIT_TEST /* solo en el núcleo de pruebas de CI (jit_test.sh): permite comprobar que el comparador DETECTA un JIT sin invalidación */
static int cjTestNoSmc;
CJ_EXPORT void cirilo_jit_debug(int flags) {
	cjTestNoSmc = flags & 1;
	cjNativeOff = (flags >> 1) & 1; /* 2 = sin código nativo (modo Fase 1) */
	cjGate = (flags >> 2) & 1; /* 4 = filtro de ganancia como en la app */
	cjCopyModeV = !((flags >> 3) & 1); /* 8 = modo de la app (bloques Thumb sin copia, ARM sin caché) */
	cjStrict = (flags >> 4) & 1; /* 16 = regla de producción para cirilo_jit_on */
	cjMemForce = ((flags >> 5) & 1) ? 3 : 0; /* 32 = simula que no hay memoria ejecutable (se aplica en el siguiente cirilo_jit_set) */
	cjCut = !((flags >> 7) & 1); /* 128 = sin corte en instrucciones no traducibles */
	cjTestCorrupt = (flags >> 6) & 1; /* 64 = la autoprueba de arranque ve un desacuerdo (se aplica en el siguiente cirilo_jit_set) */
	cjNativeOn = cirilo_jit_on && cjCode && !cjNativeOff && !cjDiagA && cjStatus >= 0;
}
#endif

static inline uint32_t cjHash(uint32_t pc, int thumb) {
	return ((pc >> 1) ^ (pc >> 11) ^ (thumb ? 0x5A5 : 0)) & (CJ_TAB - 1);
}

/* Llamado desde las macros CIRILO_JIT_IW/EW cuando se escribe en un trozo con código. */
void cirilo_jit_smc(int ewram, uint32_t offset, uint32_t size) {
	++cjStat[S_SMC_CALLS];
#ifdef CIRILO_JIT_TEST
	if (cjTestNoSmc) {
		return;
	}
#endif
	uint32_t end = offset + size - 1;
	{ /* filtro: los datos que comparten trozo de 256 B con código son lo habitual (pila, variables); sin solape no hay nada que tirar y no se recorre la lista de bloques */
		int hit = 0;
		for (uint32_t g = offset >> 8; g <= end >> 8; ++g) {
			uint32_t idx = (ewram ? 128 : 0) + g;
			if (cirilo_jit_gran[idx] && offset <= cjGHi[idx] && end >= cjGLo[idx]) {
				hit = 1;
				break;
			}
		}
		if (!hit) {
			return;
		}
	}
	for (uint32_t i = 0; i < cjRamN; ++i) {
		struct CJBlock* b = cjRam[i];
		if (b->valid && b->ew == ewram && b->hi >= offset && b->lo <= end) {
			b->valid = 0;
			for (uint32_t g = b->lo >> 8; g <= b->hi >> 8; ++g) { /* el trozo deja de vigilarse cuando no le queda ningún bloque válido */
				uint32_t gi = (b->ew ? 128 : 0) + g;
				if (cjGcnt[gi] && !--cjGcnt[gi]) {
					cirilo_jit_gran[gi] = 0;
				}
			}
			if (cjFast[cjFh(b->pc)].b == b) {
				cjFast[cjFh(b->pc)].key = 0;
			}
			++cjStat[S_INVAL];
		}
	}
	for (uint32_t g = offset >> 8; g <= end >> 8; ++g) {
		uint32_t idx = (ewram ? 128 : 0) + g;
		if (cjInv[idx] < 255) {
			++cjInv[idx];
		}
		if (cjInv[idx] > CJ_BAN && !cjBan[idx]) {
			cjBan[idx] = 1;
			++cjStat[S_BANNED];
		}
	}
}

/* ¿Esta instrucción termina el bloque (puede cambiar PC, el modo o el estado de ejecución)? Conservador: ante la duda, termina. */
static int cjTermArm(uint32_t op) {
	switch ((op >> 26) & 3) {
	case 0:
		if ((op & 0x0FFFFFF0) == 0x012FFF10) { /* BX */
			return 1;
		}
		if ((op & 0x0FB00000) == 0x03200000 || (op & 0x0FB000F0) == 0x01200000) { /* MSR */
			return 1;
		}
		if ((op & 0x0FC000F0) == 0x90 || (op & 0x0F8000F0) == 0x00800090) { /* MUL, MULL */
			return ((op >> 16) & 15) == 15 || ((op >> 12) & 15) == 15;
		}
		return ((op >> 12) & 15) == 15; /* proceso de datos, media palabra, SWP, MRS con Rd = PC */
	case 1:
		if (((op >> 25) & 7) == 3 && (op & 0x10)) { /* indefinida */
			return 1;
		}
		return (op & (1 << 20)) && ((op >> 12) & 15) == 15; /* LDR a PC */
	default:
		if (((op >> 25) & 7) == 4) { /* LDM/STM */
			return (op & (1 << 20)) && (op & 0x8000);
		}
		return 1; /* B, BL, SWI, coprocesador */
	}
}

static int cjTermThumb(uint32_t op) {
	switch (op >> 12) {
	case 0xD:
	case 0xE:
		return 1; /* Bcond, SWI, B, restos indefinidos */
	case 0xF:
		return op >= 0xF800; /* BL: el primer medio no termina, el segundo sí */
	case 4:
		if ((op & 0xFC00) == 0x4400) { /* ADD/CMP/MOV/BX con registros altos */
			return (op & 0xFF00) == 0x4700 || (op & 0x0087) == 0x0087;
		}
		return 0;
	case 0xB: {
		unsigned k = (op >> 8) & 15;
		if (k == 0xD) { /* POP {rlist, PC} */
			return 1;
		}
		return !(k == 0 || k == 4 || k == 5 || k == 0xC); /* BKPT e indefinidas */
	}
	default:
		return 0;
	}
}

/* ¿Compensa dejar este tramo nativo? k = instrucciones del tramo (si bk != 0, la última es el salto). */
/* Compuerta de ganancia. Modelo en CICLOS del anfitrión: cada instrucción pura que se deja de interpretar ahorra gainPure (≈25 instrucciones de ThumbStep a IPC≈3); cada carga/guardado
 * llama a una función auxiliar que repite el trabajo del intérprete, así que no ahorra nada y cuesta costMem de más (la pieza bl + volcado de registros); entrar al tramo cuesta
 * costEntry fijos (cjCallNative, marco, banderines) más el tamaño REAL del código emitido (words / 3 por IPC≈3: así los tramos que necesitan muchos registros o prólogos largos pesan
 * lo que pesan). Los tres valores son estimaciones de partida, no medidas: se ajustan sin recompilar con cirilo_jit_tune() a partir del panel de CPU del dispositivo. */
static int cjGainPure = CJ_GAIN_PURE, cjGainBr = CJ_GAIN_BR, cjCostEntry = CJ_COST_ENTRY, cjCostMem = CJ_COST_MEM;
CJ_EXPORT void cirilo_jit_tune(int gainPure, int costEntry, int costMem) { /* valores <= 0: sin cambio */
	if (gainPure > 0) {
		cjGainPure = gainPure;
	}
	if (costEntry > 0) {
		cjCostEntry = costEntry;
	}
	if (costMem > 0) {
		cjCostMem = costMem;
	}
}
static int cjWorth(const uint32_t* op, uint32_t k, int bk, uint32_t words) {
	uint32_t body = k - (bk ? 1 : 0), mem = 0;
	for (uint32_t i = 0; i < body; ++i) {
		uint32_t t = op[i] >> 12;
		if ((t >= 5 && t <= 9) || (op[i] & 0xF800) == 0x4800) { /* carga o guardado (registro, inmediato, SP, literal) */
			++mem;
		}
	}
	int score = (int) (body - mem) * cjGainPure + (bk ? cjGainBr : 0) - (int) mem * cjCostMem - cjCostEntry - (int) (words / 3);
	return score > 0;
}

static struct CJBlock* cjTranslate(struct ARMCore* cpu, uint32_t A, int thumb) {
	if (!thumb && !CJ_COPY_MODE) {
		return NULL;
	}
	const uint32_t w = thumb ? 2 : 4;
	uint32_t r = A >> 24, off = 0, mask = 0;
	int ram = 0, ew = 0;
	if (r == 2) {
		ram = 1; ew = 1; mask = 0x3FFFF;
	} else if (r == 3) {
		ram = 1; mask = 0x7FFF;
	} else if (r >= 8 && r <= 0xD) {
		mask = 0x01FFFFFF;
	} else {
		return NULL;
	}
	if (A & (w - 1)) {
		return NULL;
	}
	off = A & mask;
	uint32_t avail = (((A | 0xFFF) + 1) - A) / w; /* instrucciones que quedan en la página de 4 KB */
	if (avail < 3) {
		return NULL;
	}
	uint32_t nmax = avail - 2 < CJ_MAXN ? avail - 2 : CJ_MAXN;
	if (!ram) {
		if (off + (nmax + 2) * w > cjRomSize) {
			if (off + 3 * w > cjRomSize) {
				return NULL;
			}
			nmax = (cjRomSize - off) / w - 2;
		}
	} else {
		uint32_t g0 = off >> 8, g1 = (off + (nmax + 2) * w - 1) >> 8, base = ew ? 128 : 0;
		for (uint32_t g = g0; g <= g1; ++g) {
			if (cjBan[base + g]) {
				return NULL;
			}
		}
	}
	uint32_t op[CJ_MAXN + 2];
	for (uint32_t i = 0; i < nmax + 2; ++i) {
		uint32_t v;
		uint32_t x = (A + i * w) & cpu->memory.activeMask;
		if (thumb) {
			LOAD_16(v, x, cpu->memory.activeRegion);
		} else {
			LOAD_32(v, x, cpu->memory.activeRegion);
		}
		op[i] = v;
	}
	if (op[0] != cpu->prefetch[0] || op[1] != cpu->prefetch[1]) {
		return NULL; /* la región activa no es la de A (o hay un truco raro): no se toca */
	}
	uint32_t n = nmax;
	for (uint32_t i = 0; i < nmax; ++i) {
		if (thumb ? cjTermThumb(op[i]) : cjTermArm(op[i])) {
			n = i + 1;
			break;
		}
	}
	if (thumb && cjNativeOn && cjCut) {
		/* El tramo nativo es un PREFIJO del bloque: acaba en la primera instrucción que el emisor no traduce (PUSH, POP, LDM, STM, MUL, desplazamientos por registro, BX...), y todo lo
		 * que sigue iba al intérprete aunque fuera aritmética sencilla. Se corta el bloque DESPUÉS de esa instrucción: ella se interpreta y lo siguiente empieza otro bloque con su propio
		 * tramo nativo. Es equivalente por construcción (solo cambia dónde se parte la ejecución) y evita abandonar la traducción de lo que viene detrás. */
		struct CJInfo ci;
		for (uint32_t i = 0; i < n; ++i) {
			if (!cjThumbInfo(op[i], &ci)) {
				n = i + 1;
				break;
			}
		}
	}
	uint32_t words = (sizeof(struct CJBlock) - sizeof(uint32_t) * (CJ_MAXN + 2) + 4 * (n + 2) + 3) / 4;
	if (cjPoolUsed + words > CJ_POOL_WORDS || (ram && cjRamN >= CJ_RAMMAX) || (cjNativeOn && cjCodeCur + 512 > cjCode + CJ_CODE_WORDS)) {
		++cjStat[S_FLUSH];
		cjClear(1);
	}
	struct CJBlock* b = (struct CJBlock*) (cjPool + cjPoolUsed);
	cjPoolUsed += words;
	b->code = NULL;
	b->k = 0;
	b->bk = 0;
	b->target = 0;
	b->pc = A;
	b->n = (uint16_t) n;
	b->thumb = (uint8_t) thumb;
	b->valid = 1;
	b->ram = (uint8_t) ram;
	b->ew = (uint8_t) ew;
	b->lo = off;
	b->hi = off + (n + 2) * w - 1;
	memcpy(b->op, op, 4 * (n + 2));
	if (thumb && cjNativeOn && n >= CJ_MINK) {
		uint32_t* end;
		int bkind = 0;
		uint32_t tgt = 0;
		uint32_t ne = n;
		if (cjDiagB) { /* diagnóstico B: el tramo acaba antes de la primera carga o guardado */
			for (uint32_t i = 0; i < n; ++i) {
				uint32_t t = op[i] >> 12;
				if ((t >= 5 && t <= 9) || (op[i] & 0xF800) == 0x4800) {
					ne = i;
					break;
				}
			}
		}
		uint32_t kk = ne >= CJ_MINK ? cjEmitThumbPrefix(cjW(cjCodeCur), &end, op, ne, A, CJ_MINK, &bkind, &tgt) : 0; /* se escribe por la vista RW */
		if (kk) {
			end = cjX(end); /* y a partir de aquí todo se cuenta en direcciones de ejecución */
		}
		if (kk && cjGate && !cjWorth(op, kk, bkind, (uint32_t) (end - cjCodeCur))) {
			kk = 0; /* el código emitido queda sin confirmar: se sobrescribe con el siguiente */
		}
		if (kk) {
			cjStat[S_CWORDS] += (uint32_t) (end - cjCodeCur);
			cjStat[S_CINSTR] += kk;
			b->code = cjCodeCur;
			b->k = (uint16_t) kk;
			b->fr = (uint8_t) cjLastFramed;
			b->p0 = (uint8_t) cjLastP0;
			b->tail = (uint8_t) cjLastTail;
			b->bk = (uint8_t) bkind;
			b->target = tgt;
			cjCodeFlush(cjCodeCur, end);
			cjCodeCur = end;
			++cjStat[S_NBLOCKS];
		}
	}
	if (ram && (CJ_COPY_MODE || b->code)) { /* app: un bloque sin código nativo no depende de que la copia esté al día, así que no se vigila */
		cjRam[cjRamN++] = b;
		uint32_t base = ew ? 128 : 0;
		for (uint32_t g = b->lo >> 8; g <= b->hi >> 8; ++g) {
			uint32_t idx = base + g;
			if (!cjGcnt[idx]) {
				cjGLo[idx] = b->lo;
				cjGHi[idx] = b->hi;
			} else {
				if (b->lo < cjGLo[idx]) {
					cjGLo[idx] = b->lo;
				}
				if (b->hi > cjGHi[idx]) {
					cjGHi[idx] = b->hi;
				}
			}
			cirilo_jit_gran[idx] = 1;
			++cjGcnt[idx];
		}
	}
	uint32_t h = cjHash(A, thumb);
	for (struct CJBlock** pp = &cjTab[h]; *pp;) { /* tira de la cadena las copias viejas e invalidadas del mismo punto */
		if ((*pp)->pc == A && (*pp)->thumb == thumb && !(*pp)->valid) {
			*pp = (*pp)->next;
		} else {
			pp = &(*pp)->next;
		}
	}
	b->next = cjTab[h];
	cjTab[h] = b;
	++cjStat[S_CREATED];
	return b;
}

/* Un bloque = ARMStep/ThumbStep repetido, con la captación leída de la copia mientras siga válida. */
/* Estado del intérprete tras un tramo nativo. status: 1 = k instrucciones puras, 2 = salto condicional no tomado (k incluye el salto), 3 = salto tomado a target.
 * Se hace con ThumbWritePC del intérprete: región activa, recarga del pipeline y ciclos salen exactamente igual. */
static void cjNativeTail(struct ARMCore* cpu, uint32_t status, uint32_t pc0, uint32_t k, const uint32_t* op, uint32_t target) {
	if (status >= 0x100) { /* salida temprana tras m instrucciones */
		k = status & 0xFF;
	}
	if (status == 3) {
		int32_t c = 1 + cpu->memory.activeSeqCycles16; /* la instrucción de salto cuesta el prefetch de su región de origen */
		cpu->gprs[ARM_PC] = (int32_t) target;
		cpu->cycles += c + ThumbWritePC(cpu);
	} else {
		cpu->gprs[ARM_PC] = (int32_t) (pc0 + (k + 1) * WORD_SIZE_THUMB);
		cpu->prefetch[0] = op[k];
		cpu->prefetch[1] = op[k + 1];
	}
}

__attribute__((unused)) static void cjRunBlockArm(struct ARMCore* cpu, struct CJBlock* b) {
	uint32_t n = b->n, i;
	for (i = 0; i < n; ++i) {
		uint32_t opcode = cpu->prefetch[0];
		cpu->prefetch[0] = cpu->prefetch[1];
		cpu->gprs[ARM_PC] += WORD_SIZE_ARM;
		if (b->valid) {
			cpu->prefetch[1] = b->op[i + 2];
		} else {
			LOAD_32(cpu->prefetch[1], cpu->gprs[ARM_PC] & cpu->memory.activeMask, cpu->memory.activeRegion);
		}
		unsigned condition = opcode >> 28;
		int run = 1;
		if (condition != 0xE) {
			unsigned flags = cpu->cpsr.flags >> 4;
			if (!(conditionLut[condition] & (1 << flags))) {
				cpu->cycles += ARM_PREFETCH_CYCLES;
				run = 0;
			}
		}
		if (run) {
			ARMInstruction instruction = _armTable[((opcode >> 16) & 0xFF0) | ((opcode >> 4) & 0x00F)];
			instruction(cpu, opcode);
		}
		if (cpu->cycles >= cpu->nextEvent || !b->valid) {
			++i;
			break;
		}
		if ((uint32_t) cpu->gprs[ARM_PC] != b->pc + (i + 2) * WORD_SIZE_ARM) {
			if (i + 1 < n) {
				CJSTAT(S_MIDEXIT);
			}
			++i;
			break;
		}
	}
	cjStat[S_INSTR_BLOCK] += i;
}

static void cjRunBlockThumb(struct ARMCore* cpu, struct CJBlock* b, uint32_t i0) {
	uint32_t n = b->n, i;
	for (i = i0; i < n; ++i) {
		uint32_t opcode = cpu->prefetch[0];
		cpu->prefetch[0] = cpu->prefetch[1];
		cpu->gprs[ARM_PC] += WORD_SIZE_THUMB;
		if (b->valid) {
			cpu->prefetch[1] = b->op[i + 2];
		} else {
			LOAD_16(cpu->prefetch[1], cpu->gprs[ARM_PC] & cpu->memory.activeMask, cpu->memory.activeRegion);
		}
		ThumbInstruction instruction = _thumbTable[opcode >> 6];
		instruction(cpu, opcode);
		if (cpu->cycles >= cpu->nextEvent || !b->valid) {
			++i;
			break;
		}
		if ((uint32_t) cpu->gprs[ARM_PC] != b->pc + (i + 2) * WORD_SIZE_THUMB) {
			if (i + 1 < n) {
				CJSTAT(S_MIDEXIT);
			}
			++i;
			break;
		}
	}
	cjStat[S_INSTR_BLOCK] += i - i0;
}

static inline uint32_t cjPlain(struct ARMCore* cpu, uint32_t nn) { /* nn instrucciones con el intérprete (o hasta el siguiente evento) */
	uint32_t m = 0;
	do {
		ThumbStep(cpu);
		++m;
	} while (m < nn && cpu->cycles < cpu->nextEvent);
	return m;
}

static void cjRun(struct ARMCore* cpu) {
#ifdef CIRILO_JIT_PROF
	uint64_t cjT0 = cirilo_tick();
#endif
	const int thumb = cpu->executionMode == MODE_THUMB;
	const uint32_t w = thumb ? WORD_SIZE_THUMB : WORD_SIZE_ARM;
	uint32_t aIB = 0, aPR = 0, aNR = 0, aNI = 0, aIT = 0; /* contadores locales: se suman a cjStat al salir (una escritura a memoria menos por bloque) */
	if (!thumb && !CJ_COPY_MODE) { /* el modo ARM no tiene código nativo: bucle original, sin consultar la caché */
		while (cpu->cycles < cpu->nextEvent) {
			ARMStep(cpu);
		}
	} else while (cpu->cycles < cpu->nextEvent) {
		uint32_t A = (uint32_t) cpu->gprs[ARM_PC] - w;
		uint32_t key = A | (uint32_t) thumb;
		struct CJFast* fe = &cjFast[cjFh(A)];
		uint32_t h = 0;
		struct CJBlock* b;
		if (fe->b && fe->key == key) { /* (b != NULL: la entrada vacía tiene clave 0, que coincidía con ARM en la dirección 0) */
			if (!CJ_COPY_MODE && (fe->info & 0x10000)) { /* bloque sin código nativo: solo agrupa, se ejecuta con el intérprete (exacto aunque la copia esté vieja) */
				aIB += cjPlain(cpu, fe->info & 0xFFFF);
				++aPR;
				continue;
			}
			b = fe->b;
		} else {
			h = cjHash(A, thumb);
			b = cjTab[h];
			while (b && !(b->pc == A && b->thumb == thumb && b->valid)) {
				b = b->next;
			}
			if (b) {
				fe->key = key;
				fe->info = b->n | (b->code ? 0 : 0x10000);
				fe->b = b;
			}
		}
		if (b) {
			if (!CJ_COPY_MODE && !b->code) {
				aIB += cjPlain(cpu, b->n);
				++aPR;
				continue;
			}
			if (b->op[0] == cpu->prefetch[0] && b->op[1] == cpu->prefetch[1]) {
				CJSTAT(S_BLOCKS);
				if (thumb) {
					uint32_t i0 = 0;
					if (b->code) { /* tramo nativo: si no hay margen hasta el siguiente evento no hace nada y devuelve 0 */
						cjCurBlock = b;
						uint32_t st = cjRunNative(b->code, cpu, b->op, b->k, b->fr, b->p0, b->tail);
						if (st) {
							uint32_t k = st >= 0x100 ? (st & 0xFF) : b->k;
							cjNativeTail(cpu, st, b->pc, k, b->op, b->target);
							++aNR;
							aNI += k;
							aIB += k;
							if (st >= 0x100) {
								CJSTAT(S_NEARLY);
								continue; /* salida temprana: el despachador sigue desde donde quedó */
							}
							if (st >= 2) {
								CJSTAT(st == 3 ? S_NTAKEN : S_NNOTTAKEN);
								continue; /* el salto es la última instrucción del bloque */
							}
							i0 = k;
						} else {
							CJSTAT(S_NBAIL);
						}
					}
					if (i0 < b->n && cpu->cycles < cpu->nextEvent) {
						if (CJ_COPY_MODE) {
							cjRunBlockThumb(cpu, b, i0);
						} else { /* lo que queda del bloque tras el tramo nativo, con el intérprete */
							aIB += cjPlain(cpu, b->n - i0);
						}
					}
				} else {
					cjRunBlockArm(cpu, b);
				}
				continue;
			}
			CJSTAT(S_PMISS);
		} else if (cjHeatBump(key, h)) {
			if (cjTranslate(cpu, A, thumb)) {
				continue;
			}
			CJSTAT(S_REFUSED);
		}
		++aIT;
		if (thumb) {
			ThumbStep(cpu);
		} else {
			ARMStep(cpu);
		}
	}
	cjStat[S_INSTR_BLOCK] += aIB;
	cjStat[S_PRUNS] += aPR;
	cjStat[S_NRUNS] += aNR;
	cjStat[S_NINSTR] += aNI;
	cjStat[S_INSTR_INTERP] += aIT;
	cjStat[S_PC] = (uint32_t) cpu->gprs[ARM_PC];
#ifdef CIRILO_JIT_PROF /* medidor de CPU (cirilo_prof_patch.py) presente: mismo reparto que el bucle original */
	uint64_t cjT1 = cirilo_tick();
	cpu->irqh.processEvents(cpu);
	cirilo_prof_steps += cjT1 - cjT0;
	cirilo_prof_ev += cirilo_tick() - cjT1;
#else
	cpu->irqh.processEvents(cpu);
#endif
}

#ifdef CIRILO_JIT_TEST
/* AUTOPRUEBA UNITARIA del emisor (solo con -DCIRILO_JIT_TEST): secuencias aleatorias de 1-10 instrucciones Thumb traducibles (a veces acabadas en Bcond, B o BL), con registros y
 * banderines aleatorios (con valores límite), se ejecutan (a) con los manejadores del intérprete y (b) con el código nativo + cjNativeTail (lo mismo que hace el despachador);
 * deben coincidir registros, CPSR y ciclos (y, si hay salto tomado, PC, pipeline y región). También comprueba la decisión de «sin margen» y la de «salto tomado».
 * Devuelve el número de discrepancias (o -1 si este anfitrión no ejecuta código nativo); el informe de las primeras va en out. */
static uint32_t cjRng(uint32_t* s) {
	*s = *s * 1664525u + 1013904223u;
	uint32_t x = *s;
	x ^= x >> 15;
	x *= 0x2C1B3C6Du;
	x ^= x >> 12;
	return x;
}
static uint32_t cjRandOp(uint32_t* s) { /* instrucción pura o de memoria (nunca saltos) */
	for (;;) {
		uint32_t r = cjRng(s), r2 = cjRng(s), op;
		switch (r % 20) {
		case 0: case 1: op = ((r2 >> 16) % 3 << 11) | (r2 & 0x7FF); break;
		case 2: op = 0x1800 | (r2 & 0x7FF); break;
		case 3: case 4: op = 0x2000 | (r2 & 0x1FFF); break;
		case 5: case 6: case 7: op = 0x4000 | (r2 & 0x3FF); break;
		case 8: op = 0x4400 | ((r2 >> 8) % 3 << 8) | (r2 & 0xFF); break;
		case 9: op = 0xA000 | (r2 & 0xFFF); break;
		case 10: op = 0xB000 | (r2 & 0xFF); break;
		case 11: op = 0xF000 | (r2 & 0x7FF); break; /* BL, primera mitad */
		case 12: op = 0x4800 | (r2 & 0x7FF); break; /* LDR [PC, #imm] */
		case 13: case 14: op = 0x5000 | (r2 & 0xFFF); break; /* con registro */
		case 15: case 16: op = 0x6000 | (r2 & 0x1FFF); break; /* inmediato de 5 bits */
		case 17: op = 0x8000 | (r2 & 0xFFF); break; /* LDRH/STRH */
		case 18: op = 0x9000 | (r2 & 0xFFF); break; /* [SP, #imm] */
		default: op = 0x4000 | (r2 & 0x3FF); break;
		}
		struct CJInfo info;
		if (cjThumbInfo(op, &info) && info.kind != K_BCOND && info.kind != K_B && info.kind != K_BL2) {
			return op;
		}
	}
}
static uint32_t cjRandAddr(uint32_t* s) { /* una dirección de alguna región (a veces desalineada) */
	uint32_t r = cjRng(s), o = cjRng(s);
	switch (r % 10) {
	case 0: case 1: case 2: return 0x03000000u + (o & 0x7FFF);
	case 3: case 4: return 0x02000000u + (o & 0x3FFFF);
	case 5: case 6: return 0x08000000u + (o & 0xFFFF);
	case 7: return 0x0A000000u + (o & 0xFFFF);
	case 8: return 0x04000000u + (o & 0x3FF);
	default: return (cjRng(s) & 0x0F000000u) | (o & 0xFFFF);
	}
}
static uint32_t cjRandVal(uint32_t* s) {
	uint32_t r = cjRng(s);
	if (r & 8) {
		return cjRandAddr(s);
	}
	switch (r & 7) {
	case 0: return 0;
	case 1: return 1;
	case 2: return 0xFFFFFFFFu;
	case 3: return 0x80000000u;
	case 4: return 0x7FFFFFFFu;
	case 5: return cjRng(s) & 0xFF;
	default: return cjRng(s);
	}
}
static uint16_t cjTestMem[0x8000]; /* memoria falsa de 64 KB: las recargas de pipeline de los saltos leen de aquí */
static void cjTestSetRegion(struct ARMCore* cpu, uint32_t address) { /* esperas que dependen de la dirección: así un error de orden se nota */
	cpu->memory.activeRegion = (uint32_t*) cjTestMem;
	cpu->memory.activeMask = 0xFFFE;
	cpu->memory.activeSeqCycles16 = 1 + ((address >> 24) & 3);
	cpu->memory.activeNonseqCycles16 = 3 + ((address >> 26) & 3);
}
/* Accesos a «E/S» y demás regiones del entorno de pruebas: el valor depende del bus abierto (prefetch), PC y reloj; a veces cambian las esperas o fuerzan la salida
 * (como WAITCNT o una escritura a E/S), para comprobar que el código nativo lo recarga y lo respeta. */
static struct CJBlock cjFakeBlk; /* hace de «bloque en ejecución»: ciertos guardados lo invalidan, como haría el aviso de código automodificable */
static uint32_t cjTestInvalAt;
static uint32_t cjTestA0;
static uint32_t cjTestIO(struct ARMCore* cpu, uint32_t addr, int* cc, uint32_t salt) {
	uint32_t v = (addr * 2654435761u) ^ cpu->prefetch[1] ^ (uint32_t) cpu->gprs[ARM_PC] ^ (uint32_t) cpu->cycles ^ salt;
	if (cc) {
		*cc += 1 + (int) ((addr >> 20) & 3) + (cpu->cycles & 1);
	}
	if (((addr >> 8) & 7) == 0) {
		cpu->memory.activeSeqCycles16 += 1;
	}
	if (((addr >> 8) & 7) == 1) {
		cpu->nextEvent = cpu->cycles;
	}
	return v;
}
static uint32_t cjTestLoad32(struct ARMCore* cpu, uint32_t a, int* cc) { return cjTestIO(cpu, a, cc, 32); }
static uint32_t cjTestLoad16(struct ARMCore* cpu, uint32_t a, int* cc) { return cjTestIO(cpu, a, cc, 16) & 0xFFFF; }
static uint32_t cjTestLoad8(struct ARMCore* cpu, uint32_t a, int* cc) { return cjTestIO(cpu, a, cc, 8) & 0xFF; }
static void cjTestStore32(struct ARMCore* cpu, uint32_t a, int32_t v, int* cc) { cpu->spsr.packed ^= (uint32_t) v * 31u + a; if (((a >> 12) & 7) == 2 && cjFakeBlk.valid) { cjFakeBlk.valid = 0; cjTestInvalAt = ((uint32_t) cpu->gprs[ARM_PC] - cjTestA0 - 4) / 2 + 1; } cjTestIO(cpu, a, cc, 33); }
static void cjTestStore16(struct ARMCore* cpu, uint32_t a, int16_t v, int* cc) { cpu->spsr.packed ^= (uint32_t) (uint16_t) v * 17u + a; if (((a >> 12) & 7) == 2 && cjFakeBlk.valid) { cjFakeBlk.valid = 0; cjTestInvalAt = ((uint32_t) cpu->gprs[ARM_PC] - cjTestA0 - 4) / 2 + 1; } cjTestIO(cpu, a, cc, 17); }
static void cjTestStore8(struct ARMCore* cpu, uint32_t a, int8_t v, int* cc) { cpu->spsr.packed ^= (uint32_t) (uint8_t) v * 7u + a; if (((a >> 12) & 7) == 2 && cjFakeBlk.valid) { cjFakeBlk.valid = 0; cjTestInvalAt = ((uint32_t) cpu->gprs[ARM_PC] - cjTestA0 - 4) / 2 + 1; } cjTestIO(cpu, a, cc, 9); }
static int32_t cjTestStall(struct ARMCore* cpu, int32_t wait) { return wait + (int32_t) ((cpu->cycles + cpu->gprs[ARM_PC]) & 3); }
#if __has_include(<mgba/internal/gba/cirilo_fast.h>)
#define CJ_FAKE_GBA 1
static struct GBA cjGbaA, cjGbaB; /* los manejadores del intérprete y las funciones auxiliares miran cpu->master */
static uint32_t cjFakeIw[2][GBA_SIZE_IWRAM / 4], cjFakeEw[2][GBA_SIZE_EWRAM / 4], cjFakeRom[0x4000];
#endif
static void cjTestSetup(struct ARMCore* c, int which, uint32_t* rs) {
	c->memory.load32 = cjTestLoad32; c->memory.load16 = cjTestLoad16; c->memory.load8 = cjTestLoad8;
	c->memory.store32 = cjTestStore32; c->memory.store16 = cjTestStore16; c->memory.store8 = cjTestStore8;
	c->memory.stall = cjTestStall;
	c->memory.setActiveRegion = cjTestSetRegion;
#ifdef CJ_FAKE_GBA
	struct GBA* g = which ? &cjGbaB : &cjGbaA;
	c->master = (struct mCPUComponent*) g;
	g->memory.iwram = cjFakeIw[which];
	g->memory.wram = cjFakeEw[which];
	g->memory.rom = cjFakeRom;
	g->memory.romSize = sizeof(cjFakeRom);
	g->memory.activeRegion = (rs[0] & 1) ? GBA_REGION_ROM0 : GBA_REGION_IWRAM;
	g->memory.prefetch = (rs[0] >> 1) & 1;
	for (int q = 0; q < 16; ++q) {
		g->memory.waitstatesNonseq32[q] = (char) (rs[1 + (q & 7)] % 7);
		g->memory.waitstatesNonseq16[q] = (char) (rs[1 + ((q + 3) & 7)] % 5);
	}
#else
	(void) which; (void) rs;
#endif
}
/* medida de tamaño: palabras que ocupa un tramo de n instrucciones aritméticas típicas (sin salto); kind 0 = solo aritmética, 1 = con una carga LDR [r1,#4] a mitad */
CJ_EXPORT int cirilo_jit_sizeprobe(uint32_t n, uint32_t kind) {
	static const uint32_t pat[6] = {0x1888 /* adds r0,r1,r2 */, 0x3B01 /* subs r3,#1 */, 0x0088 /* lsls r0,r1,#2 */, 0x4048 /* eors r0,r1 */, 0x2105 /* movs r1,#5 */, 0x1C08 /* adds r0,r1,#0 */};
	if (CJ_NATIVE_HOST == 0) {
		return -1;
	}
	cjCodeInit();
	if (!cjCode) {
		return -2;
	}
	uint32_t ops[CJ_MAXN + 2];
	if (n > CJ_MAXN) {
		n = CJ_MAXN;
	}
	for (uint32_t j = 0; j < n; ++j) {
		ops[j] = pat[j % 6];
	}
	if (kind == 1 && n >= 3) {
		ops[n / 2] = 0x6848; /* ldr r0,[r1,#4] */
	}
	ops[n] = ops[n + 1] = 0;
	cjCodeCur = cjCode;
	uint32_t* end;
	int bkind = 0;
	uint32_t tgt = 0;
	uint32_t k = cjEmitThumbPrefix(cjCodeCur, &end, ops, n, 0x08000000u, 1, &bkind, &tgt);
	return k ? (int) (end - cjCodeCur) : 0;
}

CJ_EXPORT int cirilo_jit_selftest(uint32_t seed, uint32_t iters, char* out, uint32_t outn) {
	if (CJ_NATIVE_HOST == 0) {
		return -1;
	}
	cjCodeInit();
	if (!cjCode) {
		return -2;
	}
	int bad = 0, shown = 0;
	uint32_t rs = seed ? seed : 1;
	size_t used = 0;
	out[0] = 0;
	static struct ARMCore A, B;
	for (uint32_t i = 0; i < 0x8000; ++i) {
		cjTestMem[i] = (uint16_t) cjRng(&rs);
	}
#ifdef CJ_FAKE_GBA
	for (uint32_t i = 0; i < GBA_SIZE_IWRAM / 4; ++i) {
		cjFakeIw[0][i] = cjFakeIw[1][i] = cjRng(&rs);
	}
	for (uint32_t i = 0; i < GBA_SIZE_EWRAM / 4; ++i) {
		cjFakeEw[0][i] = cjFakeEw[1][i] = cjRng(&rs);
	}
	for (uint32_t i = 0; i < 0x4000; ++i) {
		cjFakeRom[i] = cjRng(&rs);
	}
#endif
	for (uint32_t it = 0; it < iters; ++it) {
		uint32_t n = 1 + cjRng(&rs) % 9, ops[CJ_MAXN + 2], A0 = 0x08000000u + (cjRng(&rs) & 0x7FF0) * 2;
		for (uint32_t j = 0; j < n; ++j) {
			ops[j] = cjRandOp(&rs);
		}
		int endType = cjRng(&rs) % 6; /* 0-2: sin salto; 3: Bcond; 4: B; 5: BL */
		if (endType == 3) {
			ops[n++] = 0xD000 | ((cjRng(&rs) % 14) << 8) | (cjRng(&rs) & 0xFF);
		} else if (endType == 4) {
			ops[n++] = 0xE000 | (cjRng(&rs) & 0x7FF);
		} else if (endType == 5) {
			ops[n++] = 0xF000 | (cjRng(&rs) & 0x7FF);
			ops[n++] = 0xF800 | (cjRng(&rs) & 0x7FF);
		}
		ops[n] = cjRng(&rs) & 0xFFFF;
		ops[n + 1] = cjRng(&rs) & 0xFFFF;
		uint32_t envRs[9];
		for (int q = 0; q < 9; ++q) {
			envRs[q] = cjRng(&rs);
		}
		memset(&A, 0, sizeof(A));
		cjTestSetup(&A, 0, envRs);
		cjTestSetRegion(&A, A0);
		for (int r = 0; r < 15; ++r) {
			A.gprs[r] = (int32_t) cjRandVal(&rs);
		}
		A.cpsr.packed = (cjRng(&rs) & 0xF0000000u) | 0x3F;
		A.memory.activeSeqCycles16 = cjRng(&rs) % 9;
		A.memory.activeNonseqCycles16 = A.memory.activeSeqCycles16 + cjRng(&rs) % 6;
		A.cycles = (int32_t) (cjRng(&rs) % 1000);
		uint32_t c = 1 + A.memory.activeSeqCycles16, margin;
		switch (cjRng(&rs) % 4) { /* a veces, justo al borde del margen */
		case 0: margin = (n - 1) * c; break;
		case 1: margin = (n - 1) * c + 1; break;
		case 2: margin = 1 + cjRng(&rs) % 60; break;
		default: margin = 1 + cjRng(&rs) % 5000; break;
		}
		if (margin == 0) {
			margin = 1;
		}
		A.nextEvent = A.cycles + (int32_t) margin;
		B = A;
		cjTestSetup(&B, 1, envRs);
		cjTestA0 = A0;
		if (cjCodeCur + 1024 > cjCode + CJ_CODE_WORDS) {
			cjCodeCur = cjCode;
		}
		uint32_t* end;
		int bkind = 0;
		uint32_t tgt = 0;
		uint32_t k = cjEmitThumbPrefix(cjCodeCur, &end, ops, n, A0, 1, &bkind, &tgt);
		uint32_t frT = (uint32_t) cjLastFramed, p0T = (uint32_t) cjLastP0, tailT = (uint32_t) cjLastTail;
		cjCodeFlush(cjCodeCur, end);
		/* referencia: el intérprete instrucción a instrucción, parando como él (cycles >= nextEvent); la invalidación del «bloque» no le afecta */
		cjFakeBlk.valid = 1;
		cjTestInvalAt = 0;
		cjCurBlock = NULL;
		uint32_t doneA = 0;
		int takenA = 0;
		for (uint32_t j = 0; j < n; ++j) {
			A.gprs[15] = (int32_t) (A0 + 2 * j + 4);
			A.prefetch[0] = ops[j + 1];
			A.prefetch[1] = ops[j + 2];
			uint32_t pf0 = A.prefetch[0];
			_thumbTable[ops[j] >> 6](&A, ops[j]);
			doneA = j + 1;
			if (j == n - 1 && endType >= 3) {
				takenA = A.gprs[15] != (int32_t) (A0 + 2 * j + 4) || A.prefetch[0] != pf0;
				if (endType == 3 && !takenA) {
					takenA = 0;
				}
			}
			if (A.cycles >= A.nextEvent) {
				break;
			}
		}
		/* candidato: código nativo + lo que haría el despachador, y el resto con el intérprete */
		cjFakeBlk.valid = 1;
		cjFakeBlk.pc = A0;
		memcpy(cjFakeBlk.op, ops, sizeof(cjFakeBlk.op));
		cjTestInvalAt = 0;
		cjCurBlock = &cjFakeBlk;
		uint32_t got = cjRunNative(cjCodeCur, &B, ops, k, frT, p0T, tailT);
		uint32_t invalNative = cjTestInvalAt; /* instrucción tras la que el código nativo vio invalidado su bloque (0 = ninguna) */
		cjCurBlock = NULL;
		uint32_t m = 0;
		if (k != n && k != 0) {
			got = 0xFFFF; /* el emisor no cubrió todo: no debería pasar con estas secuencias */
		}
		if (got == 0xFFFF) {
			m = 0;
		} else if (got >= 0x100) {
			m = got & 0xFF;
			cjNativeTail(&B, got, A0, m, ops, tgt);
		} else if (got) {
			m = k;
			cjNativeTail(&B, got, A0, k, ops, tgt);
		}
		int takenB = got == 3;
		if (got < 3 || got >= 0x100) { /* sigue el intérprete, como el despachador */
			for (uint32_t j = m; j < n && B.cycles < B.nextEvent; ++j) {
				B.gprs[15] = (int32_t) (A0 + 2 * j + 4);
				B.prefetch[0] = ops[j + 1];
				B.prefetch[1] = ops[j + 2];
				uint32_t pfb = B.prefetch[0];
				_thumbTable[ops[j] >> 6](&B, ops[j]);
				if (j == n - 1 && endType >= 3) {
					takenB = B.gprs[15] != (int32_t) (A0 + 2 * j + 4) || B.prefetch[0] != pfb; /* mismo criterio que en la referencia */
				}
			}
		}
		int ok = got != 0xFFFF;
		if (invalNative && (got < 0x100 || (got & 0xFF) != invalNative) && got != 0) {
			ok = 0; /* el bloque se invalidó durante el tramo nativo y este no salió justo después del guardado */
		}
		for (int r = 0; r < 15; ++r) {
			ok &= A.gprs[r] == B.gprs[r];
		}
		ok &= A.cpsr.packed == B.cpsr.packed && A.cycles == B.cycles && A.nextEvent == B.nextEvent && A.spsr.packed == B.spsr.packed;
		ok &= A.memory.activeSeqCycles16 == B.memory.activeSeqCycles16 && A.memory.activeNonseqCycles16 == B.memory.activeNonseqCycles16;
		if (doneA == n && endType >= 3 && takenA) {
			ok &= takenB && A.gprs[15] == B.gprs[15] && A.prefetch[0] == B.prefetch[0] && A.prefetch[1] == B.prefetch[1];
		}
		int memDiff = 0;
#ifdef CJ_FAKE_GBA
		if (memcmp(cjFakeIw[0], cjFakeIw[1], sizeof(cjFakeIw[0])) || memcmp(cjFakeEw[0], cjFakeEw[1], sizeof(cjFakeEw[0]))) {
			ok = 0;
			memDiff = 1;
			memcpy(cjFakeIw[1], cjFakeIw[0], sizeof(cjFakeIw[0]));
			memcpy(cjFakeEw[1], cjFakeEw[0], sizeof(cjFakeEw[0]));
		}
#endif
		if (!ok) {
			++bad;
			if (shown < 3 && used + 600 < outn) {
				++shown;
				used += snprintf(out + used, outn - used, "it=%u k=%u/%u fin=%d got=%X m=%u inval=%u doneA=%u tk=%d/%d memdiff=%d nonseq %u/%u pf %X,%X/%X,%X ops:", it, k, n, endType, got, m, invalNative, doneA, takenA, takenB, memDiff, A.memory.activeNonseqCycles16, B.memory.activeNonseqCycles16, A.prefetch[0], A.prefetch[1], B.prefetch[0], B.prefetch[1]);
				for (uint32_t j = 0; j < n; ++j) {
					used += snprintf(out + used, outn - used, " %04X", ops[j]);
				}
				used += snprintf(out + used, outn - used, " cpsr %08X/%08X cyc %d/%d next %d/%d spsr %08X/%08X seq %u/%u pc %08X/%08X", A.cpsr.packed, B.cpsr.packed, A.cycles, B.cycles, A.nextEvent, B.nextEvent,
				                 A.spsr.packed, B.spsr.packed, A.memory.activeSeqCycles16, B.memory.activeSeqCycles16, (uint32_t) A.gprs[15], (uint32_t) B.gprs[15]);
				for (int r = 0; r < 15; ++r) {
					if (A.gprs[r] != B.gprs[r]) {
						used += snprintf(out + used, outn - used, " r%d %08X/%08X", r, (uint32_t) A.gprs[r], (uint32_t) B.gprs[r]);
					}
				}
				used += snprintf(out + used, outn - used, "\n");
				if (shown == 1) { /* palabras emitidas (para desensamblarlas a mano: objdump -D -b binary -m aarch64) */
					used += snprintf(out + used, outn - used, "  codigo:");
					for (uint32_t* w = cjCodeCur; w < end && w < cjCodeCur + 160 && used + 16 < outn; ++w) {
						used += snprintf(out + used, outn - used, " %08X", *w);
					}
					used += snprintf(out + used, outn - used, "\n");
				}
			}
		}
	}
	return bad;
}
#endif
