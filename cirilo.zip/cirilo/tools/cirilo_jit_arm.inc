/* Cirilo JIT, FASE 1: esqueleto SIN código nativo. Se incluye dentro de src/arm/arm.c (justo antes de ARMRunLoop) para ver ARMStep/ThumbStep, _armTable y conditionLut.
 *
 * Qué hace: cuando un punto del programa se ejecuta varias veces («caliente»), se guarda un BLOQUE (opcodes desde ese punto hasta el siguiente salto, máx. CJ_MAXN
 * instrucciones, modo ARM o Thumb como parte de la identidad) en una caché con límite. Ejecutar un bloque = lo mismo que ARMStep/ThumbStep, instrucción a instrucción y con
 * los mismos ciclos, pero la captación de la instrucción que entra en el pipeline sale de la copia guardada en vez de leer la memoria. Si esa copia estuviera vieja
 * (código automodificable sin invalidar), el resultado diferiría del intérprete y jit_cmp lo detectaría: así se prueba la INVALIDACIÓN (SMC), el pipeline, los ciclos exactos
 * y la salida del bloque en cada instrucción, antes de generar una sola instrucción nativa (Fase 2).
 *
 * Reglas que se mantienen para el JIT real:
 *  - Cada instrucción comprueba cycles >= nextEvent al terminar (el intérprete también: muchas escrituras a E/S ponen nextEvent = cycles para forzar la salida).
 *  - Los bloques solo cubren ROM, IWRAM y EWRAM; nunca cruzan una página de 4 KB. La ROM no se vigila (solo se vacía si un truco la parchea); IWRAM/EWRAM sí (mapa por trozos de 256 B).
 *  - Un trozo que se invalida más de CJ_BAN veces se prohíbe (se interpreta siempre) para no repetir traducir/tirar.
 *  - Al entrar se comprueba que prefetch[0..1] coinciden con la copia; si no, se interpreta. */
#include <mgba/internal/gba/cirilo_jit.h>
#include <string.h>
#if defined(__aarch64__) && !defined(CIRILO_JIT_SIM)
#include <sys/mman.h>
#define CJ_NATIVE_HOST 1 /* ejecuta de verdad el código que emite */
#elif defined(CIRILO_JIT_SIM)
#define CJ_NATIVE_HOST 2 /* lo ejecuta el simulador de pruebas */
#else
#define CJ_NATIVE_HOST 0 /* otro anfitrión: sin código nativo, solo la Fase 1 */
#endif

#define CJ_EXPORT __attribute__((visibility("default")))
#define CJ_MAXN 24
#define CJ_POOL_WORDS (1 << 18) /* 1 MB de bloques */
#define CJ_TAB 4096
#define CJ_RAMMAX 2048
#define CJ_HOT 3
#define CJ_BAN 48
#define CJ_MINK 2 /* un tramo nativo necesita al menos 2 instrucciones (p. ej. cmp + bcond) para compensar la llamada */
#define CJ_CODE_WORDS (1 << 18) /* 1 MB de código nativo */
/* FASE 2c (que el JIT no pierda contra el intérprete). Dos modos de compilación:
 *  - Núcleo de pruebas de CI (-DCIRILO_JIT_TEST): se mantiene el comportamiento de las fases anteriores. Todos los bloques (también los ARM y los Thumb sin código nativo) se ejecutan con la
 *    captación leída de la copia, así que un fallo de invalidación se nota; se cuentan todos los contadores; y el filtro de ganancia está APAGADO para que se pruebe todo el código nativo.
 *  - Núcleo de la app: solo hay bloques Thumb; un bloque sin código nativo (o lo que queda de uno tras su tramo nativo) se ejecuta con ThumbStep tal cual, que es exacto siempre porque es
 *    el propio intérprete; el modo ARM usa el bucle original sin consultar la caché; y solo se deja código nativo donde la ganancia estimada compensa el costo de entrar y salir. */
#ifdef CIRILO_JIT_TEST
static int cjCopyModeV = 1; /* pruebas: cirilo_jit_debug(8) pasa al modo de la app para que el CI también lo ejercite */
#define CJ_COPY_MODE cjCopyModeV
#define CJSTAT(i) (++cjStat[i])
#define CJ_GATE_DEFAULT 0
#define CJ_NOSTEP_DEFAULT 0 /* pruebas: PUSH/POP/LDM/STM nativos, para que el CI los ejercite */
#else
#define CJ_COPY_MODE 0
#define CJSTAT(i) ((void) 0)
#define CJ_GATE_DEFAULT 1
/* App: PUSH/POP/LDM/STM NO se traducen (cortan el tramo). El diagnóstico los midió peor traducidos en 4 de 4 comparaciones (2 informes x 2 núcleos, de +3% a +9%): el 98% acaba en la función de C del
 * intérprete de todos modos, así que solo añadían una salida y una entrada del código nativo. Se activan con el interruptor 2 del diagnóstico. */
#define CJ_NOSTEP_DEFAULT 1
#endif
/* Estimación en ciclos del anfitrión (a calibrar con los contadores del panel): lo que ahorra una instrucción pura o un salto traducidos frente a ThumbStep, y lo que cuesta entrar y salir
 * del tramo nativo (llamada, decodificar el estado, ThumbWritePC) más cada acceso a memoria (marco de pila + llamada a la función auxiliar, que no es más rápida que el manejador del intérprete). */
#define CJ_GAIN_PURE 8
#define CJ_GAIN_BR 6
#define CJ_COST_ENTRY 40
#define CJ_COST_MEM 6

/* Enlace de un bloque nativo con el siguiente (Fase 3a, encadenado). Lo lee la pieza cjPieceHop (a partir del código nativo): los desplazamientos de los campos están fijados por cjEmitHopPiece. */
struct CJLink {
	struct CJBlock* t; /* bloque destino (NULL = sin enlazar); la pieza comprueba que siga válido */
	uint32_t target; /* dirección del invitado del destino (saltos tomados: para lastJump y el bucle de inactividad) */
	uint32_t n; /* instrucciones del bloque origen que se cobran (incluida la del salto): lo mismo que usa cjRunNative */
	uint32_t cnt; /* veces que el código nativo ha seguido este enlace (lo recoge cjFoldHops para los contadores) */
	uint32_t tries; /* intentos de enlazar (con tope, para no buscar eternamente un destino que nunca será nativo) */
};
#define CJ_LINK_TRIES 48
#define CJ_LINKMAX 8192
struct CJBlock {
	uint32_t pc;
	uint32_t lo, hi; /* RAM: desplazamiento físico del primer y último byte captados */
	uint16_t n;
	uint8_t thumb, valid, ram, ew;
	struct CJBlock* next; /* cadena del cajón de la tabla: sin expulsiones por colisión */
	uint32_t* code; /* tramo nativo de los k primeros instrucciones (Thumb), o NULL */
	uint16_t k;
	uint8_t p0, tail; /* tramo con memoria: instrucciones puras antes del primer acceso / pendientes al final */
	uint8_t nmem, nstep; /* accesos de memoria (en línea o por C) y PUSH/POP/LDM/STM del tramo nativo (para los contadores del diagnóstico) */
	uint8_t fr; /* el tramo nativo tiene accesos a memoria: lleva su propia contabilidad de ciclos */
	uint8_t bk; /* el tramo nativo acaba en: 0 = instrucciones puras, 1 = Bcond, 2 = salto incondicional */
	uint32_t target; /* destino de ese salto */
	uint8_t pre; /* margen que exige entrar en el tramo nativo (instrucciones): lo mismo que calcula cjRunNative; la pieza de encadenado lo comprueba al saltar aquí */
	uint8_t linked; /* ya está en la lista de bloques con enlaces (cjLinked) */
	uint8_t tried; /* ya se intentó darle código nativo por encadenado (cjPromote): no se repite */
	struct CJLink lk[2]; /* [0] = salto tomado, [1] = Bcond no tomado (sigue la instrucción de después del bloque) */
	uint32_t op[CJ_MAXN + 2];
};

int cirilo_jit_on = 0;
uint8_t cirilo_jit_gran[1152];
static uint8_t cjBan[1152], cjInv[1152], cjHeat[CJ_TAB];
static uint32_t cjGLo[1152], cjGHi[1152]; /* por trozo con código: rango (desplazamiento físico) que cubren sus bloques; una escritura fuera de él no toca ningún bloque */
static struct CJBlock* cjTab[CJ_TAB];
/* Tabla compacta de acceso rápido (caché de cjTab): una sola línea de caché por entrada, sin recorrer cadenas. Una entrada con clave = pc | thumb es SIEMPRE de un bloque válido (se anula
 * al invalidarlo); info = n de instrucciones del bloque, y el bit 16 marca «sin código nativo» para ejecutarlo sin tocar el bloque. Si hay colisión se cae a la cadena y se vuelve a llenar. */
#define CJ_FAST 4096
struct CJFast {
	uint32_t key, info;
	struct CJBlock* b;
};
static struct CJFast cjFast[CJ_FAST];

/* ---- Salida del código frío: el despachador ya no agrupa en bloques lo que no es nativo ----
 * El código que no tiene versión nativa corre en el bucle apretado de siempre (ThumbStep sin nada más: agrupar en bloques obligaba a un bucle de longitud variable, y su salida mal predicha costaba
 * más que todo lo demás). Solo los SALTOS TOMADOS avisan: ThumbWritePC (parcheado en isa-inlines.h por cirilo_jit_patch.py) mira, mientras cirilo_hook_on, si el destino tiene código nativo (mapa de
 * bits, 128 KB, con falsos positivos por el hash: solo cuestan una consulta de más) o acaba de calentarse (contador de 8 bits por destino, 64 KB). Si es así llama a cirilo_hook_hit, que usa el
 * mismo truco que _ARMSetMode: nextEvent = cycles, para salir del bucle apretado; el valor real se guarda y se repone al volver. */
#define CJ_HOOK_DEFAULT 1
static uint32_t cjIwSeen[(0x8000 / 4) / 32]; /* IWRAM: qué instrucciones ARM se han ejecutado ya (diag flag 64) */
static int cjDiagProf; /* diag flag 64: cuenta de dónde vienen las instrucciones ARM (bucle más lento: solo para el reparto) */
#ifdef CIRILO_JIT_TEST
#define CJ_ARMDISP_DEFAULT 1 /* pruebas: ARM recorre el despachador para que el CI lo ejercite */
#else
#define CJ_ARMDISP_DEFAULT 0 /* app: Doom (diagnóstico, Fase 1) dio +9..15% con ARM por el despachador y sin código nativo ARM; hasta que haya (Fase 2) ARM usa el bucle original */
#endif
static int cjArmDisp = CJ_ARMDISP_DEFAULT; /* 1 = el modo ARM recorre el despachador (bloques sin nativo + ganchos de ARMWritePC); 0 = bucle ARM original. El valor por defecto es CJ_ARMDISP_DEFAULT; diag flag 128 lo invierte */
static int cjHookMode = CJ_HOOK_DEFAULT; /* 1 (normal) = el código sin versión nativa corre en el bucle apretado y solo los saltos tomados y los Bcond no tomados consultan el despachador; 0 (diag flag 32) = se agrupa en bloques y se despacha por bloque (modo anterior). Medido en el móvil: el suelo del despachador baja de +8% a +3.5% */
int cirilo_hook_on;
int cirilo_hook_pend; /* 0 = nada, 1 = el destino tiene código nativo, 2 = el destino se acaba de calentar: crear su bloque ya */
int32_t cirilo_hook_real;
uint32_t cirilo_hook_bits[(1u << 20) / 32];
uint8_t cirilo_hook_heat[1u << 16];
uint32_t cirilo_hook_bits_arm[8192 / 32]; /* ARM: ver cirilo_hook_check_arm */
uint8_t cirilo_hook_heat_arm[8192];
void cirilo_hook_hit(struct ARMCore* cpu, int why) {
	if (!cirilo_hook_pend) { /* una sola vez por salida: el valor real de nextEvent no se pisa */
		cirilo_hook_real = cpu->nextEvent;
		cpu->nextEvent = cpu->cycles;
		cirilo_hook_pend = why;
	}
}
static inline uint32_t cjNb(uint32_t a) {
	return ((a >> 1) ^ (a >> 21)) & 0xFFFFF;
}
static inline void cjNatMark(uint32_t a, int thumb) {
	if (!thumb) {
		uint32_t na = ((a >> 2) ^ (a >> 15)) & 0x1FFF; /* mismo índice que cirilo_hook_check_arm */
		cirilo_hook_bits_arm[na >> 5] |= 1u << (na & 31);
		return;
	}
	uint32_t nb = cjNb(a);
	cirilo_hook_bits[nb >> 5] |= 1u << (nb & 31);
}
static inline uint32_t cjFh(uint32_t pc) {
	return ((pc >> 1) ^ (pc >> 13)) & (CJ_FAST - 1);
}
static struct CJBlock* cjRam[CJ_RAMMAX];
static uint32_t cjRamN, cjPoolUsed, cjRomSize;
static uint32_t cjPool[CJ_POOL_WORDS] __attribute__((aligned(8)));
enum { S_CREATED, S_BLOCKS, S_INSTR_BLOCK, S_INSTR_INTERP, S_INVAL, S_FLUSH, S_SMC_CALLS, S_BANNED, S_MIDEXIT, S_PMISS, S_REFUSED, S_NBLOCKS, S_NRUNS, S_NBAIL, S_NINSTR, S_NTAKEN, S_NNOTTAKEN, S_NEARLY, S_PRUNS, S_CWORDS /* palabras de código nativo emitidas */, S_CINSTR /* instrucciones del juego cubiertas por ese código */, S_PC /* PC al salir del último tramo (no acumula) */, S_HOPS /* saltos tomados seguidos directamente en código nativo (sin pasar por el despachador) */, S_HOPS_FT /* ídem, Bcond no tomado */, S_ARMN /* instrucciones ejecutadas en modo ARM (el JIT no las traduce) */, S_ARMCYC /* ciclos emulados gastados en llamadas a cjRun que empezaron en modo ARM */, S_THCYC /* ídem, en modo Thumb */, S_ARMBIOS /* instrucciones ARM ejecutadas desde la BIOS (solo con el perfil por región, diag flag 64) */, S_ARMIW /* ídem, desde IWRAM */, S_ARMEW /* ídem, desde EWRAM */, S_ARMROM /* ídem, desde ROM u otras regiones */,
	S_ARMC_DP /* perfil ARM por clase: proceso de datos */, S_ARMC_MUL /* multiplicaciones */, S_ARMC_LS /* LDR/STR palabra o byte */, S_ARMC_LSM /* LDM/STM */, S_ARMC_BR /* B/BL */, S_ARMC_HALF /* media palabra y con signo (y SWP) */, S_ARMC_BX /* BX */, S_ARMC_OTH /* SWI, coprocesador y el resto */,
	S_ARMCOND /* ejecutadas con condición distinta de «siempre» */, S_ARMUNIQ /* direcciones distintas de IWRAM ejecutadas */, S_N };
static uint32_t cjStat[S_N];

#include "cirilo_jit_a64.inc"
#ifdef CIRILO_JIT_SIM
#include "cirilo_jit_a64sim.inc"
#endif
static uint32_t* cjCode;
static uint32_t* cjCodeCur;
static int cjNativeOn; /* 1 si hay memoria de código y el anfitrión puede ejecutarla */
static int cjNativeOff; /* pruebas: fuerza el modo de la Fase 1 */
static int cjDiagA; /* diagnóstico (modo 2 de cirilo_jit_set): solo el despachador, ningún bloque lleva código nativo */
static int cjDiagB; /* diagnóstico (modo 3): código nativo solo para aritmética y saltos; el tramo termina antes de la primera carga o guardado */
static int cjGate = CJ_GATE_DEFAULT; /* 1 = solo deja código nativo donde compensa (cjWorth) */
static void cjPiecesInit(void);
static void cjCodeInit(void) {
	if (cjCode || CJ_NATIVE_HOST == 0) {
		return;
	}
#if CJ_NATIVE_HOST == 1
	void* m = mmap(NULL, CJ_CODE_WORDS * 4, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	cjCode = m == MAP_FAILED ? NULL : (uint32_t*) m;
#else
	static uint32_t simBuf[CJ_CODE_WORDS];
	cjCode = simBuf;
#endif
	cjCodeCur = cjCode;
	cjPiecesInit();
}
static inline void cjCodeFlush(uint32_t* from, uint32_t* to) {
#if CJ_NATIVE_HOST == 1
	__builtin___clear_cache((char*) from, (char*) to);
#else
	(void) from; (void) to;
#endif
}
/* Funciones auxiliares que llama el código nativo para cargas y guardados Thumb. Reproducen EXACTAMENTE un manejador del intérprete:
 *   currentCycles = 1 + activeSeqCycles16 (esperas de la región de ORIGEN, antes del acceso); acceso (añade sus ciclos); currentCycles += nonseq16 - seq16 (con las esperas de DESPUÉS);
 *   cpu->cycles += currentCycles (sobre el valor que tenga cpu->cycles tras el acceso, por si el acceso lo toca).
 * Antes del acceso dejan PC, pipeline y cpu->cycles como los tendría el intérprete (el acceso puede leer el bus abierto o el reloj). */
#if __has_include(<mgba/internal/gba/cirilo_fast.h>)
#include <mgba/internal/gba/cirilo_fast.h>
#define CJ_LD32(cpu, a, cc) cirilo_ld32(cpu, a, cc)
#define CJ_LD16(cpu, a, cc) cirilo_ld16(cpu, a, cc)
#define CJ_LD8(cpu, a, cc) cirilo_ld8(cpu, a, cc)
#define CJ_ST32(cpu, a, v, cc) cirilo_st32(cpu, a, v, cc)
#define CJ_ST16(cpu, a, v, cc) cirilo_st16(cpu, a, v, cc)
#define CJ_ST8(cpu, a, v, cc) cirilo_st8(cpu, a, v, cc)
#else
#define CJ_LD32(cpu, a, cc) ((cpu)->memory.load32(cpu, a, cc))
#define CJ_LD16(cpu, a, cc) ((cpu)->memory.load16(cpu, a, cc))
#define CJ_LD8(cpu, a, cc) ((cpu)->memory.load8(cpu, a, cc))
#define CJ_ST32(cpu, a, v, cc) ((cpu)->memory.store32(cpu, a, v, cc))
#define CJ_ST16(cpu, a, v, cc) ((cpu)->memory.store16(cpu, a, v, cc))
#define CJ_ST8(cpu, a, v, cc) ((cpu)->memory.store8(cpu, a, v, cc))
#endif
/* jpk = índice de la instrucción en el bloque (5 bits) | instrucciones puras pendientes << 5 | margen que hay que dejar para el siguiente trozo puro << 10. El bloque es cjCurBlock (lo fija el
 * despachador antes de llamar al código nativo). Las pendientes se cobran con las esperas de ANTES del acceso. */
static struct CJBlock* cjCurBlock; /* bloque cuyo tramo nativo se está ejecutando: de él sacan las funciones auxiliares PC y pipeline, y si un guardado lo invalida (código automodificable) hay que salir tras ese guardado */
/* contadores del diagnóstico (cirilo_jit_diag_read): llamadas a las funciones auxiliares de C y, si el diagnóstico pide tiempos, ticks dentro de ellas */
#ifdef CIRILO_JIT_PROF
#define CJ_TICK() cirilo_tick()
#else
#define CJ_TICK() 0
#endif
static uint64_t cjDiagCall[2], cjDiagHT, cjDiagSites[2]; /* llamadas: [0] accesos, [1] PUSH/POP/LDM/STM; sites: los que ejecutó el código nativo según lo emitido; ticks en las auxiliares */
static int cjDiagTime;
#define CJ_MEM_PRE \
	++cjDiagCall[0]; \
	uint64_t dt_ = cjDiagTime ? CJ_TICK() : 0; \
	const struct CJBlock* cb_ = cjCurBlock; \
	uint32_t j_ = jpk & 31, pend_ = (jpk >> 5) & 31, need_ = jpk >> 10; \
	cpu->gprs[ARM_PC] = (int32_t) (cb_->pc + 2 * j_ + 4); \
	cpu->prefetch[0] = cb_->op[j_ + 1]; \
	cpu->prefetch[1] = cb_->op[j_ + 2]; \
	cpu->cycles += (int32_t) (pend_ * (1u + (uint32_t) cpu->memory.activeSeqCycles16)); \
	int cc = 1 + cpu->memory.activeSeqCycles16;
/* «salir»: el intérprete habría parado (cycles >= nextEvent) o no cabe lo que sigue (need_ instrucciones con las esperas de DESPUÉS del acceso) */
#define CJ_MEM_POST \
	cc += cpu->memory.activeNonseqCycles16 - cpu->memory.activeSeqCycles16; \
	cpu->cycles += cc; \
	uint64_t ex_ = cpu->cycles >= cpu->nextEvent || (need_ && (uint32_t) (cpu->nextEvent - cpu->cycles) <= need_ * (1u + (uint32_t) cpu->memory.activeSeqCycles16)); \
	if (cjDiagTime) { \
		cjDiagHT += CJ_TICK() - dt_; \
	}
#define CJ_HELPER_ARGS struct ARMCore* cpu, uint32_t addr, uint32_t jpk, uint32_t value
static uint64_t cjH_ld32(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = CJ_LD32(cpu, addr, &cc); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ld16(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = CJ_LD16(cpu, addr, &cc); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ld8(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = CJ_LD8(cpu, addr, &cc); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ldsb(CJ_HELPER_ARGS) { CJ_MEM_PRE uint32_t v = (uint32_t) ARM_SXT_8(CJ_LD8(cpu, addr, &cc)); CJ_MEM_POST (void) value; return v | (ex_ << 32); }
static uint64_t cjH_ldsh(CJ_HELPER_ARGS) {
	CJ_MEM_PRE
	uint32_t v = addr & 1 ? (uint32_t) ARM_SXT_8(CJ_LD16(cpu, addr, &cc)) : (uint32_t) ARM_SXT_16(CJ_LD16(cpu, addr, &cc));
	CJ_MEM_POST
	(void) value;
	return v | (ex_ << 32);
}
static uint64_t cjH_st32(CJ_HELPER_ARGS) { CJ_MEM_PRE CJ_ST32(cpu, addr, (int32_t) value, &cc); CJ_MEM_POST return (ex_ | (cjCurBlock && !cjCurBlock->valid)) << 32; }
static uint64_t cjH_st16(CJ_HELPER_ARGS) { CJ_MEM_PRE CJ_ST16(cpu, addr, (int16_t) value, &cc); CJ_MEM_POST return (ex_ | (cjCurBlock && !cjCurBlock->valid)) << 32; }
static uint64_t cjH_st8(CJ_HELPER_ARGS) { CJ_MEM_PRE CJ_ST8(cpu, addr, (int8_t) value, &cc); CJ_MEM_POST return (ex_ | (cjCurBlock && !cjCurBlock->valid)) << 32; }
/* Tabla que recibe el código nativo (x22): las funciones auxiliares de C y, tras ellas, lo que necesitan las piezas en línea: el GBAMemory y el mapa de trozos con código (SMC). */
/* PUSH/POP/STMIA/LDMIA: el manejador REAL del intérprete (mismos ciclos, esperas, SMC y efectos en E/S), con PC y pipeline como los dejaría ThumbStep */
static uint64_t cjH_step(CJ_HELPER_ARGS) {
	const struct CJBlock* cb_ = cjCurBlock;
	uint32_t j_ = jpk & 31, pend_ = (jpk >> 5) & 31, need_ = jpk >> 10;
	(void) addr; (void) value;
	++cjDiagCall[1];
	uint64_t dt_ = cjDiagTime ? CJ_TICK() : 0;
	cpu->gprs[ARM_PC] = (int32_t) (cb_->pc + 2 * j_ + 4);
	cpu->prefetch[0] = cb_->op[j_ + 1];
	cpu->prefetch[1] = cb_->op[j_ + 2];
	cpu->cycles += (int32_t) (pend_ * (1u + (uint32_t) cpu->memory.activeSeqCycles16));
	_thumbTable[cb_->op[j_] >> 6](cpu, cb_->op[j_]);
	uint64_t ex_ = cpu->cycles >= cpu->nextEvent || (need_ && (uint32_t) (cpu->nextEvent - cpu->cycles) <= need_ * (1u + (uint32_t) cpu->memory.activeSeqCycles16));
	if (cjDiagTime) {
		cjDiagHT += CJ_TICK() - dt_;
	}
	return (ex_ | !cb_->valid) << 32;
}
static const void* cjHelperTab[H_COUNT + 2] = {cjH_ld32, cjH_ld16, cjH_ld8, cjH_ldsb, cjH_ldsh, cjH_st32, cjH_st16, cjH_st8, cjH_step};
static uint32_t* cjCodeBase; /* primera palabra libre tras las piezas: ahí empieza el código de los bloques */
/* Pieza de acceso a IWRAM/EWRAM en línea. Contrato (el mismo que las funciones auxiliares de C, cuyo cuerpo reproduce): x19 = ARMCore, x22 = cjHelperTab, w1 = dirección, w2 = jpk, w3 = valor (guardados),
 * w4 = PC del invitado en esta instrucción (para el prefetch). Devuelve x0 = valor | (salir << 32); NO conserva los banderines (los deja en x21; el sitio los restaura).
 * Cualquier otra región, o un guardado en un trozo de 256 B con código (SMC), salta a la función de C (sin haber tocado nada). Ciclos exactos: pend*(1+seq) + 1 + nonseq + espera,
 * con la espera (más 2 en cargas, 1 en guardados) pasada por el modelo de prefetch de GBAMemoryStall si se ejecuta desde ROM con prefetch activo. */
#define CJ_PATCH_B(slot, cond) (*(slot) = (cond) < 0 ? a_b((int32_t) (p - (slot))) : a_bcond(cond, (int32_t) (p - (slot))))
static uint32_t* cjEmitMemPiece(uint32_t* p, int h) {
	if (h == H_STEP) { /* sin camino en línea: directamente la función de C */
		*p++ = a_mrs_nzcv(21);
		*p++ = a_mov64(0, 19);
		*p++ = a_ldr64(16, 22, 8 * h);
		*p++ = a_br(16);
		return p;
	}
	const int store = h >= H_ST32 && h != H_STEP;
	const int sz = (h == H_LD32 || h == H_ST32) ? 32 : (h == H_LD8 || h == H_LDSB || h == H_ST8) ? 8 : 16;
	const int sh = sz == 32 ? 2 : sz == 16 ? 1 : 0; /* bits bajos que se enmascaran */
	const uint32_t oWs = offsetof(struct GBAMemory, waitstatesNonseq32) + 0, oWs16 = offsetof(struct GBAMemory, waitstatesNonseq16);
	const uint32_t oCyc = offsetof(struct ARMCore, cycles), oNext = offsetof(struct ARMCore, nextEvent);
	const uint32_t oSeq = offsetof(struct ARMCore, memory.activeSeqCycles16), oNon = offsetof(struct ARMCore, memory.activeNonseqCycles16);
	const uint32_t oLast = offsetof(struct GBAMemory, lastPrefetchedPc);
	uint32_t *bIW, *bSlow1, *bCommon, *bSlow2 = NULL, *bNoStall1, *bNoStall2, *bLoopA, *bLoopB, *bLoopBack, *bSh8 = NULL, *bShDone = NULL, *bPre = NULL;
	uint32_t* start = p;
#define E(w) (*p++ = (w))
	E(a_mrs_nzcv(21));
	E(a_ldr64(16, 22, 8 * H_COUNT));
	E(a_lsri(9, 1, 24));
	E(a_subsi(31, 9, 3));
	bIW = p; E(0);
	E(a_subsi(31, 9, 2));
	bSlow1 = p; E(0);
	/* EWRAM */
	E(a_logi(A_ANDI, 10, 1, sh, 18 - sh));
	E(a_ldr64(11, 16, offsetof(struct GBAMemory, wram)));
	E(a_ldrb_i(12, 16, (sz == 32 ? oWs : oWs16) + GBA_REGION_EWRAM));
	if (store) {
		E(a_lsri(13, 10, 8));
		E(a_addi(13, 13, 128));
	}
	bCommon = p; E(0);
	/* IWRAM */
	CJ_PATCH_B(bIW, 0);
	E(a_logi(A_ANDI, 10, 1, sh, 15 - sh));
	E(a_ldr64(11, 16, offsetof(struct GBAMemory, iwram)));
	E(a_movz(12, 0, 0));
	if (store) {
		E(a_lsri(13, 10, 8));
	}
	CJ_PATCH_B(bCommon, -1);
	if (store) { /* ¿hay código en ese trozo? entonces el guardado lo hace la función de C (que avisa al JIT) */
		E(a_ldr64(14, 22, 8 * (H_COUNT + 1)));
		E(a_ldst_r(A_LDRB_R, 14, 14, 13));
		bSlow2 = p; E(0);
	}
	/* el acceso */
	if (store) {
		E(a_ldst_r(sz == 32 ? A_STRW_R : sz == 16 ? A_STRH_R : A_STRB_R, 3, 11, 10));
		E(a_rrr(A_ORR, 0, 31, 31));
	} else {
		E(a_ldst_r(sz == 32 ? A_LDRW_R : sz == 16 ? A_LDRH_R : A_LDRB_R, 0, 11, 10));
		if (sz != 8) {
			E(a_lsli(5, 1, 3));
			if (sz == 16) {
				E(a_logi(A_ANDI, 5, 5, 3, 1));
			}
			E(a_rorv(0, 0, 5));
		}
		if (h == H_LDSB) {
			E(a_sbfm(0, 0, 0, 7));
		} else if (h == H_LDSH) {
			E(a_logi(0x72000000u, 31, 1, 0, 1)); /* tst w1, #1 */
			bSh8 = p; E(0);
			E(a_sbfm(0, 0, 0, 15));
			bShDone = p; E(0);
			CJ_PATCH_B(bSh8, 1);
			E(a_sbfm(0, 0, 0, 7));
			CJ_PATCH_B(bShDone, -1);
		}
	}
	E(a_addi(12, 12, store ? 1 : 2));
	E(a_ldr(14, 19, oSeq));
	E(a_ldr(15, 19, oNon));
	E(a_ldr(13, 16, offsetof(struct GBAMemory, activeRegion)));
	E(a_subsi(31, 13, GBA_REGION_ROM0));
	bNoStall1 = p; E(0);
	E(a_ldrb_i(13, 16, offsetof(struct GBAMemory, prefetch)));
	E(a_subsi(31, 13, 0));
	bNoStall2 = p; E(0);
	/* GBAMemoryStall: w4 = PC, w12 = espera, w14 = s (seq16), w15 = nonseq16 -> w12 = espera final */
	E(a_ldr(5, 16, oLast));
	E(a_addsub_r(A_SUB, 5, 5, 4, 0)); /* dist */
	E(a_movz(6, 8, 0)); /* maxLoads */
	E(a_movz(7, 0, 0)); /* previousLoads */
	E(a_subsi(31, 5, 16));
	bPre = p; E(0); /* b.hs */
	E(a_lsri(7, 5, 1));
	E(a_addsub_r(A_SUB, 6, 6, 7, 0));
	CJ_PATCH_B(bPre, 2);
	E(a_addi(8, 14, 1)); /* stall = s + 1 */
	E(a_movz(9, 1, 0)); /* loads */
	uint32_t* loop = p;
	E(a_addsub_r(A_SUBS, 31, 8, 12, 0));
	bLoopA = p; E(0); /* b.ge fin */
	E(a_addsub_r(A_SUBS, 31, 9, 6, 0));
	bLoopB = p; E(0); /* b.ge fin */
	E(a_addsub_r(A_ADD, 8, 8, 14, 0));
	E(a_addi(9, 9, 1));
	bLoopBack = p; E(a_b((int32_t) (loop - p)));
	CJ_PATCH_B(bLoopA, 10);
	CJ_PATCH_B(bLoopB, 10);
	(void) bLoopBack;
	E(a_addsub_r(A_ADD, 9, 9, 7, 0));
	E(a_subi(9, 9, 1));
	E(a_lsli(9, 9, 1));
	E(a_addsub_r(A_ADD, 9, 9, 4, 0));
	E(a_str(9, 16, oLast));
	E(a_addsub_r(A_SUBS, 31, 8, 12, 0));
	E(a_csel(12, 8, 12, 12)); /* stall > wait: wait = stall */
	E(a_addsub_r(A_SUB, 10, 15, 14, 0));
	E(a_addsub_r(A_SUB, 12, 12, 10, 0));
	E(a_addsub_r(A_SUB, 12, 12, 8, 0));
	CJ_PATCH_B(bNoStall1, 11);
	CJ_PATCH_B(bNoStall2, 0);
	/* ciclos y salida */
	E(a_ubfx(5, 2, 5, 5));
	E(a_addi(6, 14, 1));
	E(a_madd(5, 5, 6, 12));
	E(a_addsub_r(A_ADD, 5, 5, 15, 0));
	E(a_addi(5, 5, 1));
	E(a_ldr(7, 19, oCyc));
	E(a_addsub_r(A_ADD, 7, 7, 5, 0));
	E(a_str(7, 19, oCyc));
	E(a_lsri(8, 2, 10));
	E(a_madd(8, 8, 6, 31));
	E(a_ldr(9, 19, oNext));
	E(a_addsub_r(A_SUB, 9, 9, 7, 0));
	E(a_addsub_r(A_SUBS, 31, 9, 8, 0));
	E(a_movz(10, 1, 0));
	E(a_csel(10, 10, 31, 13)); /* le */
	E(a_orr64_lsl32(0, 0, 10));
	E(A_RET);
	/* camino lento: la función de C */
	if (bSlow2) {
		*bSlow2 = a_cbnz(14, (int32_t) (p - bSlow2));
	}
	CJ_PATCH_B(bSlow1, 1);
	E(a_mov64(0, 19));
	E(a_ldr64(16, 22, 8 * h));
	E(a_br(16));
#undef E
	(void) start;
	return p;
}
static int cjNoInline; /* diagnóstico: las piezas de memoria van directas a la función de C (como antes de la memoria en línea) */
static int cjNoChain; /* diagnóstico: sin encadenado (los bloques acaban con ret, como antes de la Fase 3a) */

/* Pieza de encadenado (Fase 3a): UNA para todos los bloques. Entra con w0 = estado con el que acaba el bloque (3 = salto tomado, 2 = Bcond no tomado; cualquier otro, o cualquier duda, = «ret» con w0 intacto, que es
 * justo lo que hacía el bloque antes), x1 = ARMCore, x16 = &bloque->lk[0] y la pila como la dejó el bloque (su marco ya deshecho; x30 = retorno a C). Si hay un destino nativo enlazado que sigue válido, comprueba SIN
 * tocar nada que el despachador haría lo mismo y, solo entonces, hace en código nativo lo que haría él:
 *   - ciclos: lo que cobra cjRunNative al acabar el tramo (n*(1+seq), n incluye la instrucción de salto) y, si el salto se toma, lo que cobra cjNativeTail: ThumbWritePC = 2 + nonseq + seq (con
 *     el salto dentro de la misma región, los ciclos activos no cambian). El no tomado solo cobra n*(1+seq);
 *   - margen: el despachador seguiría solo si cycles' < nextEvent y, si el destino exige margen (pre), si cabe: nextEvent - cycles' > pre*(1+seq) cubre las dos cosas (pre = 0: solo la primera);
 *   - salto tomado: la parte de GBASetActiveRegion que se ejecuta cuando la región no cambia: lastJump = destino, lastPrefetchedPc = 0, y la detección de bucles de inactividad (si está en modo
 *     «detectar» o el destino es el bucle conocido, no se encadena: lo hace el camino lento). PC y pipeline NO se escriben: los reconstruye quien salga del bloque (cjNativeTail, con los datos del
 *     bloque que acabe: cjCurBlock) y los accesos a memoria los ponen ellos mismos;
 *   - cjCurBlock = destino, cuenta del enlace y salto al código nativo del destino con x0 = ARMCore y x2 = tabla de auxiliares (su prólogo es el de siempre). */
static uint32_t* cjEmitHopPiece(uint32_t* p) {
	const uint32_t oCyc = offsetof(struct ARMCore, cycles), oNext = offsetof(struct ARMCore, nextEvent);
	const uint32_t oSeq = offsetof(struct ARMCore, memory.activeSeqCycles16), oNon = offsetof(struct ARMCore, memory.activeNonseqCycles16);
	const uint32_t oMaster = offsetof(struct ARMCore, master);
	const uint32_t oIdleOpt = offsetof(struct GBA, idleOptimization), oIdleLoop = offsetof(struct GBA, idleLoop), oLastJump = offsetof(struct GBA, lastJump);
	const uint32_t oLastPf = offsetof(struct GBA, memory) + offsetof(struct GBAMemory, lastPrefetchedPc);
	const uint32_t oT = offsetof(struct CJLink, t), oTgt = offsetof(struct CJLink, target), oN = offsetof(struct CJLink, n), oCnt = offsetof(struct CJLink, cnt);
	const uint32_t oValid = offsetof(struct CJBlock, valid), oPre = offsetof(struct CJBlock, pre), oCode = offsetof(struct CJBlock, code);
	if (IDLE_LOOP_REMOVE != 0 || IDLE_LOOP_DETECT != 1 || sizeof(struct CJLink) != 24) {
		return NULL;
	}
	const uint32_t w4[] = {oCyc, oNext, oSeq, oNon, oIdleOpt, oIdleLoop, oLastJump, oLastPf, oTgt, oN, oCnt};
	for (unsigned i = 0; i < sizeof(w4) / sizeof(*w4); ++i) {
		if (w4[i] > 16380 || (w4[i] & 3)) {
			return NULL; /* no cabe en el desplazamiento de ldr/str de 32 bits: sin encadenado */
		}
	}
	if (oMaster > 32760 || (oMaster & 7) || oT > 32760 || (oT & 7) || oCode > 32760 || (oCode & 7) || oValid > 4095 || oPre > 4095) {
		return NULL;
	}
	uint32_t *bTaken, *bCommon, *bRet[8], *bFt, *litCur, *litTab;
	int nRet = 0;
#define E(w) (*p++ = (w))
#define CJ_RET_IF(enc) do { bRet[nRet++] = p; E(enc); } while (0) /* se enlaza abajo con el «ret» */
	E(a_subsi(31, 0, 3));
	bTaken = p; E(0); /* b.eq tomado */
	E(a_subsi(31, 0, 2));
	CJ_RET_IF(a_bcond(1, 0)); /* b.ne ret (placeholder) */
	E(a_add64i(16, 16, (uint32_t) sizeof(struct CJLink))); /* no tomado: el enlace [1] */
	E(a_movz(17, 0, 0));
	bCommon = p; E(0); /* b común */
	*bTaken = a_bcond(0, (int32_t) (p - bTaken));
	E(a_movz(17, 1, 0)); /* w17 = 1: salto tomado */
	*bCommon = a_b((int32_t) (p - bCommon));
	E(a_ldr64(2, 16, oT));
	CJ_RET_IF(0xB4000000u | 2); /* cbz x2, ret */
	E(a_ldrb_i(3, 2, oValid));
	CJ_RET_IF(a_cbz(3, 0));
	E(a_ldr(4, 16, oN));
	E(a_ldr(5, 1, oSeq));
	E(a_ldr(7, 1, oNon));
	E(a_addi(6, 5, 1));
	E(a_madd(8, 4, 6, 31)); /* n*(1+seq) */
	E(a_addsub_r(A_ADD, 9, 7, 5, 0));
	E(a_addi(9, 9, 2)); /* 2 + nonseq + seq */
	E(a_subsi(31, 17, 0));
	E(a_csel(9, 9, 31, 1)); /* solo si el salto se toma */
	E(a_addsub_r(A_ADD, 8, 8, 9, 0)); /* ciclos que se cobran */
	E(a_ldr(9, 1, oCyc));
	E(a_addsub_r(A_ADD, 8, 8, 9, 0)); /* w8 = cycles' */
	E(a_ldr(9, 1, oNext));
	E(a_addsub_r(A_SUB, 9, 9, 8, 0)); /* margen que queda */
	E(a_ldrb_i(10, 2, oPre));
	E(a_mul(10, 10, 6));
	E(a_addsub_r(A_SUBS, 31, 9, 10, 0));
	CJ_RET_IF(a_bcond(13, 0)); /* b.le ret: no cabe (o cycles' >= nextEvent) */
	bFt = p; E(0); /* cbz w17, confirmar */
	E(a_ldr64(11, 1, oMaster));
	E(a_ldr(12, 11, oIdleOpt));
	E(a_subsi(31, 12, 0));
	CJ_RET_IF(a_bcond(12, 0)); /* b.gt ret: modo «detectar» */
	E(a_ldr(13, 16, oTgt));
	E(a_ldr(12, 11, oIdleLoop));
	E(a_addsub_r(A_SUBS, 31, 12, 13, 0));
	CJ_RET_IF(a_bcond(0, 0)); /* b.eq ret: el destino es el bucle de inactividad conocido */
	E(a_str(13, 11, oLastJump));
	E(a_str(31, 11, oLastPf));
	*bFt = a_cbz(17, (int32_t) (p - bFt));
	/* confirmar: a partir de aquí ya no hay vuelta atrás */
	E(a_str(8, 1, oCyc));
	{ uint32_t* ld = p; E(0); litCur = ld; } /* ldr x12, &cjCurBlock (literal, abajo) */
	E(a_str64(2, 12, 0));
	E(a_ldr(12, 16, oCnt));
	E(a_addi(12, 12, 1));
	E(a_str(12, 16, oCnt));
	E(a_ldr64(3, 2, oCode));
	E(a_mov64(0, 1));
	{ uint32_t* ld = p; E(0); litTab = ld; } /* ldr x2, &cjHelperTab (literal) */
	E(a_br(3));
	uint32_t* ret = p;
	E(A_RET);
	for (int q = 0; q < nRet; ++q) { /* los saltos a «ret» conservan su condición/forma */
		uint32_t w = *bRet[q];
		int32_t off = (int32_t) (ret - bRet[q]);
		if ((w & 0xFF000010u) == 0x54000000u) {
			*bRet[q] = a_bcond((int) (w & 15), off);
		} else if ((w & 0xFF000000u) == 0xB4000000u) {
			*bRet[q] = 0xB4000000u | (((uint32_t) off & 0x7FFFF) << 5) | (w & 31);
		} else {
			*bRet[q] = a_cbz((int) (w & 31), off);
		}
	}
	if ((uintptr_t) p & 7) {
		E(0xD503201Fu);
	}
	uint64_t a0 = (uint64_t) (uintptr_t) &cjCurBlock, a1 = (uint64_t) (uintptr_t) cjHelperTab;
	*litCur = a_ldr_lit(12, (int32_t) (p - litCur));
	E((uint32_t) a0); E((uint32_t) (a0 >> 32));
	*litTab = a_ldr_lit(2, (int32_t) (p - litTab));
	E((uint32_t) a1); E((uint32_t) (a1 >> 32));
#undef CJ_RET_IF
#undef E
	return p;
}
static void cjPiecesInit(void) {
	uint32_t* p = cjCode;
	for (int h = 0; h < H_COUNT; ++h) {
		cjPiece[h] = p;
		if (cjNoInline && h != H_STEP) {
			*p++ = a_mrs_nzcv(21);
			*p++ = a_mov64(0, 19);
			*p++ = a_ldr64(16, 22, 8 * h);
			*p++ = a_br(16);
		} else {
			p = cjEmitMemPiece(p, h);
		}
	}
	cjPieceHop = NULL;
	if (!cjNoChain) {
		uint32_t* q = cjEmitHopPiece(p);
		if (q) {
			cjPieceHop = p;
			p = q;
		}
	}
	cjCodeFlush(cjCode, p);
	cjCodeBase = p;
	cjCodeCur = p;
}

static inline uint32_t cjCallNative(const uint32_t* code, struct ARMCore* cpu, const uint32_t* ops, const void* const* tab) {
#if CJ_NATIVE_HOST == 1
	return ((uint32_t (*)(struct ARMCore*, const uint32_t*, const void* const*)) (uintptr_t) code)(cpu, ops, tab);
#elif CJ_NATIVE_HOST == 2
	return cjSimRun(code, cpu, ops, tab);
#else
	(void) code; (void) cpu; (void) ops; (void) tab;
	return 0;
#endif
}

/* Ejecuta un tramo nativo de k instrucciones. El código nativo NO lleva la cuenta de ciclos (los accesos a memoria se la entregan a sus funciones de C): aquí se comprueba el margen
 * inicial (como el intérprete: lo que se ejecuta antes del primer acceso, o todo salvo la última instrucción si no hay accesos, tiene que caber antes del siguiente evento; si no, devuelve 0
 * sin hacer nada) y al terminar se suma una sola vez lo pendiente (tail instrucciones, una menos si el salto se toma: ese lo cuenta el despachador). Con salida temprana (>= 0x100)
 * los ciclos ya están escritos. */
static inline uint32_t cjRunNative(const uint32_t* code, struct ARMCore* cpu, const uint32_t* ops, uint32_t k, uint32_t fr, uint32_t p0, uint32_t tail) {
	uint32_t pre = fr ? p0 : (k >= 2 ? k - 1 : 0);
	if (pre && (uint32_t) (cpu->nextEvent - cpu->cycles) <= pre * ((uint32_t) cpu->memory.activeSeqCycles16 + 1)) {
		return 0;
	}
	cjHelperTab[H_COUNT] = &((struct GBA*) cpu->master)->memory;
	cjHelperTab[H_COUNT + 1] = cirilo_jit_gran;
	uint32_t st = cjCallNative(code, cpu, ops, cjHelperTab);
	if (st < 0x100) {
		uint32_t n = fr ? tail : k; /* los accesos pueden haber cambiado las esperas: el coste es el de ahora */
		cpu->cycles += (int32_t) ((st == 3 ? n - 1 : n) * ((uint32_t) cpu->memory.activeSeqCycles16 + 1));
	}
	return st;
}

/* Tramo nativo ARM (Fase 2): puro, sin saltos ni memoria, sin encadenado. Cada instrucción cuesta 1 + activeSeqCycles32 (ejecutada o no: ver cjEmitOneArm). Como en Thumb: si lo que se
 * ejecuta antes de la última instrucción no cabe antes del siguiente evento, no hace nada y devuelve 0. */
static inline uint32_t cjRunNativeArm(const uint32_t* code, struct ARMCore* cpu, const uint32_t* ops, uint32_t k) {
	const uint32_t c = (uint32_t) cpu->memory.activeSeqCycles32 + 1, pre = k >= 2 ? k - 1 : 0;
	if (pre && (uint32_t) (cpu->nextEvent - cpu->cycles) <= pre * c) {
		return 0;
	}
	uint32_t st = cjCallNative(code, cpu, ops, cjHelperTab);
	cpu->cycles += (int32_t) (k * c);
	return st;
}
/* Estado del intérprete tras un tramo ARM de k instrucciones: PC apunta dos instrucciones por delante de la siguiente y el pipeline trae las dos siguientes */
static void cjNativeTailArm(struct ARMCore* cpu, uint32_t pc0, uint32_t k, const uint32_t* op) {
	cpu->gprs[ARM_PC] = (int32_t) (pc0 + (k + 1) * WORD_SIZE_ARM);
	cpu->prefetch[0] = op[k];
	cpu->prefetch[1] = op[k + 1];
}

/* Como cjRunNative, para el despachador, con encadenado: el código nativo puede haber saltado por el camino a otros bloques; el que acaba (el que devuelve el estado) es cjCurBlock, y de él
 * son k, fr y tail. */
static inline uint32_t cjRunNativeB(struct ARMCore* cpu, struct CJBlock* b) {
	uint32_t pre = b->pre;
	if (pre && (uint32_t) (cpu->nextEvent - cpu->cycles) <= pre * ((uint32_t) cpu->memory.activeSeqCycles16 + 1)) {
		return 0;
	}
	cjHelperTab[H_COUNT] = &((struct GBA*) cpu->master)->memory;
	cjHelperTab[H_COUNT + 1] = cirilo_jit_gran;
	uint32_t st = cjCallNative(b->code, cpu, b->op, cjHelperTab);
	if (st < 0x100) {
		const struct CJBlock* f = cjCurBlock;
		uint32_t n = f->fr ? f->tail : f->k;
		cpu->cycles += (int32_t) ((st == 3 ? n - 1 : n) * ((uint32_t) cpu->memory.activeSeqCycles16 + 1));
	}
	return st;
}

/* Contadores de los enlaces: el código nativo solo cuenta cuántas veces siguió cada uno; aquí se vuelcan a los contadores generales (como si el despachador hubiera ejecutado esos tramos). */
static struct CJBlock* cjLinked[CJ_LINKMAX];
static uint32_t cjLinkedN;
static void cjFoldHops(void) {
	for (uint32_t i = 0; i < cjLinkedN; ++i) {
		struct CJBlock* b = cjLinked[i];
		for (int w = 0; w < 2; ++w) {
			uint32_t c = b->lk[w].cnt;
			if (!c) {
				continue;
			}
			b->lk[w].cnt = 0;
			cjStat[w ? S_HOPS_FT : S_HOPS] += c;
			cjStat[w ? S_NNOTTAKEN : S_NTAKEN] += c;
			cjStat[S_NINSTR] += c * b->k;
			cjStat[S_INSTR_BLOCK] += c * b->k;
			cjDiagSites[0] += (uint64_t) c * b->nmem;
			cjDiagSites[1] += (uint64_t) c * b->nstep;
		}
	}
}
CJ_EXPORT int cirilo_jit_stats(uint32_t* out) {
	cjFoldHops();
	for (int i = 0; i < S_N; ++i) {
		out[i] = cjStat[i];
	}
	uint32_t seen = 0; /* S_ARMUNIQ = instrucciones ARM de IWRAM distintas vistas con el perfil encendido: valor absoluto, no una cuenta */
	for (uint32_t i = 0; i < sizeof(cjIwSeen) / sizeof(cjIwSeen[0]); ++i) {
		seen += (uint32_t) __builtin_popcount(cjIwSeen[i]);
	}
	out[S_ARMUNIQ] = seen;
	return S_N;
}

static void cjClear(int keepBans) {
	cjFoldHops();
	cjLinkedN = 0;
	memset(cirilo_hook_bits, 0, sizeof(cirilo_hook_bits));
	memset(cirilo_hook_heat, 0, sizeof(cirilo_hook_heat));
	memset(cirilo_hook_bits_arm, 0, sizeof(cirilo_hook_bits_arm));
	memset(cirilo_hook_heat_arm, 0, sizeof(cirilo_hook_heat_arm));
	memset(cjTab, 0, sizeof(cjTab));
	memset(cjFast, 0, sizeof(cjFast));
	memset(cjHeat, 0, sizeof(cjHeat));
	memset(cirilo_jit_gran, 0, sizeof(cirilo_jit_gran));
	if (!keepBans) {
		memset(cjBan, 0, sizeof(cjBan));
		memset(cjInv, 0, sizeof(cjInv));
	}
	cjRamN = 0;
	cjPoolUsed = 0;
	cjCodeCur = cjCodeBase;
}

void cirilo_jit_flush(void) {
	cjClear(0);
}

void cirilo_jit_reset(uint32_t romSize) {
	cjRomSize = romSize;
	cjClear(0);
}

void cirilo_jit_patch(uint32_t address) {
	uint32_t r = address >> 24;
	if (r >= 8 && r <= 0xD && cjPoolUsed) {
		++cjStat[S_FLUSH];
		cjClear(1);
	}
}

/* mode: 0 apagado, 1 JIT normal, 2 = diagnóstico A (solo despachador, sin nativo), 3 = diagnóstico B (nativo sin cargas ni guardados) */
CJ_EXPORT void cirilo_jit_set(int mode) {
	int on = mode != 0;
	cjDiagA = mode == 2;
	cjDiagB = mode == 3;
	cjClear(0);
	cirilo_jit_on = on ? 1 : 0;
	if (on) {
		cjCodeInit();
	}
	cjNativeOn = cirilo_jit_on && cjCode && !cjNativeOff && !cjDiagA;
}

#ifdef CIRILO_JIT_PROF
static uint64_t cjProfNat;
#endif
/* Diagnóstico (app: Opciones del juego → Diagnóstico del JIT). flags: 1 = memoria en línea apagada, 2 = PUSH/POP/LDM/STM TRADUCIDOS (por defecto no lo están en la app), 4 = sin filtro de ganancia (cjWorth), 8 = medir tiempos dentro de las
 * auxiliares de C. Se llama ANTES de cirilo_jit_set (que vacía la caché y aplica el modo). */
CJ_EXPORT void cirilo_jit_diag(int flags) {
	cjDiagTime = (flags >> 3) & 1;
	cjGate = (flags >> 2) & 1 ? 0 : CJ_GATE_DEFAULT;
	cjNoStep = (flags >> 1) & 1 ? 0 : CJ_NOSTEP_DEFAULT;
	cjHookMode = (flags >> 5) & 1 ? 0 : CJ_HOOK_DEFAULT;
	cjArmDisp = (flags >> 7) & 1 ? !CJ_ARMDISP_DEFAULT : CJ_ARMDISP_DEFAULT; /* diag 128 invierte el valor por defecto (para medir A/B en el móvil) */
	if (((flags >> 6) & 1) && !cjDiagProf) {
		memset(cjIwSeen, 0, sizeof(cjIwSeen));
	}
	cjDiagProf = (flags >> 6) & 1;
	cirilo_hook_pend = 0;
	int ni = flags & 1, nc = (flags >> 4) & 1;
	if (cjCode && (ni != cjNoInline || nc != cjNoChain)) {
		cjNoInline = ni;
		cjNoChain = nc;
		cjClear(0);
		cjPiecesInit();
	}
	cjNoInline = ni;
	cjNoChain = nc;
}
/* out[0] llamadas a las auxiliares de accesos, [1] a la de PUSH/POP/LDM/STM, [2] accesos ejecutados por código nativo, [3] PUSH/POP/LDM/STM ejecutados, [4] ticks dentro de las auxiliares,
 * [5] ticks dentro del código nativo (con las auxiliares), [6] palabras de código nativo en uso, [7] bloques nativos creados, [8] frecuencia de los ticks. Después se ponen a cero (salvo 6-8). */
CJ_EXPORT void cirilo_jit_diag_read(uint64_t* out) {
	cjFoldHops();
	out[0] = cjDiagCall[0]; out[1] = cjDiagCall[1]; out[2] = cjDiagSites[0]; out[3] = cjDiagSites[1]; out[4] = cjDiagHT;
#ifdef CIRILO_JIT_PROF
	out[5] = cjProfNat;
	cjProfNat = 0;
#else
	out[5] = 0;
#endif
	out[6] = cjCode ? (uint64_t) (cjCodeCur - cjCode) : 0;
	out[7] = cjStat[S_NBLOCKS];
	out[8] = 0;
	cjDiagCall[0] = cjDiagCall[1] = cjDiagSites[0] = cjDiagSites[1] = cjDiagHT = 0;
}

#ifdef CIRILO_JIT_TEST /* solo en el núcleo de pruebas de CI (jit_test.sh): permite comprobar que el comparador DETECTA un JIT sin invalidación */
static int cjTestNoSmc;
CJ_EXPORT void cirilo_jit_debug(int flags) {
	cjTestNoSmc = flags & 1;
	cjNativeOff = (flags >> 1) & 1; /* 2 = sin código nativo (modo Fase 1) */
	cjGate = (flags >> 2) & 1; /* 4 = filtro de ganancia como en la app */
	cjCopyModeV = !((flags >> 3) & 1); /* 8 = modo de la app (bloques Thumb sin copia, ARM sin caché) */
	cjNativeOn = cirilo_jit_on && cjCode && !cjNativeOff && !cjDiagA;
}
#endif

static inline uint32_t cjHash(uint32_t pc, int thumb) {
	return ((pc >> 1) ^ (pc >> 11) ^ (thumb ? 0x5A5 : 0)) & (CJ_TAB - 1);
}

/* ¿Hay algún bloque válido que aún toque el trozo g (de la región ew)? */
static int cjGranUsed(int ew, uint32_t g) {
	uint32_t lo = g << 8, hi = lo + 255;
	for (uint32_t i = 0; i < cjRamN; ++i) {
		struct CJBlock* b = cjRam[i];
		if (b->valid && b->ew == ew && b->hi >= lo && b->lo <= hi) {
			return 1;
		}
	}
	return 0;
}

/* Llamado desde las macros CIRILO_JIT_IW/EW cuando se escribe en un trozo con código. */
void cirilo_jit_smc(int ewram, uint32_t offset, uint32_t size) {
	++cjStat[S_SMC_CALLS];
#ifdef CIRILO_JIT_TEST
	if (cjTestNoSmc) {
		return;
	}
#endif
	uint32_t end = offset + size - 1;
	{ /* filtro: los datos que comparten trozo de 256 B con código son lo habitual (pila, variables); sin solape no hay nada que tirar y no se recorre la lista de bloques */
		int hit = 0;
		for (uint32_t g = offset >> 8; g <= end >> 8; ++g) {
			uint32_t idx = (ewram ? 128 : 0) + g;
			if (cirilo_jit_gran[idx] && offset <= cjGHi[idx] && end >= cjGLo[idx]) {
				hit = 1;
				break;
			}
		}
		if (!hit) {
			return;
		}
	}
	for (uint32_t i = 0; i < cjRamN; ++i) {
		struct CJBlock* b = cjRam[i];
		if (b->valid && b->ew == ewram && b->hi >= offset && b->lo <= end) {
			b->valid = 0;
			if (cjFast[cjFh(b->pc)].b == b) {
				cjFast[cjFh(b->pc)].key = 0;
			}
			++cjStat[S_INVAL];
		}
	}
	for (uint32_t g = offset >> 8; g <= end >> 8; ++g) {
		uint32_t idx = (ewram ? 128 : 0) + g;
		if (cjInv[idx] < 255) {
			++cjInv[idx];
		}
		if (cjInv[idx] > CJ_BAN && !cjBan[idx]) {
			cjBan[idx] = 1;
			++cjStat[S_BANNED];
		}
		if (!cjGranUsed(ewram, g)) {
			cirilo_jit_gran[idx] = 0;
		}
	}
}

/* ¿Esta instrucción termina el bloque (puede cambiar PC, el modo o el estado de ejecución)? Conservador: ante la duda, termina. */
static int cjTermArm(uint32_t op) {
	switch ((op >> 26) & 3) {
	case 0:
		if ((op & 0x0FFFFFF0) == 0x012FFF10) { /* BX */
			return 1;
		}
		if ((op & 0x0FB00000) == 0x03200000 || (op & 0x0FB000F0) == 0x01200000) { /* MSR */
			return 1;
		}
		if ((op & 0x0FC000F0) == 0x90 || (op & 0x0F8000F0) == 0x00800090) { /* MUL, MULL */
			return ((op >> 16) & 15) == 15 || ((op >> 12) & 15) == 15;
		}
		return ((op >> 12) & 15) == 15; /* proceso de datos, media palabra, SWP, MRS con Rd = PC */
	case 1:
		if (((op >> 25) & 7) == 3 && (op & 0x10)) { /* indefinida */
			return 1;
		}
		return (op & (1 << 20)) && ((op >> 12) & 15) == 15; /* LDR a PC */
	default:
		if (((op >> 25) & 7) == 4) { /* LDM/STM */
			return (op & (1 << 20)) && (op & 0x8000);
		}
		return 1; /* B, BL, SWI, coprocesador */
	}
}

static int cjTermThumb(uint32_t op) {
	switch (op >> 12) {
	case 0xD:
	case 0xE:
		return 1; /* Bcond, SWI, B, restos indefinidos */
	case 0xF:
		return op >= 0xF800; /* BL: el primer medio no termina, el segundo sí */
	case 4:
		if ((op & 0xFC00) == 0x4400) { /* ADD/CMP/MOV/BX con registros altos */
			return (op & 0xFF00) == 0x4700 || (op & 0x0087) == 0x0087;
		}
		return 0;
	case 0xB: {
		unsigned k = (op >> 8) & 15;
		if (k == 0xD) { /* POP {rlist, PC} */
			return 1;
		}
		return !(k == 0 || k == 4 || k == 5 || k == 0xC); /* BKPT e indefinidas */
	}
	default:
		return 0;
	}
}

/* ¿Compensa dejar este tramo nativo? k = instrucciones del tramo (si bk != 0, la última es el salto). */
static int cjWorth(const uint32_t* op, uint32_t k, int bk) {
	uint32_t body = k - (bk ? 1 : 0), mem = 0;
	for (uint32_t i = 0; i < body; ++i) {
		struct CJInfo ii;
		if (cjThumbInfo(op[i], &ii) && ii.kind == K_MEM) { /* carga o guardado (registro, inmediato, SP, literal), PUSH/POP/LDM/STM */
			++mem;
		}
	}
	int score = (int) (body - mem) * CJ_GAIN_PURE + (bk ? CJ_GAIN_BR : 0) - (int) mem * CJ_COST_MEM - CJ_COST_ENTRY;
	return score > 0;
}

/* Da código nativo a un bloque Thumb (con el filtro de ganancia si gate = 1). Devuelve 1 si lo ha emitido. Solo usa b->op y b->pc, así que sirve también para PROMOVER más tarde un bloque
 * que el filtro había dejado sin código (cjPromote). */
/* ¿Compensa dejar nativo un tramo ARM puro de k instrucciones? (mismo modelo de ganancia que Thumb, sin salto ni memoria) */
static int cjWorthArm(uint32_t k) {
	return (int) k * CJ_GAIN_PURE - CJ_COST_ENTRY > 0;
}
static int cjNativizeArm(struct CJBlock* b, int gate) {
	uint32_t* end;
	cjEmitBlk = b;
	uint32_t kk = cjEmitArmPrefix(cjCodeCur, &end, b->op, b->n, b->pc, CJ_MINK);
	cjEmitBlk = NULL;
	if (kk && gate && !cjWorthArm(kk)) {
		kk = 0;
	}
	if (!kk) {
		return 0;
	}
	cjStat[S_CWORDS] += (uint32_t) (end - cjCodeCur);
	cjStat[S_CINSTR] += kk;
	b->k = (uint16_t) kk;
	b->fr = b->nmem = b->nstep = b->p0 = b->tail = b->bk = 0;
	b->pre = (uint8_t) (kk >= 2 ? kk - 1 : 0);
	b->target = 0;
	cjCodeFlush(cjCodeCur, end);
	b->code = cjCodeCur;
	cjNatMark(b->pc, 0);
	cjCodeCur = end;
	++cjStat[S_NBLOCKS];
	return 1;
}

static int cjNativize(struct CJBlock* b, int gate) {
	const uint32_t n = b->n, A = b->pc;
	const uint32_t* op = b->op;
	if (!cjNativeOn || n < CJ_MINK || b->code) {
		return 0;
	}
	if (!b->thumb) {
		return cjNativizeArm(b, gate);
	}
	uint32_t* end;
	int bkind = 0;
	uint32_t tgt = 0;
	uint32_t ne = n;
	if (cjDiagB) { /* diagnóstico B: el tramo acaba antes de la primera carga o guardado */
		for (uint32_t i = 0; i < n; ++i) {
			struct CJInfo ii;
			if (cjThumbInfo(op[i], &ii) && ii.kind == K_MEM) {
				ne = i;
				break;
			}
		}
	}
	cjEmitBlk = b;
	uint32_t kk = ne >= CJ_MINK ? cjEmitThumbPrefix(cjCodeCur, &end, op, ne, A, CJ_MINK, &bkind, &tgt) : 0;
	cjEmitBlk = NULL;
	if (kk && gate && !cjWorth(op, kk, bkind)) {
		kk = 0; /* el código emitido queda sin confirmar: se sobrescribe con el siguiente */
	}
	if (!kk) {
		return 0;
	}
	cjStat[S_CWORDS] += (uint32_t) (end - cjCodeCur);
	cjStat[S_CINSTR] += kk;
	b->k = (uint16_t) kk;
	b->fr = (uint8_t) cjLastFramed;
	b->nmem = (uint8_t) (cjLastFramed ? cjLastNMem : 0);
	b->nstep = (uint8_t) (cjLastFramed ? cjLastNStep : 0);
	b->p0 = (uint8_t) cjLastP0;
	b->tail = (uint8_t) cjLastTail;
	b->pre = (uint8_t) (cjLastFramed ? (uint32_t) cjLastP0 : (kk >= 2 ? kk - 1 : 0));
	b->bk = (uint8_t) bkind;
	b->target = tgt;
	cjCodeFlush(cjCodeCur, end);
	b->code = cjCodeCur; /* lo último: nada ve un bloque con código a medio rellenar */
	cjNatMark(A, b->thumb);
	cjCodeCur = end;
	++cjStat[S_NBLOCKS];
	return 1;
}

static struct CJBlock* cjTranslate(struct ARMCore* cpu, uint32_t A, int thumb) {
	if (!thumb && !CJ_COPY_MODE && !cjArmDisp) {
		return NULL;
	}
	const uint32_t w = thumb ? 2 : 4;
	uint32_t r = A >> 24, off = 0, mask = 0;
	int ram = 0, ew = 0;
	if (r == 2) {
		ram = 1; ew = 1; mask = 0x3FFFF;
	} else if (r == 3) {
		ram = 1; mask = 0x7FFF;
	} else if (r >= 8 && r <= 0xD) {
		mask = 0x01FFFFFF;
	} else {
		return NULL;
	}
	if (A & (w - 1)) {
		return NULL;
	}
	off = A & mask;
	uint32_t avail = (((A | 0xFFF) + 1) - A) / w; /* instrucciones que quedan en la página de 4 KB */
	if (avail < 3) {
		return NULL;
	}
	uint32_t nmax = avail - 2 < CJ_MAXN ? avail - 2 : CJ_MAXN;
	if (!ram) {
		if (off + (nmax + 2) * w > cjRomSize) {
			if (off + 3 * w > cjRomSize) {
				return NULL;
			}
			nmax = (cjRomSize - off) / w - 2;
		}
	} else {
		uint32_t g0 = off >> 8, g1 = (off + (nmax + 2) * w - 1) >> 8, base = ew ? 128 : 0;
		for (uint32_t g = g0; g <= g1; ++g) {
			if (cjBan[base + g]) {
				return NULL;
			}
		}
	}
	uint32_t op[CJ_MAXN + 2];
	for (uint32_t i = 0; i < nmax + 2; ++i) {
		uint32_t v;
		uint32_t x = (A + i * w) & cpu->memory.activeMask;
		if (thumb) {
			LOAD_16(v, x, cpu->memory.activeRegion);
		} else {
			LOAD_32(v, x, cpu->memory.activeRegion);
		}
		op[i] = v;
	}
	if (op[0] != cpu->prefetch[0] || op[1] != cpu->prefetch[1]) {
		return NULL; /* la región activa no es la de A (o hay un truco raro): no se toca */
	}
	uint32_t n = nmax;
	for (uint32_t i = 0; i < nmax; ++i) {
		if (thumb ? cjTermThumb(op[i]) : cjTermArm(op[i])) {
			n = i + 1;
			break;
		}
	}
	uint32_t words = (sizeof(struct CJBlock) - sizeof(uint32_t) * (CJ_MAXN + 2) + 4 * (n + 2) + 3) / 4;
	words = (words + 1) & ~1u; /* cada bloque empieza alineado a 8 bytes */
	if (cjPoolUsed + words > CJ_POOL_WORDS || (ram && cjRamN >= CJ_RAMMAX) || (cjNativeOn && cjCodeCur + 512 > cjCode + CJ_CODE_WORDS)) {
		++cjStat[S_FLUSH];
		cjClear(1);
	}
	struct CJBlock* b = (struct CJBlock*) (cjPool + cjPoolUsed);
	cjPoolUsed += words;
	b->code = NULL;
	b->pre = 0;
	b->linked = 0;
	b->tried = 0;
	memset(b->lk, 0, sizeof(b->lk));
	b->nmem = b->nstep = 0;
	b->k = 0;
	b->bk = 0;
	b->target = 0;
	b->pc = A;
	b->n = (uint16_t) n;
	b->thumb = (uint8_t) thumb;
	b->valid = 1;
	b->ram = (uint8_t) ram;
	b->ew = (uint8_t) ew;
	b->lo = off;
	b->hi = off + (n + 2) * w - 1;
	memcpy(b->op, op, 4 * (n + 2));
	cjNativize(b, cjGate);
	if (ram && (CJ_COPY_MODE || b->code)) { /* app: un bloque sin código nativo no depende de que la copia esté al día, así que no se vigila */
		cjRam[cjRamN++] = b;
		uint32_t base = ew ? 128 : 0;
		for (uint32_t g = b->lo >> 8; g <= b->hi >> 8; ++g) {
			uint32_t idx = base + g;
			if (!cirilo_jit_gran[idx]) {
				cjGLo[idx] = b->lo;
				cjGHi[idx] = b->hi;
			} else {
				if (b->lo < cjGLo[idx]) {
					cjGLo[idx] = b->lo;
				}
				if (b->hi > cjGHi[idx]) {
					cjGHi[idx] = b->hi;
				}
			}
			cirilo_jit_gran[idx] = 1;
		}
	}
	uint32_t h = cjHash(A, thumb);
	for (struct CJBlock** pp = &cjTab[h]; *pp;) { /* tira de la cadena las copias viejas e invalidadas del mismo punto */
		if ((*pp)->pc == A && (*pp)->thumb == thumb && !(*pp)->valid) {
			*pp = (*pp)->next;
		} else {
			pp = &(*pp)->next;
		}
	}
	b->next = cjTab[h];
	cjTab[h] = b;
	++cjStat[S_CREATED];
	return b;
}

/* Un bloque = ARMStep/ThumbStep repetido, con la captación leída de la copia mientras siga válida. */
/* Estado del intérprete tras un tramo nativo. status: 1 = k instrucciones puras, 2 = salto condicional no tomado (k incluye el salto), 3 = salto tomado a target.
 * Se hace con ThumbWritePC del intérprete: región activa, recarga del pipeline y ciclos salen exactamente igual. */
static void cjNativeTail(struct ARMCore* cpu, uint32_t status, uint32_t pc0, uint32_t k, const uint32_t* op, uint32_t target) {
	if (status >= 0x100) { /* salida temprana tras m instrucciones */
		k = status & 0xFF;
	}
	if (status == 3) {
		int32_t c = 1 + cpu->memory.activeSeqCycles16; /* la instrucción de salto cuesta el prefetch de su región de origen */
		cpu->gprs[ARM_PC] = (int32_t) target;
		cpu->cycles += c + ThumbWritePC(cpu);
	} else {
		cpu->gprs[ARM_PC] = (int32_t) (pc0 + (k + 1) * WORD_SIZE_THUMB);
		cpu->prefetch[0] = op[k];
		cpu->prefetch[1] = op[k + 1];
	}
}

static void cjRunBlockArm(struct ARMCore* cpu, struct CJBlock* b, uint32_t i0) {
	uint32_t n = b->n, i;
	for (i = i0; i < n; ++i) {
		uint32_t opcode = cpu->prefetch[0];
		cpu->prefetch[0] = cpu->prefetch[1];
		cpu->gprs[ARM_PC] += WORD_SIZE_ARM;
		if (b->valid) {
			cpu->prefetch[1] = b->op[i + 2];
		} else {
			LOAD_32(cpu->prefetch[1], cpu->gprs[ARM_PC] & cpu->memory.activeMask, cpu->memory.activeRegion);
		}
		unsigned condition = opcode >> 28;
		int run = 1;
		if (condition != 0xE) {
			unsigned flags = cpu->cpsr.flags >> 4;
			if (!(conditionLut[condition] & (1 << flags))) {
				cpu->cycles += ARM_PREFETCH_CYCLES;
				run = 0;
			}
		}
		if (run) {
			ARMInstruction instruction = _armTable[((opcode >> 16) & 0xFF0) | ((opcode >> 4) & 0x00F)];
			instruction(cpu, opcode);
		}
		if (cpu->cycles >= cpu->nextEvent || !b->valid) {
			++i;
			break;
		}
		if ((uint32_t) cpu->gprs[ARM_PC] != b->pc + (i + 2) * WORD_SIZE_ARM) {
			if (i + 1 < n) {
				CJSTAT(S_MIDEXIT);
			}
			++i;
			break;
		}
	}
	cjStat[S_INSTR_BLOCK] += i - i0;
}

static void cjRunBlockThumb(struct ARMCore* cpu, struct CJBlock* b, uint32_t i0) {
	uint32_t n = b->n, i;
	for (i = i0; i < n; ++i) {
		uint32_t opcode = cpu->prefetch[0];
		cpu->prefetch[0] = cpu->prefetch[1];
		cpu->gprs[ARM_PC] += WORD_SIZE_THUMB;
		if (b->valid) {
			cpu->prefetch[1] = b->op[i + 2];
		} else {
			LOAD_16(cpu->prefetch[1], cpu->gprs[ARM_PC] & cpu->memory.activeMask, cpu->memory.activeRegion);
		}
		ThumbInstruction instruction = _thumbTable[opcode >> 6];
		instruction(cpu, opcode);
		if (cpu->cycles >= cpu->nextEvent || !b->valid) {
			++i;
			break;
		}
		if ((uint32_t) cpu->gprs[ARM_PC] != b->pc + (i + 2) * WORD_SIZE_THUMB) {
			if (i + 1 < n) {
				CJSTAT(S_MIDEXIT);
			}
			++i;
			break;
		}
	}
	cjStat[S_INSTR_BLOCK] += i - i0;
}

#define CJ_PLAIN_FUNCS(NAME, STEP) \
static inline uint32_t cjPlainHooked##NAME(struct ARMCore* cpu) { \
	uint32_t n = 0; \
	cirilo_hook_on = 1; \
	do { \
		STEP(cpu); \
		++n; \
	} while (cpu->cycles < cpu->nextEvent); \
	cirilo_hook_on = 0; \
	if (cirilo_hook_pend) { \
		cpu->nextEvent = cirilo_hook_real; \
	} \
	return n; \
} \
static inline uint32_t cjPlain##NAME(struct ARMCore* cpu, uint32_t nn) { \
	uint32_t m = nn; \
	do { \
		STEP(cpu); \
	} while (--m && cpu->cycles < cpu->nextEvent); \
	return nn - m; \
}
/* Un bucle por modo (el modo no cambia dentro de uno: BX y compañía ponen nextEvent = cycles y el bucle sale). */
/* Interpreta con el bucle apretado hasta el siguiente evento o hasta un salto tomado a un destino con código nativo o recién calentado. Devuelve las instrucciones ejecutadas. Quien llama ya comprobó
 * cycles < nextEvent, así que siempre avanza al menos una instrucción. cjPlain: nn instrucciones (o hasta el siguiente evento). */
CJ_PLAIN_FUNCS(Thumb, ThumbStep)
CJ_PLAIN_FUNCS(Arm, ARMStep)
static inline uint32_t cjPlainHooked(struct ARMCore* cpu, int thumb) {
	return thumb ? cjPlainHookedThumb(cpu) : cjPlainHookedArm(cpu);
}
static inline uint32_t cjPlain(struct ARMCore* cpu, uint32_t nn, int thumb) {
	return thumb ? cjPlainThumb(cpu, nn) : cjPlainArm(cpu, nn);
}
#ifdef CIRILO_JIT_PROF
/* Reparto del tiempo dentro del JIT (solo con el medidor de CPU del APK): ticks dentro del código nativo (con sus llamadas a C). Solo se mide ahí (unas centenas de entradas por
 * fotograma): medir el intérprete de los bloques sin nativo costaría más que lo medido. El resto de la CPU se obtiene por diferencia. */
static uint64_t cjProfNat;
CJ_EXPORT void cirilo_jit_times(uint64_t* out) {
	out[0] = cjProfNat;
	out[1] = 0;
}
#endif

static struct CJBlock* cjFind(uint32_t A) {
	struct CJBlock* b = cjTab[cjHash(A, 1)];
	while (b && !(b->pc == A && b->thumb == 1 && b->valid)) {
		b = b->next;
	}
	return b;
}
/* Enlaza el bloque x (que acaba de salir por el despachador con salto tomado, which = 0, o Bcond no tomado, which = 1) con su siguiente bloque si este ya es nativo y válido. El salto tomado solo se
 * encadena dentro de la misma región (así GBASetActiveRegion no cambia de región); el no tomado sigue en la misma página. Solo escribe datos: la pieza cjPieceHop los lee. */
static void cjLink(struct CJBlock* x, int which, uint32_t tgt) {
	struct CJLink* l = &x->lk[which];
	if (!cjPieceHop || l->tries >= CJ_LINK_TRIES) {
		return;
	}
	++l->tries;
	struct CJBlock* t = cjFind(tgt);
	if (t && !t->code && !t->tried) {
		/* El destino es un bloque que el filtro de ganancia dejó sin código. Con el encadenado ya no se paga la entrada desde C, y si no se promueve corta la cadena en cada vuelta (era el 4% de saltos directos).
		 * Solo ROM: la ROM no cambia y no hace falta vigilarla (los bloques de RAM sin código no se vigilan, su copia podría estar vieja). Sin vaciar nada: si no queda sitio, se deja. */
		t->tried = 1;
		if (cjGate && !t->ram && t->thumb && cjCodeCur + 512 <= cjCode + CJ_CODE_WORDS && cjNativize(t, 0)) {
			struct CJFast* fe = &cjFast[cjFh(t->pc)];
			if (fe->b == t) {
				fe->info = t->n; /* ya no es «sin código nativo» */
			}
		}
	}
	if (!t || !t->code || (which == 0 && (tgt >> 24) != (x->pc >> 24))) {
		return;
	}
	if (!x->linked) {
		if (cjLinkedN >= CJ_LINKMAX) {
			return;
		}
		cjLinked[cjLinkedN++] = x;
		x->linked = 1;
	}
	l->target = tgt;
	l->n = x->fr ? x->tail : x->k;
	l->t = t;
}

static void cjRun(struct ARMCore* cpu) {
#ifdef CIRILO_JIT_PROF
	uint64_t cjT0 = cirilo_tick();
#endif
	const int thumb = cpu->executionMode == MODE_THUMB;
	const uint32_t w = thumb ? WORD_SIZE_THUMB : WORD_SIZE_ARM;
	const int32_t cjC0 = cpu->cycles; /* para repartir los ciclos emulados entre ARM y Thumb (diagnóstico) */
	uint32_t aARM = 0;
	int first = 1; /* primera vuelta de esta llamada: se reanuda donde un evento cortó el bloque anterior, normalmente a mitad de un bloque: no se calienta (creaba un bloque nuevo en cada corte) */
	uint32_t aIB = 0, aPR = 0, aNR = 0, aNI = 0, aIT = 0; /* contadores locales: se suman a cjStat al salir (una escritura a memoria menos por bloque) */
	if (!thumb && !CJ_COPY_MODE && (!cjArmDisp || cjDiagProf)) { /* ARM fuera del despachador (diag 128) o perfil por región (diag 64): bucle original, sin consultar la caché */
		if (cjDiagProf) {
			uint32_t pr[4] = {0, 0, 0, 0}, pc[8] = {0}, pcond = 0, puniq = 0;
			while (cpu->cycles < cpu->nextEvent) {
				uint32_t rg = ((uint32_t) cpu->gprs[ARM_PC] - WORD_SIZE_ARM) >> 24;
				++pr[rg == 0 ? 0 : rg == 3 ? 1 : rg == 2 ? 2 : 3];
				{
					const uint32_t op = cpu->prefetch[0];
					if ((op >> 28) != 0xE) {
						++pcond;
					}
					uint32_t cl;
					switch ((op >> 25) & 7) {
					case 0:
					case 1:
						if ((op & 0x0FFFFFF0) == 0x012FFF10) {
							cl = 6; /* BX */
						} else if ((op & 0x0FC000F0) == 0x00000090 || (op & 0x0F8000F0) == 0x00800090) {
							cl = 1; /* MUL, MLA y las largas */
						} else if (((op >> 25) & 7) == 0 && (op & 0x90) == 0x90) {
							cl = 5; /* media palabra, con signo, SWP */
						} else {
							cl = 0; /* proceso de datos */
						}
						break;
					case 2:
					case 3:
						cl = 2;
						break;
					case 4:
						cl = 3;
						break;
					case 5:
						cl = 4;
						break;
					default:
						cl = 7;
						break;
					}
					++pc[cl];
					if (rg == 3) {
						const uint32_t ix = (((uint32_t) cpu->gprs[ARM_PC] - WORD_SIZE_ARM) & 0x7FFF) >> 2;
						if (!((cjIwSeen[ix >> 5] >> (ix & 31)) & 1)) {
							cjIwSeen[ix >> 5] |= 1u << (ix & 31);
							++puniq; /* el total no se acumula como el resto: cirilo_jit_stats lo da como valor absoluto */
						}
					}
				}
				ARMStep(cpu);
				++aARM;
			}
			cjStat[S_ARMBIOS] += pr[0];
			cjStat[S_ARMIW] += pr[1];
			cjStat[S_ARMEW] += pr[2];
			cjStat[S_ARMROM] += pr[3];
			for (int q = 0; q < 8; ++q) {
				cjStat[S_ARMC_DP + q] += pc[q];
			}
			cjStat[S_ARMCOND] += pcond;
		} else
		while (cpu->cycles < cpu->nextEvent) {
			ARMStep(cpu);
			++aARM;
		}
	} else while (cpu->cycles < cpu->nextEvent) {
		const int resume = first;
		const int fh = cirilo_hook_pend == 2; /* el destino acaba de calentarse (lo avisó el gancho de ThumbWritePC): se crea su bloque ya */
		cirilo_hook_pend = 0;
		first = 0;
		uint32_t A = (uint32_t) cpu->gprs[ARM_PC] - w;
		uint32_t key = A | (uint32_t) thumb;
		struct CJFast* fe = &cjFast[cjFh(A)];
		uint32_t h = 0;
		struct CJBlock* b;
		if (fe->key == key) {
			if (!CJ_COPY_MODE && (fe->info & 0x10000)) { /* bloque sin código nativo: solo agrupa, se ejecuta con el intérprete (exacto aunque la copia esté vieja) */
				aIB += cjHookMode ? cjPlainHooked(cpu, thumb) : cjPlain(cpu, fe->info & 0xFFFF, thumb);
				++aPR;
				continue;
			}
			b = fe->b;
		} else {
			h = cjHash(A, thumb);
			b = cjTab[h];
			while (b && !(b->pc == A && b->thumb == thumb && b->valid)) {
				b = b->next;
			}
			if (b) {
				fe->key = key;
				fe->info = b->n | (b->code ? 0 : 0x10000);
				fe->b = b;
			}
		}
		if (b) {
			if (!CJ_COPY_MODE && !b->code) {
				aIB += cjHookMode ? cjPlainHooked(cpu, thumb) : cjPlain(cpu, b->n, thumb);
				++aPR;
				continue;
			}
			if (b->op[0] == cpu->prefetch[0] && b->op[1] == cpu->prefetch[1]) {
				CJSTAT(S_BLOCKS);
				if (thumb) {
					uint32_t i0 = 0;
					if (b->code) { /* tramo nativo: si no hay margen hasta el siguiente evento no hace nada y devuelve 0 */
						cjCurBlock = b;
#ifdef CIRILO_JIT_PROF
						uint64_t cjTn0 = cirilo_tick();
#endif
						uint32_t st = cjRunNativeB(cpu, b);
#ifdef CIRILO_JIT_PROF
						cjProfNat += cirilo_tick() - cjTn0;
#endif
						if (st) {
							b = cjCurBlock; /* encadenado: el bloque que ha acabado puede no ser el que se llamó */
							uint32_t k = st >= 0x100 ? (st & 0xFF) : b->k;
							cjDiagSites[0] += b->nmem;
							cjDiagSites[1] += b->nstep;
							cjNativeTail(cpu, st, b->pc, k, b->op, b->target);
							if (st == 3 && (!b->lk[0].t || !b->lk[0].t->valid)) {
								cjLink(b, 0, b->target);
							} else if (st == 2 && (!b->lk[1].t || !b->lk[1].t->valid)) {
								cjLink(b, 1, b->pc + 2 * b->k);
							}
							++aNR;
							aNI += k;
							aIB += k;
							if (st >= 0x100) {
								CJSTAT(S_NEARLY);
								continue; /* salida temprana: el despachador sigue desde donde quedó */
							}
							if (st >= 2) {
								CJSTAT(st == 3 ? S_NTAKEN : S_NNOTTAKEN);
								continue; /* el salto es la última instrucción del bloque */
							}
							i0 = k;
						} else {
							CJSTAT(S_NBAIL);
						}
					}
					if (i0 < b->n && cpu->cycles < cpu->nextEvent) {
						if (CJ_COPY_MODE) {
							cjRunBlockThumb(cpu, b, i0);
						} else { /* lo que queda del bloque tras el tramo nativo, con el intérprete */
							aIB += cjPlain(cpu, b->n - i0, thumb);
						}
					}
				} else {
					uint32_t i0 = 0;
					if (b->code) { /* tramo nativo ARM puro: si no hay margen hasta el siguiente evento devuelve 0 sin hacer nada */
						cjCurBlock = b;
#ifdef CIRILO_JIT_TEST
						/* CJ_ARM_CHECK=1 (solo núcleo de pruebas): cada tramo nativo ARM se compara en vivo con el intérprete sobre una copia de la CPU (los tramos son puros: no tocan memoria) */
						static struct ARMCore shadow; static int sh_on = -1; static int sh_n;
						if (sh_on < 0) { sh_on = getenv("CJ_ARM_CHECK") != NULL; }
						int sh_run = 0;
						if (sh_on && (uint32_t) (cpu->nextEvent - cpu->cycles) > (b->k >= 2 ? b->k - 1 : 0) * ((uint32_t) cpu->memory.activeSeqCycles32 + 1)) {
							shadow = *cpu; sh_run = 1;
							for (uint32_t j = 0; j < b->k; ++j) {
								shadow.gprs[ARM_PC] = (int32_t) (b->pc + 4 * j + 8); shadow.prefetch[0] = b->op[j + 1]; shadow.prefetch[1] = b->op[j + 2];
								unsigned cd_ = b->op[j] >> 28;
								if (cd_ != 0xE && !(conditionLut[cd_] & (1 << (shadow.cpsr.flags >> 4)))) { shadow.cycles += 1 + shadow.memory.activeSeqCycles32; }
								else { _armTable[((b->op[j] >> 16) & 0xFF0) | ((b->op[j] >> 4) & 0xF)](&shadow, b->op[j]); }
							}
						}
#endif
						if (cjRunNativeArm(b->code, cpu, b->op, b->k)) {
							cjNativeTailArm(cpu, b->pc, b->k, b->op);
#ifdef CIRILO_JIT_TEST
							if (sh_run) {
								int bad_ = shadow.cpsr.packed != cpu->cpsr.packed || shadow.cycles != cpu->cycles;
								for (int r_ = 0; r_ < 15; ++r_) { bad_ |= shadow.gprs[r_] != cpu->gprs[r_]; }
								bad_ |= shadow.gprs[ARM_PC] != cpu->gprs[ARM_PC] || shadow.prefetch[0] != cpu->prefetch[0] || shadow.prefetch[1] != cpu->prefetch[1];
								if (bad_ && sh_n++ < 4) {
									fprintf(stderr, "SOMBRA pc=%08X k=%u cpsr %08X/%08X cyc %d/%d ops:", b->pc, b->k, shadow.cpsr.packed, cpu->cpsr.packed, shadow.cycles, cpu->cycles);
									for (uint32_t j = 0; j < b->k; ++j) { fprintf(stderr, " %08X", b->op[j]); }
									for (int r_ = 0; r_ < 15; ++r_) { if (shadow.gprs[r_] != cpu->gprs[r_]) { fprintf(stderr, " r%d %08X/%08X", r_, (uint32_t) shadow.gprs[r_], (uint32_t) cpu->gprs[r_]); } }
									fprintf(stderr, "\n");
								}
							}
#endif
							++aNR;
							aNI += b->k;
							aIB += b->k;
							i0 = b->k;
						} else {
							CJSTAT(S_NBAIL);
						}
					}
					if (i0 < b->n && cpu->cycles < cpu->nextEvent) {
						if (CJ_COPY_MODE) {
							cjRunBlockArm(cpu, b, i0);
						} else {
							aIB += cjPlain(cpu, b->n - i0, 0);
						}
					}
				}
				continue;
			}
			CJSTAT(S_PMISS);
		} else if ((fh || !(resume && !CJ_COPY_MODE)) && ((fh && !CJ_COPY_MODE) || ++cjHeat[h] >= CJ_HOT)) {
			cjHeat[h] = 0;
			if (cjTranslate(cpu, A, thumb)) {
				continue;
			}
			CJSTAT(S_REFUSED);
		}
		if (!CJ_COPY_MODE && cjHookMode) { /* sin bloque y aún frío: bucle apretado hasta que un salto tomado llegue a algo con código nativo o caliente */
			aIB += cjPlainHooked(cpu, thumb);
			continue;
		}
		++aIT;
		if (thumb) {
			ThumbStep(cpu);
		} else {
			ARMStep(cpu);
		}
	}
	cirilo_hook_pend = 0;
	cjStat[S_INSTR_BLOCK] += aIB;
	cjStat[S_PRUNS] += aPR;
	cjStat[S_NRUNS] += aNR;
	cjStat[S_NINSTR] += aNI;
	cjStat[S_INSTR_INTERP] += aIT;
	cjStat[S_PC] = (uint32_t) cpu->gprs[ARM_PC];
	if (!thumb) { /* con ARM por el despachador las instrucciones se cuentan en aIB/aIT, no en aARM */
		aARM += aIB + aIT;
	}
	cjStat[S_ARMN] += aARM;
	cjStat[thumb ? S_THCYC : S_ARMCYC] += (uint32_t) (cpu->cycles - cjC0);
#ifdef CIRILO_JIT_PROF /* medidor de CPU (cirilo_prof_patch.py) presente: mismo reparto que el bucle original */
	uint64_t cjT1 = cirilo_tick();
	cpu->irqh.processEvents(cpu);
	cirilo_prof_steps += cjT1 - cjT0;
	cirilo_prof_ev += cirilo_tick() - cjT1;
#else
	cpu->irqh.processEvents(cpu);
#endif
}

#ifdef CIRILO_JIT_TEST
/* AUTOPRUEBA UNITARIA del emisor (solo con -DCIRILO_JIT_TEST): secuencias aleatorias de 1-10 instrucciones Thumb traducibles (a veces acabadas en Bcond, B o BL), con registros y
 * banderines aleatorios (con valores límite), se ejecutan (a) con los manejadores del intérprete y (b) con el código nativo + cjNativeTail (lo mismo que hace el despachador);
 * deben coincidir registros, CPSR y ciclos (y, si hay salto tomado, PC, pipeline y región). También comprueba la decisión de «sin margen» y la de «salto tomado».
 * Devuelve el número de discrepancias (o -1 si este anfitrión no ejecuta código nativo); el informe de las primeras va en out. */
static uint32_t cjRng(uint32_t* s) {
	*s = *s * 1664525u + 1013904223u;
	uint32_t x = *s;
	x ^= x >> 15;
	x *= 0x2C1B3C6Du;
	x ^= x >> 12;
	return x;
}
static uint32_t cjRandOp(uint32_t* s) { /* instrucción pura o de memoria (nunca saltos) */
	for (;;) {
		uint32_t r = cjRng(s), r2 = cjRng(s), op;
		switch (r % 23) {
		case 0: case 1: op = ((r2 >> 16) % 3 << 11) | (r2 & 0x7FF); break;
		case 2: op = 0x1800 | (r2 & 0x7FF); break;
		case 3: case 4: op = 0x2000 | (r2 & 0x1FFF); break;
		case 5: case 6: case 7: op = 0x4000 | (r2 & 0x3FF); break;
		case 8: op = 0x4400 | ((r2 >> 8) % 3 << 8) | (r2 & 0xFF); break;
		case 9: op = 0xA000 | (r2 & 0xFFF); break;
		case 10: op = 0xB000 | (r2 & 0xFF); break;
		case 11: op = 0xF000 | (r2 & 0x7FF); break; /* BL, primera mitad */
		case 12: op = 0x4800 | (r2 & 0x7FF); break; /* LDR [PC, #imm] */
		case 13: case 14: op = 0x5000 | (r2 & 0xFFF); break; /* con registro */
		case 15: case 16: op = 0x6000 | (r2 & 0x1FFF); break; /* inmediato de 5 bits */
		case 17: op = 0x8000 | (r2 & 0xFFF); break; /* LDRH/STRH */
		case 18: op = 0x9000 | (r2 & 0xFFF); break; /* [SP, #imm] */
		case 19: op = 0xB400 | (r2 & 0x1FF); break; /* PUSH */
		case 20: op = 0xBC00 | (r2 & 0x1FF); break; /* POP */
		case 21: case 22: op = 0xC000 | (r2 & 0xFFF); break; /* STMIA, LDMIA */
		default: op = 0x4000 | (r2 & 0x3FF); break;
		}
		struct CJInfo info;
		if (cjThumbInfo(op, &info) && info.kind != K_BCOND && info.kind != K_B && info.kind != K_BL2) {
			return op;
		}
	}
}
static uint32_t cjRandAddr(uint32_t* s) { /* una dirección de alguna región (a veces desalineada) */
	uint32_t r = cjRng(s), o = cjRng(s);
	switch (r % 10) {
	case 0: case 1: case 2: return 0x03000000u + (o & 0x7FFF);
	case 3: case 4: return 0x02000000u + (o & 0x3FFFF);
	case 5: case 6: return 0x08000000u + (o & 0xFFFF);
	case 7: return 0x0A000000u + (o & 0xFFFF);
	case 8: return 0x04000000u + (o & 0x3FF);
	default: return (cjRng(s) & 0x0F000000u) | (o & 0xFFFF);
	}
}
static uint32_t cjRandVal(uint32_t* s) {
	uint32_t r = cjRng(s);
	if (r & 8) {
		return cjRandAddr(s);
	}
	switch (r & 7) {
	case 0: return 0;
	case 1: return 1;
	case 2: return 0xFFFFFFFFu;
	case 3: return 0x80000000u;
	case 4: return 0x7FFFFFFFu;
	case 5: return cjRng(s) & 0xFF;
	default: return cjRng(s);
	}
}
static uint16_t cjTestMem[0x8000]; /* memoria falsa de 64 KB: las recargas de pipeline de los saltos leen de aquí */
static void cjTestSetRegion(struct ARMCore* cpu, uint32_t address) { /* esperas que dependen de la dirección: así un error de orden se nota */
	cpu->memory.activeRegion = (uint32_t*) cjTestMem;
	cpu->memory.activeMask = 0xFFFE;
	cpu->memory.activeSeqCycles16 = 1 + ((address >> 24) & 3);
	cpu->memory.activeNonseqCycles16 = 3 + ((address >> 26) & 3);
}
/* Accesos a «E/S» y demás regiones del entorno de pruebas: el valor depende del bus abierto (prefetch), PC y reloj; a veces cambian las esperas o fuerzan la salida
 * (como WAITCNT o una escritura a E/S), para comprobar que el código nativo lo recarga y lo respeta. */
static struct CJBlock cjFakeBlk; /* hace de «bloque en ejecución»: ciertos guardados lo invalidan, como haría el aviso de código automodificable */
static uint32_t cjTestInvalAt;
static uint32_t cjTestA0;
static uint32_t cjTestIO(struct ARMCore* cpu, uint32_t addr, int* cc, uint32_t salt) {
	uint32_t v = (addr * 2654435761u) ^ cpu->prefetch[1] ^ (uint32_t) cpu->gprs[ARM_PC] ^ (uint32_t) cpu->cycles ^ salt;
	if (cc) {
		*cc += 1 + (int) ((addr >> 20) & 3) + (cpu->cycles & 1);
	}
	if (((addr >> 8) & 7) == 0) {
		cpu->memory.activeSeqCycles16 += 1;
	}
	if (((addr >> 8) & 7) == 1) {
		cpu->nextEvent = cpu->cycles;
	}
	return v;
}
static uint32_t cjTestLoad32(struct ARMCore* cpu, uint32_t a, int* cc) { return cjTestIO(cpu, a, cc, 32); }
static uint32_t cjTestLoad16(struct ARMCore* cpu, uint32_t a, int* cc) { return cjTestIO(cpu, a, cc, 16) & 0xFFFF; }
static uint32_t cjTestLoad8(struct ARMCore* cpu, uint32_t a, int* cc) { return cjTestIO(cpu, a, cc, 8) & 0xFF; }
static void cjTestStore32(struct ARMCore* cpu, uint32_t a, int32_t v, int* cc) { cpu->spsr.packed ^= (uint32_t) v * 31u + a; if (((a >> 12) & 7) == 2 && cjFakeBlk.valid) { cjFakeBlk.valid = 0; cjTestInvalAt = ((uint32_t) cpu->gprs[ARM_PC] - cjTestA0 - 4) / 2 + 1; } cjTestIO(cpu, a, cc, 33); }
static void cjTestStore16(struct ARMCore* cpu, uint32_t a, int16_t v, int* cc) { cpu->spsr.packed ^= (uint32_t) (uint16_t) v * 17u + a; if (((a >> 12) & 7) == 2 && cjFakeBlk.valid) { cjFakeBlk.valid = 0; cjTestInvalAt = ((uint32_t) cpu->gprs[ARM_PC] - cjTestA0 - 4) / 2 + 1; } cjTestIO(cpu, a, cc, 17); }
static void cjTestStore8(struct ARMCore* cpu, uint32_t a, int8_t v, int* cc) { cpu->spsr.packed ^= (uint32_t) (uint8_t) v * 7u + a; if (((a >> 12) & 7) == 2 && cjFakeBlk.valid) { cjFakeBlk.valid = 0; cjTestInvalAt = ((uint32_t) cpu->gprs[ARM_PC] - cjTestA0 - 4) / 2 + 1; } cjTestIO(cpu, a, cc, 9); }
static int32_t cjTestStall(struct ARMCore* cpu, int32_t wait) { return wait + (int32_t) ((cpu->cycles + cpu->gprs[ARM_PC]) & 3); }
#if __has_include(<mgba/internal/gba/cirilo_fast.h>)
#define CJ_FAKE_GBA 1
/* Copia literal de GBAMemoryStall (mgba/src/gba/memory.c): el núcleo de pruebas no incluye memory.c */
static int32_t GBAMemoryStall(struct ARMCore* cpu, int32_t wait) {
	struct GBA* gba = (struct GBA*) cpu->master;
	struct GBAMemory* memory = &gba->memory;
	if (memory->activeRegion < GBA_REGION_ROM0 || !memory->prefetch) {
		return wait;
	}
	int32_t previousLoads = 0;
	uint32_t dist = (memory->lastPrefetchedPc - cpu->gprs[ARM_PC]);
	int32_t maxLoads = 8;
	if (dist < 16) {
		previousLoads = dist >> 1;
		maxLoads -= previousLoads;
	}
	int32_t s = cpu->memory.activeSeqCycles16;
	int32_t stall = s + 1;
	int32_t loads = 1;
	while (stall < wait && loads < maxLoads) {
		stall += s;
		++loads;
	}
	memory->lastPrefetchedPc = cpu->gprs[ARM_PC] + WORD_SIZE_THUMB * (loads + previousLoads - 1);
	if (stall > wait) {
		wait = stall;
	}
	wait -= cpu->memory.activeNonseqCycles16 - s;
	wait -= stall;
	return wait;
}
static struct GBA cjGbaA, cjGbaB; /* los manejadores del intérprete y las funciones auxiliares miran cpu->master */
static uint32_t cjFakeIw[2][GBA_SIZE_IWRAM / 4], cjFakeEw[2][GBA_SIZE_EWRAM / 4], cjFakeRom[0x4000];
#endif
/* Multiples falsos: cada registro es un acceso suelto (los mismos que los de una palabra) y un par de ciclos; lo único que importa es que A y B los ejecuten igual */
static uint32_t cjTestLoadMultiple(struct ARMCore* cpu, uint32_t address, int mask, enum LSMDirection direction, int* cycleCounter) {
	int n = __builtin_popcount(mask);
	if (direction == LSM_DB) {
		address -= 4 * n;
	}
	uint32_t a = address;
	for (int r = 0; r < 16; ++r) {
		if (mask & (1 << r)) {
			cpu->gprs[r] = (int32_t) cpu->memory.load32(cpu, a, cycleCounter);
			a += 4;
		}
	}
	return direction == LSM_DB ? address : a;
}
static uint32_t cjTestStoreMultiple(struct ARMCore* cpu, uint32_t address, int mask, enum LSMDirection direction, int* cycleCounter) {
	int n = __builtin_popcount(mask);
	if (direction == LSM_DB) {
		address -= 4 * n;
	}
	uint32_t a = address;
	for (int r = 0; r < 16; ++r) {
		if (mask & (1 << r)) {
			cpu->memory.store32(cpu, a, cpu->gprs[r], cycleCounter);
			a += 4;
		}
	}
	return direction == LSM_DB ? address : a;
}
static void cjTestSetup(struct ARMCore* c, int which, uint32_t* rs) {
	c->memory.loadMultiple = cjTestLoadMultiple; c->memory.storeMultiple = cjTestStoreMultiple;
	c->memory.load32 = cjTestLoad32; c->memory.load16 = cjTestLoad16; c->memory.load8 = cjTestLoad8;
	c->memory.store32 = cjTestStore32; c->memory.store16 = cjTestStore16; c->memory.store8 = cjTestStore8;
	c->memory.stall = cjTestStall;
	c->memory.setActiveRegion = cjTestSetRegion;
#ifdef CJ_FAKE_GBA
	struct GBA* g = which ? &cjGbaB : &cjGbaA;
	c->master = (struct mCPUComponent*) g;
	g->memory.iwram = cjFakeIw[which];
	g->memory.wram = cjFakeEw[which];
	g->memory.rom = cjFakeRom;
	g->memory.romSize = sizeof(cjFakeRom);
	g->memory.activeRegion = (rs[0] & 1) ? GBA_REGION_ROM0 : GBA_REGION_IWRAM;
	g->memory.prefetch = (rs[0] >> 1) & 1;
	c->memory.stall = GBAMemoryStall; /* el modelo de prefetch REAL: las piezas de memoria lo reproducen en línea */
	for (int q = 0; q < 16; ++q) {
		g->memory.waitstatesNonseq32[q] = (char) (rs[1 + (q & 7)] % 7);
		g->memory.waitstatesNonseq16[q] = (char) (rs[1 + ((q + 3) & 7)] % 5);
	}
#else
	(void) which; (void) rs;
#endif
}
/* medida de tamaño: palabras que ocupa un tramo de n instrucciones aritméticas típicas (sin salto); kind 0 = solo aritmética, 1 = con una carga LDR [r1,#4] a mitad */
CJ_EXPORT int cirilo_jit_sizeprobe(uint32_t n, uint32_t kind) {
	static const uint32_t pat[6] = {0x1888 /* adds r0,r1,r2 */, 0x3B01 /* subs r3,#1 */, 0x0088 /* lsls r0,r1,#2 */, 0x4048 /* eors r0,r1 */, 0x2105 /* movs r1,#5 */, 0x1C08 /* adds r0,r1,#0 */};
	if (CJ_NATIVE_HOST == 0) {
		return -1;
	}
	cjCodeInit();
	if (!cjCode) {
		return -2;
	}
	uint32_t ops[CJ_MAXN + 2];
	if (n > CJ_MAXN) {
		n = CJ_MAXN;
	}
	for (uint32_t j = 0; j < n; ++j) {
		ops[j] = pat[j % 6];
	}
	if (kind == 1 && n >= 3) {
		ops[n / 2] = 0x6848; /* ldr r0,[r1,#4] */
	}
	ops[n] = ops[n + 1] = 0;
	cjCodeCur = cjCodeBase;
	uint32_t* end;
	int bkind = 0;
	uint32_t tgt = 0;
	uint32_t k = cjEmitThumbPrefix(cjCodeCur, &end, ops, n, 0x08000000u, 1, &bkind, &tgt);
	return k ? (int) (end - cjCodeCur) : 0;
}

CJ_EXPORT int cirilo_jit_selftest(uint32_t seed, uint32_t iters, char* out, uint32_t outn) {
	if (CJ_NATIVE_HOST == 0) {
		return -1;
	}
	cjCodeInit();
	if (!cjCode) {
		return -2;
	}
	int bad = 0, shown = 0;
	uint32_t rs = seed ? seed : 1;
	size_t used = 0;
	out[0] = 0;
	static struct ARMCore A, B;
	for (uint32_t i = 0; i < 0x8000; ++i) {
		cjTestMem[i] = (uint16_t) cjRng(&rs);
	}
#ifdef CJ_FAKE_GBA
	for (uint32_t i = 0; i < GBA_SIZE_IWRAM / 4; ++i) {
		cjFakeIw[0][i] = cjFakeIw[1][i] = cjRng(&rs);
	}
	for (uint32_t i = 0; i < GBA_SIZE_EWRAM / 4; ++i) {
		cjFakeEw[0][i] = cjFakeEw[1][i] = cjRng(&rs);
	}
	for (uint32_t i = 0; i < 0x4000; ++i) {
		cjFakeRom[i] = cjRng(&rs);
	}
#endif
	for (uint32_t it = 0; it < iters; ++it) {
		uint32_t n = 1 + cjRng(&rs) % 9, ops[CJ_MAXN + 2], A0 = 0x08000000u + (cjRng(&rs) & 0x7FF0) * 2;
		for (uint32_t j = 0; j < n; ++j) {
			ops[j] = cjRandOp(&rs);
		}
		int endType = cjRng(&rs) % 6; /* 0-2: sin salto; 3: Bcond; 4: B; 5: BL */
		if (endType == 3) {
			ops[n++] = 0xD000 | ((cjRng(&rs) % 14) << 8) | (cjRng(&rs) & 0xFF);
		} else if (endType == 4) {
			ops[n++] = 0xE000 | (cjRng(&rs) & 0x7FF);
		} else if (endType == 5) {
			ops[n++] = 0xF000 | (cjRng(&rs) & 0x7FF);
			ops[n++] = 0xF800 | (cjRng(&rs) & 0x7FF);
		}
		ops[n] = cjRng(&rs) & 0xFFFF;
		ops[n + 1] = cjRng(&rs) & 0xFFFF;
		uint32_t envRs[9];
		for (int q = 0; q < 9; ++q) {
			envRs[q] = cjRng(&rs);
		}
		memset(&A, 0, sizeof(A));
		cjTestSetup(&A, 0, envRs);
		cjTestSetRegion(&A, A0);
		for (int r = 0; r < 15; ++r) {
			A.gprs[r] = (int32_t) cjRandVal(&rs);
		}
		A.cpsr.packed = (cjRng(&rs) & 0xF0000000u) | 0x3F;
		A.memory.activeSeqCycles16 = cjRng(&rs) % 9;
		A.memory.activeNonseqCycles16 = A.memory.activeSeqCycles16 + cjRng(&rs) % 6;
		A.cycles = (int32_t) (cjRng(&rs) % 1000);
		uint32_t c = 1 + A.memory.activeSeqCycles16, margin;
		switch (cjRng(&rs) % 4) { /* a veces, justo al borde del margen */
		case 0: margin = (n - 1) * c; break;
		case 1: margin = (n - 1) * c + 1; break;
		case 2: margin = 1 + cjRng(&rs) % 60; break;
		default: margin = 1 + cjRng(&rs) % 5000; break;
		}
		if (margin == 0) {
			margin = 1;
		}
		A.nextEvent = A.cycles + (int32_t) margin;
		B = A;
		cjTestSetup(&B, 1, envRs);
		cjTestA0 = A0;
#ifdef CJ_FAKE_GBA
		{
			uint32_t lp = cjRng(&rs), near = A0 + 2 * (lp % 24);
			cjGbaA.memory.lastPrefetchedPc = cjGbaB.memory.lastPrefetchedPc = (lp >> 8) % 3 ? near : (lp * 2654435761u);
		}
#endif
		if (cjCodeCur + 1024 > cjCode + CJ_CODE_WORDS) {
			cjCodeCur = cjCodeBase;
		}
		uint32_t* end;
		int bkind = 0;
		uint32_t tgt = 0;
		cjEmitBlk = &cjFakeBlk;
		uint32_t k = cjEmitThumbPrefix(cjCodeCur, &end, ops, n, A0, 1, &bkind, &tgt);
		cjEmitBlk = NULL;
		uint32_t frT = (uint32_t) cjLastFramed, p0T = (uint32_t) cjLastP0, tailT = (uint32_t) cjLastTail;
		cjCodeFlush(cjCodeCur, end);
		/* referencia: el intérprete instrucción a instrucción, parando como él (cycles >= nextEvent); la invalidación del «bloque» no le afecta */
		cjFakeBlk.valid = 1;
		cjTestInvalAt = 0;
		cjCurBlock = NULL;
		uint32_t doneA = 0;
		int takenA = 0;
		for (uint32_t j = 0; j < n; ++j) {
			A.gprs[15] = (int32_t) (A0 + 2 * j + 4);
			A.prefetch[0] = ops[j + 1];
			A.prefetch[1] = ops[j + 2];
			uint32_t pf0 = A.prefetch[0];
			_thumbTable[ops[j] >> 6](&A, ops[j]);
			doneA = j + 1;
			if (j == n - 1 && endType >= 3) {
				takenA = A.gprs[15] != (int32_t) (A0 + 2 * j + 4) || A.prefetch[0] != pf0;
				if (endType == 3 && !takenA) {
					takenA = 0;
				}
			}
			if (A.cycles >= A.nextEvent) {
				break;
			}
		}
		/* candidato: código nativo + lo que haría el despachador, y el resto con el intérprete */
		cjFakeBlk.valid = 1;
		cjFakeBlk.pc = A0;
		memcpy(cjFakeBlk.op, ops, sizeof(cjFakeBlk.op));
		cjTestInvalAt = 0;
		cjCurBlock = &cjFakeBlk;
		uint32_t got = cjRunNative(cjCodeCur, &B, ops, k, frT, p0T, tailT);
		uint32_t invalNative = cjTestInvalAt; /* instrucción tras la que el código nativo vio invalidado su bloque (0 = ninguna) */
		cjCurBlock = NULL;
		uint32_t m = 0;
		if (k != n && k != 0) {
			got = 0xFFFF; /* el emisor no cubrió todo: no debería pasar con estas secuencias */
		}
		if (got == 0xFFFF) {
			m = 0;
		} else if (got >= 0x100) {
			m = got & 0xFF;
			cjNativeTail(&B, got, A0, m, ops, tgt);
		} else if (got) {
			m = k;
			cjNativeTail(&B, got, A0, k, ops, tgt);
		}
		int takenB = got == 3;
		if (got < 3 || got >= 0x100) { /* sigue el intérprete, como el despachador */
			for (uint32_t j = m; j < n && B.cycles < B.nextEvent; ++j) {
				B.gprs[15] = (int32_t) (A0 + 2 * j + 4);
				B.prefetch[0] = ops[j + 1];
				B.prefetch[1] = ops[j + 2];
				uint32_t pfb = B.prefetch[0];
				_thumbTable[ops[j] >> 6](&B, ops[j]);
				if (j == n - 1 && endType >= 3) {
					takenB = B.gprs[15] != (int32_t) (A0 + 2 * j + 4) || B.prefetch[0] != pfb; /* mismo criterio que en la referencia */
				}
			}
		}
		int ok = got != 0xFFFF;
		if (invalNative && (got < 0x100 || (got & 0xFF) != invalNative) && got != 0) {
			ok = 0; /* el bloque se invalidó durante el tramo nativo y este no salió justo después del guardado */
		}
		for (int r = 0; r < 15; ++r) {
			ok &= A.gprs[r] == B.gprs[r];
		}
		ok &= A.cpsr.packed == B.cpsr.packed && A.cycles == B.cycles && A.nextEvent == B.nextEvent && A.spsr.packed == B.spsr.packed;
		ok &= A.memory.activeSeqCycles16 == B.memory.activeSeqCycles16 && A.memory.activeNonseqCycles16 == B.memory.activeNonseqCycles16;
		if (doneA == n && endType >= 3 && takenA) {
			ok &= takenB && A.gprs[15] == B.gprs[15] && A.prefetch[0] == B.prefetch[0] && A.prefetch[1] == B.prefetch[1];
		}
		int memDiff = 0;
#ifdef CJ_FAKE_GBA
		ok &= cjGbaA.memory.lastPrefetchedPc == cjGbaB.memory.lastPrefetchedPc;
		if (memcmp(cjFakeIw[0], cjFakeIw[1], sizeof(cjFakeIw[0])) || memcmp(cjFakeEw[0], cjFakeEw[1], sizeof(cjFakeEw[0]))) {
			ok = 0;
			memDiff = 1;
			memcpy(cjFakeIw[1], cjFakeIw[0], sizeof(cjFakeIw[0]));
			memcpy(cjFakeEw[1], cjFakeEw[0], sizeof(cjFakeEw[0]));
		}
#endif
		if (!ok) {
			++bad;
			if (shown < 3 && used + 600 < outn) {
				++shown;
				used += snprintf(out + used, outn - used, "it=%u k=%u/%u fin=%d got=%X m=%u inval=%u doneA=%u tk=%d/%d memdiff=%d nonseq %u/%u pf %X,%X/%X,%X ops:", it, k, n, endType, got, m, invalNative, doneA, takenA, takenB, memDiff, A.memory.activeNonseqCycles16, B.memory.activeNonseqCycles16, A.prefetch[0], A.prefetch[1], B.prefetch[0], B.prefetch[1]);
				for (uint32_t j = 0; j < n; ++j) {
					used += snprintf(out + used, outn - used, " %04X", ops[j]);
				}
				used += snprintf(out + used, outn - used, " cpsr %08X/%08X cyc %d/%d next %d/%d spsr %08X/%08X seq %u/%u pc %08X/%08X", A.cpsr.packed, B.cpsr.packed, A.cycles, B.cycles, A.nextEvent, B.nextEvent,
				                 A.spsr.packed, B.spsr.packed, A.memory.activeSeqCycles16, B.memory.activeSeqCycles16, (uint32_t) A.gprs[15], (uint32_t) B.gprs[15]);
				for (int r = 0; r < 15; ++r) {
					if (A.gprs[r] != B.gprs[r]) {
						used += snprintf(out + used, outn - used, " r%d %08X/%08X", r, (uint32_t) A.gprs[r], (uint32_t) B.gprs[r]);
					}
				}
				used += snprintf(out + used, outn - used, "\n");
				if (shown == 1) { /* palabras emitidas (para desensamblarlas a mano: objdump -D -b binary -m aarch64) */
					used += snprintf(out + used, outn - used, "  codigo:");
					for (uint32_t* w = cjCodeCur; w < end && w < cjCodeCur + 160 && used + 16 < outn; ++w) {
						used += snprintf(out + used, outn - used, " %08X", *w);
					}
					used += snprintf(out + used, outn - used, "\n");
				}
			}
		}
	}
	return bad;
}

/* AUTOPRUEBA UNITARIA ARM (Fase 2): secuencias de 1-9 instrucciones de proceso de datos ARM (todas las operaciones, condiciones, formas de operando 2, con y sin S, PC como operando)
 * con registros y banderines aleatorios y valores límite; el intérprete (manejadores reales de _armTable, con la comprobación de condición de ARMStep) contra el código nativo + cjNativeTailArm
 * + el intérprete para el resto. Comparan registros, CPSR, ciclos, nextEvent, PC y pipeline. activeSeqCycles32 aleatorio: el coste es 1 + seq32 por instrucción, ejecutada o no. */
static uint32_t cjRandArmOp(uint32_t* s) {
	for (;;) {
		uint32_t r = cjRng(s), r2 = cjRng(s);
		uint32_t cond = (r & 3) ? 14 : (r >> 4) % 15;
		uint32_t w = (cond << 28) | (r2 & 0x03FFFFFFu);
		w &= ~(3u << 26);
		if (!(w & (1u << 25))) {
			w &= ~0x10u; /* sin desplazamiento por registro */
		}
		if (((r >> 8) & 7) == 0) { /* a veces PC como Rn / Rm / Rd */
			w |= (15u << (((r >> 12) % 3) * 4 + (((r >> 12) % 3) ? 8 : 0)));
		}
		struct CJArmInfo ii;
		if (cjArmInfo(w, &ii)) {
			return w;
		}
	}
}
CJ_EXPORT int cirilo_jit_selftest_arm(uint32_t seed, uint32_t iters, char* out, uint32_t outn) {
	if (CJ_NATIVE_HOST == 0) {
		return -1;
	}
	cjCodeInit();
	if (!cjCode) {
		return -2;
	}
	int bad = 0, shown = 0;
	uint32_t rs = seed ? seed : 1;
	size_t used = 0;
	out[0] = 0;
	static struct ARMCore A, B;
	for (uint32_t it = 0; it < iters; ++it) {
		uint32_t n = 1 + cjRng(&rs) % ((cjRng(&rs) & 3) ? 9 : CJ_MAXN), ops[CJ_MAXN + 2], A0 = (cjRng(&rs) & 1) ? 0x03000000u + (cjRng(&rs) & 0x7F00) * 4 : 0x08000000u + (cjRng(&rs) & 0x7FF0) * 4;
		for (uint32_t j = 0; j < n; ++j) {
			ops[j] = cjRandArmOp(&rs);
		}
		ops[n] = cjRng(&rs);
		ops[n + 1] = cjRng(&rs);
		memset(&A, 0, sizeof(A));
		for (int r = 0; r < 15; ++r) {
			A.gprs[r] = (int32_t) cjRandVal(&rs);
		}
		A.cpsr.packed = (cjRng(&rs) & 0xF0000000u) | 0x1F;
		A.shifterCarryOut = (int32_t) (cjRng(&rs) & 1);
		A.memory.activeSeqCycles32 = cjRng(&rs) % 9;
		A.cycles = (int32_t) (cjRng(&rs) % 1000);
		uint32_t c = 1 + A.memory.activeSeqCycles32, margin;
		switch (cjRng(&rs) % 4) {
		case 0: margin = (n - 1) * c; break;
		case 1: margin = (n - 1) * c + 1; break;
		case 2: margin = 1 + cjRng(&rs) % 60; break;
		default: margin = 1 + cjRng(&rs) % 5000; break;
		}
		if (margin == 0) {
			margin = 1;
		}
		A.nextEvent = A.cycles + (int32_t) margin;
		B = A;
		if (cjCodeCur + 1024 > cjCode + CJ_CODE_WORDS) {
			cjCodeCur = cjCodeBase;
		}
		uint32_t* end;
		cjEmitBlk = NULL;
		uint32_t k = cjEmitArmPrefix(cjCodeCur, &end, ops, n, A0, 1);
		cjCodeFlush(cjCodeCur, end);
#define CJ_ARM_REF(CPU, J) do { \
			(CPU)->gprs[ARM_PC] = (int32_t) (A0 + 4 * (J) + 8); \
			(CPU)->prefetch[0] = ops[(J) + 1]; \
			(CPU)->prefetch[1] = ops[(J) + 2]; \
			unsigned cd_ = ops[J] >> 28; \
			if (cd_ != 0xE && !(conditionLut[cd_] & (1 << ((CPU)->cpsr.flags >> 4)))) { \
				(CPU)->cycles += 1 + (CPU)->memory.activeSeqCycles32; \
			} else { \
				_armTable[((ops[J] >> 16) & 0xFF0) | ((ops[J] >> 4) & 0x00F)](CPU, ops[J]); \
			} \
		} while (0)
		for (uint32_t j = 0; j < n; ++j) {
			CJ_ARM_REF(&A, j);
			if (A.cycles >= A.nextEvent) {
				break;
			}
		}
		uint32_t m = 0;
		uint32_t got = k ? cjRunNativeArm(cjCodeCur, &B, ops, k) : 0;
		if (got) {
			m = k;
			cjNativeTailArm(&B, A0, k, ops);
		}
		for (uint32_t j = m; j < n && B.cycles < B.nextEvent; ++j) {
			CJ_ARM_REF(&B, j);
		}
		int ok = got < 2;
		for (int r = 0; r < 15; ++r) {
			ok &= A.gprs[r] == B.gprs[r];
		}
		ok &= A.cpsr.packed == B.cpsr.packed && A.cycles == B.cycles && A.nextEvent == B.nextEvent && A.spsr.packed == B.spsr.packed;
		ok &= A.gprs[ARM_PC] == B.gprs[ARM_PC] && A.prefetch[0] == B.prefetch[0] && A.prefetch[1] == B.prefetch[1];
		ok &= (A.shifterCarryOut & 1) == (B.shifterCarryOut & 1); /* lo lee MULS (C = shifterCarryOut): solo cuenta el bit bajo */
		if (!ok) {
			++bad;
			if (shown < 3 && used + 700 < outn) {
				++shown;
				used += snprintf(out + used, outn - used, "ARM it=%u k=%u/%u got=%X m=%u A0=%08X ops:", it, k, n, got, m, A0);
				for (uint32_t j = 0; j < n; ++j) {
					used += snprintf(out + used, outn - used, " %08X", ops[j]);
				}
				used += snprintf(out + used, outn - used, " cpsr %08X/%08X cyc %d/%d next %d/%d pc %08X/%08X", A.cpsr.packed, B.cpsr.packed, A.cycles, B.cycles, A.nextEvent, B.nextEvent, (uint32_t) A.gprs[15], (uint32_t) B.gprs[15]);
				for (int r = 0; r < 15; ++r) {
					if (A.gprs[r] != B.gprs[r]) {
						used += snprintf(out + used, outn - used, " r%d %08X/%08X", r, (uint32_t) A.gprs[r], (uint32_t) B.gprs[r]);
					}
				}
				used += snprintf(out + used, outn - used, "\n");
			}
		}
	}
	return bad;
}
#endif
