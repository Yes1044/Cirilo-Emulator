/* Cirilo: API de trucos con formato explícito para el núcleo libretro de mGBA.
 *
 * Por qué existe: retro_cheat_set() de mGBA llama siempre a mCheatAddLine(..., tipo 0 = autodetección) y mete todos los
 * códigos en un único mCheatSet, así que no se puede elegir GameShark / Action Replay / Code Breaker ni mezclar formatos.
 * mGBA sí tiene la API tipada (mCheatAddLine con GBA_CHEAT_*, GB_CHEAT_*; un mCheatSet por truco); aquí solo se expone.
 *
 * Uso: el workflow añade este archivo al final de mgba/src/platform/libretro/libretro.c (así comparte su `core` estático):
 *     cat cirilo/tools/cirilo_cheats.c >> cirilo/mgba/src/platform/libretro/libretro.c
 * Todas las funciones deben llamarse con el emulador parado (entre retro_run), nunca a la vez que retro_run.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mgba/core/cheats.h>
#include <mgba-util/string.h>
#ifdef M_CORE_GBA
#include <mgba/internal/gba/cheats.h>
#include "gba/cheats/gameshark.h"
#include "gba/cheats/parv3.h"
#endif
#ifdef M_CORE_GB
#include <mgba/internal/gb/cheats.h>
#endif

#define CIRILO_EXPORT __attribute__((visibility("default")))

/* Debe coincidir con CheatFormat (Cheats.kt). */
enum { CIRILO_AUTO = 0, CIRILO_GS12 = 1, CIRILO_GS3 = 2, CIRILO_CB = 3, CIRILO_RAW = 4 };
/* Códigos de error (negativos); -N con N>0 = «la línea N no es válida para el formato». */
#define CIRILO_ERR_NOCORE -9000
#define CIRILO_ERR_UNSUPPORTED -9001
#define CIRILO_ERR_EMPTY -9002

/* Siguiente línea no vacía de text (separadas por \n o \r), sin espacios en los extremos. */
static int cirilo_next_line(const char** p, char* out, size_t n) {
	const char* s = *p;
	while (*s) {
		while (*s == '\n' || *s == '\r') {
			++s;
		}
		const char* e = s;
		while (*e && *e != '\n' && *e != '\r') {
			++e;
		}
		const char* b = s;
		const char* f = e;
		while (b < f && (*b == ' ' || *b == '\t')) {
			++b;
		}
		while (f > b && (f[-1] == ' ' || f[-1] == '\t')) {
			--f;
		}
		s = e;
		if (f > b) {
			size_t l = (size_t) (f - b);
			if (l >= n) {
				l = n - 1;
			}
			memcpy(out, b, l);
			out[l] = '\0';
			*p = s;
			return 1;
		}
	}
	*p = s;
	return 0;
}

/* Construye un mCheatSet con todas las líneas de text. Devuelve NULL y *res<0 si algo falla. *ver = gsaVersion (GBA). */
static struct mCheatSet* cirilo_build(struct mCheatDevice* dev, int mode, const char* text, int* res, int* ver) {
	*res = 0;
	*ver = 0;
	struct mCheatSet* set = dev->createSet(dev, NULL);
	if (!set) {
		*res = CIRILO_ERR_NOCORE;
		return NULL;
	}
	enum mPlatform plat = core->platform(core);
	int type = 0;
	bool ok = true;
#ifdef M_CORE_GBA
	if (plat == mPLATFORM_GBA) {
		struct GBACheatSet* g = (struct GBACheatSet*) set;
		switch (mode) {
		case CIRILO_AUTO:
			type = GBA_CHEAT_AUTODETECT;
			break;
		case CIRILO_GS12:
			GBACheatSetGameSharkVersion(g, GBA_GS_GSAV1);
			type = GBA_CHEAT_GAMESHARK;
			break;
		case CIRILO_GS3:
			GBACheatSetGameSharkVersion(g, GBA_GS_PARV3);
			type = GBA_CHEAT_PRO_ACTION_REPLAY;
			break;
		case CIRILO_CB:
			type = GBA_CHEAT_CODEBREAKER;
			break;
		case CIRILO_RAW:
			type = GBA_CHEAT_VBA;
			break;
		default:
			ok = false;
		}
	} else
#endif
#ifdef M_CORE_GB
	if (plat == mPLATFORM_GB) {
		switch (mode) {
		case CIRILO_AUTO:
			type = GB_CHEAT_AUTODETECT;
			break;
		case CIRILO_GS12:
			type = GB_CHEAT_GAMESHARK;
			break;
		case CIRILO_RAW:
			type = GB_CHEAT_VBA;
			break;
		default: /* GameShark v3 y Code Breaker no existen para GB/GBC */
			ok = false;
		}
	} else
#endif
	{
		ok = false;
	}
	if (!ok) {
		mCheatSetDeinit(set);
		*res = CIRILO_ERR_UNSUPPORTED;
		return NULL;
	}

	char line[160];
	int n = 0;
	const char* p = text;
	while (cirilo_next_line(&p, line, sizeof(line))) {
		++n;
#ifdef M_CORE_GB
		/* GB_CHEAT_VBA de mGBA ("AAAA:VV") escribe el byte equivocado (usa el byte alto de la dirección como valor).
		 * Se convierte a GameShark 01VVLLHH, que mGBA interpreta bien. */
		if (plat == mPLATFORM_GB && mode == CIRILO_RAW) {
			uint16_t addr;
			uint8_t val;
			const char* l = hex16(line, &addr);
			if (!l || *l != ':' || !hex8(l + 1, &val) || l[3]) {
				mCheatSetDeinit(set);
				*res = -n;
				return NULL;
			}
			snprintf(line, sizeof(line), "01%02X%02X%02X", val, addr & 0xFF, addr >> 8);
			type = GB_CHEAT_GAMESHARK;
		}
#endif
		if (!mCheatAddLine(set, line, type)) {
			mCheatSetDeinit(set);
			*res = -n;
			return NULL;
		}
	}
	if (!n) {
		mCheatSetDeinit(set);
		*res = CIRILO_ERR_EMPTY;
		return NULL;
	}
#ifdef M_CORE_GBA
	if (plat == mPLATFORM_GBA) {
		*ver = ((struct GBACheatSet*) set)->gsaVersion;
	}
#endif
	*res = n;
	return set;
}

/* Comprueba un truco sin activarlo. info[0] = versión GameShark detectada (GBA: 0 ninguna, 1 GSA v1/v2, 2 GSA raw, 3 PAR v3, 4 PAR raw).
 * Devuelve nº de líneas aceptadas, o negativo (ver arriba). */
CIRILO_EXPORT int cirilo_cheat_check(int mode, const char* text, int* info) {
	if (!core) {
		return CIRILO_ERR_NOCORE;
	}
	int res, ver;
	struct mCheatSet* set = cirilo_build(core->cheatDevice(core), mode, text, &res, &ver);
	if (info) {
		info[0] = ver;
	}
	if (set) {
		mCheatSetDeinit(set);
	}
	return res;
}

/* Sustituye todos los trucos del núcleo por estos n (un mCheatSet por truco, con su formato). status[i] = líneas aceptadas o error.
 * Devuelve cuántos quedaron activos. No reinicia el juego. */
CIRILO_EXPORT int cirilo_cheat_apply(int n, const int* modes, const char** texts, int* status) {
	if (!core) {
		return CIRILO_ERR_NOCORE;
	}
	struct mCheatDevice* dev = core->cheatDevice(core);
	mCheatDeviceClear(dev);
	int added = 0;
	for (int i = 0; i < n; ++i) {
		int res, ver;
		struct mCheatSet* set = cirilo_build(dev, modes[i], texts[i], &res, &ver);
		if (status) {
			status[i] = res;
		}
		if (!set) {
			continue;
		}
		mCheatAddSet(dev, set);
		if (set->refresh) {
			set->refresh(set, dev);
		}
		++added;
	}
	return added;
}

/* Solo GBA: puntúa con las heurísticas propias de mGBA a qué variante de «XXXXXXXX XXXXXXXX» se parece la línea.
 * scores = {GameShark v1/v2 cifrado, Action Replay v3 cifrado, GameShark raw, Action Replay raw}. 0 = bien, <0 = no es un par de 8+8 hex. */
CIRILO_EXPORT int cirilo_cheat_probe(const char* line, int* scores) {
#ifdef M_CORE_GBA
	uint32_t a, b;
	const char* l = hex32(line, &a);
	if (!l) {
		return -1;
	}
	while (*l == ' ') {
		++l;
	}
	l = hex32(l, &b);
	if (!l || *l) {
		return -1;
	}
	uint32_t o1 = a, o2 = b;
	GBACheatDecryptGameShark(&o1, &o2, GBACheatGameSharkSeeds);
	scores[0] = GBACheatGameSharkProbability(o1, o2);
	o1 = a;
	o2 = b;
	GBACheatDecryptGameShark(&o1, &o2, GBACheatProActionReplaySeeds);
	scores[1] = GBACheatProActionReplayProbability(o1, o2);
	scores[2] = GBACheatGameSharkProbability(a, b);
	scores[3] = GBACheatProActionReplayProbability(a, b);
	return 0;
#else
	(void) line;
	(void) scores;
	return -1;
#endif
}
