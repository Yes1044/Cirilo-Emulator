
/* ---- Cirilo: medidor de CPU -----------------------------------------------------------------------------------------
 * Se añade al final de libretro.c (como cirilo_cheats.c). Los contadores los rellena tools/cirilo_prof_patch.py, que instrumenta
 * ARMRunLoop (instrucciones y eventos), el dibujo de línea del renderizador software y el evento de muestreo de audio.
 * Unidades: ticks del contador del sistema (cntvct_el0 en arm64; nanosegundos en 32 bits). Cada copia del núcleo tiene los suyos. */
#include <stdint.h>
#include <time.h>
uint64_t cirilo_prof_steps,cirilo_prof_ev,cirilo_prof_vid,cirilo_prof_aud;
static uint64_t cirilo_prof_last;
static uint64_t cirilo_prof_now(void){
#if defined(__aarch64__)
	uint64_t v;__asm__ volatile("mrs %0, cntvct_el0":"=r"(v));return v;
#else
	struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return (uint64_t)ts.tv_sec*1000000000ull+(uint64_t)ts.tv_nsec;
#endif
}
/* out[0]=ticks de reloj desde la última lectura (0 la primera vez), out[1]=instrucciones, out[2]=eventos (incluye vídeo y audio), out[3]=dibujo de vídeo, out[4]=audio de mGBA. Pone los contadores a cero. */
void cirilo_prof_take(uint64_t* out){
	uint64_t n=cirilo_prof_now();out[0]=cirilo_prof_last?n-cirilo_prof_last:0;cirilo_prof_last=n;
	out[1]=cirilo_prof_steps;out[2]=cirilo_prof_ev;out[3]=cirilo_prof_vid;out[4]=cirilo_prof_aud;
	cirilo_prof_steps=cirilo_prof_ev=cirilo_prof_vid=cirilo_prof_aud=0;}
