#!/usr/bin/env python3
"""Instrumenta mGBA para medir el reparto del tiempo (ver cirilo_prof.c). Uso: cirilo_prof_patch.py <carpeta mgba>
Todo o nada: si alguna sustitución no encaja exactamente una vez (otra versión de mGBA), no toca nada y sale con código 1."""
import sys,os
root=sys.argv[1]
HDR='''#include <stdint.h>
#include <time.h>
extern uint64_t cirilo_prof_steps,cirilo_prof_ev,cirilo_prof_vid,cirilo_prof_aud;
static inline uint64_t cirilo_tick(void){
#if defined(__aarch64__)
	uint64_t v;__asm__ volatile("mrs %0, cntvct_el0":"=r"(v));return v;
#else
	struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return (uint64_t)ts.tv_sec*1000000000ull+(uint64_t)ts.tv_nsec;
#endif
}
'''
RUNLOOP_OLD='''void ARMRunLoop(struct ARMCore* cpu) {
	if (cpu->executionMode == MODE_THUMB) {
		while (cpu->cycles < cpu->nextEvent) {
			ThumbStep(cpu);
		}
	} else {
		while (cpu->cycles < cpu->nextEvent) {
			ARMStep(cpu);
		}
	}
	cpu->irqh.processEvents(cpu);
}
'''
RUNLOOP_NEW='''void ARMRunLoop(struct ARMCore* cpu) {
	uint64_t cirilo_t0 = cirilo_tick();
	if (cpu->executionMode == MODE_THUMB) {
		while (cpu->cycles < cpu->nextEvent) {
			ThumbStep(cpu);
		}
	} else {
		while (cpu->cycles < cpu->nextEvent) {
			ARMStep(cpu);
		}
	}
	uint64_t cirilo_t1 = cirilo_tick();
	cpu->irqh.processEvents(cpu);
	cirilo_prof_steps += cirilo_t1 - cirilo_t0;
	cirilo_prof_ev += cirilo_tick() - cirilo_t1;
}
'''
SAMPLE_OLD='static void _sample(struct mTiming* timing, void* user, uint32_t cyclesLate) {\n'
SAMPLE_NEW='''static void _sample_inner(struct mTiming* timing, void* user, uint32_t cyclesLate);
static void _sample(struct mTiming* timing, void* user, uint32_t cyclesLate) {
	uint64_t cirilo_t = cirilo_tick();
	_sample_inner(timing, user, cyclesLate);
	cirilo_prof_aud += cirilo_tick() - cirilo_t;
}
static void _sample_inner(struct mTiming* timing, void* user, uint32_t cyclesLate) {
'''
DRAW_OLD='static void GBAVideoSoftwareRendererDrawScanline(struct GBAVideoRenderer* renderer, int y) {\n'
DRAW_NEW='''static void GBAVideoSoftwareRendererDrawScanlineInner(struct GBAVideoRenderer* renderer, int y);
static void GBAVideoSoftwareRendererDrawScanline(struct GBAVideoRenderer* renderer, int y) {
	uint64_t cirilo_t = cirilo_tick();
	GBAVideoSoftwareRendererDrawScanlineInner(renderer, y);
	cirilo_prof_vid += cirilo_tick() - cirilo_t;
}
static void GBAVideoSoftwareRendererDrawScanlineInner(struct GBAVideoRenderer* renderer, int y) {
'''
EDITS=[("src/arm/arm.c",[(RUNLOOP_OLD,RUNLOOP_NEW)]),
       ("src/gba/audio.c",[(SAMPLE_OLD,SAMPLE_NEW)]),
       ("src/gba/renderers/video-software.c",[(DRAW_OLD,DRAW_NEW)])]
out={}
for rel,subs in EDITS:
    p=os.path.join(root,rel)
    try: s=open(p,newline="").read()
    except OSError as e: print("ERROR: no se puede leer",p,e);sys.exit(1)
    for old,new in subs:
        if s.count(old)!=1: print("ERROR: %s: el fragmento esperado aparece %d veces (¿otra versión de mGBA?)"%(rel,s.count(old)));sys.exit(1)
        s=s.replace(old,new)
    out[p]=HDR+s
for p,s in out.items(): open(p,"w",newline="").write(s)
print("ok: medidor de CPU instrumentado en",len(out),"archivos")
