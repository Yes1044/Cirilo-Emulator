/* Cirilo JIT, FASE 2a: emisor arm64 (AArch64) para tramos de instrucciones Thumb «de ALU». Se incluye desde cirilo_jit_arm.inc (misma unidad que arm.c).
 *
 * Un bloque nativo ejecuta los k primeros instrucciones del bloque (todas puras: sin memoria, sin saltos, sin tocar PC) y devuelve 1; devuelve 0 SIN HABER HECHO NADA si no
 * queda margen hasta el siguiente evento (el despachador entonces ejecuta el bloque con comprobación instrucción a instrucción, que es exacta).
 * Convenio: x0 = struct ARMCore*. El tramo sin memoria no usa pila ni registros guardados (solo x0-x17). Los registros del invitado se cargan de cpu->gprs la primera vez que se usan, se
 * quedan en registros del anfitrión mientras dure el tramo (caché con desalojo LRU: caller-saved x1-x4, x13, x16, x17 sin memoria; callee-saved x23-x28 con memoria) y se vuelcan a
 * cpu->gprs solo los modificados, al salir y antes de cada llamada a C. PC y prefetch NO los toca el código nativo: los reconstruye el despachador (conoce las constantes del bloque).
 * Banderines: los N Z C V del anfitrión (arm64) son idénticos a los de ARM y mGBA calcula C y V con las fórmulas estándar, así que ADD/SUB/ADC/SBC/CMP/CMN/NEG usan adds/subs/
 * adcs/sbcs directamente. Las operaciones lógicas y los desplazamientos solo cambian N y Z (y C en los desplazamientos), conservando el resto: se hace con un análisis de vida
 * hacia atrás (los banderines que nadie lee antes de ser sobrescritos no se calculan). Al salir del bloque, todos los banderines se consideran vivos.
 * Cada instrucción cuesta 1 + activeSeqCycles16 ciclos (se lee una vez al entrar: no cambia dentro del tramo porque no hay accesos a memoria ni saltos). */
#include <stddef.h>

/* ------------------------------------------------------------ codificación A64 (32 bits, sf = 0 salvo que se indique) */
static inline uint32_t a_movz(int rd, uint32_t imm16, int hw) { return 0x52800000u | (hw << 21) | (imm16 << 5) | rd; }
static inline uint32_t a_movk(int rd, uint32_t imm16, int hw) { return 0x72800000u | (hw << 21) | (imm16 << 5) | rd; }
static inline uint32_t a_addsub_r(uint32_t base, int rd, int rn, int rm, int sh) { return base | (rm << 16) | (sh << 10) | (rn << 5) | rd; }
#define A_ADD 0x0B000000u
#define A_ADDS 0x2B000000u
#define A_SUB 0x4B000000u
#define A_SUBS 0x6B000000u
#define A_ADC 0x1A000000u
#define A_ADCS 0x3A000000u
#define A_SBC 0x5A000000u
#define A_SBCS 0x7A000000u
#define A_AND 0x0A000000u
#define A_ORR 0x2A000000u
#define A_EOR 0x4A000000u
#define A_ANDS 0x6A000000u
#define A_BIC 0x0A200000u
#define A_ORN 0x2A200000u
static inline uint32_t a_rrr(uint32_t base, int rd, int rn, int rm) { return base | (rm << 16) | (rn << 5) | rd; }
static inline uint32_t a_addi(int rd, int rn, uint32_t imm12) { return 0x11000000u | (imm12 << 10) | (rn << 5) | rd; }
static inline uint32_t a_addsi(int rd, int rn, uint32_t imm12) { return 0x31000000u | (imm12 << 10) | (rn << 5) | rd; }
static inline uint32_t a_subi(int rd, int rn, uint32_t imm12) { return 0x51000000u | (imm12 << 10) | (rn << 5) | rd; }
static inline uint32_t a_subsi(int rd, int rn, uint32_t imm12) { return 0x71000000u | (imm12 << 10) | (rn << 5) | rd; }
static inline uint32_t a_ubfm(int rd, int rn, int immr, int imms) { return 0x53000000u | (immr << 16) | (imms << 10) | (rn << 5) | rd; }
static inline uint32_t a_sbfm(int rd, int rn, int immr, int imms) { return 0x13000000u | (immr << 16) | (imms << 10) | (rn << 5) | rd; }
static inline uint32_t a_bfm(int rd, int rn, int immr, int imms) { return 0x33000000u | (immr << 16) | (imms << 10) | (rn << 5) | rd; }
static inline uint32_t a_lsli(int rd, int rn, int s) { return a_ubfm(rd, rn, (32 - s) & 31, 31 - s); }
static inline uint32_t a_lsri(int rd, int rn, int s) { return a_ubfm(rd, rn, s, 31); }
static inline uint32_t a_asri(int rd, int rn, int s) { return a_sbfm(rd, rn, s, 31); }
static inline uint32_t a_ubfx(int rd, int rn, int lsb, int w) { return a_ubfm(rd, rn, lsb, lsb + w - 1); }
static inline uint32_t a_bfi(int rd, int rn, int lsb, int w) { return a_bfm(rd, rn, (32 - lsb) & 31, w - 1); }
static inline uint32_t a_ldr(int rt, int rn, uint32_t off) { return 0xB9400000u | ((off >> 2) << 10) | (rn << 5) | rt; }
static inline uint32_t a_str(int rt, int rn, uint32_t off) { return 0xB9000000u | ((off >> 2) << 10) | (rn << 5) | rt; }
static inline uint32_t a_mrs_nzcv(int rt) { return 0xD53B4200u | rt; }
static inline uint32_t a_msr_nzcv(int rt) { return 0xD51B4200u | rt; }
static inline uint32_t a_mul(int rd, int rn, int rm) { return 0x1B007C00u | (rm << 16) | (rn << 5) | rd; }
static inline uint32_t a_bcond(int cond, int32_t words) { return 0x54000000u | (((uint32_t) words & 0x7FFFF) << 5) | cond; }
static inline uint32_t a_madd(int rd, int rn, int rm, int ra) { return 0x1B000000u | (rm << 16) | (ra << 10) | (rn << 5) | rd; }
static inline uint32_t a_mov64(int rd, int rm) { return 0xAA0003E0u | (rm << 16) | rd; } /* orr xd, xzr, xm */
static inline uint32_t a_add64i(int rd, int rn, uint32_t imm12) { return 0x91000000u | (imm12 << 10) | (rn << 5) | rd; } /* rn/rd = 31: sp */
static inline uint32_t a_sub64i(int rd, int rn, uint32_t imm12) { return 0xD1000000u | (imm12 << 10) | (rn << 5) | rd; }
static inline uint32_t a_stp64(int rt, int rt2, int rn, int32_t off) { return 0xA9000000u | ((((uint32_t) off >> 3) & 0x7F) << 15) | (rt2 << 10) | (rn << 5) | rt; }
static inline uint32_t a_ldp64(int rt, int rt2, int rn, int32_t off) { return 0xA9400000u | ((((uint32_t) off >> 3) & 0x7F) << 15) | (rt2 << 10) | (rn << 5) | rt; }
static inline uint32_t a_str64(int rt, int rn, uint32_t off) { return 0xF9000000u | ((off >> 3) << 10) | (rn << 5) | rt; }
static inline uint32_t a_ldr64(int rt, int rn, uint32_t off) { return 0xF9400000u | ((off >> 3) << 10) | (rn << 5) | rt; }
static inline uint32_t a_br(int rn) { return 0xD61F0000u | (rn << 5); }
static inline uint32_t a_bl(int32_t words) { return 0x94000000u | ((uint32_t) words & 0x3FFFFFF); }
static inline uint32_t a_blr(int rn) { return 0xD63F0000u | (rn << 5); }
static inline uint32_t a_cbnz(int rt, int32_t words) { return 0x35000000u | (((uint32_t) words & 0x7FFFF) << 5) | rt; } /* cbnz wt */
static inline uint32_t a_b(int32_t words) { return 0x14000000u | ((uint32_t) words & 0x3FFFFFF); }
#define A_RET 0xD65F03C0u
/* tbnz x0, #32, destino (desplazamiento en palabras) */
static inline uint32_t a_tbnz_x0_32(int32_t off) { return 0xB7000000u | (((uint32_t) off & 0x3FFFu) << 5); }
/* csel wd, wn, wm, cond */
static inline uint32_t a_csel(int rd, int rn, int rm, int cond) { return 0x1A800000u | ((uint32_t) rm << 16) | ((uint32_t) cond << 12) | ((uint32_t) rn << 5) | (uint32_t) rd; }
#define A_LS 9 /* b.ls: menor o igual sin signo */
/* AND/ORR con inmediato lógico de 32 bits para una sola tanda de unos contigua (bit más bajo p, ancho w < 32) */
static inline uint32_t a_logi(uint32_t base, int rd, int rn, int p, int w) { return base | (((32 - p) & 31) << 16) | ((w - 1) << 10) | (rn << 5) | rd; }
#define A_ANDI 0x12000000u

/* ------------------------------------------------------------ emisor */
struct CJEm {
	uint32_t* p;
	int base; /* registro del anfitrión que contiene el puntero a ARMCore: x0 sin marco, x19 con marco */
	int pool[8], npool; /* registros del anfitrión que hacen de caché de registros del invitado */
	int hr[16]; /* registro del anfitrión que guarda el registro g del invitado (-1 = ninguno) */
	int hg[32]; /* registro del invitado que guarda el registro h del anfitrión (-1 = libre) */
	uint32_t dirty, lock; /* dirty: invitados modificados y aún no volcados; lock: invitados en uso por la instrucción actual (no se desalojan) */
	uint32_t age[16], tick;
	int fail; /* se agotó la caché (no debería pasar: el reparto de registros se dimensiona con los que usa el tramo): el tramo se descarta */
};
static void cjEmInit(struct CJEm* e, uint32_t* code, int base, const int* pool, int npool) {
	e->p = code; e->base = base; e->npool = npool;
	for (int q = 0; q < npool; ++q) {
		e->pool[q] = pool[q];
	}
	for (int g = 0; g < 16; ++g) {
		e->hr[g] = -1; e->age[g] = 0;
	}
	for (int h = 0; h < 32; ++h) {
		e->hg[h] = -1;
	}
	e->dirty = e->lock = e->tick = 0; e->fail = 0;
}
static inline void cjE(struct CJEm* e, uint32_t w) {
	*e->p++ = w;
}
static void cjConst(struct CJEm* e, int rd, uint32_t v) {
	cjE(e, a_movz(rd, v & 0xFFFF, 0));
	if (v >> 16) {
		cjE(e, a_movk(rd, v >> 16, 1));
	}
}

enum {
	K_LSLI, K_LSRI, K_ASRI, K_ADD3, K_SUB3, K_ADD1, K_SUB1, K_MOVI, K_CMPI, K_ADDI, K_SUBI,
	K_AND, K_EOR, K_ADC, K_SBC, K_TST, K_NEG, K_CMP2, K_CMN, K_ORR, K_BIC, K_MVN,
	K_ADD4, K_CMP3, K_MOV3, K_ADD5, K_ADD6, K_ADD7, K_SUB4,
	K_MEM, /* cargas y guardados Thumb: llaman a una función auxiliar de C */
	K_BCOND, K_B, K_BL1, K_BL2 /* saltos: BL1 es una instrucción pura (fija LR); los demás terminan el bloque y solo se aceptan con destino constante */
};
enum { H_LD32, H_LD16, H_LD8, H_LDSB, H_LDSH, H_ST32, H_ST16, H_ST8, H_COUNT }; /* índices de la tabla de funciones auxiliares */
#define F_N 8
#define F_Z 4
#define F_C 2
#define F_V 1
struct CJInfo {
	uint8_t kind, rd, rn, rm; /* rm: registro fuente 2 (o 15 = PC en las formas altas) */
	uint32_t imm;
	uint8_t kill, use; /* banderines que escribe / que lee */
	uint8_t aux, helper, store; /* memoria: modo de dirección (0 = rn + imm, 1 = rn + rm, 2 = SP + imm, 3 = literal en PC), función auxiliar, ¿es un guardado? */
};

/* Clasifica un opcode Thumb. Devuelve 0 si no se traduce a nativo. */
static int cjThumbInfo(uint32_t op, struct CJInfo* i) {
	i->kill = i->use = 0; i->rm = 0; i->imm = 0;
	if (op < 0x1800) { /* desplazamientos con inmediato */
		unsigned s = (op >> 6) & 31;
		i->kind = (op >> 11) == 0 ? K_LSLI : (op >> 11) == 1 ? K_LSRI : K_ASRI;
		i->rd = op & 7; i->rn = (op >> 3) & 7; i->imm = s;
		i->kill = (i->kind == K_LSLI && s == 0) ? (F_N | F_Z) : (F_N | F_Z | F_C);
		return 1;
	}
	if (op < 0x2000) { /* sumar/restar con registro o inmediato de 3 bits */
		i->rd = op & 7; i->rn = (op >> 3) & 7; i->kill = F_N | F_Z | F_C | F_V;
		switch ((op >> 9) & 3) {
		case 0: i->kind = K_ADD3; i->rm = (op >> 6) & 7; break;
		case 1: i->kind = K_SUB3; i->rm = (op >> 6) & 7; break;
		case 2: i->kind = K_ADD1; i->imm = (op >> 6) & 7; break;
		default: i->kind = K_SUB1; i->imm = (op >> 6) & 7; break;
		}
		return 1;
	}
	if (op < 0x4000) { /* mov/cmp/add/sub con inmediato de 8 bits */
		static const uint8_t K[4] = {K_MOVI, K_CMPI, K_ADDI, K_SUBI};
		i->kind = K[(op >> 11) & 3]; i->rd = (op >> 8) & 7; i->imm = op & 0xFF;
		i->kill = i->kind == K_MOVI ? (F_N | F_Z) : (F_N | F_Z | F_C | F_V);
		return 1;
	}
	if (op < 0x4400) { /* ALU con registros */
		i->rd = op & 7; i->rn = (op >> 3) & 7;
		switch ((op >> 6) & 15) {
		case 0: i->kind = K_AND; i->kill = F_N | F_Z; return 1;
		case 1: i->kind = K_EOR; i->kill = F_N | F_Z; return 1;
		case 5: i->kind = K_ADC; i->kill = F_N | F_Z | F_C | F_V; i->use = F_C; return 1;
		case 6: i->kind = K_SBC; i->kill = F_N | F_Z | F_C | F_V; i->use = F_C; return 1;
		case 8: i->kind = K_TST; i->kill = F_N | F_Z; return 1;
		case 9: i->kind = K_NEG; i->kill = F_N | F_Z | F_C | F_V; return 1;
		case 10: i->kind = K_CMP2; i->kill = F_N | F_Z | F_C | F_V; return 1;
		case 11: i->kind = K_CMN; i->kill = F_N | F_Z | F_C | F_V; return 1;
		case 12: i->kind = K_ORR; i->kill = F_N | F_Z; return 1;
		case 14: i->kind = K_BIC; i->kill = F_N | F_Z; return 1;
		case 15: i->kind = K_MVN; i->kill = F_N | F_Z; return 1;
		default: return 0; /* LSL/LSR/ASR/ROR por registro (+1 ciclo) y MUL (ciclos según el valor) */
		}
	}
	if (op < 0x4800) { /* registros altos */
		unsigned o = (op >> 8) & 3;
		i->rd = (op & 7) | ((op >> 4) & 8);
		i->rm = ((op >> 3) & 7) | ((op >> 3) & 8);
		if (o == 3 || i->rd == 15) {
			return 0;
		}
		i->kind = o == 0 ? K_ADD4 : o == 1 ? K_CMP3 : K_MOV3;
		i->kill = o == 1 ? (F_N | F_Z | F_C | F_V) : 0;
		return 1;
	}
	if (op >= 0x4800 && op < 0xA000) { /* cargas y guardados */
		i->kind = K_MEM;
		i->use = F_N | F_Z | F_C | F_V; /* tras cada acceso puede haber una salida temprana: ahí todos los banderines deben estar al día */
		if (op < 0x5000) { /* LDR rd, [PC, #imm] */
			i->rd = (op >> 8) & 7; i->imm = (op & 0xFF) << 2; i->aux = 3; i->helper = H_LD32; i->store = 0;
		} else if (op < 0x6000) { /* con registro */
			static const uint8_t H[8] = {H_ST32, H_ST16, H_ST8, H_LDSB, H_LD32, H_LD16, H_LD8, H_LDSH};
			unsigned f = (op >> 9) & 7;
			i->rd = op & 7; i->rn = (op >> 3) & 7; i->rm = (op >> 6) & 7; i->aux = 1; i->helper = H[f]; i->store = f < 3;
		} else if (op < 0x8000) { /* LDR/STR/LDRB/STRB con inmediato de 5 bits */
			static const uint8_t H[4] = {H_ST32, H_LD32, H_ST8, H_LD8};
			unsigned f = (op >> 11) & 3, imm5 = (op >> 6) & 31;
			i->rd = op & 7; i->rn = (op >> 3) & 7; i->imm = (f < 2) ? imm5 * 4 : imm5; i->aux = 0; i->helper = H[f]; i->store = !(f & 1);
		} else if (op < 0x9000) { /* LDRH/STRH con inmediato */
			i->rd = op & 7; i->rn = (op >> 3) & 7; i->imm = ((op >> 6) & 31) * 2; i->aux = 0; i->helper = (op & 0x0800) ? H_LD16 : H_ST16; i->store = !(op & 0x0800);
		} else { /* [SP, #imm] */
			i->rd = (op >> 8) & 7; i->imm = (op & 0xFF) << 2; i->aux = 2; i->helper = (op & 0x0800) ? H_LD32 : H_ST32; i->store = !(op & 0x0800);
		}
		return 1;
	}
	if (op >= 0xA000 && op < 0xB000) { /* ADD rd, PC/SP, #imm */
		i->kind = (op & 0x0800) ? K_ADD6 : K_ADD5; i->rd = (op >> 8) & 7; i->imm = (op & 0xFF) << 2;
		return 1;
	}
	if (op >= 0xB000 && op < 0xB100) { /* ADD/SUB SP, #imm */
		i->kind = (op & 0x80) ? K_SUB4 : K_ADD7; i->imm = (op & 0x7F) << 2;
		return 1;
	}
	if (op >= 0xD000 && op < 0xDE00) { /* Bcond (las condiciones 14 y 15 son indefinida y SWI) */
		static const uint8_t M[14] = {F_Z, F_Z, F_C, F_C, F_N, F_N, F_V, F_V, F_C | F_Z, F_C | F_Z, F_N | F_V, F_N | F_V, F_Z | F_N | F_V, F_Z | F_N | F_V};
		i->kind = K_BCOND; i->rm = (op >> 8) & 15; i->use = M[i->rm];
		return 1;
	}
	if (op >= 0xE000 && op < 0xE800) {
		i->kind = K_B;
		return 1;
	}
	if (op >= 0xF000) {
		i->kind = op < 0xF800 ? K_BL1 : K_BL2; i->imm = op & 0x7FF;
		return 1;
	}
	return 0;
}

/* r = registro del invitado, w = registro del anfitrión */
static inline void cjLd(struct CJEm* e, int w, int g) {
	cjE(e, a_ldr(w, e->base, offsetof(struct ARMCore, gprs) + 4 * g));
}
static inline void cjSt(struct CJEm* e, int w, int g) {
	cjE(e, a_str(w, e->base, offsetof(struct ARMCore, gprs) + 4 * g));
}
/* Devuelve el registro del anfitrión que guarda el registro g del invitado; load = traerlo de cpu->gprs si aún no está. Desaloja el menos usado recientemente (volcándolo si está sucio). */
static int cjAlloc(struct CJEm* e, int g, int load) {
	if (e->hr[g] >= 0) {
		e->age[g] = ++e->tick; e->lock |= 1u << g;
		return e->hr[g];
	}
	int h = -1;
	for (int q = 0; q < e->npool; ++q) {
		if (e->hg[e->pool[q]] < 0) {
			h = e->pool[q];
			break;
		}
	}
	if (h < 0) {
		uint32_t best = ~0u;
		for (int q = 0; q < e->npool; ++q) {
			int hh = e->pool[q], gg = e->hg[hh];
			if (!((e->lock >> gg) & 1) && e->age[gg] < best) {
				best = e->age[gg]; h = hh;
			}
		}
		if (h < 0) {
			e->fail = 1;
			return e->pool[0];
		}
		int gg = e->hg[h];
		if ((e->dirty >> gg) & 1) {
			cjSt(e, h, gg);
			e->dirty &= ~(1u << gg);
		}
		e->hr[gg] = -1; e->hg[h] = -1;
	}
	e->hr[g] = h; e->hg[h] = g; e->age[g] = ++e->tick; e->lock |= 1u << g;
	if (load) {
		cjLd(e, h, g);
	}
	return h;
}
static inline int cjUse(struct CJEm* e, int g) { return cjAlloc(e, g, 1); } /* para leerlo */
static inline int cjDef(struct CJEm* e, int g) { int h = cjAlloc(e, g, 0); e->dirty |= 1u << g; return h; } /* para escribirlo entero */
/* vuelca a cpu->gprs los registros modificados (los str no tocan los banderines); la caché sigue válida */
static void cjFlush(struct CJEm* e) {
	for (int g = 0; g < 16; ++g) {
		if ((e->dirty >> g) & 1) {
			cjSt(e, e->hr[g], g);
		}
	}
	e->dirty = 0;
}
/* Actualiza N/Z (y conserva el resto de lo que haga falta) tras un resultado en wres, con C nuevo opcional en w11 (hasC)
 * need = banderines vivos tras la instrucción; keep = banderines de ENTRADA que esta instrucción deja intactos (conservarlos si están vivos) */
static void cjFlagsNZ(struct CJEm* e, int wres, unsigned need, unsigned keepMask /* F_C|F_V que se conservan */, int hasC) {
	unsigned preserve = need & keepMask;
	unsigned wantNew = need & (F_N | F_Z | (hasC ? F_C : 0));
	if (!wantNew) {
		return; /* nadie lee lo que esta instrucción cambiaría y no se ha tocado ningún banderín */
	}
	uint32_t keepBits = (preserve & F_C ? 0x20000000u : 0) | (preserve & F_V ? 0x10000000u : 0);
	if (keepBits) {
		cjE(e, a_mrs_nzcv(9));
	}
	cjE(e, a_rrr(A_ANDS, 31, wres, wres)); /* tst wres, wres: N y Z; C y V a 0 */
	if (keepBits || (hasC && (need & F_C))) {
		cjE(e, a_mrs_nzcv(10));
		if (keepBits) {
			cjE(e, a_logi(A_ANDI, 9, 9, keepBits == 0x30000000u ? 28 : (keepBits == 0x20000000u ? 29 : 28), keepBits == 0x30000000u ? 2 : 1));
			cjE(e, a_rrr(A_ORR, 10, 10, 9));
		}
		if (hasC && (need & F_C)) {
			cjE(e, a_addsub_r(A_ORR, 10, 10, 11, 29) | 0); /* orr w10, w10, w11, lsl #29 */
		}
		cjE(e, a_msr_nzcv(10));
	}
}

/* Emite una instrucción. A = dirección de la instrucción; need = banderines vivos tras ella.
 * Los operandos se piden a la caché de registros (cjUse para leer, cjDef para escribir); el destino puede ser el propio registro fuente, así que el carry de los desplazamientos
 * se calcula ANTES que el resultado. w14 es el único temporal (w9-w11 los usa cjFlagsNZ). */
static void cjEmitOne(struct CJEm* e, const struct CJInfo* i, uint32_t A, unsigned need) {
	const int S0 = 14;
	uint32_t pcv = A + 4; /* valor que lee una instrucción Thumb al usar PC */
	e->lock = 0;
	switch (i->kind) {
	case K_LSLI:
	case K_LSRI:
	case K_ASRI: {
		unsigned s = i->imm;
		int rn = cjUse(e, i->rn);
		int hasC = 0;
		if (i->kind == K_LSLI) {
			if (s && (need & F_C)) {
				cjE(e, a_ubfx(11, rn, 32 - s, 1)); hasC = 1;
			}
		} else if (s == 0) { /* #0 significa #32 */
			if (need & F_C) {
				cjE(e, a_lsri(11, rn, 31)); hasC = 1;
			}
		} else if (need & F_C) {
			cjE(e, a_ubfx(11, rn, s - 1, 1)); hasC = 1;
		}
		int rd = cjDef(e, i->rd);
		if (i->kind == K_LSLI) {
			if (s) {
				cjE(e, a_lsli(rd, rn, s));
			} else if (rd != rn) {
				cjE(e, a_rrr(A_ORR, rd, 31, rn)); /* mov */
			}
		} else if (s == 0) {
			cjE(e, i->kind == K_LSRI ? a_movz(rd, 0, 0) : a_asri(rd, rn, 31));
		} else {
			cjE(e, i->kind == K_LSRI ? a_lsri(rd, rn, s) : a_asri(rd, rn, s));
		}
		/* LSL #0 conserva C; los demás lo reescriben */
		cjFlagsNZ(e, rd, need, (i->kind == K_LSLI && s == 0) ? (F_C | F_V) : F_V, hasC);
		return;
	}
	case K_ADD3: case K_SUB3: case K_ADD1: case K_SUB1: case K_ADDI: case K_SUBI: {
		int isImm = i->kind == K_ADD1 || i->kind == K_SUB1 || i->kind == K_ADDI || i->kind == K_SUBI;
		int isAdd = i->kind == K_ADD3 || i->kind == K_ADD1 || i->kind == K_ADDI;
		int src = (i->kind == K_ADDI || i->kind == K_SUBI) ? i->rd : i->rn;
		int rn = cjUse(e, src);
		int rm = isImm ? 0 : cjUse(e, i->rm);
		int rd = cjDef(e, i->rd);
		if (isImm) {
			cjE(e, isAdd ? (need ? a_addsi(rd, rn, i->imm) : a_addi(rd, rn, i->imm)) : (need ? a_subsi(rd, rn, i->imm) : a_subi(rd, rn, i->imm)));
		} else {
			cjE(e, a_addsub_r(isAdd ? (need ? A_ADDS : A_ADD) : (need ? A_SUBS : A_SUB), rd, rn, rm, 0));
		}
		return;
	}
	case K_MOVI: {
		int rd = cjDef(e, i->rd);
		cjE(e, a_movz(rd, i->imm, 0));
		cjFlagsNZ(e, rd, need, F_C | F_V, 0);
		return;
	}
	case K_CMPI:
		if (need) {
			int rn = cjUse(e, i->rd);
			cjE(e, a_subsi(31, rn, i->imm));
		}
		return;
	case K_AND: case K_EOR: case K_ORR: case K_BIC: {
		int a = cjUse(e, i->rd), b = cjUse(e, i->rn);
		int rd = cjDef(e, i->rd);
		uint32_t op = i->kind == K_AND ? A_AND : i->kind == K_EOR ? A_EOR : i->kind == K_ORR ? A_ORR : A_BIC;
		cjE(e, a_rrr(op, rd, a, b));
		cjFlagsNZ(e, rd, need, F_C | F_V, 0);
		return;
	}
	case K_MVN: {
		int rn = cjUse(e, i->rn);
		int rd = cjDef(e, i->rd);
		cjE(e, a_rrr(A_ORN, rd, 31, rn));
		cjFlagsNZ(e, rd, need, F_C | F_V, 0);
		return;
	}
	case K_TST: {
		if (!(need & (F_N | F_Z))) {
			return;
		}
		int a = cjUse(e, i->rd), b = cjUse(e, i->rn);
		cjE(e, a_rrr(A_AND, S0, a, b));
		cjFlagsNZ(e, S0, need, F_C | F_V, 0);
		return;
	}
	case K_ADC: case K_SBC: {
		int a = cjUse(e, i->rd), b = cjUse(e, i->rn);
		int rd = cjDef(e, i->rd);
		cjE(e, a_rrr(i->kind == K_ADC ? (need ? A_ADCS : A_ADC) : (need ? A_SBCS : A_SBC), rd, a, b));
		return;
	}
	case K_NEG: {
		int rn = cjUse(e, i->rn);
		int rd = cjDef(e, i->rd);
		cjE(e, a_addsub_r(need ? A_SUBS : A_SUB, rd, 31, rn, 0));
		return;
	}
	case K_CMP2: case K_CMN:
		if (need) {
			int a = cjUse(e, i->rd), b = cjUse(e, i->rn);
			cjE(e, a_addsub_r(i->kind == K_CMP2 ? A_SUBS : A_ADDS, 31, a, b, 0));
		}
		return;
	case K_ADD4: {
		int a = cjUse(e, i->rd), b;
		if (i->rm == 15) {
			cjConst(e, S0, pcv); b = S0;
		} else {
			b = cjUse(e, i->rm);
		}
		int rd = cjDef(e, i->rd);
		cjE(e, a_addsub_r(A_ADD, rd, a, b, 0));
		return;
	}
	case K_MOV3: {
		if (i->rm == 15) {
			int rd = cjDef(e, i->rd);
			cjConst(e, rd, pcv);
		} else {
			int rn = cjUse(e, i->rm);
			int rd = cjDef(e, i->rd);
			if (rd != rn) {
				cjE(e, a_rrr(A_ORR, rd, 31, rn));
			}
		}
		return;
	}
	case K_CMP3:
		if (need) {
			int a = cjUse(e, i->rd), b;
			if (i->rm == 15) {
				cjConst(e, S0, pcv); b = S0;
			} else {
				b = cjUse(e, i->rm);
			}
			cjE(e, a_addsub_r(A_SUBS, 31, a, b, 0));
		}
		return;
	case K_ADD5: {
		int rd = cjDef(e, i->rd);
		cjConst(e, rd, (pcv & ~3u) + i->imm);
		return;
	}
	case K_ADD6: {
		int rn = cjUse(e, 13);
		int rd = cjDef(e, i->rd);
		cjE(e, a_addi(rd, rn, i->imm));
		return;
	}
	case K_BL1: { /* LR = PC + (imm11 con signo << 12) */
		int16_t imm = (int16_t) ((i->imm & 0x7FF) << 5);
		int rd = cjDef(e, 14);
		cjConst(e, rd, pcv + (uint32_t) ((int32_t) imm * 128));
		return;
	}
	case K_BCOND: case K_B: case K_BL2: case K_MEM:
		return; /* los emite cjEmitThumbPrefix */
	case K_ADD7: case K_SUB4: {
		int rn = cjUse(e, 13);
		int rd = cjDef(e, 13);
		cjE(e, i->kind == K_ADD7 ? a_addi(rd, rn, i->imm) : a_subi(rd, rn, i->imm));
		return;
	}
	}
}

/* registros del invitado (0-14) que tocan las kp primeras instrucciones: dimensiona la caché del tramo con memoria */
static uint32_t cjRegMask(const struct CJInfo* info, uint32_t kp) {
	uint32_t m = 0;
	for (uint32_t j = 0; j < kp; ++j) {
		const struct CJInfo* i = &info[j];
		switch (i->kind) {
		case K_LSLI: case K_LSRI: case K_ASRI: case K_ADD1: case K_SUB1: case K_AND: case K_EOR: case K_ADC: case K_SBC: case K_TST: case K_NEG:
		case K_CMP2: case K_CMN: case K_ORR: case K_BIC: case K_MVN:
			m |= (1u << i->rd) | (1u << i->rn);
			break;
		case K_ADD3: case K_SUB3:
			m |= (1u << i->rd) | (1u << i->rn) | (1u << i->rm);
			break;
		case K_MOVI: case K_CMPI: case K_ADDI: case K_SUBI: case K_ADD5:
			m |= 1u << i->rd;
			break;
		case K_ADD4: case K_CMP3: case K_MOV3:
			m |= (1u << i->rd) | (i->rm != 15 ? 1u << i->rm : 0);
			break;
		case K_ADD6:
			m |= (1u << i->rd) | (1u << 13);
			break;
		case K_ADD7: case K_SUB4:
			m |= 1u << 13;
			break;
		case K_BL1:
			m |= 1u << 14;
			break;
		case K_MEM:
			m |= 1u << i->rd;
			if (i->aux == 0 || i->aux == 1) {
				m |= 1u << i->rn;
			}
			if (i->aux == 1) {
				m |= 1u << i->rm;
			}
			if (i->aux == 2) {
				m |= 1u << 13;
			}
			break;
		default:
			break;
		}
	}
	return m & 0x7FFF;
}

/* destino y tipo del salto que cierra un tramo (k = instrucciones del tramo, la última es el salto); blLr = valor nuevo de LR para BL (o ~0) */
static void cjBranchTarget(const struct CJInfo* info, const uint32_t* op, uint32_t A, uint32_t k, int* bk, uint32_t* target, uint32_t* blLr) {
	const struct CJInfo* bi = &info[k - 1];
	uint32_t pcv = A + 2 * (k - 1) + 4;
	*blLr = ~0u;
	if (bi->kind == K_BCOND) {
		int8_t imm = (int8_t) op[k - 1];
		*target = pcv + (uint32_t) ((int32_t) imm * 2);
		*bk = 1;
	} else if (bi->kind == K_B) {
		int16_t imm = (int16_t) ((op[k - 1] & 0x7FF) << 5);
		*target = pcv + (uint32_t) ((int32_t) imm >> 4);
		*bk = 2;
	} else {
		const struct CJInfo* b1 = &info[k - 2];
		int16_t imm1 = (int16_t) ((b1->imm & 0x7FF) << 5);
		uint32_t lr = (A + 2 * (k - 2) + 4) + (uint32_t) ((int32_t) imm1 * 128);
		*target = lr + ((op[k - 1] & 0x7FF) << 1);
		*blLr = pcv - 1;
		*bk = 2;
	}
}

/* Tramo con cargas/guardados: tiene marco de pila (guarda x19-x22, x30 y los registros de la caché), mantiene en x19 el puntero a ARMCore, en x20 el de los opcodes del bloque y en x22 la
 * tabla de funciones auxiliares (que le pasa quien lo llama en x2). El código NO lleva la cuenta de ciclos: cada acceso hace «movz w2, #jpk; bl pieza» y la pieza (una por función auxiliar y
 * bloque, compartida por todos los accesos del bloque) pone x0 = ARMCore, guarda los banderines y salta a la función de C (w1 = dirección, w2 = jpk = índice de la instrucción | instrucciones puras
 * pendientes << 5 | margen que hay que dejar para el siguiente trozo puro << 10, w3 = valor a guardar; PC, pipeline y bloque los saca de cjCurBlock) que suma los ciclos pendientes, hace TODA la contabilidad exacta de ciclos del intérprete (prefetch de la región de origen +
 * acceso + nonseq - seq, tras posibles cambios de esperas), deja PC y pipeline como los tendría el intérprete (por si el acceso lee el bus abierto) y escribe cpu->cycles. La función devuelve
 * el valor cargado en los 32 bits bajos y en el bit 32 «hay que salir» (cycles >= nextEvent, no cabe el siguiente trozo puro o el guardado invalidó el bloque): un solo tbnz.
 * El margen inicial y la suma de los ciclos del final del tramo los hace cjRunNative (en C), con p0 y tail que se dejan en cjLastP0/cjLastTail.
 * Salidas: 0x100|m = salida temprana tras m instrucciones (cpu->cycles ya está escrito); 1, 2 y 3 como en el tramo sin memoria. */
static int cjLastP0, cjLastTail;
static uint32_t cjEmitFramed(uint32_t* code, uint32_t** end, const struct CJInfo* info, const uint32_t* op, uint32_t k, int branch, uint32_t A,
                            const uint8_t* liveOut, unsigned live, unsigned anyWrite, int* bk, uint32_t* target) {
	struct CJEm e;
	const int BASE = 19, NZS = 21, TAB = 22;
	uint32_t kp = k - branch;
	int nreg = __builtin_popcount(cjRegMask(info, kp));
	if (nreg > 6) {
		nreg = 6;
	}
	const int pool[6] = {23, 24, 25, 26, 27, 28};
	int pairs = (nreg + 1) / 2, frame = 48 + 16 * pairs;
	cjEmInit(&e, code, BASE, pool, nreg);
	int blSkip = branch && info[k - 1].kind == K_BL2; /* la constante de BL1 queda pisada por la de BL2 */
	uint32_t blLr = ~0u;
	if (branch) {
		cjBranchTarget(info, op, A, k, bk, target, &blLr);
	}
	uint32_t* exits[CJ_MAXN + 2];
	uint32_t exitM[CJ_MAXN + 2];
	int nExits = 0;
	uint32_t* callAt[CJ_MAXN + 2]; /* instrucciones bl por enlazar con la pieza de su función auxiliar */
	int callH[CJ_MAXN + 2], nCalls = 0;
	/* marco */
	cjE(&e, a_sub64i(31, 31, frame));
	cjE(&e, a_stp64(19, 20, 31, 0));
	cjE(&e, a_stp64(21, 22, 31, 16));
	cjE(&e, a_str64(30, 31, 32));
	for (int q = 0; q < pairs; ++q) {
		cjE(&e, a_stp64(23 + 2 * q, 24 + 2 * q, 31, 48 + 16 * q));
	}
	cjE(&e, a_mov64(BASE, 0));
	cjE(&e, a_mov64(TAB, 2));
	uint32_t pend = 0, j = 0;
	#define CJ_ISPURE(q) (info[q].kind != K_MEM)
	{
		uint32_t p0 = 0;
		while (p0 < kp && CJ_ISPURE(p0)) {
			++p0;
		}
		cjLastP0 = (int) p0; /* instrucciones puras antes del primer acceso: cjRunNative comprueba que caben antes del siguiente evento */
	}
	if (live || anyWrite) { /* con salidas tempranas los banderines deben estar siempre cargados */
		cjE(&e, a_ldr(12, BASE, offsetof(struct ARMCore, cpsr)));
		cjE(&e, a_msr_nzcv(12));
	}
	for (j = 0; j < kp; ++j) {
		if (CJ_ISPURE(j)) {
			if (!(blSkip && j == k - 2)) {
				cjEmitOne(&e, &info[j], A + 2 * j, liveOut[j]);
			}
			++pend;
			continue;
		}
		const struct CJInfo* mi = &info[j];
		uint32_t pcv = A + 2 * j + 4;
		/* dirección en w1 (los registros del invitado salen de la caché) */
		e.lock = 0;
		if (mi->aux == 3) {
			cjConst(&e, 1, (pcv & ~3u) + mi->imm);
		} else if (mi->aux == 1) {
			int ra = cjUse(&e, mi->rn), rb = cjUse(&e, mi->rm);
			cjE(&e, a_addsub_r(A_ADD, 1, ra, rb, 0));
		} else {
			int ra = cjUse(&e, mi->aux == 2 ? 13 : mi->rn);
			if (mi->imm) {
				cjE(&e, a_addi(1, ra, mi->imm));
			} else {
				cjE(&e, a_rrr(A_ORR, 1, 31, ra));
			}
		}
		if (mi->store) {
			int rv = cjUse(&e, mi->rd);
			cjE(&e, a_rrr(A_ORR, 3, 31, rv));
		}
		cjFlush(&e); /* el acceso, y las salidas tempranas tras él, ven cpu->gprs al día */
		/* ¿cuánto margen hay que dejar para el siguiente trozo puro? (el intérprete comprueba cycles < nextEvent antes de cada instrucción) */
		uint32_t need;
		{
			uint32_t p = 0;
			while (j + 1 + p < kp && CJ_ISPURE(j + 1 + p)) {
				++p;
			}
			int followed = (j + 1 + p < kp) || branch; /* otro acceso o el salto ejecuta tras el tramo */
			need = followed ? p : (p ? p - 1 : 0);
		}
		cjE(&e, a_movz(2, j | (pend << 5) | (need << 10), 0));
		callAt[nCalls] = e.p;
		callH[nCalls++] = mi->helper;
		cjE(&e, 0); /* bl pieza (se enlaza abajo) */
		if (!mi->store) { /* resultado: a cpu->gprs (escritura inmediata, las salidas tempranas no vuelcan) y a la caché */
			cjSt(&e, 0, mi->rd);
			e.lock = 0;
			int rl = cjAlloc(&e, mi->rd, 0);
			cjE(&e, a_rrr(A_ORR, rl, 31, 0));
		}
		pend = 0;
		exitM[nExits] = j + 1;
		exits[nExits++] = e.p;
		cjE(&e, 0); /* tbnz x0, #32: hay que salir (se enlaza con su pieza de salida) */
		cjE(&e, a_msr_nzcv(NZS)); /* los banderines del invitado vuelven después de la llamada */
	}
	#undef CJ_ISPURE
	/* final: salto o fin del tramo; pend = instrucciones pendientes de sumar (las suma cjRunNative: tail, o tail-1 si el salto se toma) */
	cjLastTail = (int) pend + (branch ? 1 : 0); /* el salto también cuesta su prefetch */
	if (branch && info[k - 1].kind == K_BL2) {
		e.lock = 0;
		cjConst(&e, cjDef(&e, 14), blLr);
	}
	cjFlush(&e); /* los str no tocan los banderines */
	if (branch) {
		const struct CJInfo* bi = &info[k - 1];
		if (bi->kind == K_BCOND) {
			cjE(&e, a_movz(15, 2, 0));
			cjE(&e, a_movz(14, 3, 0));
			cjE(&e, a_csel(15, 14, 15, bi->rm)); /* tomado: 3, no tomado: 2 */
		} else {
			cjE(&e, a_movz(15, 3, 0));
		}
	} else {
		cjE(&e, a_movz(15, 1, 0));
	}
	/* exit: banderines, marco, estado */
	uint32_t* exitTail = e.p;
	if (anyWrite) {
		cjE(&e, a_mrs_nzcv(12));
		cjE(&e, a_ldr(14, BASE, offsetof(struct ARMCore, cpsr)));
		cjE(&e, a_lsri(12, 12, 28));
		cjE(&e, a_bfi(14, 12, 28, 4));
		cjE(&e, a_str(14, BASE, offsetof(struct ARMCore, cpsr)));
	}
	cjE(&e, a_rrr(A_ORR, 0, 31, 15));
	cjE(&e, a_ldp64(19, 20, 31, 0));
	cjE(&e, a_ldp64(21, 22, 31, 16));
	cjE(&e, a_ldr64(30, 31, 32));
	for (int q = 0; q < pairs; ++q) {
		cjE(&e, a_ldp64(23 + 2 * q, 24 + 2 * q, 31, 48 + 16 * q));
	}
	cjE(&e, a_add64i(31, 31, frame));
	cjE(&e, A_RET);
	/* salidas tempranas: movz w15, #(0x100|m); b exitTail */
	for (int q = 0; q < nExits; ++q) {
		uint32_t* stub = e.p;
		cjE(&e, a_msr_nzcv(NZS)); /* los banderines del invitado siguen guardados en x21 */
		cjE(&e, a_movz(15, 0x100 | exitM[q], 0));
		cjE(&e, a_b((int32_t) (exitTail - e.p)));
		*exits[q] = a_tbnz_x0_32((int32_t) (stub - exits[q]));
	}
	/* piezas compartidas de llamada: x0 = ARMCore, banderines del invitado a x21 y salto a la función de C (que vuelve directamente al bl: x30) */
	uint32_t* piece[H_COUNT] = {0};
	for (int q = 0; q < nCalls; ++q) {
		if (!piece[callH[q]]) {
			piece[callH[q]] = e.p;
			cjE(&e, a_mov64(0, BASE));
			cjE(&e, a_mrs_nzcv(NZS));
			cjE(&e, a_ldr64(16, TAB, 8 * callH[q]));
			cjE(&e, a_br(16));
		}
		*callAt[q] = a_bl((int32_t) (piece[callH[q]] - callAt[q]));
	}
	*end = e.p;
	if (e.fail) {
		return 0;
	}
	return k;
}

/* Traduce el tramo nativo del principio del bloque: op[0..n-1] son los opcodes Thumb desde la dirección A. Devuelve k (nº de instrucciones nativas, 0 si no se emite nada).
 * El tramo termina en la primera instrucción no traducible o en un salto con destino constante (B, Bcond, BL con su primera mitad en el mismo tramo), que se cuenta dentro de k.
 * *bk = 0 (solo instrucciones puras), 1 (acaba en Bcond) o 2 (acaba en salto incondicional); *target = destino del salto.
 * Tramo sin memoria: el código devuelve en w0 1 = tramo puro ejecutado, 2 = salto condicional NO tomado, 3 = salto tomado (los ciclos del tramo y del margen los lleva cjRunNative; los propios del salto, el despachador:
 * la instrucción de salto cuesta 1 + activeSeqCycles16 de la región de origen MÁS lo que devuelva ThumbWritePC, y WritePC debe ver los ciclos sin sumar la instrucción, como en el intérprete). */
static int cjLastFramed; /* el último tramo emitido es de los con memoria (lleva su propia contabilidad de ciclos) */
static uint32_t cjEmitThumbPrefix(uint32_t* code, uint32_t** end, const uint32_t* op, uint32_t n, uint32_t A, uint32_t minK, int* bk, uint32_t* target) {
	struct CJInfo info[CJ_MAXN];
	uint32_t k = 0;
	int branch = 0;
	*bk = 0;
	while (k < n && cjThumbInfo(op[k], &info[k])) {
		int kd = info[k].kind;
		if (kd == K_BL2 && !(k > 0 && info[k - 1].kind == K_BL1)) {
			break; /* la segunda mitad sin la primera en el mismo tramo: LR no es constante */
		}
		++k;
		if (kd == K_BCOND || kd == K_B || kd == K_BL2) {
			branch = 1;
			break;
		}
	}
	if (k < minK) {
		return 0;
	}
	uint32_t kp = k - branch; /* instrucciones puras */
	/* vida de banderines hacia atrás: al salir del tramo todos los banderines están vivos */
	uint8_t liveOut[CJ_MAXN];
	unsigned live = 0xF, anyWrite = 0;
	for (int j = (int) k - 1; j >= 0; --j) {
		liveOut[j] = (uint8_t) live;
		live = (live & ~info[j].kill) | info[j].use;
		anyWrite |= info[j].kill;
	}
	cjLastFramed = 0;
	for (uint32_t q = 0; q < kp; ++q) {
		if (info[q].kind == K_MEM) {
			cjLastFramed = 1;
			return cjEmitFramed(code, end, info, op, k, branch, A, liveOut, live, anyWrite, bk, target);
		}
	}
	struct CJEm e;
	static const int cpool[7] = {1, 2, 3, 4, 13, 16, 17}; /* caller-saved libres: x0 = cpu, 5-8 ciclos, 9-12 y 14 banderines, 15 salida */
	cjEmInit(&e, code, 0, cpool, 7);
	int blSkip = branch && info[k - 1].kind == K_BL2;
	/* Sin contabilidad de ciclos: el margen y la suma k*coste los hace cjRunNative (en C), una vez por tramo. */
	if (live) { /* algún banderín se lee antes de escribirse: traer los del invitado */
		cjE(&e, a_ldr(12, 0, offsetof(struct ARMCore, cpsr)));
		cjE(&e, a_msr_nzcv(12));
	}
	for (uint32_t j = 0; j < kp; ++j) {
		if (!(blSkip && j == k - 2)) {
			cjEmitOne(&e, &info[j], A + 2 * j, liveOut[j]);
		}
	}
	if (blSkip) {
		e.lock = 0;
		cjConst(&e, cjDef(&e, 14), (A + 2 * (k - 1) + 4) - 1);
	}
	cjFlush(&e); /* volcado de los registros modificados (no toca banderines) */
	if (branch) {
		const struct CJInfo* bi = &info[k - 1];
		uint32_t pcv = A + 2 * (k - 1) + 4;
		if (bi->kind == K_BCOND) {
			int8_t imm = (int8_t) op[k - 1];
			*target = pcv + (uint32_t) ((int32_t) imm * 2);
			*bk = 1;
			cjE(&e, a_movz(15, 2, 0));
			cjE(&e, a_movz(14, 3, 0));
			cjE(&e, a_csel(15, 14, 15, bi->rm)); /* tomado: 3, no tomado: 2 (csel no toca los banderines) */
		} else if (bi->kind == K_B) {
			int16_t imm = (int16_t) ((op[k - 1] & 0x7FF) << 5);
			*target = pcv + (uint32_t) ((int32_t) imm >> 4);
			*bk = 2;
			cjE(&e, a_movz(15, 3, 0));
		} else { /* BL2: LR = destino de la primera mitad + imm; el nuevo LR = PC - 1 */
			const struct CJInfo* b1 = &info[k - 2];
			int16_t imm1 = (int16_t) ((b1->imm & 0x7FF) << 5);
			uint32_t lr = (A + 2 * (k - 2) + 4) + (uint32_t) ((int32_t) imm1 * 128);
			*target = lr + ((op[k - 1] & 0x7FF) << 1);
			*bk = 2;
			cjE(&e, a_movz(15, 3, 0));
		}
	} else {
		cjE(&e, a_movz(15, 1, 0));
	}
	if (anyWrite) { /* devolver los banderines al invitado */
		cjE(&e, a_mrs_nzcv(12));
		cjE(&e, a_ldr(14, 0, offsetof(struct ARMCore, cpsr)));
		cjE(&e, a_lsri(12, 12, 28));
		cjE(&e, a_bfi(14, 12, 28, 4));
		cjE(&e, a_str(14, 0, offsetof(struct ARMCore, cpsr)));
	}
	cjE(&e, a_rrr(A_ORR, 0, 31, 15)); /* mov w0, w15: el estado se devuelve al final porque x0 es cpu hasta aquí */
	cjE(&e, A_RET);
	*end = e.p;
	if (e.fail) {
		return 0;
	}
	return k;
}
