#!/bin/sh
# Compila y ejecuta el banco de pruebas x86 del JIT contra el mGBA indicado (arm.c SIN parchear con el JIT; el medidor da igual).
# Uso: tools/jit_test/run.sh <carpeta de mgba>      Código de salida 0 = el JIT coincide con el intérprete.
set -e
MG="$1"
HERE="$(cd "$(dirname "$0")" && pwd)"
T="$HERE/.."
gcc -O2 -fwrapv -fno-strict-aliasing -w -I"$MG/src" -I"$MG/include" -I"$HERE/inc" -I"$T" -D_GNU_SOURCE -DM_CORE_GBA -DDISABLE_THREADING -DCOLOR_16_BIT -DCOLOR_5_6_5 \
  "$HERE/harness.c" "$MG/src/arm/isa-arm.c" "$MG/src/arm/isa-thumb.c" -o "$HERE/harness_bin"
"$HERE/harness_bin" 40000 1
"$HERE/harness_bin" 40000 2
"$HERE/harness_bin" 1 1 unit
