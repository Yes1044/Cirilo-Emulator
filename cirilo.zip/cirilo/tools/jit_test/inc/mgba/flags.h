#define BINARY_NAME "mgba"
#define PROJECT_NAME "mGBA"
#define PROJECT_VERSION "0"
#define LIBRARY_VERSION "0"
#define VERSION_STRING "0"
#define M_CORE_GBA
#define M_CORE_GB
#define MINIMAL_CORE 2
#define DISABLE_THREADING
#define COLOR_16_BIT
#define COLOR_5_6_5
