/* Pruebas en x86 del JIT: el JIT genera ARM64, un emulador ARM64 mínimo (solo las instrucciones que emite) lo ejecuta y se compara con el
 * intérprete de mGBA sobre programas Thumb aleatorios (con memoria falsa). Uso: harness [ejecuciones] [semilla] [unit]. Salida 0 = todo coincide. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
/* contadores del medidor (los define libretro.c en el núcleo real; aquí solo para enlazar un arm.c ya instrumentado) */
uint64_t cirilo_prof_steps, cirilo_prof_ev, cirilo_prof_vid, cirilo_prof_aud;
#define CJ_TEST 1
#include "arm/arm.c"
static int cj_test_exec(const uint32_t* code, struct ARMCore* cpu);
#include "cirilo_jit.c"

static uint32_t gw(uint64_t* x, int r) { return r == 31 ? 0 : (uint32_t) x[r]; }
static void sw(uint64_t* x, int r, uint32_t v) { if (r != 31) x[r] = v; }
static uint32_t addc(uint32_t a, uint32_t b, int cin, uint32_t* f) {
	uint64_t r64 = (uint64_t) a + b + cin;
	uint32_t r = (uint32_t) r64;
	uint32_t n = r >> 31, z = r == 0, c = (uint32_t) ((r64 >> 32) & 1), v = ((~(a ^ b)) & (a ^ r)) >> 31;
	*f = (n << 31) | (z << 30) | (c << 29) | (v << 28);
	return r;
}
static uint64_t g_exec_count[64];
static int cj_test_exec(const uint32_t* code, struct ARMCore* cpu) {
	uint64_t x[32];
	memset(x, 0xA5, sizeof x);
	uint64_t stack[64];
	uint64_t sp = (uint64_t) (uintptr_t) (stack + 64);
	uint32_t nzcv = 0;
	x[0] = (uint64_t) (uintptr_t) cpu;
	const uint32_t* pc = code;
	long steps = 0;
	for (;;) {
		if (++steps > 200000) { fprintf(stderr, "ejecutor: bucle infinito\n"); abort(); }
		uint32_t i = *pc;
		const uint32_t* cur = pc++;
		int rd = i & 31, rn = (i >> 5) & 31, rm = (i >> 16) & 31;
		uint32_t f;
		if ((i & 0xFFC00000) == 0xB9400000 || (i & 0xFFC00000) == 0xB9000000) {
			uint64_t base = rn == 31 ? sp : x[rn];
			uint32_t* a = (uint32_t*) (uintptr_t) (base + ((i >> 10) & 0xFFF) * 4);
			if (i & 0x00400000) sw(x, rd, *a); else *a = gw(x, rd);
		} else if ((i & 0xFFC00000) == 0xA9800000 || (i & 0xFFC00000) == 0xA9000000 || (i & 0xFFC00000) == 0xA9400000 || (i & 0xFFC00000) == 0xA8C00000) {
			int imm = (int) ((i >> 15) & 0x7F); if (imm & 0x40) imm -= 128; imm *= 8;
			int rt2 = (i >> 10) & 31;
			uint32_t kind = i & 0xFFC00000;
			uint64_t base = rn == 31 ? sp : x[rn];
			if (kind == 0xA9800000) base += imm;
			uint64_t* a = (uint64_t*) (uintptr_t) (kind == 0xA8C00000 ? base : base + (kind == 0xA9800000 ? 0 : imm));
			if (kind == 0xA9800000 || kind == 0xA9000000) { a[0] = x[rd]; a[1] = x[rt2]; } else { x[rd] = a[0]; x[rt2] = a[1]; }
			if (kind == 0xA8C00000) base += imm;
			if (kind == 0xA9800000 || kind == 0xA8C00000) { if (rn == 31) sp = base; else x[rn] = base; }
		} else if ((i & 0xFF800000) == 0x11000000 || (i & 0xFF800000) == 0x51000000 || (i & 0xFF800000) == 0x31000000 || (i & 0xFF800000) == 0x71000000) {
			uint32_t imm = (i >> 10) & 0xFFF, kind = i & 0xFF800000;
			if (i & 0x00400000) { fprintf(stderr, "ejecutor: LSL12 no soportado\n"); abort(); }
			int sub = (kind == 0x51000000 || kind == 0x71000000), s = (kind == 0x31000000 || kind == 0x71000000);
			uint32_t a = gw(x, rn);
			uint32_t r = sub ? addc(a, ~imm, 1, &f) : addc(a, imm, 0, &f);
			if (s) { nzcv = f; sw(x, rd, r); } else { if (rd == 31 || rn == 31) { fprintf(stderr, "ejecutor: add imm con SP\n"); abort(); } sw(x, rd, r); }
		} else if ((i & 0xFFE0FC00) == 0x0B000000 || (i & 0xFFE0FC00) == 0x2B000000 || (i & 0xFFE0FC00) == 0x4B000000 || (i & 0xFFE0FC00) == 0x6B000000) {
			uint32_t kind = i & 0xFFE0FC00, a = gw(x, rn), b = gw(x, rm);
			int sub = (kind == 0x4B000000 || kind == 0x6B000000), s = (kind == 0x2B000000 || kind == 0x6B000000);
			uint32_t r = sub ? addc(a, ~b, 1, &f) : addc(a, b, 0, &f);
			if (s) nzcv = f;
			sw(x, rd, r);
		} else if ((i & 0xFFE0FC00) == 0x3A000000 || (i & 0xFFE0FC00) == 0x7A000000) {
			uint32_t a = gw(x, rn), b = gw(x, rm); int c = (nzcv >> 29) & 1;
			uint32_t r = (i & 0x40000000) ? addc(a, ~b, c, &f) : addc(a, b, c, &f);
			nzcv = f; sw(x, rd, r);
		} else if ((i & 0xFFE0FC00) == 0x0A000000 || (i & 0xFFE0FC00) == 0x2A000000 || (i & 0xFFE0FC00) == 0x4A000000 || (i & 0xFFE0FC00) == 0x0A200000 || (i & 0xFFE0FC00) == 0x2A200000) {
			uint32_t kind = i & 0xFFE0FC00, a = gw(x, rn), b = gw(x, rm), r = 0;
			if (kind == 0x0A000000) r = a & b; else if (kind == 0x2A000000) r = a | b; else if (kind == 0x4A000000) r = a ^ b; else if (kind == 0x0A200000) r = a & ~b; else r = a | ~b;
			sw(x, rd, r);
		} else if ((i & 0xFFE0FC00) == 0xAA000000) {
			x[rd] = (rn == 31 ? 0 : x[rn]) | (rm == 31 ? 0 : x[rm]);
		} else if ((i & 0xFF800000) == 0x52800000) {
			sw(x, rd, ((i >> 5) & 0xFFFF) << (16 * ((i >> 21) & 3)));
		} else if ((i & 0xFF800000) == 0x72800000) {
			int hw = (i >> 21) & 3; uint32_t cur32 = gw(x, rd);
			cur32 = (cur32 & ~(0xFFFFu << (16 * hw))) | (((i >> 5) & 0xFFFF) << (16 * hw)); sw(x, rd, cur32);
		} else if ((i & 0xFF800000) == 0xD2800000) {
			x[rd] = (uint64_t) ((i >> 5) & 0xFFFF) << (16 * ((i >> 21) & 3));
		} else if ((i & 0xFF800000) == 0xF2800000) {
			int hw = (i >> 21) & 3;
			x[rd] = (x[rd] & ~(0xFFFFull << (16 * hw))) | ((uint64_t) ((i >> 5) & 0xFFFF) << (16 * hw));
		} else if ((i & 0xFFC00000) == 0x53000000 || (i & 0xFFC00000) == 0x13000000 || (i & 0xFFC00000) == 0x33000000) {
			uint32_t kind = i & 0xFFC00000; int immr = (i >> 16) & 63, imms = (i >> 10) & 63; uint32_t src = gw(x, rn), dst = gw(x, rd), r;
			if (imms >= immr) { /* extracción */
				int w = imms - immr + 1; uint32_t field = (src >> immr) & (w == 32 ? 0xFFFFFFFFu : ((1u << w) - 1));
				if (kind == 0x53000000) r = field;
				else if (kind == 0x13000000) r = (uint32_t) ((int32_t) (field << (32 - w)) >> (32 - w));
				else { uint32_t mask = (w == 32 ? 0xFFFFFFFFu : ((1u << w) - 1)); r = (dst & ~mask) | field; }
			} else { /* inserción: ancho imms+1 en la posición 32-immr */
				int w = imms + 1, pos = 32 - immr; uint32_t field = src & ((1u << w) - 1);
				if (kind == 0x53000000) r = field << pos;
				else if (kind == 0x13000000) { r = (uint32_t) ((int32_t) (field << (32 - w)) >> (32 - w)) << pos; }
				else { uint32_t mask = ((1u << w) - 1) << pos; r = (dst & ~mask) | (field << pos); }
			}
			sw(x, rd, r);
		} else if ((i & 0xFFFFFFE0) == 0xD53B4200) {
			x[rd] = nzcv;
		} else if ((i & 0xFFFFFFE0) == 0xD51B4200) {
			nzcv = (uint32_t) x[rd] & 0xF0000000u;
		} else if ((i & 0xFFE08000) == 0x1B000000) {
			int ra = (i >> 10) & 31; sw(x, rd, gw(x, ra) + gw(x, rn) * gw(x, rm));
		} else if ((i & 0xFF000010) == 0x54000000) {
			int imm = (int) ((i >> 5) & 0x7FFFF); if (imm & 0x40000) imm -= 0x80000; int cc = i & 15;
			int n = nzcv >> 31, z = (nzcv >> 30) & 1, c = (nzcv >> 29) & 1, v = (nzcv >> 28) & 1, t = 0;
			switch (cc >> 1) { case 0: t = z; break; case 1: t = c; break; case 2: t = n; break; case 3: t = v; break; case 4: t = c && !z; break; case 5: t = n == v; break; case 6: t = (n == v) && !z; break; default: t = 1; }
			if ((cc & 1) && cc != 15) t = !t;
			if (t) pc = cur + imm;
		} else if ((i & 0xFFFFFC1F) == 0xD63F0000) {
			uint64_t fn = x[rn]; int k;
			((void (*)(void*, unsigned)) (uintptr_t) fn)((void*) (uintptr_t) x[0], (unsigned) (uint32_t) x[1]);
			for (k = 0; k <= 18; ++k) x[k] = 0xDEADBEEFDEADBEEFull;
		} else if ((i & 0xFFFFFC1F) == 0xD65F0000) {
			return (int) (uint32_t) x[0];
		} else {
			fprintf(stderr, "ejecutor: instruccion no soportada %08X\n", i); abort();
		}
	}
}

static void anchors(void) {
	struct { const char* n; uint32_t got, want; } t[] = {
		{ "ret", I_RET, 0xD65F03C0 },
		{ "stp x29,x30,[sp,#-48]!", I_STP_PRE(29, 30, 31, -48), 0xA9BD7BFD },
		{ "stp x19,x20,[sp,#16]", I_STP(19, 20, 31, 16), 0xA90153F3 },
		{ "ldp x29,x30,[sp],#48", I_LDP_POST(29, 30, 31, 48), 0xA8C37BFD },
		{ "mov x0,x19", I_MOVX(0, 19), 0xAA1303E0 },
		{ "add w0,w1,w2", I_ADD_REG(0, 1, 2), 0x0B020020 },
		{ "ldr w0,[x1,#4]", I_LDRW(0, 1, 4), 0xB9400420 },
		{ "mrs x0,nzcv", I_MRS_NZCV(0), 0xD53B4200 },
		{ "msr nzcv,x0", I_MSR_NZCV(0), 0xD51B4200 },
		{ "lsl w0,w1,#2", I_LSL(0, 1, 2), 0x531E7420 },
		{ "lsr w0,w1,#2", I_LSR(0, 1, 2), 0x53027C20 },
		{ "asr w0,w1,#2", I_ASR(0, 1, 2), 0x13027C20 },
		{ "movz w0,#1", I_MOVZ(0, 1, 0), 0x52800020 },
		{ "blr x16", I_BLR(16), 0xD63F0200 },
		{ "madd w0,w22,w1,w0", I_MADD(0, 22, 1, 0), 0x1B0102C0 },
		{ "subs wzr,w0,w1", I_SUBS_REG(31, 0, 1), 0x6B01001F },
		{ "subs wzr,w0,#0", I_SUBS_IMM(31, 0, 0), 0x7100001F },
	};
	size_t k; int bad = 0;
	for (k = 0; k < sizeof t / sizeof t[0]; ++k) if (t[k].got != t[k].want) { printf("ANCLA MAL %s: %08X (esperado %08X)\n", t[k].n, t[k].got, t[k].want); bad++; }
	printf("anclas de codificacion: %s\n", bad ? "FALLAN" : "ok");
}

int main(int argc, char** argv) {
	int runs = argc > 1 ? atoi(argv[1]) : 3000; if (argc > 2) cj_seed = (uint32_t) strtoul(argv[2], 0, 0); if (getenv("CJ_TR")) cj_trace_run = atoi(getenv("CJ_TR"));
	anchors();
	if (argc > 3 && !strcmp(argv[3], "unit")) {
		int bad = 0, tested = 0, op;
		for (op = 0; op < 0x10000 && bad < 40; ++op) {
			int k = cj_classify(op);
			if (k != 1 && k != 2) continue;
			struct CJCache uc; memset(&uc, 0, sizeof uc);
			uc.tab = calloc(CJ_TAB_MASK + 1, sizeof(struct CJEntry)); uc.cap = (1u << 20) / 4; uc.code = calloc(uc.cap, 4);
			cj_force_op = op; cj_seed = 0x1000 + op; char e2[300] = "";
			const char* r2 = cj_selftest(&uc, 25, e2, sizeof e2); tested++;
			if (r2) { printf("op %04X (clase %d): %s\n", op, k, r2); bad++; }
			free(uc.tab); free(uc.code);
		}
		printf("unitario: %d instrucciones probadas, %d con fallo\n", tested, bad);
		return bad != 0;
	}
	struct CJCache c; memset(&c, 0, sizeof c);
	c.tab = calloc(CJ_TAB_MASK + 1, sizeof(struct CJEntry));
	c.cap = (4u << 20) / 4; c.code = calloc(c.cap, 4);
	char err[300] = "";
	const char* r = cj_selftest(&c, runs, err, sizeof err);
	printf("autoprueba %d ejecuciones: %s\n", runs, r ? r : "OK");
	printf("bloques compilados %llu, ciclos en JIT %llu de %llu (%.1f%%)\n", (unsigned long long) c.blocks, (unsigned long long) c.jitCycles, (unsigned long long) c.totCycles, c.totCycles ? 100.0 * c.jitCycles / c.totCycles : 0.0);
	return r ? 1 : 0;
}
