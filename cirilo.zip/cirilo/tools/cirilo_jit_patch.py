#!/usr/bin/env python3
"""Cirilo JIT (Fase 1). Uso: cirilo_jit_patch.py <carpeta mgba>   (ejecutar DESPUÉS de cirilo_fast_patch.py)
Todo o nada: si algo no encaja con el mGBA fijado, sale con error y no deja nada a medias.
 - copia cirilo_jit.h a include/mgba/internal/gba/ y cirilo_jit_arm.inc, cirilo_jit_a64.inc y cirilo_jit_a64sim.inc a src/arm/
 - arm.c: incluye el .inc y hace que ARMRunLoop use el despachador de bloques cuando cirilo_jit_on
 - memory.c y cirilo_fast.h: tras cada escritura a IWRAM/EWRAM avisan al JIT (SMC); GBAPatch* (trucos en ROM) vacían la caché; reset y cargar estado también"""
import os, re, shutil, sys
here = os.path.dirname(os.path.abspath(__file__))
root = sys.argv[1]
def die(m):
    print("cirilo_jit_patch: " + m, file=sys.stderr); sys.exit(1)
def rd(p):
    with open(os.path.join(root, p), encoding="utf-8", errors="surrogateescape") as f: return f.read()
files = {}
def count_sub(s, pat, rep, expect, what):
    s2, n = re.subn(pat, rep, s)
    if n != expect: die("%s: esperaba %d coincidencias y hay %d" % (what, expect, n))
    return s2
# ---- arm.c
arm = rd("src/arm/arm.c")
anchor = "void ARMRunLoop(struct ARMCore* cpu) {\n\tif (cpu->executionMode == MODE_THUMB) {"
if arm.count(anchor) != 1: die("arm.c: no encuentro ARMRunLoop")
if "cirilo_jit_arm.inc" in arm: die("arm.c ya está parcheado")
arm = arm.replace(anchor, '#include "cirilo_jit_arm.inc"\n\nvoid ARMRunLoop(struct ARMCore* cpu) {\n\tif (cirilo_jit_on) {\n\t\tcjRun(cpu);\n\t\treturn;\n\t}\n\tif (cpu->executionMode == MODE_THUMB) {', 1)
for need in ("static inline void ARMStep(", "static inline void ThumbStep(", "conditionLut[16]"):
    if need not in arm: die("arm.c: falta " + need)
files["src/arm/arm.c"] = arm
# ---- memory.c
mem = rd("src/gba/memory.c")
inc = "#include <mgba/internal/gba/memory.h>\n"
if mem.count(inc) != 1: die("memory.c: no encuentro el include esperado")
mem = mem.replace(inc, inc + "#include <mgba/internal/gba/cirilo_jit.h>\n", 1)
def jit_notes(s, var, expect, what):
    s = count_sub(s, r"STORE_32\(value, address & \(GBA_SIZE_(IWRAM|EWRAM) - 4\), %s->(?:iwram|wram)\);" % var,
                  lambda m: m.group(0) + " CIRILO_JIT_%s(address & (GBA_SIZE_%s - 4), 4);" % ("IW" if m.group(1) == "IWRAM" else "EW", m.group(1)), expect[0], what + " STORE_32")
    s = count_sub(s, r"STORE_16\(value, address & \(GBA_SIZE_(IWRAM|EWRAM) - 2\), %s->(?:iwram|wram)\);" % var,
                  lambda m: m.group(0) + " CIRILO_JIT_%s(address & (GBA_SIZE_%s - 2), 2);" % ("IW" if m.group(1) == "IWRAM" else "EW", m.group(1)), expect[1], what + " STORE_16")
    s = count_sub(s, r"\(\(int8_t\*\) %s->(?:iwram|wram)\)\[address & \(GBA_SIZE_(IWRAM|EWRAM) - 1\)\] = value;" % var,
                  lambda m: m.group(0) + " CIRILO_JIT_%s(address & (GBA_SIZE_%s - 1), 1);" % ("IW" if m.group(1) == "IWRAM" else "EW", m.group(1)), expect[2], what + " store8")
    return s
mem = jit_notes(mem, "memory", (4, 4, 4), "memory.c")
mem = count_sub(mem, r"(void GBAPatch(?:32|16|8)\(struct ARMCore\* cpu, uint32_t address, [a-z0-9_]+ value, [a-z0-9_]+\* old\) \{)", lambda m: m.group(1) + "\n\tcirilo_jit_patch(address);", 3, "memory.c GBAPatch")
a = "void GBAMemoryReset(struct GBA* gba) {"
if mem.count(a) != 1: die("memory.c: GBAMemoryReset")
mem = mem.replace(a, a + "\n\tcirilo_jit_reset(gba->memory.romSize);", 1)
a = "void GBAMemoryDeserialize(struct GBAMemory* memory, const struct GBASerializedState* state) {"
if mem.count(a) != 1: die("memory.c: GBAMemoryDeserialize")
mem = mem.replace(a, a + "\n\tcirilo_jit_flush();", 1)
files["src/gba/memory.c"] = mem
# ---- cirilo_fast.h (si el camino rápido está aplicado)
fh = "include/mgba/internal/gba/cirilo_fast.h"
if os.path.exists(os.path.join(root, fh)):
    s = rd(fh)
    s = jit_notes(s, "m", (2, 2, 2), "cirilo_fast.h")
    if "#include <mgba/internal/gba/cirilo_jit.h>" not in s:
        s = re.sub(r"(#include <[^>]+>\n)", lambda m: m.group(1) + "#include <mgba/internal/gba/cirilo_jit.h>\n", s, count=1)
    files[fh] = s
else:
    print("cirilo_jit_patch: aviso: sin cirilo_fast.h (camino rápido no aplicado); solo se vigila memory.c")
# ---- todo bien: escribir
for p, s in files.items():
    with open(os.path.join(root, p), "w", encoding="utf-8", errors="surrogateescape") as f: f.write(s)
shutil.copyfile(os.path.join(here, "cirilo_jit.h"), os.path.join(root, "include/mgba/internal/gba/cirilo_jit.h"))
for f in ("cirilo_jit_arm.inc", "cirilo_jit_a64.inc", "cirilo_jit_a64sim.inc"):
    shutil.copyfile(os.path.join(here, f), os.path.join(root, "src/arm", f))
print("ok: JIT fase 1 (despachador de bloques + vigilancia SMC en %d archivos)" % len(files))
