#!/usr/bin/env python3
"""Integra el JIT (tools/cirilo_jit.c) en mGBA. Uso: cirilo_jit_patch.py <carpeta mgba>
Debe ir DESPUÉS de cirilo_prof_patch.py (toca el ARMRunLoop ya instrumentado). Todo o nada: si algo no encaja, no modifica nada y sale con 1."""
import os,sys
root=sys.argv[1]
here=os.path.dirname(os.path.abspath(__file__))
def rd(p):
    with open(p,newline="") as f: return f.read()
arm=os.path.join(root,"src/arm/arm.c")
lib=os.path.join(root,"src/platform/libretro/libretro.c")
try:
    s=rd(arm); l=rd(lib); jit=rd(os.path.join(here,"cirilo_jit.c"))
except OSError as e:
    print("ERROR:",e); sys.exit(1)
HEAD="void ARMRunLoop(struct ARMCore* cpu) {\n"
OLD=HEAD+"\tuint64_t cirilo_t0 = cirilo_tick();\n\tif (cpu->executionMode == MODE_THUMB) {\n"
NEW=("extern int cirilo_jit_active;\nvoid cirilo_jit_steps(struct ARMCore* cpu);\n"+HEAD+"\tuint64_t cirilo_t0 = cirilo_tick();\n"
     "\tif (cirilo_jit_active) {\n\t\tcirilo_jit_steps(cpu);\n\t} else if (cpu->executionMode == MODE_THUMB) {\n")
if s.count(OLD)!=1 or "cirilo_jit_steps" in s:
    print("ERROR: arm.c no tiene el ARMRunLoop instrumentado esperado (¿falló el medidor, o ya está parcheado?)"); sys.exit(1)
s=s.replace(OLD,NEW)+"\n"+jit
HOOKS=["void retro_reset(void) {\n","bool retro_load_game(const struct retro_game_info* game) {\n","void retro_unload_game(void) {\n",
       "void retro_cheat_reset(void) {\n","void retro_cheat_set(unsigned index, bool enabled, const char* code) {\n"]
for h in HOOKS:
    if l.count(h)!=1:
        print("ERROR: libretro.c: no encuentro una sola vez:",h.strip()); sys.exit(1)
for h in HOOKS:
    l=l.replace(h,h+"\tcirilo_jit_flush();\n")
# declaración antes de la primera función que la usa (retro_reset aparece antes que las demás)
idx=l.index(HOOKS[0])
l=l[:idx]+"void cirilo_jit_flush(void);\n"+l[idx:]
with open(arm,"w",newline="") as f: f.write(s)
with open(lib,"w",newline="") as f: f.write(l)
print("ok: JIT integrado (arm.c y libretro.c)")
