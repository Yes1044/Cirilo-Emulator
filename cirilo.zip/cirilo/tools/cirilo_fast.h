/* Camino rápido de memoria para el intérprete ARM de mGBA (Cirilo). Lo copia tools/cirilo_fast_patch.py a
 * include/mgba/internal/gba/cirilo_fast.h y cambia cpu->memory.loadN/storeN por cirilo_ldN/cirilo_stN en isa-arm.c e isa-thumb.c.
 *
 * Qué hace: las cargas y guardados a IWRAM, EWRAM y (solo cargas) ROM, que son casi todos los de un juego como Doom, se resuelven aquí,
 * en línea, sin la llamada indirecta a GBALoad32/GBAStore32 ni su `switch` por región. Todo lo demás (E/S, paleta, VRAM, OAM, BIOS, SRAM,
 * ROM fuera de rango, ROM2_EX en 16 bits por la EEPROM…) se delega tal cual en cpu->memory.loadN/storeN.
 *
 * Exactitud: cada rama copia la de src/gba/memory.c (mismo valor, mismos ciclos, misma rotación de accesos desalineados y mismo
 * GBAMemoryStall, incluida su salida temprana). Si memory.c cambia, hay que revisar este archivo. tools/test/fast_diff.c lo comprueba
 * contra las funciones originales. */
#ifndef CIRILO_FAST_H
#define CIRILO_FAST_H

#include <mgba/internal/arm/macros.h>
#include <mgba/internal/gba/gba.h>
#include <mgba/internal/gba/memory.h>

#define CIRILO_LIKELY(x) __builtin_expect(!!(x), 1)

/* Igual que el principio de GBAMemoryStall: si no se ejecuta desde ROM o no hay prefetch, la espera es la espera. */
static inline int32_t cirilo_stall(struct ARMCore* cpu, struct GBAMemory* m, int32_t wait) {
	if (m->activeRegion < GBA_REGION_ROM0 || !m->prefetch) {
		return wait;
	}
	return cpu->memory.stall(cpu, wait);
}

static inline uint32_t cirilo_ld32(struct ARMCore* cpu, uint32_t address, int* cc) {
	struct GBAMemory* m = &((struct GBA*) cpu->master)->memory;
	uint32_t r = address >> BASE_OFFSET;
	uint32_t value;
	int wait;
	if (r == GBA_REGION_IWRAM) {
		LOAD_32(value, address & (GBA_SIZE_IWRAM - 4), m->iwram);
		wait = 0;
	} else if (r >= GBA_REGION_ROM0 && r <= GBA_REGION_ROM2_EX && (address & (GBA_SIZE_ROM0 - 4)) < m->romSize) {
		LOAD_32(value, address & (GBA_SIZE_ROM0 - 4), m->rom);
		wait = m->waitstatesNonseq32[r];
	} else if (r == GBA_REGION_EWRAM) {
		LOAD_32(value, address & (GBA_SIZE_EWRAM - 4), m->wram);
		wait = m->waitstatesNonseq32[GBA_REGION_EWRAM];
	} else {
		return cpu->memory.load32(cpu, address, cc);
	}
	if (cc) {
		wait += 2;
		if (address < GBA_BASE_ROM0) {
			wait = cirilo_stall(cpu, m, wait);
		}
		*cc += wait;
	}
	int rotate = (address & 3) << 3;
	return ROR(value, rotate);
}

static inline uint32_t cirilo_ld16(struct ARMCore* cpu, uint32_t address, int* cc) {
	struct GBAMemory* m = &((struct GBA*) cpu->master)->memory;
	uint32_t r = address >> BASE_OFFSET;
	uint32_t value;
	int wait;
	if (r == GBA_REGION_IWRAM) {
		LOAD_16(value, address & (GBA_SIZE_IWRAM - 2), m->iwram);
		wait = 0;
	} else if (r >= GBA_REGION_ROM0 && r <= GBA_REGION_ROM2 && (address & (GBA_SIZE_ROM0 - 2)) < m->romSize) {
		LOAD_16(value, address & (GBA_SIZE_ROM0 - 2), m->rom);
		wait = m->waitstatesNonseq16[r];
	} else if (r == GBA_REGION_EWRAM) {
		LOAD_16(value, address & (GBA_SIZE_EWRAM - 2), m->wram);
		wait = m->waitstatesNonseq16[GBA_REGION_EWRAM];
	} else {
		return cpu->memory.load16(cpu, address, cc);
	}
	if (cc) {
		wait += 2;
		if (address < GBA_BASE_ROM0) {
			wait = cirilo_stall(cpu, m, wait);
		}
		*cc += wait;
	}
	int rotate = (address & 1) << 3;
	return ROR(value, rotate);
}

static inline uint32_t cirilo_ld8(struct ARMCore* cpu, uint32_t address, int* cc) {
	struct GBAMemory* m = &((struct GBA*) cpu->master)->memory;
	uint32_t r = address >> BASE_OFFSET;
	uint32_t value;
	int wait;
	if (r == GBA_REGION_IWRAM) {
		value = ((uint8_t*) m->iwram)[address & (GBA_SIZE_IWRAM - 1)];
		wait = 0;
	} else if (r >= GBA_REGION_ROM0 && r <= GBA_REGION_ROM2_EX && (address & (GBA_SIZE_ROM0 - 1)) < m->romSize) {
		value = ((uint8_t*) m->rom)[address & (GBA_SIZE_ROM0 - 1)];
		wait = m->waitstatesNonseq16[r];
	} else if (r == GBA_REGION_EWRAM) {
		value = ((uint8_t*) m->wram)[address & (GBA_SIZE_EWRAM - 1)];
		wait = m->waitstatesNonseq16[GBA_REGION_EWRAM];
	} else {
		return cpu->memory.load8(cpu, address, cc);
	}
	if (cc) {
		wait += 2;
		if (address < GBA_BASE_ROM0) {
			wait = cirilo_stall(cpu, m, wait);
		}
		*cc += wait;
	}
	return value;
}

static inline void cirilo_st32(struct ARMCore* cpu, uint32_t address, int32_t value, int* cc) {
	struct GBAMemory* m = &((struct GBA*) cpu->master)->memory;
	uint32_t r = address >> BASE_OFFSET;
	int wait;
	if (r == GBA_REGION_IWRAM) {
		STORE_32(value, address & (GBA_SIZE_IWRAM - 4), m->iwram);
		wait = 0;
	} else if (r == GBA_REGION_EWRAM) {
		STORE_32(value, address & (GBA_SIZE_EWRAM - 4), m->wram);
		wait = m->waitstatesNonseq32[GBA_REGION_EWRAM];
	} else {
		cpu->memory.store32(cpu, address, value, cc);
		return;
	}
	if (cc) {
		++wait;
		wait = cirilo_stall(cpu, m, wait); /* aquí siempre address < ROM0 */
		*cc += wait;
	}
}

static inline void cirilo_st16(struct ARMCore* cpu, uint32_t address, int16_t value, int* cc) {
	struct GBAMemory* m = &((struct GBA*) cpu->master)->memory;
	uint32_t r = address >> BASE_OFFSET;
	int wait;
	if (r == GBA_REGION_IWRAM) {
		STORE_16(value, address & (GBA_SIZE_IWRAM - 2), m->iwram);
		wait = 0;
	} else if (r == GBA_REGION_EWRAM) {
		STORE_16(value, address & (GBA_SIZE_EWRAM - 2), m->wram);
		wait = m->waitstatesNonseq16[GBA_REGION_EWRAM];
	} else {
		cpu->memory.store16(cpu, address, value, cc);
		return;
	}
	if (cc) {
		++wait;
		wait = cirilo_stall(cpu, m, wait);
		*cc += wait;
	}
}

static inline void cirilo_st8(struct ARMCore* cpu, uint32_t address, int8_t value, int* cc) {
	struct GBAMemory* m = &((struct GBA*) cpu->master)->memory;
	uint32_t r = address >> BASE_OFFSET;
	int wait;
	if (r == GBA_REGION_IWRAM) {
		((int8_t*) m->iwram)[address & (GBA_SIZE_IWRAM - 1)] = value;
		wait = 0;
	} else if (r == GBA_REGION_EWRAM) {
		((int8_t*) m->wram)[address & (GBA_SIZE_EWRAM - 1)] = value;
		wait = m->waitstatesNonseq16[GBA_REGION_EWRAM];
	} else {
		cpu->memory.store8(cpu, address, value, cc);
		return;
	}
	if (cc) {
		++wait;
		wait = cirilo_stall(cpu, m, wait);
		*cc += wait;
	}
}

#endif
