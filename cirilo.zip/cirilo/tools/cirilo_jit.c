
/* ===== Cirilo JIT (fase 1) ==================================================================================================
 * Se añade al FINAL de src/arm/arm.c (ver tools/cirilo_jit_patch.py), así que ve las funciones estáticas del intérprete.
 *
 * Qué hace: traduce a ARM64 bloques de código Thumb que corre desde la ROM del cartucho.
 *  - Las instrucciones aritméticas, lógicas y de desplazamiento por inmediato se traducen en línea.
 *  - Todo lo demás que no cambia de modo (cargas, almacenamientos, PUSH/POP, ramas...) llama al MISMO manejador del intérprete
 *    (_thumbTable), con el estado (PC, cola de búsqueda, ciclos) puesto exactamente como lo dejaría ThumbStep. Así las ramas
 *    siguen pasando por setActiveRegion (detección de bucles ociosos incluida) y la memoria por sus funciones de siempre.
 *  - Los registros del juego siguen viviendo en la estructura del procesador (no hay asignación de registros del host).
 *  - Los ciclos son exactos: cada tramo comprueba al empezar que el intérprete habría ejecutado todas sus instrucciones antes
 *    del siguiente evento; si no, el bloque sale sin ejecutar nada y el intérprete avanza de una en una.
 *  - Solo se compila código en ROM (inmutable). ARM, IWRAM y EWRAM los sigue ejecutando el intérprete.
 * Seguridad: al activarlo se ejecuta una autoprueba (programas Thumb aleatorios, JIT contra intérprete, con memoria falsa). Si
 * algo falla, o la CPU lanza SIGILL/SIGSEGV, el JIT se queda apagado y el motivo sale en el panel.
 * Solo ARM64 y little-endian. Compilación con -DCJ_TEST: el código generado lo ejecuta un emulador ARM64 mínimo (pruebas en x86).
 * ============================================================================================================================ */
#include <mgba/internal/gba/gba.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifndef CJ_TEST
#include <setjmp.h>
#include <signal.h>
#include <sys/mman.h>
#endif

int cirilo_jit_active;

#define CJ_MAX_INSTR 32
#define CJ_TAB_BITS 16
#define CJ_TAB_MASK ((1u << CJ_TAB_BITS) - 1)
#define CJ_RESERVE (24 * 1024)

/* ---------- desplazamientos dentro de ARMCore ---------- */
#define CJ_OFF(m) ((int) offsetof(struct ARMCore, m))
#define CJ_OFF_G(i) (CJ_OFF(gprs) + 4 * (i))
#define CJ_OFF_PF(i) (CJ_OFF(prefetch) + 4 * (i))
#define CJ_OFF_CPSR CJ_OFF(cpsr)
#define CJ_OFF_CYC CJ_OFF(cycles)
#define CJ_OFF_NEXT CJ_OFF(nextEvent)
#define CJ_OFF_SEQ16 CJ_OFF(memory.activeSeqCycles16)

/* ---------- emisor ARM64 ---------- */
typedef struct {
	uint32_t* p;
	uint32_t* end;
	int overflow;
} CJEm;

static void E(CJEm* e, uint32_t w) {
	if (e->p >= e->end) {
		e->overflow = 1;
		return;
	}
	*e->p++ = w;
}

#define R_CPU 19
#define R_C 22
#define CC_GE 10

#define I_LDRW(rt, rn, off) (0xB9400000u | ((((unsigned) (off) >> 2) & 0xFFFu) << 10) | ((rn) << 5) | (rt))
#define I_STRW(rt, rn, off) (0xB9000000u | ((((unsigned) (off) >> 2) & 0xFFFu) << 10) | ((rn) << 5) | (rt))
#define I_ADD_IMM(rd, rn, i) (0x11000000u | (((i) & 0xFFFu) << 10) | ((rn) << 5) | (rd))
#define I_ADDS_IMM(rd, rn, i) (0x31000000u | (((i) & 0xFFFu) << 10) | ((rn) << 5) | (rd))
#define I_SUB_IMM(rd, rn, i) (0x51000000u | (((i) & 0xFFFu) << 10) | ((rn) << 5) | (rd))
#define I_SUBS_IMM(rd, rn, i) (0x71000000u | (((i) & 0xFFFu) << 10) | ((rn) << 5) | (rd))
#define I_ADD_REG(rd, rn, rm) (0x0B000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_ADDS_REG(rd, rn, rm) (0x2B000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_SUB_REG(rd, rn, rm) (0x4B000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_SUBS_REG(rd, rn, rm) (0x6B000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_ADCS(rd, rn, rm) (0x3A000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_SBCS(rd, rn, rm) (0x7A000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_AND(rd, rn, rm) (0x0A000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_ORR(rd, rn, rm) (0x2A000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_EOR(rd, rn, rm) (0x4A000000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_BIC(rd, rn, rm) (0x0A200000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_ORN(rd, rn, rm) (0x2A200000u | ((rm) << 16) | ((rn) << 5) | (rd))
#define I_MOVZ(rd, imm16, hw) (0x52800000u | ((hw) << 21) | (((imm16) & 0xFFFFu) << 5) | (rd))
#define I_MOVK(rd, imm16, hw) (0x72800000u | ((hw) << 21) | (((imm16) & 0xFFFFu) << 5) | (rd))
#define I_MOVZX(rd, imm16, hw) (0xD2800000u | ((hw) << 21) | (((imm16) & 0xFFFFu) << 5) | (rd))
#define I_MOVKX(rd, imm16, hw) (0xF2800000u | ((hw) << 21) | (((imm16) & 0xFFFFu) << 5) | (rd))
#define I_MOVX(rd, rm) (0xAA0003E0u | ((rm) << 16) | (rd))
#define I_UBFM(rd, rn, immr, imms) (0x53000000u | ((immr) << 16) | ((imms) << 10) | ((rn) << 5) | (rd))
#define I_SBFM(rd, rn, immr, imms) (0x13000000u | ((immr) << 16) | ((imms) << 10) | ((rn) << 5) | (rd))
#define I_BFM(rd, rn, immr, imms) (0x33000000u | ((immr) << 16) | ((imms) << 10) | ((rn) << 5) | (rd))
#define I_LSL(rd, rn, s) I_UBFM(rd, rn, (32 - (s)) & 31, 31 - (s))
#define I_LSR(rd, rn, s) I_UBFM(rd, rn, s, 31)
#define I_ASR(rd, rn, s) I_SBFM(rd, rn, s, 31)
#define I_UBFX(rd, rn, lsb, w) I_UBFM(rd, rn, lsb, (lsb) + (w) -1)
#define I_BFI(rd, rn, lsb, w) I_BFM(rd, rn, (32 - (lsb)) & 31, (w) -1)
#define I_MRS_NZCV(rt) (0xD53B4200u | (rt))
#define I_MSR_NZCV(rt) (0xD51B4200u | (rt))
#define I_MADD(rd, rn, rm, ra) (0x1B000000u | ((rm) << 16) | ((ra) << 10) | ((rn) << 5) | (rd))
#define I_BCOND(cc, imm19) (0x54000000u | ((((unsigned) (imm19)) & 0x7FFFFu) << 5) | (cc))
#define I_BLR(rn) (0xD63F0000u | ((rn) << 5))
#define I_RET 0xD65F03C0u
#define I_STP_PRE(rt, rt2, rn, off) (0xA9800000u | ((((unsigned) ((off) / 8)) & 0x7Fu) << 15) | ((rt2) << 10) | ((rn) << 5) | (rt))
#define I_STP(rt, rt2, rn, off) (0xA9000000u | ((((unsigned) ((off) / 8)) & 0x7Fu) << 15) | ((rt2) << 10) | ((rn) << 5) | (rt))
#define I_LDP(rt, rt2, rn, off) (0xA9400000u | ((((unsigned) ((off) / 8)) & 0x7Fu) << 15) | ((rt2) << 10) | ((rn) << 5) | (rt))
#define I_LDP_POST(rt, rt2, rn, off) (0xA8C00000u | ((((unsigned) ((off) / 8)) & 0x7Fu) << 15) | ((rt2) << 10) | ((rn) << 5) | (rt))

static void em_mov32(CJEm* e, int rd, uint32_t v) {
	E(e, I_MOVZ(rd, v & 0xFFFF, 0));
	if (v >> 16) {
		E(e, I_MOVK(rd, v >> 16, 1));
	}
}

static void em_mov64(CJEm* e, int rd, uint64_t v) {
	E(e, I_MOVZX(rd, (unsigned) (v & 0xFFFF), 0));
	int hw;
	for (hw = 1; hw < 4; ++hw) {
		unsigned part = (unsigned) ((v >> (16 * hw)) & 0xFFFF);
		if (part) {
			E(e, I_MOVKX(rd, part, hw));
		}
	}
}

static void em_prologue(CJEm* e) {
	E(e, I_STP_PRE(29, 30, 31, -48));
	E(e, I_STP(19, 20, 31, 16));
	E(e, I_STP(21, 22, 31, 32));
	E(e, I_MOVX(R_CPU, 0));
}

static void em_epilogue(CJEm* e) {
	E(e, I_LDP(21, 22, 31, 32));
	E(e, I_LDP(19, 20, 31, 16));
	E(e, I_LDP_POST(29, 30, 31, 48));
	E(e, I_RET);
}

/* ---------- acceso a la ROM y estado del procesador ---------- */
static int cj_rom_ok(const struct GBA* gba, uint32_t addr, uint32_t bytes) {
	uint32_t reg = addr >> 24;
	if (reg < 8 || reg > 13 || !gba->memory.rom) {
		return 0;
	}
	uint32_t off = addr & (GBA_SIZE_ROM0 - 1);
	return (size_t) off + bytes <= gba->memory.romSize;
}

static uint16_t cj_rom16(const struct GBA* gba, uint32_t addr) {
	return ((const uint16_t*) gba->memory.rom)[(addr & gba->memory.romMask) >> 1];
}

static void em_store_const(CJEm* e, int off, uint32_t v) {
	em_mov32(e, 0, v);
	E(e, I_STRW(0, R_CPU, off));
}

/* Estado del procesador tal como lo deja ThumbStep MIENTRAS ejecuta la instrucción en `addr`. */
static void em_state_exec(CJEm* e, const struct GBA* gba, uint32_t addr) {
	em_store_const(e, CJ_OFF_G(ARM_PC), addr + 4);
	em_store_const(e, CJ_OFF_PF(0), cj_rom16(gba, addr + 2));
	em_store_const(e, CJ_OFF_PF(1), cj_rom16(gba, addr + 4));
}

/* Estado en reposo antes de ejecutar la instrucción en `addr`. */
static void em_state_rest(CJEm* e, const struct GBA* gba, uint32_t addr) {
	em_store_const(e, CJ_OFF_G(ARM_PC), addr + 2);
	em_store_const(e, CJ_OFF_PF(0), cj_rom16(gba, addr));
	em_store_const(e, CJ_OFF_PF(1), cj_rom16(gba, addr + 2));
}

/* cpu->cycles += pend * c (c en R_C) */
static void em_flush(CJEm* e, int pend) {
	if (pend <= 0) {
		return;
	}
	E(e, I_LDRW(0, R_CPU, CJ_OFF_CYC));
	if (pend == 1) {
		E(e, I_ADD_REG(0, 0, R_C));
	} else {
		em_mov32(e, 1, (uint32_t) pend);
		E(e, I_MADD(0, R_C, 1, 0));
	}
	E(e, I_STRW(0, R_CPU, CJ_OFF_CYC));
}

/* Comprobación de inicio de tramo. Devuelve la posición de la rama a parchear. */
static uint32_t* em_check(CJEm* e, int m) {
	E(e, I_LDRW(R_C, R_CPU, CJ_OFF_SEQ16));
	E(e, I_ADD_IMM(R_C, R_C, 1));
	E(e, I_LDRW(0, R_CPU, CJ_OFF_CYC));
	E(e, I_LDRW(1, R_CPU, CJ_OFF_NEXT));
	if (m > 0) {
		em_mov32(e, 2, (uint32_t) m);
		E(e, I_MADD(0, R_C, 2, 0));
	}
	E(e, I_SUBS_REG(31, 0, 1));
	uint32_t* at = e->p;
	E(e, I_BCOND(CC_GE, 0));
	return at;
}

static void em_patch_bcond(uint32_t* at, const uint32_t* target) {
	ptrdiff_t d = target - at;
	*at = I_BCOND(CC_GE, d);
}

/* ---------- flags ---------- */
static void em_flags_full(CJEm* e) {
	E(e, I_MRS_NZCV(2));
	E(e, I_LSR(2, 2, 28));
	E(e, I_LDRW(3, R_CPU, CJ_OFF_CPSR));
	E(e, I_BFI(3, 2, 28, 4));
	E(e, I_STRW(3, R_CPU, CJ_OFF_CPSR));
}

/* N y Z a partir de w0; si cReg >= 0, ese registro (0/1) pasa a ser C */
static void em_flags_nz(CJEm* e, int cReg) {
	E(e, I_SUBS_IMM(31, 0, 0));
	E(e, I_MRS_NZCV(2));
	E(e, I_LSR(2, 2, 30));
	E(e, I_LDRW(3, R_CPU, CJ_OFF_CPSR));
	E(e, I_BFI(3, 2, 30, 2));
	if (cReg >= 0) {
		E(e, I_BFI(3, cReg, 29, 1));
	}
	E(e, I_STRW(3, R_CPU, CJ_OFF_CPSR));
}

static void em_load_host_flags(CJEm* e) {
	E(e, I_LDRW(3, R_CPU, CJ_OFF_CPSR));
	E(e, I_MSR_NZCV(3));
}

#define LDG(rt, g) E(e, I_LDRW(rt, R_CPU, CJ_OFF_G(g)))
#define STG(rt, g) E(e, I_STRW(rt, R_CPU, CJ_OFF_G(g)))

/* ---------- clasificación ----------
 * 0 = no soportada: el bloque termina ANTES de ella y la ejecuta el intérprete
 * 1 = en línea
 * 2 = llamada al manejador del intérprete, no cambia el PC
 * 3 = llamada al manejador, puede cambiar el PC: fin de bloque */
static int cj_classify(unsigned op) {
	switch (op >> 11) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
		return 1;
	case 8:
		if ((op >> 10) == 0x10) {
			switch ((op >> 6) & 15) {
			case 2:
			case 3:
			case 4:
			case 7:
			case 13:
				return 2;
			default:
				return 1;
			}
		} else {
			int sub = (op >> 8) & 3;
			int rd = (op & 7) | ((op >> 4) & 8);
			int rm = (op >> 3) & 15;
			if (sub == 3) {
				return 3;
			}
			if (rd == 15 && sub != 1) {
				return 3;
			}
			if (rd == 15 || rm == 15) {
				return 2;
			}
			return 1;
		}
	case 9:
		return 2;
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
		return 2;
	case 20:
	case 21:
		return 1;
	case 22:
	case 23:
		if ((op >> 8) == 0xB0) {
			return 1;
		}
		if ((op >> 9) == 0x5A) {
			return 2;
		}
		if ((op >> 9) == 0x5E) {
			return (op & 0x100) ? 3 : 2;
		}
		return 0;
	case 24:
		return 2;
	case 25:
		return (op & 0xFF) ? 2 : 3;
	case 26:
	case 27:
		return (((op >> 8) & 15) < 14) ? 3 : 0;
	case 28:
		return 3;
	case 29:
		return 0;
	case 30:
		return 2;
	case 31:
		return 3;
	}
	return 0;
}

/* ---------- instrucciones en línea ---------- */
static void cj_emit_alu(CJEm* e, unsigned op, uint32_t addr) {
	switch (op >> 11) {
	case 0:
	case 1:
	case 2: {
		int kind = op >> 11, imm = (op >> 6) & 31, rm = (op >> 3) & 7, rd = op & 7, c = -1;
		LDG(0, rm);
		if (kind == 0) {
			if (imm) {
				E(e, I_UBFX(5, 0, 32 - imm, 1));
				E(e, I_LSL(0, 0, imm));
				c = 5;
			}
		} else if (kind == 1) {
			if (imm) {
				E(e, I_UBFX(5, 0, imm - 1, 1));
				E(e, I_LSR(0, 0, imm));
			} else {
				E(e, I_UBFX(5, 0, 31, 1));
				E(e, I_MOVZ(0, 0, 0));
			}
			c = 5;
		} else {
			if (imm) {
				E(e, I_UBFX(5, 0, imm - 1, 1));
				E(e, I_ASR(0, 0, imm));
			} else {
				E(e, I_UBFX(5, 0, 31, 1));
				E(e, I_ASR(0, 0, 31));
			}
			c = 5;
		}
		STG(0, rd);
		em_flags_nz(e, c);
		return;
	}
	case 3: {
		int isImm = (op >> 10) & 1, sub = (op >> 9) & 1, v = (op >> 6) & 7, rn = (op >> 3) & 7, rd = op & 7;
		LDG(0, rn);
		if (isImm) {
			E(e, sub ? I_SUBS_IMM(0, 0, v) : I_ADDS_IMM(0, 0, v));
		} else {
			LDG(1, v);
			E(e, sub ? I_SUBS_REG(0, 0, 1) : I_ADDS_REG(0, 0, 1));
		}
		STG(0, rd);
		em_flags_full(e);
		return;
	}
	case 4:
	case 5:
	case 6:
	case 7: {
		int sub = (op >> 11) & 3, rd = (op >> 8) & 7;
		unsigned imm = op & 0xFF;
		if (sub == 0) {
			E(e, I_MOVZ(0, imm, 0));
			STG(0, rd);
			E(e, I_LDRW(3, R_CPU, CJ_OFF_CPSR));
			E(e, I_MOVZ(4, imm == 0 ? 1 : 0, 0));
			E(e, I_BFI(3, 4, 30, 2));
			E(e, I_STRW(3, R_CPU, CJ_OFF_CPSR));
			return;
		}
		LDG(0, rd);
		if (sub == 1) {
			E(e, I_SUBS_IMM(31, 0, imm));
		} else {
			E(e, sub == 2 ? I_ADDS_IMM(0, 0, imm) : I_SUBS_IMM(0, 0, imm));
			STG(0, rd);
		}
		em_flags_full(e);
		return;
	}
	case 8:
		if ((op >> 10) == 0x10) {
			int opc = (op >> 6) & 15, rd = op & 7, rn = (op >> 3) & 7;
			switch (opc) {
			case 0: /* AND */
			case 1: /* EOR */
			case 12: /* ORR */
			case 14: /* BIC */
			case 8: /* TST */
				LDG(0, rd);
				LDG(1, rn);
				E(e, opc == 1 ? I_EOR(0, 0, 1) : opc == 12 ? I_ORR(0, 0, 1) : opc == 14 ? I_BIC(0, 0, 1) : I_AND(0, 0, 1));
				if (opc != 8) {
					STG(0, rd);
				}
				em_flags_nz(e, -1);
				return;
			case 15: /* MVN */
				LDG(1, rn);
				E(e, I_ORN(0, 31, 1));
				STG(0, rd);
				em_flags_nz(e, -1);
				return;
			case 5: /* ADC */
			case 6: /* SBC */
				em_load_host_flags(e);
				LDG(0, rd);
				LDG(1, rn);
				E(e, opc == 5 ? I_ADCS(0, 0, 1) : I_SBCS(0, 0, 1));
				STG(0, rd);
				em_flags_full(e);
				return;
			case 9: /* NEG */
				LDG(1, rn);
				E(e, I_SUBS_REG(0, 31, 1));
				STG(0, rd);
				em_flags_full(e);
				return;
			case 10: /* CMP */
			case 11: /* CMN */
				LDG(0, rd);
				LDG(1, rn);
				E(e, opc == 10 ? I_SUBS_REG(31, 0, 1) : I_ADDS_REG(31, 0, 1));
				em_flags_full(e);
				return;
			}
		} else {
			int sub = (op >> 8) & 3;
			int rd = (op & 7) | ((op >> 4) & 8);
			int rm = (op >> 3) & 15;
			if (sub == 0) {
				LDG(0, rd);
				LDG(1, rm);
				E(e, I_ADD_REG(0, 0, 1));
				STG(0, rd);
			} else if (sub == 1) {
				LDG(0, rd);
				LDG(1, rm);
				E(e, I_SUBS_REG(31, 0, 1));
				em_flags_full(e);
			} else {
				LDG(0, rm);
				STG(0, rd);
			}
			return;
		}
		return;
	case 20: { /* ADD Rd, PC, #imm */
		int rd = (op >> 8) & 7;
		uint32_t v = ((addr + 4) & 0xFFFFFFFCu) + ((op & 0xFF) << 2);
		em_mov32(e, 0, v);
		STG(0, rd);
		return;
	}
	case 21: { /* ADD Rd, SP, #imm */
		int rd = (op >> 8) & 7;
		LDG(0, ARM_SP);
		E(e, I_ADD_IMM(0, 0, (op & 0xFF) << 2));
		STG(0, rd);
		return;
	}
	case 22:
	case 23: { /* ADD/SUB SP, #imm7 */
		unsigned imm = (op & 0x7F) << 2;
		LDG(0, ARM_SP);
		E(e, (op & 0x80) ? I_SUB_IMM(0, 0, imm) : I_ADD_IMM(0, 0, imm));
		STG(0, ARM_SP);
		return;
	}
	}
}

/* ---------- compilación de un bloque ---------- */
struct CJEntry {
	uint32_t addr;
	uint32_t w0, w1;
	int (*fn)(struct ARMCore*);
	uint8_t state; /* 0 vacía, 1 compilada, 2 no compilable */
	uint8_t n;
	uint8_t nAlu, nMem, nTerm; /* mezcla estática del bloque, para las estadísticas */
};

struct CJCache {
	struct CJEntry* tab;
	uint32_t* code;
	size_t cap; /* en palabras */
	size_t used;
	uint64_t blocks, flushes, jitCycles, totCycles;
	/* estadísticas (cirilo_jit_take) */
	uint64_t cycArm, cycThumbRam, cycThumbRom, runs, fails, dynAlu, dynMem, dynTerm, compiledDelta;
	unsigned rr;
	uint8_t hot; /* visitas necesarias antes de compilar (0 = compilar enseguida; las pruebas usan 0) */
	uint8_t heat[CJ_TAB_MASK + 1];
};

static struct CJCache cj_real;

static void cj_flush(struct CJCache* c) {
	if (c->tab) {
		memset(c->tab, 0, sizeof(struct CJEntry) * (CJ_TAB_MASK + 1));
	}
	memset(c->heat, 0, sizeof(c->heat));
	c->used = 0;
	c->flushes++;
}

static struct CJEntry* cj_find(struct CJCache* c, uint32_t addr) {
	uint32_t i = (addr >> 1) & CJ_TAB_MASK;
	struct CJEntry* a = &c->tab[i];
	if (a->addr == addr && a->state) {
		return a;
	}
	struct CJEntry* b = &c->tab[i ^ 1];
	if (b->addr == addr && b->state) {
		return b;
	}
	return NULL;
}

static struct CJEntry* cj_compile(struct CJCache* c, struct ARMCore* cpu, struct GBA* gba, uint32_t addr) {
	if ((c->used + CJ_RESERVE / 4) > c->cap) {
		cj_flush(c);
	}
	struct CJEntry* ea = &c->tab[(addr >> 1) & CJ_TAB_MASK];
	struct CJEntry* eb = &c->tab[((addr >> 1) & CJ_TAB_MASK) ^ 1];
	struct CJEntry* ent = !ea->state ? ea : !eb->state ? eb : ((c->rr++ & 1) ? eb : ea);
	ent->addr = addr;
	ent->state = 2;
	ent->fn = NULL;
	ent->n = 0;
	if (!cj_rom_ok(gba, addr, 6)) {
		return ent;
	}

	unsigned ops[CJ_MAX_INSTR];
	int kinds[CJ_MAX_INSTR];
	int n = 0;
	while (n < CJ_MAX_INSTR) {
		uint32_t a = addr + 2 * n;
		if ((a >> 24) != (addr >> 24) || !cj_rom_ok(gba, a, 6)) {
			break;
		}
		unsigned op = cj_rom16(gba, a);
		int k = cj_classify(op);
		if (!k) {
			break;
		}
		ops[n] = op;
		kinds[n] = k;
		++n;
		if (k == 3) {
			break;
		}
	}
	int terminal = n > 0 && kinds[n - 1] == 3;
	if (!terminal && n > 0 && !cj_rom_ok(gba, addr + 2 * n, 4)) {
		--n;
	}
	if (n == 0) {
		return ent;
	}
	terminal = kinds[n - 1] == 3;

	CJEm em;
	em.p = c->code + c->used;
	em.end = c->code + c->cap;
	em.overflow = 0;
	CJEm* e = &em;
	uint32_t* start = em.p;

	struct {
		uint32_t* at;
		uint32_t addr;
	} fix[CJ_MAX_INSTR + 1];
	int nfix = 0;

	em_prologue(e);
	int i = 0, pend = 0;
	while (i < n) {
		int t = i;
		while (t < n && kinds[t] == 1) {
			++t;
		}
		int m = (t < n) ? (t - i) : (t - i - 1);
		if (m < 0) {
			m = 0;
		}
		fix[nfix].at = em_check(e, m);
		fix[nfix].addr = (i == 0) ? 0xFFFFFFFFu : addr + 2 * i;
		++nfix;
		for (; i < t; ++i) {
			cj_emit_alu(e, ops[i], addr + 2 * i);
			++pend;
		}
		if (t < n) {
			uint32_t a = addr + 2 * t;
			em_flush(e, pend);
			pend = 0;
			em_state_exec(e, gba, a);
			E(e, I_MOVX(0, R_CPU));
			em_mov32(e, 1, ops[t]);
			em_mov64(e, 16, (uint64_t) (uintptr_t) _thumbTable[ops[t] >> 6]);
			E(e, I_BLR(16));
			i = t + 1;
		}
	}
	if (!terminal) {
		em_flush(e, pend);
		em_state_rest(e, gba, addr + 2 * n);
	}
	E(e, I_MOVZ(0, 1, 0));
	em_epilogue(e);
	/* salidas por falta de tiempo antes del siguiente evento */
	int f;
	for (f = 0; f < nfix; ++f) {
		em_patch_bcond(fix[f].at, em.p);
		if (fix[f].addr == 0xFFFFFFFFu) {
			E(e, I_MOVZ(0, 0, 0));
		} else {
			em_state_rest(e, gba, fix[f].addr);
			E(e, I_MOVZ(0, 1, 0));
		}
		em_epilogue(e);
	}
	if (em.overflow) {
		return ent;
	}
#ifndef CJ_TEST
	__builtin___clear_cache((char*) start, (char*) em.p);
#endif
	c->used += (size_t) (em.p - start);
	c->blocks++;
	ent->fn = (int (*)(struct ARMCore*)) (void*) start;
	ent->w0 = cj_rom16(gba, addr);
	ent->w1 = cj_rom16(gba, addr + 2);
	ent->n = (uint8_t) n;
	ent->nAlu = ent->nMem = ent->nTerm = 0;
	for (f = 0; f < n; ++f) {
		if (kinds[f] == 1) {
			ent->nAlu++;
		} else if (kinds[f] == 2) {
			ent->nMem++;
		} else {
			ent->nTerm++;
		}
	}
	c->compiledDelta++;
	ent->state = 1;
	return ent;
}

#ifdef CJ_TEST
#define CJ_CALL(fn, cpu) cj_test_exec((const uint32_t*) (void*) (fn), (cpu))
#else
#define CJ_CALL(fn, cpu) ((fn)(cpu))
#endif

/* Ejecuta hasta cpu->cycles >= cpu->nextEvent, igual que el bucle del intérprete. */
static void cj_run(struct CJCache* c, struct ARMCore* cpu) {
	struct GBA* gba = (struct GBA*) cpu->master;
	int32_t start = cpu->cycles;
	uint64_t jc = 0;
	while (cpu->cycles < cpu->nextEvent) {
		int32_t c0 = cpu->cycles;
		if (cpu->executionMode == MODE_THUMB) {
			uint32_t addr = (uint32_t) cpu->gprs[ARM_PC] - 2;
			if ((addr >> 24) - 8u <= 5u) { /* solo se compila código de la ROM */
				struct CJEntry* ent = cj_find(c, addr);
				if (!ent) {
					uint8_t* h = &c->heat[(addr >> 1) & CJ_TAB_MASK];
					if (!c->hot || ++*h >= c->hot) {
						*h = 0;
						ent = cj_compile(c, cpu, gba, addr);
					}
				}
				if (ent && ent->fn && gba->memory.activeRegion == (int) (addr >> 24) && cpu->memory.activeRegion == gba->memory.rom &&
				    cpu->prefetch[0] == ent->w0 && cpu->prefetch[1] == ent->w1) {
					if (CJ_CALL(ent->fn, cpu)) {
						jc += (uint64_t) (cpu->cycles - c0);
						c->runs++;
						c->dynAlu += ent->nAlu;
						c->dynMem += ent->nMem;
						c->dynTerm += ent->nTerm;
						continue;
					}
					c->fails++;
				}
				ThumbStep(cpu);
				c->cycThumbRom += (uint64_t) (cpu->cycles - c0);
			} else {
				ThumbStep(cpu);
				c->cycThumbRam += (uint64_t) (cpu->cycles - c0);
			}
		} else {
			ARMStep(cpu);
			c->cycArm += (uint64_t) (cpu->cycles - c0);
		}
	}
	c->jitCycles += jc;
	c->totCycles += (uint64_t) (cpu->cycles - start);
}

/* ---------- autoprueba: programas Thumb aleatorios, JIT contra intérprete, con memoria falsa ---------- */
static struct {
	uint32_t hash;
	uint32_t nset, nops;
} cj_fk;
static uint32_t* cj_fk_ram;

static void cj_fk_mix(uint32_t v) {
	cj_fk.hash = (cj_fk.hash ^ v) * 16777619u + 0x9E3779B9u;
}

static uint32_t cj_rng_state = 1;
static uint32_t cj_seed = 0x1234ABCDu;
static int cj_trace_run = -1; /* solo pruebas */
static int cj_force_op = -1; /* solo pruebas: rellena la ROM falsa con una única instrucción */
static uint32_t cj_rnd(void) {
	uint32_t x = cj_rng_state;
	x ^= x << 13;
	x ^= x >> 17;
	x ^= x << 5;
	return cj_rng_state = x;
}

static uint32_t cj_fk_ld(struct ARMCore* cpu, uint32_t addr, int* cyc, int size) {
	cj_fk.nops++;
#ifdef CJ_TRACE
	fprintf(stderr, "  L%d addr=%08X cyc=%d pc=%08X pf0=%04X pf1=%04X\n", size, addr, cpu->cycles, (unsigned) cpu->gprs[ARM_PC], cpu->prefetch[0], cpu->prefetch[1]);
#endif
	uint32_t v = (addr * 2654435761u) ^ (cpu->prefetch[1] * 40503u) ^ ((uint32_t) cpu->gprs[ARM_PC] * 2246822519u) ^ (uint32_t) cpu->cycles;
	cj_fk_mix(addr ^ 0x1000u ^ (uint32_t) size);
	cj_fk_mix((uint32_t) cpu->cycles ^ ((uint32_t) cpu->gprs[ARM_PC] << 7) ^ cpu->prefetch[0] ^ (cpu->prefetch[1] << 3));
	*cyc += 1 + (int) (addr & 3);
	return size == 4 ? v : size == 2 ? (v & 0xFFFF) : (v & 0xFF);
}
static uint32_t cj_fk_load32(struct ARMCore* cpu, uint32_t a, int* c) { return cj_fk_ld(cpu, a, c, 4); }
static uint32_t cj_fk_load16(struct ARMCore* cpu, uint32_t a, int* c) { return cj_fk_ld(cpu, a, c, 2); }
static uint32_t cj_fk_load8(struct ARMCore* cpu, uint32_t a, int* c) { return cj_fk_ld(cpu, a, c, 1); }
static void cj_fk_st(struct ARMCore* cpu, uint32_t addr, int32_t value, int* cyc, int size) {
	cj_fk.nops++;
#ifdef CJ_TRACE
	fprintf(stderr, "  S%d addr=%08X cyc=%d pc=%08X pf0=%04X pf1=%04X\n", size, addr, cpu->cycles, (unsigned) cpu->gprs[ARM_PC], cpu->prefetch[0], cpu->prefetch[1]);
#endif
	cj_fk_mix(addr ^ 0x2000u ^ (uint32_t) size);
	cj_fk_mix((uint32_t) value ^ (uint32_t) cpu->cycles ^ ((uint32_t) cpu->gprs[ARM_PC] << 7) ^ cpu->prefetch[0] ^ (cpu->prefetch[1] << 3));
	*cyc += 1 + (int) (addr & 3);
	if ((addr & 0xFF) == 0x5A) {
		cpu->nextEvent = cpu->cycles; /* como una escritura de E/S que pide procesar eventos ya */
	} else if ((addr & 0xFF) == 0xA5) {
		cpu->memory.activeSeqCycles16 += 1; /* como un cambio de WAITCNT */
	}
}
static void cj_fk_store32(struct ARMCore* cpu, uint32_t a, int32_t v, int* c) { cj_fk_st(cpu, a, v, c, 4); }
static void cj_fk_store16(struct ARMCore* cpu, uint32_t a, int16_t v, int* c) { cj_fk_st(cpu, a, v, c, 2); }
static void cj_fk_store8(struct ARMCore* cpu, uint32_t a, int8_t v, int* c) { cj_fk_st(cpu, a, v, c, 1); }
static uint32_t cj_fk_loadm(struct ARMCore* cpu, uint32_t addr, int mask, enum LSMDirection dir, int* cyc) {
	int i;
	(void) dir;
	for (i = 0; i < 16; ++i) {
		if (mask & (1 << i)) {
			cpu->gprs[i] = (int32_t) cj_fk_ld(cpu, addr, cyc, 4);
			addr += 4;
		}
	}
	return addr;
}
static uint32_t cj_fk_storem(struct ARMCore* cpu, uint32_t addr, int mask, enum LSMDirection dir, int* cyc) {
	int i;
	if (dir & LSM_D) {
		for (i = 15; i >= 0; --i) {
			if (mask & (1 << i)) {
				addr -= 4;
				cj_fk_st(cpu, addr, cpu->gprs[i], cyc, 4);
			}
		}
		return addr;
	}
	for (i = 0; i < 16; ++i) {
		if (mask & (1 << i)) {
			cj_fk_st(cpu, addr, cpu->gprs[i], cyc, 4);
			addr += 4;
		}
	}
	return addr;
}
static int32_t cj_fk_stall(struct ARMCore* cpu, int32_t wait) {
	(void) cpu;
	return wait;
}
static void cj_fk_setregion(struct ARMCore* cpu, uint32_t addr) {
	struct GBA* gba = (struct GBA*) cpu->master;
	cj_fk.nset++;
	cj_fk_mix(addr ^ 0x3000u);
	int reg = (int) (addr >> 24);
	if (reg >= 8 && reg <= 13 && (addr & (GBA_SIZE_ROM0 - 1)) < gba->memory.romSize) {
		gba->memory.activeRegion = reg;
		cpu->memory.activeRegion = gba->memory.rom;
		cpu->memory.activeMask = gba->memory.romMask;
		cpu->memory.activeSeqCycles16 = gba->memory.waitstatesSeq16[reg];
		cpu->memory.activeNonseqCycles16 = gba->memory.waitstatesNonseq16[reg];
	} else {
		gba->memory.activeRegion = 3;
		cpu->memory.activeRegion = cj_fk_ram;
		cpu->memory.activeMask = 0xFFFF;
		cpu->memory.activeSeqCycles16 = 0;
		cpu->memory.activeNonseqCycles16 = 0;
	}
	cpu->memory.activeMask &= ~1u;
}

static unsigned cj_gen_op(void) {
	unsigned r = cj_rnd(), v = cj_rnd();
	switch (r % 24) {
	case 0:
	case 1:
		return (((v >> 9) % 3) << 11) | (((v >> 6) & 31) << 6) | (v & 63);
	case 2:
	case 3:
		return 0x1800 | (v & 0x7FF);
	case 4:
	case 5:
	case 6:
		return 0x2000 | (v & 0x1FFF);
	case 7:
	case 8:
	case 9:
		return 0x4000 | (v & 0x3FF);
	case 10:
	case 11: {
		unsigned sub = (v >> 8) % 3; /* sin BX */
		unsigned hh = (v >> 6) & 3;
		unsigned rd = v & 7, rm = (v >> 3) & 7;
		if (!(cj_rnd() & 7)) {
			rd = 7;
			hh |= 2; /* a veces rd = PC */
		}
		return 0x4400 | (sub << 8) | (hh << 6) | (rm << 3) | rd;
	}
	case 12:
		return 0xA000 | (v & 0xFFF);
	case 13:
		return 0xB000 | (v & 0xFF);
	case 14:
	case 15:
	case 16:
		return 0x5000 | (v & 0xFFF);
	case 17:
	case 18:
	case 19:
		return 0x6000 | (v & 0x3FFF);
	case 20:
		return ((v & 1) ? 0xB400 : 0xBC00) | (v & 0x1FF);
	case 21:
		return 0xC000 | (v & 0xFFF);
	case 22: {
		unsigned cond = v % 14;
		return 0xD000 | (cond << 8) | ((v >> 8) & 0xFF);
	}
	default:
		return 0xE000 | (v & 0x7FF);
	}
}

static const char* cj_diff(const struct ARMCore* a, const struct ARMCore* b, uint32_t ha, uint32_t hb, char* buf, size_t n) {
	int i;
	for (i = 0; i < 16; ++i) {
		if (a->gprs[i] != b->gprs[i]) {
			snprintf(buf, n, "r%d esperado %08X obtenido %08X", i, (unsigned) a->gprs[i], (unsigned) b->gprs[i]);
			return buf;
		}
	}
#define CJ_CMP(f, name)                                                                                                \
	if ((uint32_t) (a->f) != (uint32_t) (b->f)) {                                                                      \
		snprintf(buf, n, name " esperado %08X obtenido %08X", (unsigned) (a->f), (unsigned) (b->f));                  \
		return buf;                                                                                                    \
	}
	CJ_CMP(cpsr.packed, "cpsr")
	CJ_CMP(cycles, "ciclos")
	CJ_CMP(nextEvent, "evento")
	CJ_CMP(prefetch[0], "cola0")
	CJ_CMP(prefetch[1], "cola1")
	CJ_CMP(memory.activeSeqCycles16, "seq16")
	CJ_CMP(memory.activeNonseqCycles16, "nseq16")
	CJ_CMP(executionMode, "modo")
#undef CJ_CMP
	if (a->memory.activeRegion != b->memory.activeRegion) {
		snprintf(buf, n, "region activa distinta");
		return buf;
	}
	if (ha != hb) {
		snprintf(buf, n, "llamadas a memoria distintas");
		return buf;
	}
	return NULL;
}

/* Devuelve NULL si todo coincide; si no, el motivo en err. */
static const char* cj_selftest(struct CJCache* c, int runs, char* err, size_t errn) {
	const uint32_t romBytes = 0x10000;
	struct GBA* gba = (struct GBA*) calloc(1, sizeof(struct GBA));
	struct ARMCore* ref = (struct ARMCore*) calloc(1, sizeof(struct ARMCore));
	struct ARMCore* jit = (struct ARMCore*) calloc(1, sizeof(struct ARMCore));
	uint32_t* rom = (uint32_t*) calloc(1, romBytes);
	cj_fk_ram = (uint32_t*) calloc(1, 0x10000);
	const char* res = NULL;
	if (!gba || !ref || !jit || !rom || !cj_fk_ram) {
		snprintf(err, errn, "sin memoria para la autoprueba");
		res = err;
		goto done;
	}
	cj_rng_state = cj_seed;
	uint16_t* r16 = (uint16_t*) rom;
	uint32_t i;
	for (i = 0; i < romBytes / 2; ++i) {
		if (cj_force_op >= 0) {
			r16[i] = (uint16_t) cj_force_op;
			continue;
		}
		unsigned op = cj_gen_op();
		if ((op >> 11) == 0x1C) {
			op = 0xE000 | ((op & 0x7FF) % 0x20);
		}
		r16[i] = (uint16_t) op;
		if (!(cj_rnd() % 40) && i + 1 < romBytes / 2) { /* par BL */
			unsigned hi = cj_rnd(), lo = cj_rnd();
			r16[i] = (uint16_t) (0xF000 | (hi & 0x7));
			r16[i + 1] = (uint16_t) (0xF800 | (lo & 0x7F));
			++i;
		}
	}
	gba->cpu = ref;
	ref->master = &gba->d;
	jit->master = &gba->d;
	gba->memory.rom = rom;
	gba->memory.romSize = romBytes;
	gba->memory.romMask = romBytes - 1;
	{
		static const char ns[3] = { 3, 4, 8 }, sq[3] = { 1, 4, 8 };
		int k;
		for (k = 0; k < 6; ++k) {
			gba->memory.waitstatesNonseq16[8 + k] = ns[k >> 1];
			gba->memory.waitstatesSeq16[8 + k] = sq[k >> 1];
		}
	}
	ref->memory.load32 = cj_fk_load32;
	ref->memory.load16 = cj_fk_load16;
	ref->memory.load8 = cj_fk_load8;
	ref->memory.store32 = cj_fk_store32;
	ref->memory.store16 = cj_fk_store16;
	ref->memory.store8 = cj_fk_store8;
	ref->memory.loadMultiple = cj_fk_loadm;
	ref->memory.storeMultiple = cj_fk_storem;
	ref->memory.stall = cj_fk_stall;
	ref->memory.setActiveRegion = cj_fk_setregion;
	ref->executionMode = MODE_THUMB;

	int run;
	for (run = 0; run < runs; ++run) {
		static const uint32_t bases[3] = { 0x08000000u, 0x0A000000u, 0x0C000000u };
		uint32_t x = bases[cj_rnd() % 3] + ((cj_rnd() % (romBytes / 2 - 64)) << 1);
		int k;
		for (k = 0; k < 13; ++k) {
			uint32_t v = cj_rnd();
			switch (cj_rnd() & 7) {
			case 0:
				v &= 0xFF;
				break;
			case 1:
				v = (v & 0xFFFFFF00u) | 0x5A;
				break;
			case 2:
				v = (v & 0xFFFFFF00u) | 0xA5;
				break;
			case 3:
				v = 0x80000000u >> (v & 7);
				break;
			case 4:
			case 5: {
				static const uint32_t edge[] = { 0, 1, 2, 0x7FFFFFFFu, 0x80000000u, 0x80000001u, 0xFFFFFFFFu, 0xFFFFFFFEu, 0xFFFFu, 0xFFFF0000u, 0x10000u, 0xFFu };
				v = edge[cj_rnd() % (sizeof edge / sizeof edge[0])];
				break;
			}
			default:
				break;
			}
			ref->gprs[k] = (int32_t) v;
		}
		ref->gprs[ARM_SP] = (int32_t) (0x03007F00u + (cj_rnd() & 0xFC));
		ref->gprs[ARM_LR] = (int32_t) cj_rnd();
		ref->cpsr.packed = (int32_t) ((cj_rnd() & 0xF0000000u) | 0x3F);
		ref->cycles = (int32_t) (cj_rnd() % 30);
		ref->nextEvent = ref->cycles + 4 + (int32_t) (cj_rnd() % 260);
		ref->executionMode = MODE_THUMB;
		cj_fk.hash = 0;
		cj_fk.nset = cj_fk.nops = 0;
		cj_fk_setregion(ref, x);
		ref->gprs[ARM_PC] = (int32_t) (x + 2);
		ref->prefetch[0] = cj_rom16(gba, x);
		ref->prefetch[1] = cj_rom16(gba, x + 2);
		int savedRegion = gba->memory.activeRegion;
		if (cj_rnd() & 1) {
			/* el siguiente evento cae justo en el límite de alguna instrucción (±1), para probar los bordes */
			int32_t tr[48];
			int nt = 0;
			memcpy(jit, ref, sizeof(*ref));
			jit->nextEvent = jit->cycles + 100000;
			while (nt < 48 && jit->cycles < jit->nextEvent) {
				tr[nt++] = jit->cycles;
				if (jit->executionMode == MODE_THUMB) {
					ThumbStep(jit);
				} else {
					ARMStep(jit);
				}
			}
			gba->memory.activeRegion = savedRegion;
			if (nt) {
				int32_t t = tr[cj_rnd() % nt] + (int32_t) (cj_rnd() % 3) - 1;
				if (t > ref->cycles) {
					ref->nextEvent = t;
				}
			}
		}
		memcpy(jit, ref, sizeof(*ref));
		jit->master = &gba->d;
		cj_fk.hash = 0;
		cj_fk.nset = cj_fk.nops = 0;
		/* referencia: solo el intérprete */
#ifdef CJ_TRACE
		fprintf(stderr, "RUN %d x=%08X cyc=%d next=%d\n REF\n", run, (unsigned) x, ref->cycles, ref->nextEvent);
#endif
		while (ref->cycles < ref->nextEvent) {
			if (run == cj_trace_run) {
				fprintf(stderr, "  ref pc=%08X op=%04X cpsr=%08X cyc=%d next=%d r0=%08X r1=%08X r2=%08X r3=%08X\n", (unsigned) ref->gprs[ARM_PC] - 2, ref->prefetch[0], (unsigned) ref->cpsr.packed, ref->cycles, ref->nextEvent, (unsigned) ref->gprs[0], (unsigned) ref->gprs[1], (unsigned) ref->gprs[2], (unsigned) ref->gprs[3]);
			}
			if (ref->executionMode == MODE_THUMB) {
				ThumbStep(ref);
			} else {
				ARMStep(ref);
			}
		}
		uint32_t hashRef = cj_fk.hash;
		uint32_t nsetRef = cj_fk.nset;
		int regionRef = gba->memory.activeRegion;
		/* JIT */
#ifdef CJ_TRACE
		fprintf(stderr, " JIT\n");
#endif
		cj_fk.hash = 0;
		cj_fk.nset = cj_fk.nops = 0;
		gba->memory.activeRegion = savedRegion;
		gba->cpu = jit;
		cj_run(c, jit);
		gba->cpu = ref;
		const char* d = cj_diff(ref, jit, hashRef, cj_fk.hash, err, errn);
		if (!d && (nsetRef != cj_fk.nset || regionRef != gba->memory.activeRegion)) {
			snprintf(err, errn, "setActiveRegion distinto");
			d = err;
		}
		if (d) {
			char head[80];
			snprintf(head, sizeof head, "[%d @%08X op %04X]", run, (unsigned) x, (unsigned) cj_rom16(gba, x));
			char tmp[160];
			snprintf(tmp, sizeof tmp, "%s %s", head, d);
			snprintf(err, errn, "%s", tmp);
			res = err;
			goto done;
		}
	}
done:
	free(gba);
	free(ref);
	free(jit);
	free(rom);
	free(cj_fk_ram);
	cj_fk_ram = NULL;
	return res;
}

/* ---------- interfaz pública ---------- */
static int cj_state; /* 0 apagado, 1 activo, 2 fallo */
static char cj_err[200];
static int cj_tested;

#ifndef CJ_TEST
static sigjmp_buf cj_jb;
static void cj_sig(int s) {
	(void) s;
	siglongjmp(cj_jb, 1);
}

static int cj_alloc(struct CJCache* c, size_t bytes) {
	c->tab = (struct CJEntry*) calloc(CJ_TAB_MASK + 1, sizeof(struct CJEntry));
	c->hot = 2;
	void* m = mmap(NULL, bytes, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	if (!c->tab || m == MAP_FAILED) {
		return 0;
	}
	c->code = (uint32_t*) m;
	c->cap = bytes / 4;
	c->used = 0;
	return 1;
}

static void cj_release(struct CJCache* c) {
	if (c->code) {
		munmap(c->code, c->cap * 4);
	}
	free(c->tab);
	memset(c, 0, sizeof(*c));
}
#endif

static int cj_layout_ok(void) {
	struct ARMCore probe;
	memset(&probe, 0, sizeof(probe));
	probe.cpsr.packed = (int32_t) 0x80000000u;
	if (!probe.cpsr.n || probe.cpsr.z || probe.cpsr.c || probe.cpsr.v) {
		return 0;
	}
	int offs[] = { CJ_OFF_G(0), CJ_OFF_G(15), CJ_OFF_PF(0), CJ_OFF_PF(1), CJ_OFF_CPSR, CJ_OFF_CYC, CJ_OFF_NEXT, CJ_OFF_SEQ16 };
	size_t k;
	for (k = 0; k < sizeof(offs) / sizeof(offs[0]); ++k) {
		if (offs[k] < 0 || offs[k] > 16000 || (offs[k] & 3)) {
			return 0;
		}
	}
	return sizeof(int) == 4 && sizeof(void*) == 8;
}

#ifndef CJ_TEST
/* on = 1: activa (con autoprueba la primera vez); on = 0: apaga. Devuelve el estado (0 apagado, 1 activo, 2 fallo). */
__attribute__((visibility("default"))) int cirilo_jit_set(int on) {
	if (!on) {
		cirilo_jit_active = 0;
		if (cj_state == 1) {
			cj_state = 0;
		}
		return cj_state;
	}
	if (cj_state == 2) {
		return 2;
	}
	if (cj_state == 1 && cirilo_jit_active) {
		return 1;
	}
#if !defined(__aarch64__) && !defined(CJ_CHECK_BUILD)
	snprintf(cj_err, sizeof cj_err, "solo ARM64");
	cj_state = 2;
	return 2;
#else
	if (!cj_layout_ok()) {
		snprintf(cj_err, sizeof cj_err, "estructura del procesador inesperada");
		cj_state = 2;
		return 2;
	}
	if (!cj_tested) {
		struct CJCache* tp = (struct CJCache*) calloc(1, sizeof(struct CJCache));
		if (!tp) {
			snprintf(cj_err, sizeof cj_err, "sin memoria");
			cj_state = 2;
			return 2;
		}
		struct CJCache* t = tp;
		struct sigaction nsa, osi, osv, osb;
		memset(&nsa, 0, sizeof nsa);
		nsa.sa_handler = cj_sig;
		sigemptyset(&nsa.sa_mask);
		sigaction(SIGILL, &nsa, &osi);
		sigaction(SIGSEGV, &nsa, &osv);
		sigaction(SIGBUS, &nsa, &osb);
		const char* r = NULL;
		if (sigsetjmp(cj_jb, 1) == 0) {
			if (!cj_alloc(t, 1 << 20)) {
				snprintf(cj_err, sizeof cj_err, "no se pudo reservar memoria ejecutable");
				r = cj_err;
			} else {
				t->hot = 0; /* en la autoprueba se compila todo a la primera */
				r = cj_selftest(t, 1500, cj_err, sizeof cj_err);
			}
		} else {
			snprintf(cj_err, sizeof cj_err, "la autoprueba provocó una señal (instrucción ilegal o acceso inválido)");
			r = cj_err;
		}
		sigaction(SIGILL, &osi, NULL);
		sigaction(SIGSEGV, &osv, NULL);
		sigaction(SIGBUS, &osb, NULL);
		cj_release(t);
		free(tp);
		cj_tested = 1;
		if (r) {
			cj_state = 2;
			return 2;
		}
	}
	if (!cj_real.code && !cj_alloc(&cj_real, 16u << 20)) {
		snprintf(cj_err, sizeof cj_err, "no se pudo reservar memoria ejecutable");
		cj_state = 2;
		return 2;
	}
	cj_flush(&cj_real);
	cj_state = 1;
	cirilo_jit_active = 1;
	return 1;
#endif
}

__attribute__((visibility("default"))) void cirilo_jit_flush(void) {
	if (cj_real.tab) {
		cj_flush(&cj_real);
	}
}

/* out[0]=ciclos dentro de bloques, out[1]=ciclos totales, out[2]=estado, out[3]=bloques compilados (acumulado), out[4]=ciclos interpretados en modo ARM,
 * out[5]=ciclos interpretados en Thumb fuera de la ROM, out[6]=ciclos interpretados en Thumb de la ROM, out[7]=bloques ejecutados, out[8]=bloques que salieron sin
 * ejecutar nada (evento cerca), out[9..11]=instrucciones ejecutadas dentro de bloques (en línea / manejador / terminal), out[12]=vaciados de caché (acumulado),
 * out[13]=bloques compilados desde la última lectura. Todo menos los acumulados se pone a cero al leer. Necesita espacio para 16 valores. */
__attribute__((visibility("default"))) void cirilo_jit_take(uint64_t* out) {
	out[0] = cj_real.jitCycles;
	out[1] = cj_real.totCycles;
	out[2] = (uint64_t) cj_state;
	out[3] = cj_real.blocks;
	out[4] = cj_real.cycArm;
	out[5] = cj_real.cycThumbRam;
	out[6] = cj_real.cycThumbRom;
	out[7] = cj_real.runs;
	out[8] = cj_real.fails;
	out[9] = cj_real.dynAlu;
	out[10] = cj_real.dynMem;
	out[11] = cj_real.dynTerm;
	out[12] = cj_real.flushes;
	out[13] = cj_real.compiledDelta;
	cj_real.jitCycles = cj_real.totCycles = 0;
	cj_real.cycArm = cj_real.cycThumbRam = cj_real.cycThumbRom = 0;
	cj_real.runs = cj_real.fails = cj_real.dynAlu = cj_real.dynMem = cj_real.dynTerm = cj_real.compiledDelta = 0;
}

__attribute__((visibility("default"))) const char* cirilo_jit_error(void) {
	return cj_err;
}

/* Lo llama ARMRunLoop (parcheado) cuando cirilo_jit_active != 0. */
__attribute__((visibility("default"))) void cirilo_jit_steps(struct ARMCore* cpu) {
	cj_run(&cj_real, cpu);
}
#endif
