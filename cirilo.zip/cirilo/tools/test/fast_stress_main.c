typedef unsigned int u32; typedef unsigned short u16;
#define R16(a) (*(volatile u16*) (a))
u32 stress_arm(u32, u32); u32 stress_thumb(u32, u32);
void __attribute__((noreturn)) main(void) {
	R16(0x04000100) = 0; R16(0x04000102) = 0x0080; R16(0x04000104) = 0; R16(0x04000106) = 0x0084; // TM0 a 1 ciclo, TM1 en cascada
	u32 seed = 12345, k = 0; volatile u32* out = (volatile u32*) 0x03006F00;
	for (;;) {
		R16(0x04000204) = (u16) (((seed >> 3) & 0x1F) | ((seed >> 9) & 0x3) << 5 | ((seed >> 13) & 1) << 14); // WAITCNT: esperas y prefetch al azar
		seed = seed * 1103515245u + 12345u;
		out[0] = stress_arm(seed, 3000); out[1] = stress_thumb(seed ^ 0xABCDu, 3000); out[2] = ++k;
	}
}
