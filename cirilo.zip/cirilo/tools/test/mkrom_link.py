import struct
# ROM GBA de prueba para el cable: modo multijugador, envia un contador por SIOMLT_SEND cada fotograma (el maestro inicia la transferencia)
# y guarda en IWRAM: [0x03000000]=RECV1, [0x03000002]=lo que envia esta consola, [0x03000004]=RECV0.
r=bytearray(0x400)
r[0:4]=struct.pack('<I',0xEA00002E)
r[0xA0:0xAC]=b'CIRILOLINK\0\0'; r[0xAC:0xB0]=b'ALNK'; r[0xB0:0xB2]=b'01'; r[0xB2]=0x96
chk=0
for b in r[0xA0:0xBD]: chk=(chk-b)&0xFF
r[0xBD]=(chk-0x19)&0xFF
code=[];lab={};fix=[]
def E(w): code.append(w)
def L(n): lab[n]=len(code)
def B(cond,n): fix.append((len(code),cond,n)); code.append(0)
def strh(rt,rn,off): return 0xE1C00000|(rn<<16)|(rt<<12)|((off>>4)<<8)|0xB0|(off&0xF)
def ldrh(rt,rn,off): return 0xE1D00000|(rn<<16)|(rt<<12)|((off>>4)<<8)|0xB0|(off&0xF)
E(0xE3A00404); E(0xE2804C01); E(0xE3A05403); E(0xE3A01000); E(strh(1,4,0x34))
E(0xE3A01A02); E(0xE3811003); E(strh(1,4,0x28)); E(0xE3A02000)
L('loop'); E(0xE2822001); E(strh(2,4,0x2A))
E(ldrh(1,4,0x28)); E(0xE3811080); E(strh(1,4,0x28))
L('wait'); E(ldrh(1,4,0x28)); E(0xE3110080); B(0x1,'wait')
E(ldrh(3,4,0x22)); E(strh(3,5,0)); E(strh(2,5,2)); E(ldrh(6,4,0x20)); E(strh(6,5,4))
L('v1'); E(ldrh(1,0,6)); E(0xE35100A0); B(0x1,'v1')
L('v2'); E(ldrh(1,0,6)); E(0xE35100A0); B(0x0,'v2')
B(0xE,'loop')
for i,c,n in fix: code[i]=(c<<28)|0x0A000000|((lab[n]-(i+2))&0xFFFFFF)
for i,w in enumerate(code): r[0xC0+4*i:0xC4+4*i]=struct.pack('<I',w)
open('link.gba','wb').write(r)
