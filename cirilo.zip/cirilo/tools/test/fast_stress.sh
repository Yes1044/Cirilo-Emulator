#!/bin/sh
# Compila tools/test/fast_stress.c a una ROM de GBA (fast_stress.gba) con clang + lld + llvm-objcopy (sin devkitARM). Uso: sh fast_stress.sh [carpeta de salida]
set -e; D=$(cd "$(dirname "$0")" && pwd); O=${1:-.}; mkdir -p "$O"; cd "$O"
F="--target=armv4t-none-eabi -O2 -ffreestanding -fno-builtin -nostdlib -fno-stack-protector -fno-pic -mfloat-abi=soft"
clang $F -marm -DNAME=stress_arm -c "$D/fast_stress.c" -o s_arm.o
clang $F -mthumb -DTHUMB -DNAME=stress_thumb -c "$D/fast_stress.c" -o s_thumb.o
clang $F -mthumb -c "$D/fast_stress_main.c" -o s_main.o
cat > crt0.s <<'EOS'
.section .text.start,"ax"
.arm
.global _start
_start:
	b 1f
	.space 0xBC
1:	ldr sp, =0x03006E00
	ldr r0, =main
	bx r0
.ltorg
EOS
clang --target=armv4t-none-eabi -c crt0.s -o crt0.o
printf 'ENTRY(_start)\nSECTIONS { . = 0x08000000; .text : { *(.text.start) *(.text*) *(.rodata*) } /DISCARD/ : { *(.ARM.*) *(.comment) } }\n' > l.ld
ld.lld -T l.ld crt0.o s_main.o s_arm.o s_thumb.o -o s.elf
llvm-objcopy -O binary s.elf s.bin
python3 -I - <<'EOP'
import struct
r=bytearray(open('s.bin','rb').read()); r+=b'\0'*((-len(r))%4)
r[0xA0:0xAC]=b'CIRILOSTRES\0'; r[0xAC:0xB0]=b'ASTR'; r[0xB0:0xB2]=b'01'; r[0xB2]=0x96
c=0
for b in r[0xA0:0xBD]: c=(c-b)&0xFF
r[0xBD]=(c-0x19)&0xFF
open('fast_stress.gba','wb').write(r); print('fast_stress.gba',len(r),'bytes')
EOP
