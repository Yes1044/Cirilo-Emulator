#!/usr/bin/env bash
# build manual (sin cmake) de mgba_libretro.so: mk.sh <carpeta mgba> <salida.so> [flags extra]
set -e
D=$1; OUT=$2; shift 2; EXTRA="$*"
cd $D
mkdir -p _gen/mgba/core
cat > _gen/mgba/flags.h <<'H'
#ifndef FLAGS_H
#define FLAGS_H
#define MINIMAL_CORE 2
#define COLOR_16_BIT
#define COLOR_5_6_5
#define DISABLE_THREADING
#define M_CORE_GBA
#define M_CORE_GB
#define USE_PTHREADS
#define ENABLE_VFS
#endif
H
mkdir -p _gen/mgba/core && cp _gen/mgba/flags.h _gen/mgba/core/flags.h
cat > _gen/version.c <<'H'
const char* const gitCommit="x";const char* const gitCommitShort="x";const char* const gitBranch="x";int gitRevision=0;const char* const binaryName="mgba";const char* const projectName="mGBA";const char* const projectVersion="0.0";
H
SRC="src/arm/arm.c src/arm/decoder-arm.c src/arm/decoder.c src/arm/decoder-thumb.c src/arm/isa-arm.c src/arm/isa-thumb.c
$(ls src/core/*.c | grep -v -E 'scripting|library|thread|directories|test') 
$(ls src/gba/*.c) src/gba/renderers/cache-set.c src/gba/renderers/common.c src/gba/renderers/software-bg.c src/gba/renderers/software-mode0.c src/gba/renderers/software-obj.c src/gba/renderers/video-software.c
$(ls src/gba/cheats/*.c) $(ls src/gba/sio/*.c) $(ls src/gba/cart/*.c 2>/dev/null)
$(ls src/gb/*.c) $(ls src/gb/mbc/*.c 2>/dev/null) $(ls src/gb/renderers/*.c) $(ls src/gb/sio/*.c) $(ls src/sm83/*.c)
$(ls src/util/*.c) $(ls src/util/vfs/vfs-fd.c src/util/vfs/vfs-mem.c 2>/dev/null) $(ls src/util/image/*.c) src/third-party/inih/ini.c src/platform/libretro/libretro.c _gen/version.c"
gcc -shared -fPIC -O2 -fwrapv -w -D__LIBRETRO__ -DMGBA_STANDALONE -DENABLE_VFS -DENABLE_VFS_FD -DMINIMAL_CORE=2 -DCOLOR_16_BIT -DCOLOR_5_6_5 -DDISABLE_THREADING -DM_CORE_GBA -DM_CORE_GB -DHAVE_STRTOF_L -DHAVE_LOCALE -D_GNU_SOURCE $EXTRA -I include -I src -I _gen $SRC -o $OUT -lm 2>&1 | head -40
