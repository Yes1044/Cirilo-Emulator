// Prueba del Link local GB/GBC con un hilo por consola. Uso: ./harness_gb romA romB [0|1|2]   (romA va en la consola 0, romB en la 1; modo 0 = con ritmo 59,7 fps (como la app), 1 = con ritmo + 300 pausas aleatorias, 2 = sin ritmo)
// Con A=link_m.gb y B=link_s.gb el maestro es la consola 0; con A=link_s.gb y B=link_m.gb la consola 1 inicia las transferencias (cambio de papeles del lockstep).
#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
#include "libretro.h"
typedef struct{void*h;void(*env)(retro_environment_t);void(*vid)(retro_video_refresh_t);void(*asb)(retro_audio_sample_batch_t);void(*as)(retro_audio_sample_t);void(*ip)(retro_input_poll_t);void(*is)(retro_input_state_t);
 void(*init)(void);void(*run)(void);bool(*load)(const struct retro_game_info*);
 void*(*create)(void);int(*attach)(void*,int);void(*detach)(void*,int);void(*destroy)(void*);void(*intr)(void*,int);int(*dbg)(char*,int);unsigned(*rd8)(unsigned);
 volatile int frames,videos,nulls;}C;
static C c[2];
static bool env(unsigned cmd,void*d){if(cmd==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return true;if(cmd==RETRO_ENVIRONMENT_GET_CAN_DUPE){*(bool*)d=true;return true;}return false;}
static void vid0(const void*d,unsigned w,unsigned h,size_t p){(void)w;(void)h;(void)p;if(d)c[0].videos++;else c[0].nulls++;}
static void vid1(const void*d,unsigned w,unsigned h,size_t p){(void)w;(void)h;(void)p;if(d)c[1].videos++;else c[1].nulls++;}
static size_t asb(const int16_t*d,size_t n){(void)d;return n;}static void as1(int16_t l,int16_t r){(void)l;(void)r;}static void ip(void){}
static int16_t is(unsigned a,unsigned b,unsigned cc,unsigned d){(void)a;(void)b;(void)cc;(void)d;return 0;}
static volatile int stop[2];static int paced=1;
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
// con ritmo = como Emu.kt: reloj monótono a 59,7275 fps, sin correr para recuperar retrasos
static void* thr(void*a){int i=(int)(intptr_t)a;double nx=now();while(!stop[i]){c[i].run();c[i].frames++;
  if(paced){nx+=1.0/59.7275;double d=nx-now();if(d>0)usleep((useconds_t)(d*1e6));else nx=now();}}return NULL;}
#define SY(v,n) do{*(void**)&c[i].v=dlsym(c[i].h,n);if(!c[i].v){printf("falta %s\n",n);exit(2);}}while(0)
static pthread_t th[2];
static void start(int i){stop[i]=0;pthread_create(&th[i],NULL,thr,(void*)(intptr_t)i);}
static int pauseAll(void*lk){stop[0]=stop[1]=1;c[0].intr(lk,1);int ok=1;
 for(int i=0;i<2;i++){struct timespec t;clock_gettime(CLOCK_REALTIME,&t);t.tv_sec+=5;if(pthread_timedjoin_np(th[i],NULL,&t)){printf("  !! el hilo %d NO terminó (bloqueado esperando a la otra consola)\n",i);ok=0;}}
 c[0].intr(lk,0);return ok;}
static char* rd(const char*p,long*n){FILE*f=fopen(p,"rb");if(!f){perror(p);exit(2);}fseek(f,0,SEEK_END);*n=ftell(f);fseek(f,0,SEEK_SET);char*b=malloc(*n);fread(b,1,*n,f);fclose(f);return b;}
int main(int argc,char**argv){
 const char*rom[2]={argc>1?argv[1]:"link_m.gb",argc>2?argv[2]:"link_s.gb"};int mode=argc>3?atoi(argv[3]):0;int stress=(mode==1);paced=(mode!=2);
 const char*lib[2]={"./coreA.so","./coreB.so"};
 for(int i=0;i<2;i++){long n;char*buf=rd(rom[i],&n);
  c[i].h=dlopen(lib[i],RTLD_NOW|RTLD_LOCAL);if(!c[i].h){printf("dlopen: %s\n",dlerror());return 2;}
  SY(env,"retro_set_environment");SY(vid,"retro_set_video_refresh");SY(asb,"retro_set_audio_sample_batch");SY(as,"retro_set_audio_sample");SY(ip,"retro_set_input_poll");SY(is,"retro_set_input_state");
  SY(init,"retro_init");SY(run,"retro_run");SY(load,"retro_load_game");SY(create,"cirilo_link_create");SY(attach,"cirilo_link_attach");SY(detach,"cirilo_link_detach");SY(destroy,"cirilo_link_destroy");SY(intr,"cirilo_link_interrupt");SY(dbg,"cirilo_link_dbg");SY(rd8,"test_rd8");
  c[i].env(env);c[i].init();c[i].vid(i?vid1:vid0);c[i].asb(asb);c[i].as(as1);c[i].ip(ip);c[i].is(is);
  struct retro_game_info g={rom[i],buf,n,NULL};if(!c[i].load(&g)){printf("no cargó la ROM %d\n",i);return 2;}}
 void*lk=c[0].create();if(!lk){puts("create falló");return 2;}
 int r0=c[0].attach(lk,0),r1=c[1].attach(lk,1);printf("attach: %d %d\n",r0,r1);if(r0||r1)return 2;
 int fails=0;double t0=now();
 start(0);start(1);
 // muestreo cada 100 ms: acumula transferencias (contador de 8 bits con vuelta)
 long tot[2]={0,0};unsigned last[2]={0,0};
 for(int s=0;s<40;s++){usleep(100000);for(int i=0;i<2;i++){unsigned v=c[i].rd8(0xC000);tot[i]+=(v-last[i])&0xFF;last[i]=v;}
  if(s%10==9){char b[96];c[0].dbg(b,sizeof b);printf("t=%.0fs frames %d/%d transferencias %ld/%ld cable[%s]\n",(s+1)/10.0,c[0].frames,c[1].frames,tot[0],tot[1],b);}}
 int a0=c[0].frames,a1=c[1].frames;
 if(a0<(paced?150:60)||a1<(paced?150:60)){printf("FALLO: casi no avanzaron (%d/%d)\n",a0,a1);fails++;}
 if(paced&&abs(a0-a1)>3){printf("FALLO: las consolas se descuadraron (%d vs %d fotogramas)\n",a0,a1);fails++;}
 if(tot[0]<(paced?150:100)||tot[1]<(paced?150:100)){printf("FALLO: casi no hubo transferencias (%ld/%ld)\n",tot[0],tot[1]);fails++;}
 for(int k=0;k<5;k++){usleep(150000+k*37000);if(!pauseAll(lk)){fails++;break;}
  printf("pausa %d: frames %d/%d nulls %d/%d\n",k+1,c[0].frames,c[1].frames,c[0].nulls,c[1].nulls);start(0);start(1);}
 sleep(2);int b0=c[0].frames,b1=c[1].frames;if(b0<=a0||b1<=a1){printf("FALLO: tras las pausas no avanzan (%d/%d -> %d/%d)\n",a0,a1,b0,b1);fails++;}
 if(stress){srand(7);int bad=0;for(int k=0;k<300;k++){usleep(1000+rand()%25000);if(!pauseAll(lk)){bad++;break;}start(0);start(1);}
  printf("estrés: 300 pausas aleatorias, hilos colgados=%d, frames %d/%d\n",bad,c[0].frames,c[1].frames);if(bad)fails++;}
 pauseAll(lk);
 unsigned o0=c[0].rd8(0xC000),r0v=c[0].rd8(0xC001),o1=c[1].rd8(0xC000),r1v=c[1].rd8(0xC001);
 printf("consola0: envía %u recibe %u | consola1: envía %u recibe %u\n",o0,r0v,o1,r1v);
 int d1=((int)r0v-(int)o1)&0xFF,d2=((int)r1v-(int)o0)&0xFF; if(d1>128)d1-=256; if(d2>128)d2-=256;
 if(abs(d1)>1){puts("FALLO: la consola 0 no recibe lo que envía la 1");fails++;}
 if(abs(d2)>1){puts("FALLO: la consola 1 no recibe lo que envía la 0");fails++;}
 c[0].detach(lk,0);c[1].detach(lk,1);c[0].destroy(lk);
 printf("%s (%.1f s)\n",fails?"RESULTADO: FALLÓ":"RESULTADO: OK",now()-t0);return fails?1:0;}
