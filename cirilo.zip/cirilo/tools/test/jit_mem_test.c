#include "cirilo_jit_mem.h"
#include <stdio.h>
#include <string.h>
int main(void) {
	int fails = 0;
	for (int force = 0; force <= 3; ++force) {
		struct CJMem m;
		int ok = cjMemAlloc(&m, 1 << 20, force);
		printf("force=%d ok=%d kind=%d err=%d\n", force, ok, m.kind, m.err);
		if (force == 3) { if (ok || m.kind) { puts("FALLO: force=3 debe fallar"); ++fails; } continue; }
		if (!ok) { puts("FALLO: no hay memoria ejecutable"); ++fails; continue; }
		if (force == 2 && m.kind != 2) { puts("FALLO: se esperaba doble vista"); ++fails; }
		if (force == 2 && m.rw == m.rx) { puts("FALLO: las vistas deben ser distintas"); ++fails; }
#if defined(__x86_64__)
		static const uint8_t code[] = {0xB8, 0x2A, 0, 0, 0, 0xC3}; /* mov eax,42 ; ret */
		memcpy(m.rw + 4096, code, sizeof code);                      /* se escribe por la vista RW */
		int r = ((int (*)(void)) (m.rx + 4096))();                   /* se ejecuta por la vista RX */
		if (r != 42) { printf("FALLO: devolvió %d\n", r); ++fails; }
		if (m.kind == 2) { /* una escritura posterior por RW debe verse en RX */
			m.rw[4096 + 1] = 7;
			if (((int (*)(void)) (m.rx + 4096))() != 7) { puts("FALLO: la vista RX no ve la escritura"); ++fails; }
		}
#endif
		cjMemFree(&m);
	}
	puts(fails ? "RESULTADO: FALLO" : "RESULTADO: OK");
	return fails != 0;
}
