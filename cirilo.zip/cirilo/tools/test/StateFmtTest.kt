import app.cirilo.StateFmt
import java.util.*

fun main(){
 var f=0
 fun eq(a:Any?,b:Any?,m:String){if(a!=b){f++;println("FALLO "+m+": "+a+" != "+b)}else println("ok    "+m)}
 val n=1_000_000_000_000L
 eq(StateFmt.ago(n,n),"hace un momento","ahora")
 eq(StateFmt.ago(n,n+5000),"hace un momento","reloj adelantado")
 eq(StateFmt.ago(n,n-44_000),"hace un momento","44 s")
 eq(StateFmt.ago(n,n-45_000),"hace 1 min","45 s")
 eq(StateFmt.ago(n,n-5L*60_000),"hace 5 min","5 min")
 eq(StateFmt.ago(n,n-59L*60_000),"hace 59 min","59 min")
 eq(StateFmt.ago(n,n-60L*60_000),"hace 1 h","1 h")
 eq(StateFmt.ago(n,n-23L*3_600_000),"hace 23 h","23 h")
 eq(StateFmt.ago(n,n-30L*3_600_000),"ayer","30 h")
 eq(StateFmt.ago(n,n-4L*86_400_000),"hace 4 días","4 días")
 eq(StateFmt.ago(n,n-31L*86_400_000),"","31 días")
 val c=Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply{set(2026,10,4,12,20,0)}
 TimeZone.setDefault(TimeZone.getTimeZone("UTC"))
 eq(StateFmt.stamp(c.timeInMillis,c.timeInMillis,Locale("es")),"4 nov, 12:20","misma fecha, sin año")
 eq(StateFmt.stamp(c.timeInMillis+400L*86_400_000,c.timeInMillis,Locale("es")),"4 nov 2026, 12:20","otro año")
 eq(StateFmt.line(c.timeInMillis+5L*60_000,c.timeInMillis),"hace 5 min · "+StateFmt.stamp(c.timeInMillis,c.timeInMillis),"línea")
 eq(StateFmt.line(c.timeInMillis+40L*86_400_000,c.timeInMillis),StateFmt.stamp(c.timeInMillis+40L*86_400_000,c.timeInMillis),"más de 30 días: solo fecha")
 println(if(f==0)"TODO OK" else "$f fallos");if(f>0)System.exit(1)
}
