// Prueba unitaria del emisor del JIT (Fase 2): llama a cirilo_jit_selftest del núcleo candidato (compilado con -DCIRILO_JIT_TEST).
// Uso: jit_unit core.so [semilla] [iteraciones]     Salida: 0 = sin discrepancias, 1 = discrepancias, 2 = error, 3 = este anfitrión no ejecuta código nativo.
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
int main(int argc, char** argv) {
	if (argc < 2) { fprintf(stderr, "uso: %s core.so [semilla] [iteraciones]\n", argv[0]); return 2; }
	void* h = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
	if (!h) { fprintf(stderr, "%s\n", dlerror()); return 2; }
	int (*st)(uint32_t, uint32_t, char*, uint32_t) = dlsym(h, "cirilo_jit_selftest");
	if (!st) { fprintf(stderr, "el núcleo no exporta cirilo_jit_selftest (¿sin -DCIRILO_JIT_TEST?)\n"); return 2; }
	static char rep[8192];
	uint32_t seed = argc > 2 ? strtoul(argv[2], 0, 0) : 1, iters = argc > 3 ? strtoul(argv[3], 0, 0) : 200000;
	int r = st(seed, iters, rep, sizeof rep);
	if (r < 0) { printf("este anfitrión no ejecuta código nativo (%d): se omite\n", r); return 3; }
	printf("%s", rep);
	printf("%s: %u secuencias aleatorias, %d discrepancias\n", r ? "FALLO" : "OK", iters, r);
	return r ? 1 : 0;
}
