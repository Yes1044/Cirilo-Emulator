// Experimento: guardar y cargar los estados de las DOS consolas a la vez con el cable activo (ver investigación de estados con Link local).
// Uso: ./st gba link.gba link.gba | ./st gb link_m.gb link_s.gb   [resync]
#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <execinfo.h>
#include "libretro.h"
static volatile const char*stage="";static void segv(int x){(void)x;char b[120];int n=snprintf(b,sizeof b,"\nSEGV en: %s\n",stage);write(2,b,n);void*bt[24];int m=backtrace(bt,24);backtrace_symbols_fd(bt,m,2);_exit(139);}
typedef struct{void*h;void(*env)(retro_environment_t);void(*vid)(retro_video_refresh_t);void(*asb)(retro_audio_sample_batch_t);void(*as)(retro_audio_sample_t);void(*ip)(retro_input_poll_t);void(*is)(retro_input_state_t);
 void(*init)(void);void(*run)(void);bool(*load)(const struct retro_game_info*);size_t(*ssz)(void);bool(*ser)(void*,size_t);bool(*unser)(const void*,size_t);
 void*(*create)(void);int(*attach)(void*,int);void(*detach)(void*,int);void(*destroy)(void*);void(*intr)(void*,int);unsigned(*rd8)(unsigned);unsigned(*rd16)(unsigned);void(*resync)(void*,int);int(*idle)(void*);
 volatile int frames;char*st;size_t sn;}C;
static C c[2];
static bool env(unsigned cmd,void*d){if(cmd==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return true;if(cmd==RETRO_ENVIRONMENT_GET_CAN_DUPE){*(bool*)d=true;return true;}return false;}
static void vid(const void*d,unsigned w,unsigned h,size_t p){(void)d;(void)w;(void)h;(void)p;}
static size_t asb(const int16_t*d,size_t n){(void)d;return n;}static void as1(int16_t l,int16_t r){(void)l;(void)r;}static void ip(void){}
static int16_t is(unsigned a,unsigned b,unsigned cc,unsigned d){(void)a;(void)b;(void)cc;(void)d;return 0;}
static volatile int stop[2];static int paced=1;
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
static void* thr(void*a){int i=(int)(intptr_t)a;double nx=now();while(!stop[i]){c[i].run();c[i].frames++;nx+=1.0/59.7275;double d=nx-now();if(d>0)usleep((useconds_t)(d*1e6));else nx=now();}return NULL;}
#define SY(v,n) do{*(void**)&c[i].v=dlsym(c[i].h,n);if(!c[i].v){printf("falta %s\n",n);exit(2);}}while(0)
static pthread_t th[2];
static void start(int i){stop[i]=0;pthread_create(&th[i],NULL,thr,(void*)(intptr_t)i);}
static int pauseAll(void*lk){stop[0]=stop[1]=1;c[0].intr(lk,1);int ok=1;
 for(int i=0;i<2;i++){struct timespec t;clock_gettime(CLOCK_REALTIME,&t);t.tv_sec+=5;if(pthread_timedjoin_np(th[i],NULL,&t)){printf("  !! hilo %d colgado\n",i);ok=0;}}
 c[0].intr(lk,0);return ok;}
static char* rd(const char*p,long*n){FILE*f=fopen(p,"rb");if(!f){perror(p);exit(2);}fseek(f,0,SEEK_END);*n=ftell(f);fseek(f,0,SEEK_SET);char*b=malloc(*n);if(fread(b,1,*n,f)!=(size_t)*n)exit(2);fclose(f);return b;}
// contadores visibles: (propio enviado, recibido) por consola
static void vals(int gba,int i,unsigned*own,unsigned*rcv){if(gba){*own=c[i].rd16(0x03000002);*rcv=i==0?c[i].rd16(0x03000000):c[i].rd16(0x03000004);}else{*own=c[i].rd8(0xC000);*rcv=c[i].rd8(0xC001);}}
int main(int argc,char**argv){signal(SIGSEGV,segv);
 int gba=!strcmp(argv[1],"gba");const char*rom[2]={argv[2],argv[3]};const char*lib[2]={"./coreA.so","./coreB.so"};
 for(int i=0;i<2;i++){long n;char*buf=rd(rom[i],&n);
  c[i].h=dlopen(lib[i],RTLD_NOW|RTLD_LOCAL);if(!c[i].h){printf("dlopen: %s\n",dlerror());return 2;}
  SY(env,"retro_set_environment");SY(vid,"retro_set_video_refresh");SY(asb,"retro_set_audio_sample_batch");SY(as,"retro_set_audio_sample");SY(ip,"retro_set_input_poll");SY(is,"retro_set_input_state");
  SY(init,"retro_init");SY(run,"retro_run");SY(load,"retro_load_game");SY(ssz,"retro_serialize_size");SY(ser,"retro_serialize");SY(unser,"retro_unserialize");
  SY(create,"cirilo_link_create");SY(attach,"cirilo_link_attach");SY(detach,"cirilo_link_detach");SY(destroy,"cirilo_link_destroy");SY(intr,"cirilo_link_interrupt");SY(rd8,"test_rd8");SY(rd16,"test_rd16");SY(resync,"cirilo_link_resync");SY(idle,"cirilo_link_idle");
  c[i].env(env);c[i].init();c[i].vid(vid);c[i].asb(asb);c[i].as(as1);c[i].ip(ip);c[i].is(is);
  struct retro_game_info g={rom[i],buf,n,NULL};if(!c[i].load(&g)){printf("no cargó la ROM %d\n",i);return 2;}}
 void*lk=c[0].create();int r0=c[0].attach(lk,0),r1=c[1].attach(lk,1);printf("attach %d %d, tamaño estado %zu/%zu\n",r0,r1,c[0].ssz(),c[1].ssz());if(r0||r1)return 2;
 srand(5);int fails=0;start(0);start(1);usleep(600000);
 for(int k=0;k<40;k++){
  stage="pausa1";usleep(20000+rand()%80000);if(!pauseAll(lk)){fails++;break;}
  {int tries=0;while(!c[0].idle(lk)&&tries<200){start(0);start(1);usleep(1000+rand()%3000);if(!pauseAll(lk)){fails++;break;}tries++;}if(tries)printf("  (esperó %d intentos hasta un instante inactivo)\n",tries);}
  stage="serialize";for(int i=0;i<2;i++){size_t z=c[i].ssz();c[i].st=realloc(c[i].st,z);c[i].sn=z;if(!c[i].ser(c[i].st,z)){printf("serialize %d falló\n",i);fails++;}}
  unsigned so[2],sr[2];for(int i=0;i<2;i++)vals(gba,i,&so[i],&sr[i]);
  stage="corriendo tras guardar";start(0);start(1);usleep(300000+rand()%300000);stage="pausa2";if(!pauseAll(lk)){fails++;break;}
  stage="unserialize";int ok=1;for(int i=0;i<2;i++)if(!c[i].unser(c[i].st,c[i].sn)){printf("unserialize %d falló\n",i);ok=0;fails++;}
  if(!gba&&argc>4)for(int i=0;i<2;i++)c[i].resync(lk,i);
  unsigned lo[2],lr[2];for(int i=0;i<2;i++)vals(gba,i,&lo[i],&lr[i]);
  int same=(lo[0]==so[0]&&lo[1]==so[1]&&lr[0]==sr[0]&&lr[1]==sr[1]);
  stage="corriendo tras cargar";int f0=c[0].frames,f1=c[1].frames;start(0);start(1);usleep(500000);
  int adv=(c[0].frames-f0>10&&c[1].frames-f1>10);
  pauseAll(lk);unsigned eo[2],er[2];for(int i=0;i<2;i++)vals(gba,i,&eo[i],&er[i]);
  int d1=((int)er[0]-(int)eo[1])&0xFF,d2=((int)er[1]-(int)eo[0])&0xFF;if(d1>128)d1-=256;if(d2>128)d2-=256;
  int cons=(abs(d1)<=3&&abs(d2)<=3);int prog=((eo[0]-lo[0])&0xFF)>10;
  printf("ciclo %2d: carga fiel=%d avanzan=%d progreso=%d consistentes=%d (envia %u/%u recibe %u/%u)\n",k,same,adv,prog,cons,eo[0],eo[1],er[0],er[1]);
  if(!ok||!same||!adv||!cons||!prog)fails++;
  start(0);start(1);}
 pauseAll(lk);printf("%s\n",fails?"RESULTADO: FALLÓ":"RESULTADO: OK");return fails?1:0;}
