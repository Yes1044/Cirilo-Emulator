// Prueba del Link local con un hilo por consola (ver tools/test/LEEME.txt, apartado 4): dos copias del núcleo, cada una en su hilo, ROM que intercambia datos por el cable.
#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
#include "../../app/src/main/cpp/libretro.h"
typedef struct{void*h;void(*env)(retro_environment_t);void(*vid)(retro_video_refresh_t);void(*asb)(retro_audio_sample_batch_t);void(*as)(retro_audio_sample_t);void(*ip)(retro_input_poll_t);void(*is)(retro_input_state_t);
 void(*init)(void);void(*run)(void);bool(*load)(const struct retro_game_info*);
 void*(*create)(void);int(*attach)(void*,int);void(*detach)(void*,int);void(*destroy)(void*);void(*intr)(void*,int);int(*dbg)(char*,int);unsigned(*rd16)(unsigned);
 volatile int frames,videos,nulls;}C;
static C c[2];
static bool env(unsigned cmd,void*d){if(cmd==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return true;if(cmd==RETRO_ENVIRONMENT_GET_CAN_DUPE){*(bool*)d=true;return true;}return false;}
static void vid0(const void*d,unsigned w,unsigned h,size_t p){(void)w;(void)h;(void)p;if(d)c[0].videos++;else c[0].nulls++;}
static void vid1(const void*d,unsigned w,unsigned h,size_t p){(void)w;(void)h;(void)p;if(d)c[1].videos++;else c[1].nulls++;}
static size_t asb(const int16_t*d,size_t n){(void)d;return n;}static void as1(int16_t l,int16_t r){(void)l;(void)r;}static void ip(void){}
static int16_t is(unsigned a,unsigned b,unsigned cc,unsigned d){(void)a;(void)b;(void)cc;(void)d;return 0;}
static volatile int stop[2];
static void* thr(void*a){int i=(int)(intptr_t)a;while(!stop[i]){c[i].run();c[i].frames++;}return NULL;}
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+t.tv_nsec*1e-9;}
#define SY(v,n) do{*(void**)&c[i].v=dlsym(c[i].h,n);if(!c[i].v){printf("falta %s\n",n);exit(2);}}while(0)
static pthread_t th[2];
static void start(int i){stop[i]=0;pthread_create(&th[i],NULL,thr,(void*)(intptr_t)i);}
// pausa como lo hace Kotlin: pedir parar, interrumpir el cable, unir, quitar la interrupción
static int pauseAll(void*lk){stop[0]=stop[1]=1;c[0].intr(lk,1);int ok=1;
 for(int i=0;i<2;i++){struct timespec t;clock_gettime(CLOCK_REALTIME,&t);t.tv_sec+=5;if(pthread_timedjoin_np(th[i],NULL,&t)){printf("  !! el hilo %d NO terminó (bloqueado esperando a la otra consola)\n",i);ok=0;}}
 c[0].intr(lk,0);return ok;}
int main(int argc,char**argv){
 const char*rom=argc>1?argv[1]:"link.gba";int dbgmode=argc>2?atoi(argv[2]):0;(void)dbgmode;
 FILE*f=fopen(rom,"rb");fseek(f,0,SEEK_END);long n=ftell(f);fseek(f,0,SEEK_SET);char*buf=malloc(n);fread(buf,1,n,f);fclose(f);
 const char*lib[2]={"./coreA.so","./coreB.so"};
 for(int i=0;i<2;i++){c[i].h=dlopen(lib[i],RTLD_NOW|RTLD_LOCAL);if(!c[i].h){printf("dlopen: %s\n",dlerror());return 2;}
  SY(env,"retro_set_environment");SY(vid,"retro_set_video_refresh");SY(asb,"retro_set_audio_sample_batch");SY(as,"retro_set_audio_sample");SY(ip,"retro_set_input_poll");SY(is,"retro_set_input_state");
  SY(init,"retro_init");SY(run,"retro_run");SY(load,"retro_load_game");SY(create,"cirilo_link_create");SY(attach,"cirilo_link_attach");SY(detach,"cirilo_link_detach");SY(destroy,"cirilo_link_destroy");SY(intr,"cirilo_link_interrupt");SY(dbg,"cirilo_link_dbg");SY(rd16,"test_rd16");
  c[i].env(env);c[i].init();c[i].vid(i?vid1:vid0);c[i].asb(asb);c[i].as(as1);c[i].ip(ip);c[i].is(is);
  struct retro_game_info g={rom,buf,n,NULL};if(!c[i].load(&g)){printf("no cargó la ROM %d\n",i);return 2;}}
 void*lk=c[0].create();if(!lk){puts("create falló");return 2;}
 int r0=c[0].attach(lk,0),r1=c[1].attach(lk,1);printf("attach: %d %d\n",r0,r1);if(r0||r1)return 2;
 int fails=0;
 // 1) dos hilos libres durante 4 s: no deben colgarse, deben avanzar parejos y la ROM debe recibir los datos de la otra
 double t0=now();start(0);start(1);
 for(int s=0;s<4;s++){sleep(1);char b[96];c[0].dbg(b,sizeof b);printf("t=%ds frames %d/%d video %d/%d  cable[%s]\n",s+1,c[0].frames,c[1].frames,c[0].videos,c[1].videos,b);}
 int a0=c[0].frames,a1=c[1].frames;
 if(a0<60||a1<60){printf("FALLO: casi no avanzaron (%d/%d)\n",a0,a1);fails++;}
 if(abs(a0-a1)>2){printf("FALLO: las consolas se descuadraron (%d vs %d fotogramas)\n",a0,a1);fails++;}
 // 2) pausas repetidas a mitad de partida, como hace la app (menú, cambiar de juego...)
 for(int k=0;k<5;k++){usleep(150000+k*37000);if(!pauseAll(lk)){fails++;break;}
  printf("pausa %d: frames %d/%d nulls %d/%d\n",k+1,c[0].frames,c[1].frames,c[0].nulls,c[1].nulls);start(0);start(1);}
 sleep(2);
 int b0=c[0].frames,b1=c[1].frames;if(b0<=a0||b1<=a1){printf("FALLO: tras las pausas no avanzan (%d/%d -> %d/%d)\n",a0,a1,b0,b1);fails++;}
 if(dbgmode==1){srand(7);int bad=0;for(int k=0;k<300;k++){usleep(1000+rand()%25000);if(!pauseAll(lk)){bad++;break;}start(0);start(1);}
  printf("estrés: 300 pausas aleatorias, hilos colgados=%d, frames %d/%d\n",bad,c[0].frames,c[1].frames);if(bad)fails++;}
 // 3) datos del cable: [0x03000000]=RECV1, [..02]=envío propio, [..04]=RECV0
 pauseAll(lk);
 unsigned m_r1=c[0].rd16(0x03000000),m_own=c[0].rd16(0x03000002),m_r0=c[0].rd16(0x03000004);
 unsigned s_r1=c[1].rd16(0x03000000),s_own=c[1].rd16(0x03000002),s_r0=c[1].rd16(0x03000004);
 printf("maestro: envía %u, ve RECV0=%u RECV1=%u | esclava: envía %u, ve RECV0=%u RECV1=%u\n",m_own,m_r0,m_r1,s_own,s_r0,s_r1);
 if(m_own<30||s_own<30){puts("FALLO: la ROM casi no ha transferido");fails++;}
 if((int)m_r1-(int)s_own>2||(int)s_own-(int)m_r1>3){puts("FALLO: el maestro no recibe lo que envía la esclava");fails++;}
 if((int)s_r0-(int)m_own>2||(int)m_own-(int)s_r0>3){puts("FALLO: la esclava no recibe lo que envía el maestro");fails++;}
 // 4) desconectar y destruir con las dos paradas
 c[0].detach(lk,0);c[1].detach(lk,1);c[0].destroy(lk);
 printf("%s (%.1f s)\n",fails?"RESULTADO: FALLÓ":"RESULTADO: OK",now()-t0);return fails?1:0;}
