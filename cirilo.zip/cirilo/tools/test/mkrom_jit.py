#!/usr/bin/env python3
"""Generador de ROMs de prueba ALEATORIAS para el JIT de Cirilo (sin devkitARM ni clang: escribe el código máquina directamente).
Uso: mkrom_jit.py salida.gba [--seed N] [--mode arm|thumb|mixed|smc] [--routines N] [--len N] [--list salida.lst]

La ROM no «hace» nada útil: ejecuta, en bucle infinito, rutinas ARM y Thumb aleatorias (ALU con todos los desplazamientos y condiciones, multiplicaciones,
cargas/guardados de todos los tamaños con y sin alinear sobre IWRAM, EWRAM, ROM (y sus espejos con otras esperas), VRAM y paleta, LDM/STM, PUSH/POP,
SWP, MRS/MSR, saltos condicionales, bucles, BL/BX) en ROM, IWRAM y EWRAM, con WAITCNT cambiante y un temporizador de 1 ciclo que se mezcla en un
checksum: un solo ciclo de diferencia cambia el resultado. El modo «smc» además reescribe instrucciones de rutinas que viven en RAM, con la CPU (STR/STRH)
y con DMA, entre ejecución y ejecución: un JIT sin invalidación acabaría ejecutando código viejo.
Se compara con tools/test/jit_cmp.c (referencia contra candidato, estado completo en cada fotograma). Mismo seed = misma ROM."""
import sys, random, struct, argparse

# ---------------------------------------------------------------- ARM
AL = 0xE
def arm_imm(v):
    """Devuelve el campo operando2 (rot<<8|imm8) para una constante inmediata de ARM, o None."""
    v &= 0xFFFFFFFF
    for r in range(0, 32, 2):
        x = ((v << r) | (v >> (32 - r))) & 0xFFFFFFFF if r else v
        if x < 256:
            return ((r // 2) << 8) | x
    return None
def a_dp(cond, op, s, rn, rd, op2, i=0): return (cond << 28) | (i << 25) | (op << 21) | (s << 20) | (rn << 16) | (rd << 12) | op2
def a_dp_imm(cond, op, s, rn, rd, imm): return a_dp(cond, op, s, rn, rd, arm_imm(imm), 1)
def a_dp_reg(cond, op, s, rn, rd, rm, typ=0, sh=0): return a_dp(cond, op, s, rn, rd, (sh << 7) | (typ << 5) | rm)
def a_dp_rsr(cond, op, s, rn, rd, rm, typ, rs): return a_dp(cond, op, s, rn, rd, (rs << 8) | (typ << 5) | 0x10 | rm)
def a_mul(cond, a, s, rd, rn, rs, rm): return (cond << 28) | (a << 21) | (s << 20) | (rd << 16) | (rn << 12) | (rs << 8) | 0x90 | rm
def a_mull(cond, u, a, s, rdhi, rdlo, rs, rm): return (cond << 28) | (1 << 23) | (u << 22) | (a << 21) | (s << 20) | (rdhi << 16) | (rdlo << 12) | (rs << 8) | 0x90 | rm
def a_sdt_imm(cond, p, u, b, w, l, rn, rd, off): return (cond << 28) | (0b01 << 26) | (p << 24) | (u << 23) | (b << 22) | (w << 21) | (l << 20) | (rn << 16) | (rd << 12) | off
def a_sdt_reg(cond, p, u, b, w, l, rn, rd, rm, typ=0, sh=0): return (cond << 28) | (0b011 << 25) | (p << 24) | (u << 23) | (b << 22) | (w << 21) | (l << 20) | (rn << 16) | (rd << 12) | (sh << 7) | (typ << 5) | rm
def a_hw_imm(cond, p, u, w, l, sh, rn, rd, off): return (cond << 28) | (p << 24) | (u << 23) | (1 << 22) | (w << 21) | (l << 20) | (rn << 16) | (rd << 12) | ((off >> 4) << 8) | 0x90 | (sh << 5) | (off & 15)
def a_hw_reg(cond, p, u, w, l, sh, rn, rd, rm): return (cond << 28) | (p << 24) | (u << 23) | (w << 21) | (l << 20) | (rn << 16) | (rd << 12) | 0x90 | (sh << 5) | rm
def a_bdt(cond, p, u, w, l, rn, rlist): return (cond << 28) | (0b100 << 25) | (p << 24) | (u << 23) | (w << 21) | (l << 20) | (rn << 16) | rlist
def a_swp(cond, b, rn, rd, rm): return (cond << 28) | 0x01000090 | (b << 22) | (rn << 16) | (rd << 12) | rm
def a_bx(cond, rm): return (cond << 28) | 0x012FFF10 | rm
def a_b(cond, link, off): return (cond << 28) | (0b101 << 25) | (link << 24) | (off & 0xFFFFFF)
def a_mrs(cond, rd): return (cond << 28) | 0x010F0000 | (rd << 12)
def a_msr_f(cond, rm): return (cond << 28) | 0x0128F000 | rm
def a_const(rd, val, cond=AL):
    """4 instrucciones fijas (el tamaño no depende del valor): mov + 3 orr por bytes."""
    w = [a_dp_imm(cond, 0xD, 0, 0, rd, val & 0xFF)]
    for k in (1, 2, 3):
        w.append(a_dp_imm(cond, 0xC, 0, rd, rd, val & (0xFF << (8 * k))))
    return w

# ---------------------------------------------------------------- Thumb
def t_f1(op, imm5, rs, rd): return (op << 11) | (imm5 << 6) | (rs << 3) | rd
def t_f2(i, op, rn, rs, rd): return 0x1800 | (i << 10) | (op << 9) | (rn << 6) | (rs << 3) | rd
def t_f3(op, rd, imm8): return 0x2000 | (op << 11) | (rd << 8) | imm8
def t_f4(op, rs, rd): return 0x4000 | (op << 6) | (rs << 3) | rd
def t_f5(op, rd, rs): return 0x4400 | (op << 8) | ((rd >> 3) << 7) | ((rs >> 3) << 6) | ((rs & 7) << 3) | (rd & 7)
def t_f6(rd, imm8): return 0x4800 | (rd << 8) | imm8
def t_f7(l, b, ro, rb, rd): return 0x5000 | (l << 11) | (b << 10) | (ro << 6) | (rb << 3) | rd
def t_f8(h, s, ro, rb, rd): return 0x5200 | (h << 11) | (s << 10) | (ro << 6) | (rb << 3) | rd
def t_f9(b, l, imm5, rb, rd): return 0x6000 | (b << 12) | (l << 11) | (imm5 << 6) | (rb << 3) | rd
def t_f10(l, imm5, rb, rd): return 0x8000 | (l << 11) | (imm5 << 6) | (rb << 3) | rd
def t_f11(l, rd, imm8): return 0x9000 | (l << 11) | (rd << 8) | imm8
def t_f12(sp, rd, imm8): return 0xA000 | (sp << 11) | (rd << 8) | imm8
def t_f13(s, imm7): return 0xB000 | (s << 7) | imm7
def t_f14(l, r, rlist): return 0xB400 | (l << 11) | (r << 8) | rlist
def t_f15(l, rb, rlist): return 0xC000 | (l << 11) | (rb << 8) | rlist
def t_f16(cond, off8): return 0xD000 | (cond << 8) | (off8 & 0xFF)
def t_f18(off11): return 0xE000 | (off11 & 0x7FF)
def t_bl(off):  # off en bytes respecto a (dirección de la 1ª mitad + 4)
    return [0xF000 | ((off >> 12) & 0x7FF), 0xF800 | ((off >> 1) & 0x7FF)]
T_BX_LR = 0x4770

# ---------------------------------------------------------------- Rutinas
ROM_BASE = 0x08000000
ROM_DATA = 0x08010000        # datos de lectura (aleatorios) para las ventanas de ROM
ROM_TBL  = 0x08012000        # tabla de variantes de SMC (para DMA)
ROM_SIZE = 0x08013000 - ROM_BASE
VARS = 0x03007F00            # [0]=semilla, [4]=checksum, [8]=iteración
STACK = 0x03007E00
IW_CODE, EW_CODE = 0x03000100, 0x02000100
REGIONS = {  # nombre: (dirección de r10/r6 = centro de una ventana de 0x200 bytes, escribible)
    'iwram': (0x03001100, True), 'ewram': (0x02010100, True), 'vram': (0x06004100, True), 'pram': (0x05000100, True),
    'rom': (ROM_DATA + 0x100, False), 'rom1': (0x0A000000 + (ROM_DATA - ROM_BASE) + 0x100, False), 'rom2': (0x0C000000 + (ROM_DATA - ROM_BASE) + 0x100, False),
}
WRITABLE = [k for k, v in REGIONS.items() if v[1]]
ALLREG = list(REGIONS)

class Routine:
    def __init__(self, thumb, where):
        self.thumb, self.where = thumb, where       # where: 'rom' | 'iwram' | 'ewram'
        self.items = []                              # ('w', valor) | ('b', cond, etiqueta, link) | ('lbl', n) | ('pool', rd, valor) (Thumb)
        self.writable = True
        self.slot = None                            # (índice de item, variante A, variante B)
        self.addr = 0
        self.size = 0
        self.code = []

def rand_cond(rng, p_al=0.7):
    if rng.random() < p_al: return AL
    return rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13])

D = list(range(0, 9))          # registros de datos ARM
def arm_simple(rng, writable, allow_mem=True, cond=None):
    """Una instrucción ARM ‘recta’ (sin saltos): devuelve lista de palabras."""
    c = rand_cond(rng) if cond is None else cond
    k = rng.random()
    rd, rn, rm, rs = (rng.choice(D) for _ in range(4))
    if k < 0.40:                                   # proceso de datos
        op = rng.randrange(16); s = 1 if op in (8, 9, 10, 11) else rng.randrange(2)
        if op in (8, 9, 10, 11): rd = 0
        if op in (13, 15): rn = 0
        form = rng.random()
        if form < 0.30:
            v = rng.choice([rng.randrange(256), rng.randrange(256) << rng.choice([2, 8, 16, 24, 28]) & 0xFFFFFFFF, 0xFF, 0x80000000, 1, 0xFF000000, 0x3FC])
            if arm_imm(v) is None: v = rng.randrange(256)
            return [a_dp_imm(c, op, s, rn, rd, v)]
        if form < 0.70:
            typ = rng.randrange(4); sh = rng.choice([0, 0, 1, 2, 5, 8, 15, 16, 24, 31]) if typ != 3 else rng.choice([0, 1, 7, 16, 31])
            if typ in (1, 2) and rng.random() < 0.3: sh = 0                      # LSR/ASR #0 = #32
            return [a_dp_reg(c, op, s, rn, rd, rm, typ, sh)]
        return [a_dp_rsr(c, op, s, rn, rd, rm, rng.randrange(4), rs)]           # desplazamiento por registro
    if k < 0.50:                                   # multiplicaciones
        if rng.random() < 0.5:
            rd = rng.choice([r for r in D if r != rm])
            acc = rng.randrange(2)
            return [a_mul(c, acc, rng.randrange(2), rd, rn if acc else 0, rs, rm)]
        hi, lo, m = rng.sample(D, 3)
        return [a_mull(c, rng.randrange(2), rng.randrange(2), rng.randrange(2), hi, lo, rs, m)]
    if k < 0.52:                                   # MRS / MSR solo banderines
        return [a_mrs(c, rd)] if rng.random() < 0.5 else [a_msr_f(c, rm)]
    if not allow_mem:
        return [a_dp_reg(c, 0xC, 0, rn, rd, rm, 0, 0)]
    kk = rng.random()
    st = writable and rng.random() < 0.45
    lval = 0 if st else 1
    if kk < 0.35:                                  # LDR/STR/LDRB/STRB
        b = rng.randrange(2); un = rng.randrange(2)
        off = rng.choice([0, 4, 8, 12, 0x20, 0x7C]) if not b and rng.random() < 0.6 else rng.randrange(0, 0x7F)
        if not b and rng.random() < 0.25: off |= rng.choice([1, 2, 3])          # sin alinear (rotación)
        form = rng.random()
        rest = a_dp_imm(c, 2 if un else 4, 0, 10, 10, off) if off else None   # deshace la escritura de r10 (misma condición)
        if form < 0.55 or not off:
            return [a_sdt_imm(c, 1, un, b, 0, lval, 10, rd, off)]
        if form < 0.75:
            return [a_sdt_imm(c, 1, un, b, 1, lval, 10, rd, off), rest]       # pre-indexado con escritura
        if form < 0.85:
            return [a_sdt_imm(c, 0, un, b, 0, lval, 10, rd, off), rest]       # post-indexado
        return [a_sdt_reg(c, 1, un, b, 0, lval, 10, rd, 11, 0, rng.choice([0, 0, 1, 2]))]
    if kk < 0.60:                                  # media palabra / con signo
        sh = rng.choice([1, 1, 2, 3]) if not st else 1
        l = lval if sh == 1 else 1
        un = rng.randrange(2)
        if rng.random() < 0.6:
            return [a_hw_imm(c, 1, un, 0, l, sh, 10, rd, rng.randrange(0, 0x7F))]
        return [a_hw_reg(c, 1, un, 0, l, sh, 10, rd, 11)]
    if kk < 0.82:                                  # LDM/STM
        n = rng.randrange(1, 6); regs = rng.sample(range(0, 9), n); rl = sum(1 << r for r in regs)
        p, u = rng.choice([(0, 1), (1, 1), (0, 0), (1, 0)])
        l = 0 if st else 1
        if rng.random() < 0.4:                                                    # con escritura y restauración
            w = [a_bdt(c, p, u, 1, l, 10, rl)]
            w.append(a_dp_imm(c, 2 if u else 4, 0, 10, 10, 4 * n))               # u=1 → sub; u=0 → add
            return w
        return [a_bdt(c, p, u, 0, l, 10, rl)]
    if kk < 0.90 and writable:                     # SWP/SWPB (r10 siempre alineado)
        return [a_swp(c, rng.randrange(2), 10, rd, rm)]
    return [a_sdt_imm(c, 1, 1, 0, 0, 1, 10, rd, rng.randrange(0, 0x7C) & ~3)]

def gen_arm(rng, r, nchunks, with_bl=True):
    it = r.items; lc = [0]
    def lab(): lc[0] += 1; return 'L%d' % lc[0]
    subs = []
    if with_bl:
        it.append(('w', a_dp_reg(AL, 0xD, 0, 0, 12, 14)))                          # mov r12, lr
    for _ in range(nchunks):
        k = rng.random()
        if k < 0.50:
            for w in arm_simple(rng, r.writable): it.append(('w', w))
        elif k < 0.70:                                                            # salto condicional hacia delante
            c = rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]); l = lab()
            it.append(('b', c, l, 0))
            for _ in range(rng.randrange(1, 5)):
                for w in arm_simple(rng, r.writable): it.append(('w', w))
            it.append(('lbl', l))
        elif k < 0.88:                                                            # bucle
            l = lab(); it.append(('w', a_dp_imm(AL, 0xD, 0, 0, 9, rng.randrange(2, 9)))); it.append(('lbl', l))
            for _ in range(rng.randrange(1, 6)):
                for w in arm_simple(rng, r.writable): it.append(('w', w))
            it.append(('w', a_dp_imm(AL, 2, 1, 9, 9, 1))); it.append(('b', 1, l, 0))
        elif with_bl:                                                             # llamada a una subrutina local
            n = len(subs); subs.append([arm_simple(rng, r.writable) for _ in range(rng.randrange(1, 6))])
            it.append(('b', rand_cond(rng, 0.8), 'S%d' % n, 1))
        else:
            for w in arm_simple(rng, r.writable): it.append(('w', w))
    it.append(('w', a_bx(AL, 12 if with_bl else 14)))
    for n, body in enumerate(subs):
        it.append(('lbl', 'S%d' % n))
        for ws in body:
            for w in ws: it.append(('w', w))
        it.append(('w', a_bx(AL, 14)))

# ---- Thumb
TD = [0, 1, 2, 3, 4]
def thumb_simple(rng, writable, r, allow_mem=True):
    """Una instrucción Thumb recta; devuelve lista de halfwords (todas de 16 bits). r = rutina (para el pool)."""
    k = rng.random()
    rd, rs, rn = (rng.choice(TD) for _ in range(3))
    if k < 0.14: return [t_f1(rng.randrange(3), rng.choice([0, 1, 2, 5, 8, 15, 16, 31, rng.randrange(32)]), rs, rd)]
    if k < 0.24:
        if rng.random() < 0.5: return [t_f2(0, rng.randrange(2), rn, rs, rd)]
        return [t_f2(1, rng.randrange(2), rng.randrange(8), rs, rd)]
    if k < 0.36: return [t_f3(rng.randrange(4), rd, rng.choice([0, 1, 0x7F, 0x80, 0xFF, rng.randrange(256)]))]
    if k < 0.58: return [t_f4(rng.randrange(16), rs, rd)]
    if k < 0.64:
        hi = rng.choice([8, 8, 8, 12])                                              # r8/r12 (r12 solo es seguro para MOV/ADD/CMP, no para BX)
        op = rng.choice([0, 1, 2])
        if rng.random() < 0.5: return [t_f5(op, rd, 8)] if op != 1 else [t_f5(1, rd, 8)]
        return [t_f5(op, 8, rs)] if op != 1 else [t_f5(1, 8, rs)]
    if not allow_mem: return [t_f3(0, rd, rng.randrange(256))]
    kk = rng.random(); st = writable and rng.random() < 0.45
    if kk < 0.22: return [t_f7(0 if st else 1, rng.randrange(2), 7, 6, rd)]
    if kk < 0.38: return [t_f8(*rng.choice([(0, 0), (0, 1), (1, 0), (1, 1)]) if not st else (0, 0), 7, 6, rd)]
    if kk < 0.58: return [t_f9(0, 0 if st else 1, rng.randrange(32), 6, rd)] if rng.random() < 0.6 else [t_f9(1, 0 if st else 1, rng.randrange(32), 6, rd)]
    if kk < 0.70: return [t_f10(0 if st else 1, rng.randrange(32), 6, rd)]
    if kk < 0.78: return [t_f11(0 if (st and rng.random() < 0.5) else 1, rd, rng.randrange(0, 16))]  # [sp,#imm] (la pila propia, 0x100 bytes)
    if kk < 0.84:
        pi = len(r.pool_vals); r.pool_vals.append(rng.choice([rng.getrandbits(32), 0, 0xFFFFFFFF, 0x80000000]))
        return [('pool', rd, pi)]
    if kk < 0.90: return [t_f12(rng.randrange(2), rd, rng.randrange(0, 16))]
    n = rng.randrange(1, 5); regs = rng.sample(range(0, 5), n); rl = sum(1 << x for x in regs)
    if kk < 0.95:
        return [t_f15(0 if st else 1, 6, rl), t_f3(3, 6, 4 * n)] if True else []
    n2 = rng.randrange(1, 5); regs2 = rng.sample(range(0, 5), n); rl2 = sum(1 << x for x in regs2)
    return [t_f14(0, 0, rl), t_f3(0, rd, 1), t_f14(1, 0, rl2)]                     # push {..}; add rd,#1; pop {..}

def gen_thumb(rng, r, nchunks):
    it = r.items; r.pool_vals = []; lc = [0]
    def lab(): lc[0] += 1; return 'L%d' % lc[0]
    subs = []
    it.append(('w', t_f5(2, 12, 14)))                                                # mov r12, lr
    def emit(ws):
        for w in ws: it.append(('p', w[1], w[2]) if isinstance(w, tuple) else ('w', w))
    for _ in range(nchunks):
        k = rng.random()
        if k < 0.52: emit(thumb_simple(rng, r.writable, r))
        elif k < 0.72:
            c = rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]); l = lab()
            it.append(('bc', c, l))
            for _ in range(rng.randrange(1, 5)): emit(thumb_simple(rng, r.writable, r))
            it.append(('lbl', l))
        elif k < 0.90:
            l = lab(); it.append(('w', t_f3(0, 5, rng.randrange(2, 9)))); it.append(('lbl', l))
            for _ in range(rng.randrange(1, 6)): emit(thumb_simple(rng, r.writable, r))
            it.append(('w', t_f3(3, 5, 1))); it.append(('bc', 1, l))
        else:
            n = len(subs); subs.append([thumb_simple(rng, r.writable, r) for _ in range(rng.randrange(1, 6))]); it.append(('bl', 'S%d' % n))
    it.append(('w', t_f5(3, 0, 12)))                                                 # bx r12
    for n, body in enumerate(subs):
        it.append(('lbl', 'S%d' % n))
        for ws in body: emit(ws)
        it.append(('w', T_BX_LR))

def layout_arm(r):
    pos, labels = 0, {}
    for e in r.items:
        if e[0] == 'lbl': labels[e[1]] = pos
        else: pos += 4
    out, pos = [], 0
    for e in r.items:
        if e[0] == 'lbl': continue
        if e[0] == 'w': out.append(e[1])
        else:
            _, c, l, link = e; out.append(a_b(c, link, (labels[l] - (pos + 8)) // 4))
        pos += 4
    r.code = out; r.size = 4 * len(out)

def layout_thumb(r):
    pos, labels = 0, {}
    for e in r.items:
        if e[0] == 'lbl': labels[e[1]] = pos
        else: pos += 4 if e[0] == 'bl' else 2
    code_end = (pos + 3) & ~3
    out, pos = [], 0
    for e in r.items:
        if e[0] == 'lbl': continue
        if e[0] == 'w': out.append(e[1]); pos += 2
        elif e[0] == 'bc':
            out.append(t_f16(e[1], (labels[e[2]] - (pos + 4)) // 2)); pos += 2
        elif e[0] == 'bl':
            out += t_bl(labels[e[1]] - (pos + 4)); pos += 4
        elif e[0] == 'p':
            base = (pos + 4) & ~3; poff = code_end + 4 * e[2]; imm = (poff - base) // 4
            assert 0 <= imm < 256, 'pool fuera de alcance'
            out.append(t_f6(e[1], imm)); pos += 2
    if len(out) % 2: out.append(0x46C0)                                              # nop (mov r8,r8)
    words = out
    for v in r.pool_vals: words += [v & 0xFFFF, v >> 16]
    r.code = words; r.size = 2 * len(words)

def make_slot(rng, r, thumb):
    """Elige un item recto (no salto ni pool) como ranura de SMC; devuelve (índice del halfword/palabra, variante original, variante nueva)."""
    cand = []
    if thumb:
        pos = 0
        for e in r.items:
            if e[0] == 'lbl': continue
            if e[0] == 'w' and e[1] != T_BX_LR and (e[1] >> 11) in (0, 1, 3, 4, 5, 6, 7, 8) and (e[1] & 0xF800) < 0x4800 and (e[1] >> 10) != 0x11 and not ((e[1] >> 13) == 1 and ((e[1] >> 8) & 7) == 5): cand.append(pos)
            pos += 4 if e[0] == 'bl' else 2
        if not cand: return None
        return rng.choice(cand)
    pos = 0
    for e in r.items:
        if e[0] == 'lbl': continue
        if e[0] == 'w' and (e[1] >> 25) & 7 == 0 and (e[1] >> 28) == AL and (e[1] & 0x90) != 0x90 and (e[1] & 0x0FF00000) < 0x03C00000 and ((e[1] >> 20) & 0x1F) not in (0x10, 0x12, 0x14, 0x16) and max((e[1] >> 12) & 15, (e[1] >> 16) & 15, e[1] & 15, (e[1] >> 8) & 15 if e[1] & 0x10 else 0) <= 8: cand.append(pos)
        pos += 4
    if not cand: return None
    return rng.choice(cand)

def build(args):
    rng = random.Random(args.seed)
    mode = args.mode
    routines = []
    for i in range(args.routines):
        thumb = {'arm': False, 'thumb': True}.get(mode, rng.random() < 0.5)
        where = rng.choice(['rom', 'rom', 'iwram', 'ewram']) if mode != 'smc' else rng.choice(['iwram', 'ewram'])
        r = Routine(thumb, where)
        r.writable = rng.random() < 0.75
        r.pool_vals = []
        (gen_thumb if thumb else gen_arm)(rng, r, args.len)
        (layout_thumb if thumb else layout_arm)(r)
        routines.append(r)
    # ranuras de SMC
    tbl = 0
    slots = []
    if mode in ('smc', 'mixed') :
        for r in routines:
            if r.where == 'rom' or rng.random() < 0.15 and mode == 'mixed': continue
            pos = make_slot(rng, r, r.thumb)
            if pos is None: continue
            if r.thumb:
                a = r.code[pos // 2]
                if (a & 0xF800) in (0x4800,): continue
                b = None
                for _ in range(20):
                    w = thumb_simple(rng, False, r, allow_mem=False)
                    if len(w) == 1 and not isinstance(w[0], tuple) and w[0] != a and (w[0] >> 11) in (0, 1, 3, 4, 5, 6, 7, 8) and (w[0] & 0xF800) < 0x4800: b = w[0]; break
                if b is None: continue
            else:
                a = r.code[pos // 4]
                b = None
                for _ in range(20):
                    w = arm_simple(rng, False, allow_mem=False, cond=AL)
                    if len(w) == 1 and w[0] != a and (w[0] >> 25) & 7 == 0 and (w[0] & 0x90) != 0x90 and ((w[0] >> 20) & 0x1F) not in (0x10, 0x12, 0x14, 0x16): b = w[0]; break
                if b is None: continue
            slots.append((r, pos, a, b, ROM_TBL + tbl)); tbl += 8
    return rng, routines, slots

def place(routines, rom_pos):
    iw, ew = IW_CODE, EW_CODE
    for r in routines:
        r.size = (r.size + 3) & ~3
        if r.where == 'rom':
            r.addr = ROM_BASE + rom_pos; rom_pos += r.size
        else:
            if r.where == 'iwram': r.addr = iw; iw += r.size
            else: r.addr = ew; ew += r.size
            r.src = ROM_BASE + rom_pos; rom_pos += r.size
    assert iw < 0x03001000, 'demasiado codigo en IWRAM: baja --routines/--len'
    assert ew < 0x02010000, 'demasiado codigo en EWRAM'
    assert rom_pos < ROM_DATA - ROM_BASE, 'ROM demasiado grande: baja --routines/--len/--calls'

def build_main(rng, routines, slots, ncalls, mode):
    W = []
    def c32(rd, v, cond=AL): W.extend(a_const(rd, v, cond))
    # ---- arranque
    c32(13, STACK)
    c32(1, 0x04000102); c32(2, 0x0080); W.append(a_hw_imm(AL, 1, 1, 0, 0, 1, 1, 2, 0))       # TM0: 1 ciclo, activo
    c32(1, 0x04000106); c32(2, 0x0084); W.append(a_hw_imm(AL, 1, 1, 0, 0, 1, 1, 2, 0))       # TM1: cascada
    c32(12, VARS); c32(0, (rng.getrandbits(32) | 1)); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 12, 0, 0))
    W.append(a_dp_imm(AL, 0xD, 0, 0, 0, 0)); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 12, 0, 4)); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 12, 0, 8))
    for r in routines:                                                                         # copiar a RAM las rutinas que viven allí
        if r.where == 'rom': continue
        c32(0, r.src); c32(1, r.addr); W.append(a_dp_imm(AL, 0xD, 0, 0, 2, r.size // 4))
        W.append(a_sdt_imm(AL, 0, 1, 0, 0, 1, 0, 3, 4)); W.append(a_sdt_imm(AL, 0, 1, 0, 0, 0, 1, 3, 4))   # ldr r3,[r0],#4 ; str r3,[r1],#4
        W.append(a_dp_imm(AL, 2, 1, 2, 2, 1)); W.append(a_b(1, 0, -5))                          # subs r2,r2,#1 ; bne → ldr (4 instrucciones atrás)
    top = len(W)
    # ---- bucle principal
    def xorshift():
        W.append(a_dp_reg(AL, 1, 0, 0, 0, 0, 0, 13)); W.append(a_dp_reg(AL, 1, 0, 0, 0, 0, 1, 17)); W.append(a_dp_reg(AL, 1, 0, 0, 0, 0, 0, 5))
    def transform(rk):
        t = rng.random()
        if t < 0.30: W.append(a_dp_reg(AL, 0xD, 0, 0, rk, 0))
        elif t < 0.42: W.append(a_dp_reg(AL, 0xD, 0, 0, rk, 0, 1, 24))
        elif t < 0.52: W.append(a_dp_reg(AL, 0xD, 0, 0, rk, 0, 1, 16))
        elif t < 0.60: W.append(a_dp_reg(AL, 0xD, 0, 0, rk, 0, 1, 28))
        elif t < 0.68: W.append(a_dp_imm(AL, 0xD, 0, 0, rk, 0))
        elif t < 0.75: W.append(a_dp_imm(AL, 0xD, 0, 0, rk, 1))
        elif t < 0.82: W.append(a_dp_imm(AL, 0xF, 0, 0, rk, 0))
        elif t < 0.90: W.append(a_dp_imm(AL, 0xD, 0, 0, rk, 0x80000000))
        elif t < 0.95: W.append(a_dp_imm(AL, 0xF, 0, 0, rk, 0x80000000))
        else: W.append(a_dp_reg(AL, 0xD, 0, 0, rk, 0, 0, 0)); W.append(a_dp_imm(AL, 0, 0, rk, rk, 0xFF))
    slot_by_routine = {}
    for s in slots: slot_by_routine.setdefault(id(s[0]), []).append(s)
    order = routines[:]; rng.shuffle(order)                                                  # todas las rutinas se llaman al menos una vez
    for n in range(ncalls):
        r = order[n] if n < len(order) else rng.choice(routines)
        # SMC antes de la llamada
        for (rr, pos, a, b, tbladdr) in slot_by_routine.get(id(r), []):
            if rng.random() < 0.8:
                dest = r.addr + pos
                c32(12, VARS); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 1, 12, 2, 8)); W.append(a_dp_imm(AL, 8, 1, 2, 0, 1))        # r2=iter ; tst r2,#1
                if rng.random() < 0.5:                                                         # por CPU
                    c32(0, a, 0); c32(0, b, 1)                                                 # r0 = (iter&1) ? b : a
                    c32(1, dest)
                    W.append(a_hw_imm(AL, 1, 1, 0, 0, 1, 1, 0, 0) if r.thumb else a_sdt_imm(AL, 1, 1, 0, 0, 0, 1, 0, 0))   # strh/str r0,[dest]
                else:                                                                          # por DMA3 (inmediato, 16 o 32 bits)
                    c32(0, tbladdr); W.append(a_dp_imm(1, 4, 0, 0, 0, 4))                      # r0 = tabla + ((iter&1) ? 4 : 0)
                    c32(1, 0x040000D4); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 1, 0, 0))       # DMA3SAD
                    c32(0, dest); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 1, 0, 4))             # DMA3DAD
                    c32(0, 0x84000001 if not r.thumb else 0x80000001); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 1, 0, 8))   # DMA3CNT
                    W.append(a_dp_imm(AL, 0xD, 0, 0, 0, 0)); W.append(a_dp_imm(AL, 0xD, 0, 0, 0, 0))
        # WAITCNT
        if rng.random() < 0.5:
            c32(1, 0x04000204); c32(2, rng.choice([0x0000, 0x4000, 0x4317, 0x0014, 0x4014, 0x0004, 0x5FFF & 0x7FFF, 0x4210]))
            W.append(a_hw_imm(AL, 1, 1, 0, 0, 1, 1, 2, 0))
        # datos aleatorios en r0-r8
        c32(12, VARS); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 1, 12, 0, 0))
        for k in range(1, 9): xorshift(); transform(k)
        xorshift(); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 12, 0, 0)); transform(0)
        reg = rng.choice(WRITABLE if r.writable else ALLREG); base = REGIONS[reg][0]
        c32(10, base); idx = rng.choice([0, 4, 8, 0x10, 0x3C, 0x24, 1, 2, 3, 0x1D, 0x3F]) if rng.random() < 0.9 else 0
        W.append(a_dp_imm(AL, 0xD, 0, 0, 11, idx))
        if r.thumb: W.append(a_dp_reg(AL, 0xD, 0, 0, 6, 10)); W.append(a_dp_reg(AL, 0xD, 0, 0, 7, 11))
        c32(12, r.addr | (1 if r.thumb else 0)); W.append(a_dp_reg(AL, 0xD, 0, 0, 14, 15)); W.append(a_bx(AL, 12))
        # checksum
        c32(12, VARS); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 1, 12, 9, 4))
        for k in range(9): W.append(a_dp_reg(AL, 1, 0, 9, 9, k, 3, (k * 5 + 1) % 32 or 1))
        W.append(a_mrs(AL, 11)); W.append(a_dp_reg(AL, 1, 0, 9, 9, 11))
        c32(10, 0x04000100); W.append(a_hw_imm(AL, 1, 1, 0, 1, 1, 10, 11, 0)); W.append(a_dp_reg(AL, 4, 0, 9, 9, 11, 0, 5))
        W.append(a_hw_imm(AL, 1, 1, 0, 1, 1, 10, 11, 4)); W.append(a_dp_reg(AL, 1, 0, 9, 9, 11, 3, 13))
        W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 12, 9, 4))
    c32(12, VARS); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 1, 12, 0, 8)); W.append(a_dp_imm(AL, 4, 0, 0, 0, 1)); W.append(a_sdt_imm(AL, 1, 1, 0, 0, 0, 12, 0, 8))
    W.append(a_b(AL, 0, top - (len(W) + 2)))
    return W

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('out'); ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--mode', default='mixed', choices=['arm', 'thumb', 'mixed', 'smc']); ap.add_argument('--routines', type=int, default=8)
    ap.add_argument('--len', type=int, default=24); ap.add_argument('--calls', type=int, default=0); ap.add_argument('--list')
    args = ap.parse_args()
    rng, routines, slots = build(args)
    ncalls = args.calls or max(10, args.routines * 2)
    st = rng.getstate()
    place(routines, 0xC0 + 0x4000)                    # pasada provisional: el tamaño de main no depende de las direcciones
    main_w = build_main(rng, routines, slots, ncalls, args.mode)
    rng.setstate(st)
    place(routines, (0xC0 + 4 * len(main_w) + 3) & ~3)
    main_n = build_main(rng, routines, slots, ncalls, args.mode)
    assert len(main_n) == len(main_w); main_w = main_n
    rom = bytearray(ROM_SIZE)
    rom[0:4] = struct.pack('<I', 0xEA000000 | (((0xC0 - 8) // 4) & 0xFFFFFF))        # b 0xC0
    rom[0xA0:0xAC] = b'CIRILOJIT\0\0\0'; rom[0xAC:0xB0] = b'AJIT'; rom[0xB0:0xB2] = b'01'; rom[0xB2] = 0x96
    c = 0
    for b in rom[0xA0:0xBD]: c = (c - b) & 0xFF
    rom[0xBD] = (c - 0x19) & 0xFF
    for i, w in enumerate(main_w): struct.pack_into('<I', rom, 0xC0 + 4 * i, w)
    lst = []
    lst.append(('arm', ROM_BASE + 0xC0, main_w))
    for r in routines:
        pos = (r.addr - ROM_BASE) if r.where == 'rom' else (r.src - ROM_BASE)
        if r.thumb:
            for i, h in enumerate(r.code): struct.pack_into('<H', rom, pos + 2 * i, h)
        else:
            for i, w in enumerate(r.code): struct.pack_into('<I', rom, pos + 4 * i, w)
        lst.append(('thumb' if r.thumb else 'arm', r.addr, r.code))
    rr = random.Random(args.seed ^ 0x5EED)
    for i in range(ROM_DATA - ROM_BASE, ROM_TBL - ROM_BASE): rom[i] = rr.getrandbits(8)
    for (r, pos, a, b, t) in slots:
        o = t - ROM_BASE
        if r.thumb: struct.pack_into('<HHHH', rom, o, a, 0, b, 0)
        else: struct.pack_into('<II', rom, o, a, b)
    open(args.out, 'wb').write(rom)
    nr = len(routines)
    print('%s: seed %d, modo %s, %d rutinas (%d Thumb, %d en RAM), %d ranuras SMC, main %d bytes' % (args.out, args.seed, args.mode, nr, sum(r.thumb for r in routines), sum(r.where != 'rom' for r in routines), len(slots), len(main_w) * 4))
    if args.list:
        with open(args.list, 'w') as f:
            for (r, pos, a, b, t) in slots: f.write('#slot %08x %s A=%x B=%x\n' % (r.addr + pos, 'thumb' if r.thumb else 'arm', a, b))
            for kind, addr, code in lst:
                f.write('@%s %08x\n' % (kind, addr))
                for x in code: f.write('%0*x\n' % (8 if kind == 'arm' else 4, x))
main()
