// ROM de estrés para el camino rápido de memoria: mezcla cargas y guardados de todos los tamaños (alineados o no, con y sin signo) sobre IWRAM, EWRAM,
// ROM (con espejos y fuera de rango), VRAM, paleta y E/S, en modo ARM y en Thumb, cambiando WAITCNT (con y sin prefetch). Un temporizador de 32 bits
// de 1 ciclo se mete en el resultado, así que un solo ciclo de diferencia cambia el estado. Compilar con tools/test/fast_stress.sh.
typedef unsigned int u32; typedef unsigned short u16; typedef unsigned char u8;
#define R16(a) (*(volatile u16*) (a))
#define MOD(x, n) ((((x) & 0xFFFFu) * (n)) >> 16) // sin divisiones (ARMv4T no las tiene)
static inline u32 rnd(u32* s) { *s = *s * 1664525u + 1013904223u; return *s ^ (*s >> 15); }
#define ROL(x, n) (((x) << (n)) | ((x) >> (32 - (n))))
#define LD(op, d, a) __asm__ volatile(op " %0, [%1]" : "=l"(d) : "l"(a) : "memory")
#define LDX(op, d, a, z) __asm__ volatile(op " %0, [%1, %2]" : "=l"(d) : "l"(a), "l"(z) : "memory")
#define ST(op, v, a) __asm__ volatile(op " %0, [%1]" : : "l"(v), "l"(a) : "memory")
u32 NAME(u32 seed, u32 iters) {
	u32 s = seed, acc = 0, v, z = seed & 0;
	while (iters--) {
		u32 r = rnd(&s), q = rnd(&s), a;
		switch (MOD(r >> 8, 9u)) {
		case 0: case 1: a = 0x03000000u + MOD(q, 0x6F00u); break;                   // IWRAM
		case 2: case 3: a = 0x02000000u + (q & 0x3FFFFu); break;                  // EWRAM
		case 4: case 5: a = 0x08000000u + MOD(q >> 8, 5u) * 0x01000000u + MOD(q >> 16, 0x9000u); break; // ROM y espejos, dentro y fuera de rango
		case 6: a = 0x06000000u + (q & 0x17FFFu); break;                           // VRAM
		case 7: a = 0x05000000u + (q & 0x3FFu); break;                             // paleta
		default: a = 0x04000100u + (q & 0x3Cu); break;                             // E/S (temporizadores)
		}
		if (!(r & 0x10)) a &= ~3u; // la mitad de los accesos, alineados
		u32 hi = a >> 24, w = hi == 2 || hi == 3 || hi == 5 || hi == 6; // zonas donde se puede escribir sin romper el programa
		switch (r & 15) {
		case 0: LD("ldr", v, a); break;
		case 1: LD("ldrh", v, a); break;
		case 2: LD("ldrb", v, a); break;
		case 3: LDX("ldrsb", v, a, z); break;
		case 4: LDX("ldrsh", v, a, z); break;
		case 5: if (w) { ST("str", q, a); } v = q; break;
		case 6: if (w) { ST("strh", q, a); } v = q >> 3; break;
		case 7: if (w) { ST("strb", q, a); } v = q >> 5; break;
		case 8: LD("ldr", v, a); LD("ldr", q, a + 4); v += q; break;
		case 9: LD("ldrh", v, a); LD("ldrh", q, a + 2); v ^= q << 7; break;
		case 10: if (w) { ST("str", q, a); LD("ldr", v, a); } else v = 0; break;
		case 11: if (w) { ST("strb", q, a); LD("ldrb", v, a); } else v = 1; break;
#ifndef THUMB
		case 12: if (w && hi != 5 && hi != 6) { __asm__ volatile("swp %0, %1, [%2]" : "=&r"(v) : "r"(q), "r"(a & ~3u) : "memory"); } else v = 2; break;
		case 13: if (w && hi != 5 && hi != 6) { __asm__ volatile("swpb %0, %1, [%2]" : "=&r"(v) : "r"(q), "r"(a) : "memory"); } else v = 3; break;
#endif
		default: { u32 t0 = R16(0x04000100), t1 = R16(0x04000104); v = t0 | (t1 << 16); } break;
		}
		acc = ROL(acc, 5) ^ v ^ (R16(0x04000100) * 0x10001u) ^ (R16(0x04000104) << 3); // cualquier ciclo de más o de menos cambia esto
	}
	return acc;
}
