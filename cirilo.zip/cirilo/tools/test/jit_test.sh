#!/usr/bin/env bash
# Cirilo - pruebas diferenciales del JIT (Linux x86-64 o arm64; no forma parte del APK).
# Compila DOS núcleos del mismo mGBA fijado: «ref» (sin tocar) y «cand» (con los parches de Cirilo: camino rápido de memoria y, cuando exista, el JIT),
# y comprueba que dan EXACTAMENTE lo mismo (estado completo, vídeo y audio, fotograma a fotograma) con:
#   - ROMs aleatorias de tools/test/mkrom_jit.py (ARM, Thumb, mixtas y con código automodificable por CPU y DMA),
#   - la ROM de estrés de memoria de tools/test/fast_stress.sh (si hay clang+lld+llvm-objcopy),
#   - las ROMs libres jsmolka/gba-tests (arm, thumb, memory, bios) si se pueden descargar.
# Además hace una AUTOPRUEBA: compila un tercer núcleo con un fallo de ciclos metido a propósito y exige que el comparador lo detecte.
# Uso, desde la carpeta cirilo/:   bash tools/test/jit_test.sh
# Con JIT=1 además: autoprueba de la invalidación SMC (el mismo candidato con la invalidación apagada tiene que DIFERIR) y se exige que el JIT ejecute bloques.
# Variables: SEEDS (semillas por modo, 24)  FRAMES (fotogramas por ROM, 600)  JIT=1 (activar el JIT en el candidato: Fase 1+)  SELFTEST=0 (omitir autoprueba)
#            W (carpeta de trabajo, ./jit_work)  MGBA (carpeta con el mGBA fijado ya descargado)
#            SKIP_BUILD=1 con REF_SO, CAND_SO y BUG_SO (núcleos ya compilados con jit_hook.c; solo para depurar este script)
set -u
HERE=$(cd "$(dirname "$0")" && pwd); ROOT=$(cd "$HERE/../.." && pwd)
W=${W:-$ROOT/jit_work}; SEEDS=${SEEDS:-24}; FRAMES=${FRAMES:-600}; JIT=${JIT:-0}; SELFTEST=${SELFTEST:-1}
COMMIT=a67176cd3e6bf60a5016d7adc94357142dd12617
SIMFLAG=""; [ "$(uname -m)" = aarch64 ] || SIMFLAG="-DCIRILO_JIT_SIM"   # fuera de arm64 el código que emite el JIT lo ejecuta un simulador de pruebas (tools/cirilo_jit_a64sim.inc)
mkdir -p "$W/logs" "$W/fallos"; cd "$W" || exit 2
FAILS=0; TOTAL=0; SUMMARY="$W/resumen.md"; : > "$SUMMARY"
say() { echo "== $*"; }
warn() { echo "::warning::$*"; }

build_core() {  # $1 = carpeta con el mGBA ya parcheado, $2 = banderas C extra (opcional) → deja $1/b/mgba_libretro.so
  local extra=${2:-}
  mkdir -p "$1/b" && ( cd "$1/b" && cmake .. -DCMAKE_BUILD_TYPE=Release "-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG -fwrapv $extra" -DBUILD_LIBRETRO=ON -DSKIP_LIBRARY=ON -DBUILD_QT=OFF -DBUILD_SDL=OFF \
      -DDISABLE_DEPS=ON -DUSE_EPOXY=OFF -DBUILD_GL=OFF -DBUILD_GLES2=OFF -DBUILD_GLES3=OFF -DENABLE_SCRIPTING=OFF -DUSE_LUA=OFF -DUSE_FREETYPE=OFF \
      -DUSE_JSON_C=OFF -DUSE_LZMA=OFF -DUSE_ELF=OFF -DUSE_DISCORD_RPC=OFF > cmake.log 2>&1 && make -j"$(nproc 2>/dev/null || echo 2)" mgba_libretro > make.log 2>&1 ) \
    || { cp "$1/b/cmake.log" "$W/logs/build_$1_cmake.log" 2>/dev/null; cp "$1/b/make.log" "$W/logs/build_$1_make.log" 2>/dev/null; tail -40 "$1/b/cmake.log" "$1/b/make.log" 2>/dev/null; echo "::error::no compila $1 (logs en logs/build_$1_*.log)"; return 1; }
}

if [ "${SKIP_BUILD:-0}" = 1 ]; then
  REF_SO=$REF_SO; CAND_SO=$CAND_SO; BUG_SO=${BUG_SO:-}
else
  say "mGBA fijado"
  if [ -z "${MGBA:-}" ]; then
    rm -rf src && git init -q src && git -C src fetch -q --depth 1 https://github.com/mgba-emu/mgba $COMMIT && git -C src checkout -q FETCH_HEAD || { echo "::error::no se pudo descargar mGBA"; exit 2; }
    MGBA=$W/src
  fi
  rm -rf ref cand bug; cp -r "$MGBA" ref; cp -r "$MGBA" cand
  for d in ref cand; do cat "$HERE/jit_hook.c" >> $d/src/platform/libretro/libretro.c; done
  say "parches de Cirilo en el candidato"
  # mismo orden que el APK (build.yml): medidor de CPU -> camino rápido -> JIT. El JIT tiene que encajar con el ARMRunLoop ya instrumentado por el medidor
  if [ -f "$ROOT/tools/cirilo_prof_patch.py" ] && python3 "$ROOT/tools/cirilo_prof_patch.py" cand; then cat "$ROOT/tools/cirilo_prof.c" >> cand/src/platform/libretro/libretro.c; echo "ok: medidor de CPU (como en el APK)"; else warn "sin medidor de CPU en el candidato (el APK sí lo lleva: el JIT no se prueba con su ARMRunLoop)"; fi
  if python3 "$ROOT/tools/cirilo_fast_patch.py" cand ""; then echo "ok: camino rápido de memoria"; else warn "sin camino rápido de memoria (el candidato queda como mGBA original)"; fi
  if [ -f "$ROOT/tools/cirilo_jit_patch.py" ]; then
    python3 "$ROOT/tools/cirilo_jit_patch.py" cand && echo "ok: JIT parcheado" || { echo "::error::el parche del JIT no encaja"; exit 2; }
    grep -q "define CIRILO_JIT_PROF" cand/src/arm/arm.c && echo "ok: el JIT va sobre el ARMRunLoop con medidor (como en el APK)"
  fi
  if [ "$SELFTEST" = 1 ]; then
    cp -r ref bug
    # fallo de ciclos a propósito: 1 ciclo extra en LDMIA/STMIA de Thumb cuando la lista incluye r0
    python3 - <<'PY' || SELFTEST=0
import re
p='bug/src/arm/isa-thumb.c'; s=open(p).read()
old='address = cpu->memory. LS ## Multiple(cpu, address, rs, LSM_ ## DIRECTION, &currentCycles); \\'
assert old in s
open(p,'w').write(s.replace(old, old[:-2]+' currentCycles += (rs & 1); \\',1))
PY
  fi
  say "compilando ref"; build_core ref || exit 2
  say "compilando cand"; build_core cand "-DCIRILO_JIT_TEST $SIMFLAG" || exit 2
  if [ "$SELFTEST" = 1 ]; then say "compilando bug (autoprueba)"; build_core bug || SELFTEST=0; fi
  REF_SO=$W/ref/b/mgba_libretro.so; CAND_SO=$W/cand/b/mgba_libretro.so; BUG_SO=$W/bug/b/mgba_libretro.so
fi
cp "$REF_SO" "$W/core_ref.so"; cp "$CAND_SO" "$W/core_cand.so"; [ -n "${BUG_SO:-}" ] && [ -f "$BUG_SO" ] && cp "$BUG_SO" "$W/core_bug.so"
gcc -O1 -Wall -o jit_cmp "$HERE/jit_cmp.c" -ldl -I"$ROOT/app/src/main/cpp" || { echo "::error::no compila jit_cmp"; exit 2; }
JARG=(); [ "$JIT" = 1 ] && JARG=(-J)

run() {  # run <nombre> <rom> <fotogramas> [args de jit_cmp]
  local n=$1 rom=$2 fr=$3; shift 3; local log="$W/logs/$n.log" st; mkdir -p "$W/fallos/$n"
  ./jit_cmp ./core_ref.so ./core_cand.so "$rom" "$fr" "${JARG[@]}" -d "$W/fallos/$n" -p "$W/logs/$n.ppm" "$@" > "$log" 2>&1; st=$?
  TOTAL=$((TOTAL+1))
  if [ $st = 0 ]; then local jl; jl=$(grep -m1 '^JIT:' "$log" | sed -E 's/^JIT: bloques_creados=([0-9]+) bloques_ejecutados=([0-9]+) instr_en_bloques=([0-9]+) instr_interpretadas=([0-9]+).*invalidaciones=([0-9]+).*bloques_nativos=([0-9]+) ejecuciones_nativas=([0-9]+) sin_margen=([0-9]+) instr_nativas=([0-9]+).*/ · JIT: \1 bloques (\6 nativos), \3 instr en bloques, \9 nativas en \7 ejecuciones (\8 sin margen), \4 interpretadas, \5 invalidaciones/; s/^JIT:$//'); echo "  ok    $n  $(tail -1 "$log" | sed 's/^OK: //')$jl"; echo "| ok | $n | $(tail -1 "$log" | sed 's/^OK: //')$jl |" >> "$SUMMARY"; rmdir "$W/fallos/$n" 2>/dev/null
  elif [ $st = 3 ]; then FAILS=$((FAILS+1)); cp "$rom" "$W/fallos/$n/" 2>/dev/null; echo "  FALLO $n: la ROM se colgó (instrucción indefinida); la prueba es vacía"; echo "| **FALLO** | $n | la ROM se colgó (instrucción indefinida): prueba vacía |" >> "$SUMMARY"
  else FAILS=$((FAILS+1)); cp "$rom" "$W/fallos/$n/" 2>/dev/null; echo "  FALLO $n"; sed 's/^/        /' "$log" | head -30; echo "| **FALLO** | $n | $(grep -m1 DIFERENCIA "$log") |" >> "$SUMMARY"; fi
}

echo "| resultado | prueba | detalle |" >> "$SUMMARY"; echo "|---|---|---|" >> "$SUMMARY"

if [ "$SELFTEST" = 1 ] && [ -f "$W/core_bug.so" ]; then
  say "autoprueba del comparador (tiene que DETECTAR el fallo metido a propósito)"
  python3 "$HERE/mkrom_jit.py" self.gba --seed 1 --mode mixed >/dev/null
  if ./jit_cmp ./core_ref.so ./core_bug.so self.gba 300 > logs/autoprueba.log 2>&1; then echo "::error::AUTOPRUEBA: el comparador NO detectó un fallo de ciclos; no te fíes de los demás resultados"; FAILS=$((FAILS+1)); echo "| **FALLO** | autoprueba | el comparador no detectó el fallo |" >> "$SUMMARY"
  else echo "  ok    autoprueba: $(grep -m1 DIFERENCIA logs/autoprueba.log)"; echo "| ok | autoprueba | detecta un fallo de ciclos metido a propósito |" >> "$SUMMARY"; fi
fi

if [ "$JIT" = 1 ]; then
  say "autoprueba del JIT: sin invalidación SMC el candidato TIENE que diferir en las ROM con código automodificable"
  python3 "$HERE/mkrom_jit.py" selfsmc.gba --seed 1 --mode smc >/dev/null
  if ./jit_cmp ./core_ref.so ./core_cand.so selfsmc.gba 300 -J -X > logs/autoprueba_smc.log 2>&1; then echo "::error::AUTOPRUEBA SMC: sin invalidación no hubo diferencias; las ROM smc no sirven"; FAILS=$((FAILS+1)); echo "| **FALLO** | autoprueba SMC | no detecta un JIT sin invalidación |" >> "$SUMMARY"
  elif grep -q DIFERENCIA logs/autoprueba_smc.log; then echo "  ok    autoprueba SMC: $(grep -m1 DIFERENCIA logs/autoprueba_smc.log)"; echo "| ok | autoprueba SMC | un JIT sin invalidación se detecta |" >> "$SUMMARY"
  else echo "::error::AUTOPRUEBA SMC: falló por otra causa"; cat logs/autoprueba_smc.log | head; FAILS=$((FAILS+1)); fi
fi

if [ "$JIT" = 1 ]; then
  say "prueba unitaria del emisor ($(uname -m)): secuencias Thumb aleatorias, intérprete contra código nativo"
  gcc -O1 -Wall -o jit_unit "$HERE/jit_unit.c" -ldl || { echo "::error::no compila jit_unit"; exit 2; }
  for sd in 1 2 3 4 5; do
    ./jit_unit ./core_cand.so $sd 200000 > logs/unit_$sd.log 2>&1; ust=$?
    if [ $ust = 3 ]; then echo "  (este anfitrión no ejecuta código nativo: se omite)"; break
    elif [ $ust = 0 ]; then echo "  ok    unit semilla $sd: $(tail -1 logs/unit_$sd.log)"; echo "| ok | unit_$sd | $(tail -1 logs/unit_$sd.log) |" >> "$SUMMARY"
    else FAILS=$((FAILS+1)); echo "  FALLO unit semilla $sd"; head -12 logs/unit_$sd.log | cut -c1-600; echo "| **FALLO** | unit_$sd | $(tail -1 logs/unit_$sd.log) |" >> "$SUMMARY"; fi
  done
fi

say "ROMs aleatorias (mkrom_jit.py): $SEEDS semillas × 4 modos × $FRAMES fotogramas"
for mode in arm thumb mixed smc; do
  for seed in $(seq 1 "$SEEDS"); do
    python3 "$HERE/mkrom_jit.py" "rnd_${mode}_$seed.gba" --seed "$seed" --mode "$mode" --routines 8 --len 30 > /dev/null || { echo "::error::mkrom_jit falla ($mode $seed)"; FAILS=$((FAILS+1)); continue; }
    run "rnd_${mode}_$seed" "rnd_${mode}_$seed.gba" "$FRAMES"
  done
done

if [ "$JIT" = 1 ]; then
  say "MODO DE LA APP (-A): las mismas ROMs con bloques Thumb sin copia, ARM sin caché y lo que queda de un bloque en el intérprete"
  python3 "$HERE/mkrom_jit.py" selfsmc.gba --seed 1 --mode smc >/dev/null
  if ./jit_cmp ./core_ref.so ./core_cand.so selfsmc.gba 300 -J -A -X > logs/autoprueba_smc_app.log 2>&1; then warn "autoprueba SMC en modo app: sin invalidación no hubo diferencias (el código nativo de esa ROM no se queda viejo)"
  elif grep -q DIFERENCIA logs/autoprueba_smc_app.log; then echo "  ok    autoprueba SMC (app): $(grep -m1 DIFERENCIA logs/autoprueba_smc_app.log)"; echo "| ok | autoprueba SMC (app) | un JIT sin invalidación se detecta también en modo app |" >> "$SUMMARY"
  else warn "autoprueba SMC en modo app falló por otra causa"; head -5 logs/autoprueba_smc_app.log; fi
  for mode in arm thumb mixed smc; do
    for seed in $(seq 1 "$SEEDS"); do
      [ -f "rnd_${mode}_$seed.gba" ] && run "app_${mode}_$seed" "rnd_${mode}_$seed.gba" "$FRAMES" -A
    done
  done
  # modos de diagnóstico de la app (A: solo despachador; B: nativo sin cargas ni guardados): también deben ser exactos
  for dm in 2 3; do
    for mode in thumb mixed smc; do
      for seed in 1 2 3 4 5 6; do
        [ -f "rnd_${mode}_$seed.gba" ] && run "diag${dm}_${mode}_$seed" "rnd_${mode}_$seed.gba" "$FRAMES" -A -M$dm
      done
    done
    [ -f "$W/stress/fast_stress.gba" ] && run "diag${dm}_fast_stress" "$W/stress/fast_stress.gba" 2000 -s 25 -A -M$dm
  done
fi

say "ROM de estrés de memoria (fast_stress)"
if command -v clang >/dev/null && command -v ld.lld >/dev/null && command -v llvm-objcopy >/dev/null; then
  if sh "$HERE/fast_stress.sh" "$W/stress" > logs/fast_stress_build.log 2>&1; then run fast_stress "$W/stress/fast_stress.gba" 2000 -s 25; [ "$JIT" = 1 ] && run fast_stress_app "$W/stress/fast_stress.gba" 2000 -s 25 -A; else warn "fast_stress.sh no compila (ver logs/fast_stress_build.log)"; fi
else warn "sin clang/lld/llvm-objcopy: se omite fast_stress"; fi

say "ROMs libres de jsmolka/gba-tests"
if [ ! -d gba-tests ]; then git clone -q --depth 1 https://github.com/jsmolka/gba-tests gba-tests 2>/dev/null || warn "no se pudo descargar gba-tests"; fi
for t in arm/arm thumb/thumb memory/memory bios/bios; do
  [ -f "gba-tests/$t.gba" ] && run "gba-tests_$(basename $t)" "gba-tests/$t.gba" 600 || echo "  (falta gba-tests/$t.gba)"
  [ "$JIT" = 1 ] && [ -f "gba-tests/$t.gba" ] && run "gba-tests_app_$(basename $t)" "gba-tests/$t.gba" 600 -A
done

echo; echo "RESULTADO: $((TOTAL-FAILS)) de $TOTAL pruebas idénticas, $FAILS con diferencias"
{ echo; echo "**$((TOTAL-FAILS)) de $TOTAL pruebas idénticas, $FAILS con diferencias** (JIT=$JIT, $SEEDS semillas, $FRAMES fotogramas)"; } >> "$SUMMARY"
[ -n "${GITHUB_STEP_SUMMARY:-}" ] && cat "$SUMMARY" >> "$GITHUB_STEP_SUMMARY"
[ "$FAILS" = 0 ]
