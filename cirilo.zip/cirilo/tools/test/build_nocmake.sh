#!/usr/bin/env bash
# Compila el núcleo libretro de mGBA (GBA+GB) SIN cmake, con gcc/clang y make. Solo para pruebas en Linux (el APK usa cmake/NDK).
# Uso: build_nocmake.sh <carpeta mGBA (ya parcheada o no)> [banderas C extra]   → deja <carpeta>/b/mgba_libretro.so
# Replica las listas de fuentes y definiciones de CMakeLists.txt (BUILD_LIBRETRO, DISABLE_DEPS): __LIBRETRO__ COLOR_16_BIT COLOR_5_6_5 DISABLE_THREADING MGBA_STANDALONE ENABLE_VFS MINIMAL_CORE=2
set -e
SRC=$(cd "$1" && pwd); EXTRA=${2:-}; CC=${CC:-gcc}; OPT=${OPT:--O2}
B=$SRC/b; mkdir -p $B/gen/mgba
cat > $B/gen/mgba/flags.h <<'H'
#ifndef FLAGS_H
#define FLAGS_H
#define MINIMAL_CORE 2
#define COLOR_16_BIT
#define COLOR_5_6_5
#define DISABLE_THREADING
#define M_CORE_GBA
#define M_CORE_GB
#define ENABLE_VFS
#define ENABLE_VFS_FD
#define HAVE_STRDUP
#define HAVE_LOCALTIME_R
#define HAVE_POPCOUNT32
#endif
H
cat > $B/gen/version.c <<'V'
#include <mgba/core/version.h>
MGBA_EXPORT const char* const gitCommit = "a67176cd3e6bf60a5016d7adc94357142dd12617";
MGBA_EXPORT const char* const gitCommitShort = "a67176cd";
MGBA_EXPORT const char* const gitBranch = "pinned";
MGBA_EXPORT const int gitRevision = 0;
MGBA_EXPORT const char* const binaryName = "mgba";
MGBA_EXPORT const char* const projectName = "mGBA";
MGBA_EXPORT const char* const projectVersion = "0.11-pinned";
V
cd $SRC/src
FILES="core/bitmap-cache.c core/cache-set.c core/cheats.c core/config.c core/core.c core/directories.c core/input.c core/interface.c core/lockstep.c core/log.c core/map-cache.c core/mem-search.c core/rewind.c core/serialize.c core/sync.c core/thread.c core/tile-cache.c core/timing.c
arm/arm.c arm/decoder-arm.c arm/decoder.c arm/decoder-thumb.c arm/isa-arm.c arm/isa-thumb.c
sm83/decoder.c sm83/isa-sm83.c sm83/sm83.c
gba/audio.c gba/bios.c gba/cart/ereader.c gba/cart/gpio.c gba/cart/matrix.c gba/cart/unlicensed.c gba/cart/vfame.c gba/cheats.c gba/cheats/codebreaker.c gba/cheats/gameshark.c gba/cheats/parv3.c gba/core.c gba/dma.c gba/gba.c gba/hle-bios.c gba/input.c gba/io.c gba/memory.c gba/overrides.c gba/renderers/cache-set.c gba/renderers/common.c gba/renderers/gl.c gba/renderers/software-bg.c gba/renderers/software-mode0.c gba/renderers/software-obj.c gba/renderers/video-software.c gba/savedata.c gba/serialize.c gba/sharkport.c gba/sio.c gba/sio/gbp.c gba/timer.c gba/video.c
gb/audio.c gb/cheats.c gb/core.c gb/gb.c gb/input.c gb/io.c gb/mbc.c gb/mbc/huc-3.c gb/mbc/licensed.c gb/mbc/mbc.c gb/mbc/pocket-cam.c gb/mbc/tama5.c gb/mbc/unlicensed.c gb/memory.c gb/overrides.c gb/serialize.c gb/renderers/cache-set.c gb/renderers/software.c gb/sio.c gb/timer.c gb/video.c
util/circle-buffer.c util/configuration.c util/crc32.c util/formatting.c util/gbk-table.c util/hash.c util/md5.c util/sha1.c util/string.c util/table.c util/vector.c util/vfs.c util/audio-buffer.c util/audio-resampler.c util/convolve.c util/geometry.c util/image.c util/image/export.c util/image/font.c util/interpolator.c util/patch.c util/patch-fast.c util/patch-ips.c util/patch-ups.c util/ring-fifo.c util/sfo.c util/text-codec.c
util/vfs/vfs-mem.c util/vfs/vfs-fifo.c util/vfs/vfs-fd.c
third-party/inih/ini.c platform/posix/memory.c platform/libretro/libretro.c"
EXTRAF=""; for f in gba/sio/lockstep.c gb/sio/lockstep.c; do grep -q "$f" $SRC/src/platform/libretro/.cirilo_link 2>/dev/null && EXTRAF="$EXTRAF $f"; done
[ -f $B/extra_sources ] && EXTRAF="$EXTRAF $(cat $B/extra_sources)"
DEFS="-D__LIBRETRO__ -DCOLOR_16_BIT -DCOLOR_5_6_5 -DDISABLE_THREADING -DMGBA_STANDALONE -DENABLE_VFS -DENABLE_VFS_FD -DMINIMAL_CORE=2 -DM_CORE_GBA -DM_CORE_GB -D_GNU_SOURCE -DHAVE_STRDUP -DHAVE_LOCALTIME_R -DHAVE_STRTOF_L -DHAVE_LOCALE"
INC="-I$SRC/include -I$SRC/src -I$B/gen -I$SRC/src/third-party/inih"
{
echo "OBJS :="
for f in $FILES $EXTRAF; do o=$B/obj/$(echo $f | tr / _).o; echo "OBJS += $o"; echo "$o: $SRC/src/$f"; echo "	@mkdir -p $B/obj; $CC $OPT -fPIC -fwrapv -w $DEFS $INC $EXTRA -c \$< -o \$@"; done
echo "$B/obj/version.o: $B/gen/version.c"; echo "	@mkdir -p $B/obj; $CC $OPT -fPIC -w $DEFS $INC -c \$< -o \$@"
echo "$B/mgba_libretro.so: \$(OBJS) $B/obj/version.o"; echo "	$CC -shared -o \$@ \$^ -lm -ldl"
} > $B/Makefile
make -s -f $B/Makefile $B/mgba_libretro.so -j"$(nproc)"
ls -la $B/mgba_libretro.so
