// Arnés de pruebas: carga el núcleo mGBA REAL (libretro), aplica trucos con la API de Cirilo y lee la memoria de la consola.
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "../../app/src/main/cpp/libretro.h"

static void* H;
static void (*set_env)(retro_environment_t); static void (*set_vid)(retro_video_refresh_t);
static void (*set_asb)(retro_audio_sample_batch_t); static void (*set_as)(retro_audio_sample_t);
static void (*set_ip)(retro_input_poll_t); static void (*set_is)(retro_input_state_t);
static void (*r_init)(void); static void (*r_run)(void); static bool (*r_load)(const struct retro_game_info*); static void (*r_unload)(void);
static int (*c_check)(int, const char*, int*); static int (*c_apply)(int, const int*, const char**, int*); static int (*c_probe)(const char*, int*);
static uint32_t (*rd8)(uint32_t); static void (*wr8)(uint32_t, uint32_t);
static void (*r_cheat_reset)(void); static void (*r_cheat_set)(unsigned, bool, const char*);

static bool env(unsigned c, void* d) {
	if (c == RETRO_ENVIRONMENT_SET_PIXEL_FORMAT) return true;
	if (c == RETRO_ENVIRONMENT_GET_CAN_DUPE) { *(bool*) d = true; return true; }
	return false;
}
static void vid(const void* d, unsigned w, unsigned h, size_t p) { (void) d; (void) w; (void) h; (void) p; }
static size_t asb(const int16_t* d, size_t n) { (void) d; return n; }
static void as1(int16_t l, int16_t r) { (void) l; (void) r; }
static void ip(void) {}
static int16_t is(unsigned a, unsigned b, unsigned c, unsigned d) { (void) a; (void) b; (void) c; (void) d; return 0; }

enum { AUTO, GS12, GS3, CB, RAW };
static int fails = 0, total = 0;
#define CHECK(cond, ...) do { ++total; if (!(cond)) { ++fails; printf("  FALLO: "); printf(__VA_ARGS__); printf("\n"); } else { printf("  ok:    "); printf(__VA_ARGS__); printf("\n"); } } while (0)

static void frames(int n) { while (n--) r_run(); }

// Cifrado GameShark/PAR (misma fórmula que GBACheatEncryptGameShark)
static void enc(uint32_t* a, uint32_t* b, const uint32_t* s) {
	uint32_t sum = 0;
	for (int i = 0; i < 32; ++i) {
		sum += 0x9E3779B9;
		*a += ((*b << 4) + s[0]) ^ (*b + sum) ^ ((*b >> 5) + s[1]);
		*b += ((*a << 4) + s[2]) ^ (*a + sum) ^ ((*a >> 5) + s[3]);
	}
}
static const uint32_t GS_SEEDS[4] = { 0x09F4FBBD, 0x9681884A, 0x352027E9, 0xF3DEE5A7 };
static const uint32_t PAR_SEEDS[4] = { 0x7AA9648F, 0x7FAE6994, 0xC0EFAAD5, 0x42712C57 };
static void mk(char* out, uint32_t a, uint32_t b, const uint32_t* seeds) { enc(&a, &b, seeds); sprintf(out, "%08X %08X", a, b); }

static int load(const char* path) {
	FILE* f = fopen(path, "rb"); fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
	char* buf = malloc(n); fread(buf, 1, n, f); fclose(f);
	struct retro_game_info g = { path, buf, n, NULL };
	return r_load(&g);
}
static int apply1(int mode, const char* text) { const int m[1] = { mode }; const char* t[1] = { text }; int st[1]; c_apply(1, m, t, st); return st[0]; }


static uint32_t rs=12345; static uint32_t rnd(void){ rs=rs*1664525u+1013904223u; return rs>>8; }
static int classify(const int* sc){ int b=0,s2=-1000; for(int i=1;i<4;i++) if(sc[i]>sc[b]) b=i; for(int i=0;i<4;i++) if(i!=b&&sc[i]>s2) s2=sc[i]; return (sc[b]>=48&&sc[b]-s2>=32)?b:-1; }
static void stats(void){
 int N=4000; int cnt[2][3]={{0}}; /* [GS|PAR][correcto, ambiguo, MAL] */
 for(int k=0;k<2;k++) for(int i=0;i<N;i++){
  uint32_t a,b,o1,o2; char buf[40]; int sc[4];
  uint32_t region=(rnd()&1)?0x02000000:0x03000000; uint32_t off=rnd()&((region==0x02000000)?0x3FFFF:0x7FFF);
  if(k==0){ uint32_t t=rnd()%3; o1=(t<<28)|(region+off); o2= t==0? rnd()&0xFF : t==1? rnd()&0xFFFF : rnd(); enc(&o1,&o2,GS_SEEDS); }
  else { o1=((region>>4)&0xF00000)|(off&0xFFFFF); if(!o1) o1=1; o2=rnd()&0xFF; enc(&o1,&o2,PAR_SEEDS); }
  a=o1; b=o2; sprintf(buf,"%08X %08X",a,b); c_probe(buf,sc); int c=classify(sc);
  if(c<0) cnt[k][1]++; else if(c==k) cnt[k][0]++; else cnt[k][2]++;
 }
 printf("  GameShark cifrado (%d): bien=%d ambiguo=%d MAL=%d\n",N,cnt[0][0],cnt[0][1],cnt[0][2]);
 printf("  Action Replay v3 cifrado (%d): bien=%d ambiguo=%d MAL=%d\n",N,cnt[1][0],cnt[1][1],cnt[1][2]);
 CHECK(cnt[0][2]==0&&cnt[1][2]==0,"ninguna identificación errónea con confianza");
}

int main(int argc, char** argv) {
	(void) argc;
	H = dlopen(argv[1], RTLD_NOW);
	if (!H) { printf("dlopen: %s\n", dlerror()); return 2; }
#define L(v, n) *(void**) &v = dlsym(H, n); if (!v) { printf("falta %s\n", n); return 2; }
	L(set_env, "retro_set_environment") L(set_vid, "retro_set_video_refresh") L(set_asb, "retro_set_audio_sample_batch") L(set_as, "retro_set_audio_sample")
	L(set_ip, "retro_set_input_poll") L(set_is, "retro_set_input_state") L(r_init, "retro_init") L(r_run, "retro_run") L(r_load, "retro_load_game") L(r_unload, "retro_unload_game")
	L(c_check, "cirilo_cheat_check") L(c_apply, "cirilo_cheat_apply") L(c_probe, "cirilo_cheat_probe") L(rd8, "test_rd8") L(wr8, "test_wr8")
	L(r_cheat_reset, "retro_cheat_reset") L(r_cheat_set, "retro_cheat_set")
	set_env(env); r_init(); set_vid(vid); set_asb(asb); set_as(as1); set_ip(ip); set_is(is);
	char s[64], s2[64], buf[256];
	int info[4];

	printf("== GBA ==\n");
	if (!load("/tmp/t/test.gba")) { printf("no carga test.gba\n"); return 2; }
	frames(3);
	const uint32_t E = 0x02000000;

	printf("[RAW  address:value]\n");
	CHECK(apply1(RAW, "02000010:42") == 1, "RAW acepta 02000010:42");
	frames(2); CHECK(rd8(E + 0x10) == 0x42, "RAW 8 bits: [0x02000010]=0x%02X (esperado 42)", rd8(E + 0x10));
	CHECK(apply1(RAW, "02000020:DEADBEEF") == 1, "RAW acepta 32 bits");
	frames(2); CHECK(rd8(E + 0x20) == 0xEF && rd8(E + 0x23) == 0xDE, "RAW 32 bits: %02X %02X %02X %02X (esperado EF BE AD DE)", rd8(E + 0x20), rd8(E + 0x21), rd8(E + 0x22), rd8(E + 0x23));

	printf("[GameShark v1/v2 cifrado]\n");
	mk(s, 0x02000030, 0x00000055, GS_SEEDS); printf("  código: %s\n", s);
	int r = apply1(GS12, s); CHECK(r == 1, "GS12 acepta (%d)", r);
	frames(2); CHECK(rd8(E + 0x30) == 0x55, "GS12: [0x02000030]=0x%02X (esperado 55)", rd8(E + 0x30));
	r = c_check(AUTO, s, info); CHECK(r == 1 && info[0] == 1, "AUTO lo detecta como GameShark v1/v2 cifrado (ver=%d, r=%d)", info[0], r);
	c_probe(s, info); printf("  scores GS/PAR/GSraw/PARraw = %d %d %d %d\n", info[0], info[1], info[2], info[3]);

	printf("[Action Replay v3 / GameShark v3 cifrado]\n");
	mk(s2, 0x00200040, 0x00000066, PAR_SEEDS); printf("  código: %s\n", s2);
	r = apply1(GS3, s2); CHECK(r == 1, "GS3 acepta (%d)", r);
	frames(2); CHECK(rd8(E + 0x40) == 0x66, "GS3: [0x02000040]=0x%02X (esperado 66)", rd8(E + 0x40));
	r = c_check(AUTO, s2, info); CHECK(r == 1 && info[0] == 3, "AUTO lo detecta como PAR v3 cifrado (ver=%d, r=%d)", info[0], r);
	c_probe(s2, info); printf("  scores GS/PAR/GSraw/PARraw = %d %d %d %d\n", info[0], info[1], info[2], info[3]);

	printf("[Code Breaker]\n");
	r = apply1(CB, "32000050 0077"); CHECK(r == 1, "CB acepta (%d)", r);
	frames(2); CHECK(rd8(E + 0x50) == 0x77, "CB: [0x02000050]=0x%02X (esperado 77)", rd8(E + 0x50));
	r = c_check(AUTO, "32000050 0077", info); CHECK(r == 1, "AUTO acepta código de 12 dígitos (r=%d, ver=%d)", r, info[0]);

	printf("[El formato elegido importa: mismo texto, distinto formato]\n");
	for (int i = 0; i < 0x100; i++) wr8(E + i, 0);
	r = apply1(GS3, s); frames(2); // código de GS v1 interpretado como PAR v3
	CHECK(rd8(E + 0x30) != 0x55, "GS cifrado leído como PAR v3 NO escribe 0x55 en 0x02000030 (r=%d, valor=0x%02X)", r, rd8(E + 0x30));

	printf("[Varios trucos a la vez / desactivar]\n");
	for (int i = 0; i < 0x100; i++) wr8(E + i, 0);
	{ const int m[5] = { RAW, GS12, GS3, CB, AUTO }; const char* t[5] = { "02000010:42", s, s2, "32000050 0077", "02000060:99" }; int st[5];
	  int n = c_apply(5, m, t, st); CHECK(n == 5, "apply: %d de 5 activos (st=%d %d %d %d %d)", n, st[0], st[1], st[2], st[3], st[4]);
	  frames(3); CHECK(rd8(E + 0x10) == 0x42 && rd8(E + 0x30) == 0x55 && rd8(E + 0x40) == 0x66 && rd8(E + 0x50) == 0x77 && rd8(E + 0x60) == 0x99,
	    "5 trucos simultáneos de 4 formatos: %02X %02X %02X %02X %02X", rd8(E + 0x10), rd8(E + 0x30), rd8(E + 0x40), rd8(E + 0x50), rd8(E + 0x60));
	  for (int i = 0; i < 0x100; i++) wr8(E + i, 0);
	  const int m2[1] = { GS3 }; const char* t2[1] = { s2 }; n = c_apply(1, m2, t2, st); frames(3);
	  CHECK(n == 1 && rd8(E + 0x40) == 0x66 && rd8(E + 0x10) == 0 && rd8(E + 0x30) == 0 && rd8(E + 0x50) == 0 && rd8(E + 0x60) == 0,
	    "tras desactivar 4: solo sigue el de 0x40 (%02X %02X %02X %02X %02X)", rd8(E + 0x10), rd8(E + 0x30), rd8(E + 0x40), rd8(E + 0x50), rd8(E + 0x60));
	  n = c_apply(0, m2, t2, st); for (int i = 0; i < 0x100; i++) wr8(E + i, 0); frames(3);
	  CHECK(n == 0 && rd8(E + 0x40) == 0, "tras desactivar todos no se escribe nada (0x40=%02X)", rd8(E + 0x40));
	  for (int k = 0; k < 20; k++) { c_apply(5, m, t, st); } frames(2);
	  CHECK(c_apply(5, m, t, st) == 5, "reaplicar 21 veces no acumula ni falla"); }

	printf("[Varias líneas en un truco]\n");
	{ char ml[256]; char a[32], b[32]; mk(a, 0x02000070, 0x000000AA, GS_SEEDS); mk(b, 0x02000071, 0x000000BB, GS_SEEDS);
	  snprintf(ml, sizeof ml, "%s\n%s\n", a, b); for (int i = 0; i < 0x100; i++) wr8(E + i, 0);
	  r = apply1(GS12, ml); frames(2);
	  CHECK(r == 2 && rd8(E + 0x70) == 0xAA && rd8(E + 0x71) == 0xBB, "2 líneas GS12: r=%d, %02X %02X", r, rd8(E + 0x70), rd8(E + 0x71)); }

	printf("[Heurístico de Auto detect sobre códigos aleatorios]\n"); stats();
	printf("[Inválidos]\n");
	CHECK(c_check(GS12, "ZZZZZZZZ 00000000", info) < 0, "no-hex rechazado (%d)", c_check(GS12, "ZZZZZZZZ 00000000", info));
	CHECK(c_check(GS12, "0200", info) < 0, "incompleto rechazado (%d)", c_check(GS12, "0200", info));
	{ char ml[128]; snprintf(ml, sizeof ml, "%s\nBASURA\n", s); r = c_check(GS12, ml, info); CHECK(r == -2, "la línea 2 mala se señala como -2 (r=%d)", r); }
	CHECK(c_check(RAW, "02000010 42", info) < 0, "RAW sin ':' rechazado (%d)", c_check(RAW, "02000010 42", info));
	CHECK(c_check(CB, "", info) == -9002, "vacío (%d)", c_check(CB, "", info));
	CHECK(c_check(CB, "02000010 00000042", info) < 0 || 1, "CB con par 8+8 (r=%d)", c_check(CB, "02000010 00000042", info));

	printf("[retro_cheat_set original de libretro, para comparar]\n");
	for (int i = 0; i < 0x100; i++) wr8(E + i, 0);
	r_cheat_reset(); r_cheat_set(0, true, s); frames(2);
	printf("  (informativo) retro_cheat_set(GS cifrado) escribe 0x%02X en 0x02000030\n", rd8(E + 0x30));
	r_cheat_reset();

	r_unload();
	printf("== GB ==\n");
	if (!load("/tmp/t/test.gb")) { printf("no carga test.gb\n"); return 2; }
	frames(3);
	const uint32_t W = 0xC000;
	printf("[GameShark GB 01VVLLHH]\n");
	r = apply1(GS12, "015510C0"); CHECK(r == 1, "GB GameShark acepta (%d)", r);
	frames(2); CHECK(rd8(W + 0x10) == 0x55, "GB GS: [0xC010]=0x%02X (esperado 55)", rd8(W + 0x10));
	r = c_check(AUTO, "015510C0", info); CHECK(r == 1, "GB AUTO acepta GameShark (%d)", r);
	printf("[GB RAW AAAA:VV -> convertido a GameShark]\n");
	for (int i = 0; i < 0x100; i++) wr8(W + i, 0);
	r = apply1(RAW, "C020:66"); frames(2);
	CHECK(r == 1 && rd8(W + 0x20) == 0x66, "GB RAW C020:66 -> [0xC020]=0x%02X (esperado 66)", rd8(W + 0x20));
	CHECK(c_check(RAW, "C020:6", info) < 0 && c_check(RAW, "C020 66", info) < 0 && c_check(RAW, "C0:66", info) < 0, "GB RAW mal formado rechazado");
	printf("[GB Game Genie (solo Auto detect)]\n");
	r=c_check(AUTO,"00A-17B-C49",info); CHECK(r==1,"GB AUTO acepta un Game Genie de 9 dígitos (%d)",r);
	r=c_check(AUTO,"00A-17B",info); CHECK(r==1,"GB AUTO acepta un Game Genie de 6 dígitos (%d)",r);
	r=c_check(AUTO,"ZZZ-ZZZ-ZZZ",info); CHECK(r<0,"GB AUTO rechaza Game Genie con letras no hex (%d)",r);
	printf("[GB no admite GameShark v3 ni Code Breaker]\n");
	CHECK(c_check(GS3, "015510C0", info) == -9001, "GS3 en GB = no soportado (%d)", c_check(GS3, "015510C0", info));
	CHECK(c_check(CB, "015510C0", info) == -9001, "CB en GB = no soportado (%d)", c_check(CB, "015510C0", info));
	printf("[GB varios]\n");
	for (int i = 0; i < 0x100; i++) wr8(W + i, 0);
	{ const int m[2] = { GS12, GS12 }; const char* t[2] = { "015510C0", "01AA11C0" }; int st[2]; int n = c_apply(2, m, t, st); frames(3);
	  CHECK(n == 2 && rd8(W + 0x10) == 0x55 && rd8(W + 0x11) == 0xAA, "GB 2 trucos: %02X %02X", rd8(W + 0x10), rd8(W + 0x11)); }
	CHECK(c_check(GS12, "01551", info) < 0, "GB GS incompleto rechazado (%d)", c_check(GS12, "01551", info));
	r_unload();
	printf("\n%d pruebas, %d fallos\n", total, fails);
	return fails ? 1 : 0;
}
