// Prueba local del diagnóstico (diag.h) con un núcleo libretro de pruebas y una ROM: uso: diag_test core.so rom.gba [fotogramas]
#include <dlfcn.h>
#include "../../app/src/main/cpp/libretro.h"
#include "../../app/src/main/cpp/diag.h"
static uint64_t fh=0;
static bool env(unsigned c,void*d){if(c==RETRO_ENVIRONMENT_SET_PIXEL_FORMAT)return true;if(c==RETRO_ENVIRONMENT_GET_CAN_DUPE){*(bool*)d=true;return true;}return false;}
static void vid(const void*d,unsigned w,unsigned h,size_t p){if(!d)return;uint64_t x=1469598103934665603ull;for(unsigned y=0;y<h;y++)x=diag::fnv((const char*)d+y*p,w*2,x);fh=x;}
static size_t asb(const int16_t*,size_t n){return n;}static void as1(int16_t,int16_t){}static void ip(){}static int16_t is(unsigned,unsigned,unsigned,unsigned){return 0;}
int main(int argc,char**argv){
 void*h=dlopen(argv[1],RTLD_NOW);if(!h){puts(dlerror());return 2;}
 #define F(t,n) auto n=(t)dlsym(h,#n)
 F(void(*)(retro_environment_t),retro_set_environment);F(void(*)(),retro_init);F(void(*)(retro_video_refresh_t),retro_set_video_refresh);F(void(*)(retro_audio_sample_batch_t),retro_set_audio_sample_batch);
 F(void(*)(retro_audio_sample_t),retro_set_audio_sample);F(void(*)(retro_input_poll_t),retro_set_input_poll);F(void(*)(retro_input_state_t),retro_set_input_state);
 F(bool(*)(const retro_game_info*),retro_load_game);F(void(*)(),retro_run);F(size_t(*)(),retro_serialize_size);F(bool(*)(void*,size_t),retro_serialize);F(bool(*)(const void*,size_t),retro_unserialize);
 F(void(*)(int),cirilo_jit_set);F(void(*)(int),cirilo_jit_diag);F(void(*)(uint64_t*),cirilo_jit_diag_read);F(int(*)(uint32_t*),cirilo_jit_stats);F(void(*)(uint64_t*),cirilo_prof_cumul);F(uint64_t(*)(),cirilo_prof_freq);
 retro_set_environment(env);retro_init();retro_set_video_refresh(vid);retro_set_audio_sample_batch(asb);retro_set_audio_sample(as1);retro_set_input_poll(ip);retro_set_input_state(is);
 FILE*f=fopen(argv[2],"rb");std::vector<char> rom(1<<25);size_t n=fread(rom.data(),1,rom.size(),f);fclose(f);rom.resize(n);
 retro_game_info g={argv[2],rom.data(),rom.size(),nullptr};if(!retro_load_game(&g)){puts("no carga");return 2;}
 cirilo_jit_set(1);for(int i=0;i<200;i++)retro_run();
 DiagIf d;d.run=[&]{retro_run();};d.ssz=[&]{return retro_serialize_size();};d.ser=[&](void*p,size_t z){return retro_serialize(p,z);};d.unser=[&](const void*p,size_t z){return retro_unserialize(p,z);};
 d.jset=[&](int m){cirilo_jit_set(m);};d.jdiag=[&](int x){cirilo_jit_diag(x);};d.jread=[&](uint64_t*o){cirilo_jit_diag_read(o);};d.jstats=[&](uint32_t*o){return cirilo_jit_stats(o);};
 d.pcum=[&](uint64_t*o){cirilo_prof_cumul(o);};d.pfreq=[&]{return cirilo_prof_freq();};d.frameHash=[&]{return fh;};d.origMode=1;d.hasJit=true;
 d.frames=argc>3?atoi(argv[3]):60;d.quick=argc>4;d.warm=30;d.rounds=2;
 std::atomic<int> pr{0};std::string r=diag::run(d,&pr,nullptr);fputs(r.c_str(),stdout);
 for(int i=0;i<50;i++)retro_run();puts("el juego sigue corriendo tras el diagnóstico: ok");return 0;}
