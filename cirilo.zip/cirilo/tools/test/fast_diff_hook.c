// Gancho de prueba (solo para la prueba, no va en el APK): se añade al final de libretro.c del núcleo parcheado. Compara cada carga/guardado de cirilo_fast.h con GBALoadN/GBAStoreN. Ver LEEME.txt punto 5.
#include <mgba/internal/gba/cirilo_fast.h>
static uint64_t cf_s;
static uint32_t cf_rnd(void) { cf_s ^= cf_s << 13; cf_s ^= cf_s >> 7; cf_s ^= cf_s << 17; return (uint32_t) (cf_s >> 16); }
__attribute__((visibility("default"))) int test_fast_diff(unsigned seed, int n, unsigned* counts) {
	struct ARMCore* cpu = core->cpu; struct GBA* gba = core->board; struct GBAMemory* m = &gba->memory;
	cf_s = 0x9E3779B97F4A7C15ull ^ ((uint64_t) seed << 20) ^ seed;
	int bad = 0;
	uint32_t pc0 = cpu->gprs[15]; int ar0 = m->activeRegion; bool pf0 = m->prefetch; uint32_t lp0 = m->lastPrefetchedPc;
	uint32_t s160 = cpu->memory.activeSeqCycles16, n160 = cpu->memory.activeNonseqCycles16;
	char w32[256], w16[256]; memcpy(w32, m->waitstatesNonseq32, 256); memcpy(w16, m->waitstatesNonseq16, 256);
	for (int i = 0; i < n; ++i) {
		/* estado de espera/prefetch aleatorio */
		static const int ars[] = {0, 2, 3, 8, 9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF};
		m->activeRegion = ars[cf_rnd() % 11]; m->prefetch = cf_rnd() & 1;
		cpu->gprs[15] = (cf_rnd() & 1 ? 0x08000000u : 0x02000000u) + (cf_rnd() & 0xFFFF);
		m->lastPrefetchedPc = cf_rnd() % 3 ? cpu->gprs[15] + (int)(cf_rnd() % 40) - 20 : cf_rnd();
		cpu->memory.activeSeqCycles16 = 1 + cf_rnd() % 8; cpu->memory.activeNonseqCycles16 = 1 + cf_rnd() % 8;
		for (int k = 0; k < 16; ++k) { m->waitstatesNonseq32[k] = cf_rnd() % 9; m->waitstatesNonseq16[k] = cf_rnd() % 9; }
		int op = cf_rnd() % 6, cls = cf_rnd() % 4;
		uint32_t reg = cls == 0 ? 3 : cls == 1 ? 2 : (8 + cf_rnd() % 6);
		if (op < 3 && op == 1 && reg == 0xD) reg = 0xC; /* load16 a ROM2_EX lee la EEPROM (con efectos): se prueba que delega por construcción */
		uint32_t span = reg == 3 ? 0x8000 : reg == 2 ? 0x40000 : (uint32_t) m->romSize + 0x20;
		uint32_t address = (reg << 24) | ((cf_rnd() % (span + (reg < 4 ? 0x20 : 0))) + (cf_rnd() % 3 == 0 ? 0 : 0));
		if (reg < 4 && cf_rnd() % 4 == 0) address = (reg << 24) | (cf_rnd() & 0x00FFFFFF); /* con espejos */
		int use_cc = cf_rnd() % 8 != 0; int c1 = (int) cf_rnd() % 1000, c2 = c1; int* p1 = use_cc ? &c1 : 0; int* p2 = use_cc ? &c2 : 0;
		int32_t val = (int32_t) cf_rnd() ^ ((int32_t) cf_rnd() << 16);
		uint32_t lpSave = m->lastPrefetchedPc; uint32_t v1 = 0, v2 = 0; int lp1, lp2;
		if (op < 3) { /* cargas */
			uint32_t (*ref[3])(struct ARMCore*, uint32_t, int*) = {GBALoad32, GBALoad16, GBALoad8};
			uint32_t (*fst[3])(struct ARMCore*, uint32_t, int*) = {cirilo_ld32, cirilo_ld16, cirilo_ld8};
			v1 = ref[op](cpu, address, p1); lp1 = m->lastPrefetchedPc; m->lastPrefetchedPc = lpSave;
			v2 = fst[op](cpu, address, p2); lp2 = m->lastPrefetchedPc;
			if (v1 != v2 || c1 != c2 || lp1 != lp2) { if (bad < 10) printf("DIF carga%d a=%08X v %08X/%08X c %d/%d lp %08X/%08X ar=%d pf=%d\n", op, address, v1, v2, c1, c2, lp1, lp2, m->activeRegion, m->prefetch); ++bad; }
		} else { /* guardados: se compara la ventana de memoria tocada */
			int o = op - 3; uint8_t* base = reg == 3 ? (uint8_t*) m->iwram : reg == 2 ? (uint8_t*) m->wram : 0;
			uint32_t mask = reg == 3 ? 0x7FFF : 0x3FFFF; uint8_t w0[16], wA[16], wB[16];
			if (!base) { reg = 3; address = (3u << 24) | (address & 0x7FFF); base = (uint8_t*) m->iwram; mask = 0x7FFF; }
			uint32_t off = (address & mask) & ~3u; for (int k = 0; k < 16; ++k) w0[k] = base[(off + k - 4) & mask];
			/* original */
			if (o == 0) GBAStore32(cpu, address, val, p1); else if (o == 1) GBAStore16(cpu, address, (int16_t) val, p1); else GBAStore8(cpu, address, (int8_t) val, p1);
			lp1 = m->lastPrefetchedPc; for (int k = 0; k < 16; ++k) wA[k] = base[(off + k - 4) & mask];
			for (int k = 0; k < 16; ++k) base[(off + k - 4) & mask] = w0[k]; m->lastPrefetchedPc = lpSave;
			if (o == 0) cirilo_st32(cpu, address, val, p2); else if (o == 1) cirilo_st16(cpu, address, (int16_t) val, p2); else cirilo_st8(cpu, address, (int8_t) val, p2);
			lp2 = m->lastPrefetchedPc; for (int k = 0; k < 16; ++k) wB[k] = base[(off + k - 4) & mask];
			if (memcmp(wA, wB, 16) || c1 != c2 || lp1 != lp2) { if (bad < 10) printf("DIF guardado%d a=%08X c %d/%d lp %08X/%08X mem %d\n", o, address, c1, c2, lp1, lp2, memcmp(wA, wB, 16)); ++bad; }
		}
		if (counts) counts[op * 16 + reg]++;
	}
	cpu->gprs[15] = pc0; m->activeRegion = ar0; m->prefetch = pf0; m->lastPrefetchedPc = lp0;
	cpu->memory.activeSeqCycles16 = s160; cpu->memory.activeNonseqCycles16 = n160; memcpy(m->waitstatesNonseq32, w32, 256); memcpy(m->waitstatesNonseq16, w16, 256);
	return bad;
}
