# ROMs GB de prueba para el cable: link_m.gb (maestro, reloj interno, 1 transferencia por fotograma) y link_s.gb (esclava, reloj externo).
# Cada una guarda en WRAM: [C000]=contador propio enviado, [C001]=último byte recibido.
import sys
def mk(master,name):
    g=bytearray(0x8000)
    g[0x100:0x104]=bytes([0x00,0xC3,0x50,0x01])
    g[0x104:0x134]=bytes.fromhex('CEED6666CC0D000B03730083000C000D0008111F8889000EDCCC6EE6DDDDD999BBBB67636E0EECCCDDDC999FBBB9333E')
    g[0x134:0x13E]=name.encode().ljust(10,b'\0')[:10]
    x=0
    for b in g[0x134:0x14D]: x=(x-b-1)&0xFF
    g[0x14D]=x
    c=bytearray()
    c+=bytes([0x06,0x00])                 # ld b,0
    loop=len(c)
    c+=bytes([0x04,0x78,0xE0,0x01])       # inc b ; ld a,b ; ldh (SB),a
    c+=bytes([0x3E,0x81 if master else 0x80,0xE0,0x02])   # ld a,SC ; ldh (SC),a
    w=len(c)
    c+=bytes([0xF0,0x02,0xE6,0x80,0x20,(w-(len(c)+6))&0xFF])  # ldh a,(SC); and 80; jr nz,w
    c+=bytes([0xF0,0x01,0xEA,0x01,0xC0,0x78,0xEA,0x00,0xC0])  # ld a,(SB); ld (C001),a; ld a,b; ld (C000),a
    if master:
        v1=len(c); c+=bytes([0xF0,0x44,0xFE,0x90,0x20,(v1-(len(c)+6))&0xFF])
        v2=len(c); c+=bytes([0xF0,0x44,0xFE,0x90,0x28,(v2-(len(c)+6))&0xFF])
    c+=bytes([0x18,(loop-(len(c)+2))&0xFF])
    g[0x150:0x150+len(c)]=c
    open(name+'.gb','wb').write(g)
mk(True,'link_m'); mk(False,'link_s')
