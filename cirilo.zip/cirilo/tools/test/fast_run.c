// Prueba del camino rápido de memoria (tools/cirilo_fast.h). Carga un núcleo libretro de mGBA, ejecuta una ROM N fotogramas y escribe
// un hash del estado serializado (registros, ciclos, temporizadores y toda la memoria) cada 25 fotogramas, más hashes del vídeo y el audio.
// Dos núcleos (sin parchear y parcheado) tienen que dar EXACTAMENTE las mismas líneas.
// Con el 4º argumento «d» y un núcleo con el gancho test_fast_diff (ver LEEME.txt) compara además cada carga/guardado contra GBALoadN/GBAStoreN.
// Uso: fast_run núcleo.so rom.gba fotogramas [d]
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include "../../app/src/main/cpp/libretro.h"
static uint64_t vh = 14695981039346656037ull, ah = 14695981039346656037ull;
static void fnv(uint64_t* h, const void* d, size_t n) { const uint8_t* p = d; while (n--) { *h ^= *p++; *h *= 1099511628211ull; } }
static bool env(unsigned c, void* d) {
	if (c == RETRO_ENVIRONMENT_SET_PIXEL_FORMAT) return true;
	if (c == RETRO_ENVIRONMENT_GET_CAN_DUPE) { *(bool*) d = true; return true; }
	return false;
}
static void vid(const void* d, unsigned w, unsigned h, size_t p) { if (d) for (unsigned y = 0; y < h; ++y) fnv(&vh, (const uint8_t*) d + y * p, w * 2); }
static size_t asb(const int16_t* d, size_t n) { fnv(&ah, d, n * 4); return n; }
static void as1(int16_t l, int16_t r) { (void) l; (void) r; }
static void ip(void) {}
static int16_t is(unsigned a, unsigned b, unsigned c, unsigned d) { (void) a; (void) b; (void) c; (void) d; return 0; }
int main(int argc, char** argv) {
	if (argc < 4) return 2;
	void* H = dlopen(argv[1], RTLD_NOW); if (!H) { puts(dlerror()); return 2; }
#define S(n) __typeof__(&n) n##_ = dlsym(H, #n)
	void (*set_env)(retro_environment_t) = dlsym(H, "retro_set_environment"); void (*set_vid)(retro_video_refresh_t) = dlsym(H, "retro_set_video_refresh");
	void (*set_asb)(retro_audio_sample_batch_t) = dlsym(H, "retro_set_audio_sample_batch"); void (*set_as)(retro_audio_sample_t) = dlsym(H, "retro_set_audio_sample");
	void (*set_ip)(retro_input_poll_t) = dlsym(H, "retro_set_input_poll"); void (*set_is)(retro_input_state_t) = dlsym(H, "retro_set_input_state");
	void (*r_init)(void) = dlsym(H, "retro_init"); void (*r_run)(void) = dlsym(H, "retro_run"); bool (*r_load)(const struct retro_game_info*) = dlsym(H, "retro_load_game");
	size_t (*ser_n)(void) = dlsym(H, "retro_serialize_size"); bool (*ser)(void*, size_t) = dlsym(H, "retro_serialize");
	int (*diff)(unsigned, int, unsigned*) = dlsym(H, "test_fast_diff");
	set_env(env); set_vid(vid); set_asb(asb); set_as(as1); set_ip(ip); set_is(is); r_init();
	FILE* f = fopen(argv[2], "rb"); if (!f) return 2; fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); uint8_t* rom = malloc(n); if (fread(rom, 1, n, f) != (size_t) n) return 2; fclose(f);
	struct retro_game_info gi = {argv[2], rom, (size_t) n, NULL};
	if (!r_load(&gi)) { puts("no carga"); return 2; }
	int frames = atoi(argv[3]); size_t sn = ser_n(); uint8_t* sb = malloc(sn); struct timespec t0, t1; clock_gettime(CLOCK_MONOTONIC, &t0);
	for (int i = 1; i <= frames; ++i) {
		r_run();
		if (i % 25 == 0 || i == frames) { uint64_t h = 14695981039346656037ull; if (!ser(sb, sn)) { puts("serialize falla"); return 2; } fnv(&h, sb, sn); printf("f%04d estado %016llx\n", i, (unsigned long long) h); }
	}
	clock_gettime(CLOCK_MONOTONIC, &t1); double s = (t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
	printf("video %016llx audio %016llx\n", (unsigned long long) vh, (unsigned long long) ah);
	fprintf(stderr, "%.3f s (%.1f fps)\n", s, frames / s);
	if (argc > 4 && argv[4][0] == 'd') {
		if (!diff) { puts("este núcleo no tiene test_fast_diff"); return 2; }
		unsigned cnt[96] = {0}; int bad = 0; long tot = 0;
		for (unsigned seed = 1; seed <= 40; ++seed) { bad += diff(seed, 250000, cnt); tot += 250000; }
		printf("diferencial: %ld comparaciones, %d diferencias\n", tot, bad);
		const char* on[] = {"LDR", "LDRH", "LDRB", "STR", "STRH", "STRB"}; for (int o = 0; o < 6; ++o) { printf("  %-5s IWRAM %u EWRAM %u ROM %u\n", on[o], cnt[o * 16 + 3], cnt[o * 16 + 2], cnt[o * 16 + 8] + cnt[o * 16 + 9] + cnt[o * 16 + 10] + cnt[o * 16 + 11] + cnt[o * 16 + 12] + cnt[o * 16 + 13]); }
		return bad ? 1 : 0;
	}
	return 0;
}
