// Comparador diferencial para el JIT (Cirilo). Carga DOS núcleos libretro (referencia = mGBA sin tocar, candidato = núcleo con las modificaciones/JIT)
// en el mismo proceso, ejecuta la misma ROM fotograma a fotograma y compara, tras cada fotograma (o cada N):
//   - el estado serializado COMPLETO, byte a byte (registros, ciclos, temporizadores, DMA, E/S y toda la memoria),
//   - el hash del vídeo y del audio de ese fotograma.
// Si algo difiere, dice en qué fotograma, qué campos (con los ganchos de jit_hook.c) y desensambla la instrucción en el PC de cada núcleo.
// Uso: jit_cmp ref.so cand.so rom.gba fotogramas [-s N] [-d carpeta] [-p salida.ppm] [-w dirección] [-J] [-v]
//   -s N: comparar cada N fotogramas (por defecto 1)      -d: si difiere, guarda ref.state y cand.state ahí      -p: guarda el último fotograma de la referencia (PPM)
//   -w DIR: al final imprime 3 palabras de la referencia en esa dirección (p. ej. 0x03007F00 en las ROM de mkrom_jit.py: semilla, checksum, iteración)
//   -A: modo de la app (bloques Thumb sin copia, ARM sin caché; cirilo_jit_debug(8)). Con -J.
//   -J: activa el JIT en el candidato antes de cargar la ROM (llama a cirilo_jit_set(1) del núcleo; error si no existe). Sin -J se compara sin JIT.
//   -X: (con -J, núcleo compilado con -DCIRILO_JIT_TEST) apaga la invalidación SMC del candidato: la autoprueba exige que entonces SÍ difiera
//   -N: (con -J, núcleo con -DCIRILO_JIT_TEST) sin código nativo: modo de la Fase 1 (para aislar fallos del emisor)
//   -v: una línea por fotograma comparado
// Código de salida: 0 = idénticos, 1 = difieren, 2 = error de uso/carga, 3 = idénticos pero la ROM se colgó en una instrucción indefinida (prueba vacía).
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include "libretro.h"

struct Core {
	const char* name;
	void* h;
	void (*run)(void);
	size_t (*ser_n)(void);
	bool (*ser)(void*, size_t);
	int (*regs)(uint32_t*);
	void (*describe)(size_t, char*, size_t);
	void (*disasm)(uint32_t, char*, size_t);
	uint32_t (*peek)(uint32_t);
	int (*jstats)(uint32_t*);
	uint64_t vh, ah;
	uint16_t* fb; unsigned fw, fh;
	double secs;
	uint8_t* st; size_t sn;
};
static struct Core C[2];
static void fnv(uint64_t* h, const void* d, size_t n) { const uint8_t* p = d; while (n--) { *h ^= *p++; *h *= 1099511628211ull; } }
static bool env(unsigned c, void* d) {
	if (c == RETRO_ENVIRONMENT_SET_PIXEL_FORMAT) return true;
	if (c == RETRO_ENVIRONMENT_GET_CAN_DUPE) { *(bool*) d = true; return true; }
	return false;
}
static void vid(int i, const void* d, unsigned w, unsigned h, size_t p) {
	struct Core* c = &C[i];
	if (!d) return;
	if (!c->fb || c->fw != w || c->fh != h) { free(c->fb); c->fb = malloc((size_t) w * h * 2); c->fw = w; c->fh = h; }
	for (unsigned y = 0; y < h; ++y) { memcpy(c->fb + (size_t) y * w, (const uint8_t*) d + y * p, w * 2); }
	fnv(&c->vh, c->fb, (size_t) w * h * 2);
}
static size_t asb(int i, const int16_t* d, size_t n) { fnv(&C[i].ah, d, n * 4); return n; }
#define CB(i) \
	static void vid##i(const void* d, unsigned w, unsigned h, size_t p) { vid(i, d, w, h, p); } \
	static size_t asb##i(const int16_t* d, size_t n) { return asb(i, d, n); }
CB(0) CB(1)
static void as1(int16_t l, int16_t r) { (void) l; (void) r; }
static void ip(void) {}
static int16_t is(unsigned a, unsigned b, unsigned c, unsigned d) { (void) a; (void) b; (void) c; (void) d; return 0; }

static int want_jit, want_nosmc, want_nonative, want_app, want_mode = 1; /* -M2 / -M3: modos de diagnóstico A y B del JIT */
static bool load(int i, const char* path, const char* name, uint8_t* rom, long n, const char* romname) {
	struct Core* c = &C[i];
	c->name = name;
	c->h = dlopen(path, RTLD_NOW | RTLD_LOCAL);
	if (!c->h) { fprintf(stderr, "%s: %s\n", path, dlerror()); return false; }
	void (*set_env)(retro_environment_t) = dlsym(c->h, "retro_set_environment");
	void (*set_vid)(retro_video_refresh_t) = dlsym(c->h, "retro_set_video_refresh");
	void (*set_asb)(retro_audio_sample_batch_t) = dlsym(c->h, "retro_set_audio_sample_batch");
	void (*set_as)(retro_audio_sample_t) = dlsym(c->h, "retro_set_audio_sample");
	void (*set_ip)(retro_input_poll_t) = dlsym(c->h, "retro_set_input_poll");
	void (*set_is)(retro_input_state_t) = dlsym(c->h, "retro_set_input_state");
	void (*r_init)(void) = dlsym(c->h, "retro_init");
	bool (*r_load)(const struct retro_game_info*) = dlsym(c->h, "retro_load_game");
	c->run = dlsym(c->h, "retro_run"); c->ser_n = dlsym(c->h, "retro_serialize_size"); c->ser = dlsym(c->h, "retro_serialize");
	c->regs = dlsym(c->h, "test_regs"); c->describe = dlsym(c->h, "test_state_describe"); c->disasm = dlsym(c->h, "test_disasm"); c->peek = dlsym(c->h, "test_peek32"); c->jstats = dlsym(c->h, "cirilo_jit_stats");
	if (!set_env || !set_vid || !r_init || !r_load || !c->run || !c->ser) { fprintf(stderr, "%s: no es un núcleo libretro\n", path); return false; }
	set_env(env); set_vid(i ? vid1 : vid0); set_asb(i ? asb1 : asb0); set_as(as1); set_ip(ip); set_is(is); r_init();
	if (i == 1 && want_jit) {
		void (*jset)(int) = dlsym(c->h, "cirilo_jit_set");
		if (!jset) { fprintf(stderr, "%s: no exporta cirilo_jit_set (¿núcleo sin JIT?)\n", path); return false; }
		jset(want_mode);
		if (want_nosmc || want_nonative || want_app) {
			void (*dbg)(int) = dlsym(c->h, "cirilo_jit_debug");
			if (!dbg) { fprintf(stderr, "%s: sin cirilo_jit_debug (compila con -DCIRILO_JIT_TEST)\n", path); return false; }
			dbg((want_nosmc ? 1 : 0) | (want_nonative ? 2 : 0) | (want_app ? 8 : 0));
		}
	}
	struct retro_game_info gi = {romname, rom, (size_t) n, NULL};
	if (!r_load(&gi)) { fprintf(stderr, "%s: no carga la ROM\n", path); return false; }
	c->vh = c->ah = 14695981039346656037ull;
	c->sn = c->ser_n(); c->st = malloc(c->sn);
	return true;
}
static const char* REGN[] = {"r0","r1","r2","r3","r4","r5","r6","r7","r8","r9","r10","r11","r12","sp","lr","pc","cpsr","spsr","ciclos","nextEvent","modo","halted","prefetch0","prefetch1"};
static void describe_diff(int frame) {
	struct Core *a = &C[0], *b = &C[1];
	printf("DIFERENCIA en el fotograma %d\n", frame);
	if (a->regs && b->regs) {
		uint32_t ra[32], rb[32]; int n = a->regs(ra); b->regs(rb);
		for (int i = 0; i < n; ++i) if (ra[i] != rb[i]) printf("  registro %-9s ref=%08x cand=%08x\n", REGN[i], ra[i], rb[i]);
		char d[160];
		if (a->disasm) { a->disasm(ra[15] - (ra[20] ? 8 : 4), d, sizeof d); printf("  ref  en PC-%d: %s\n", ra[20] ? 8 : 4, d); }
		if (b->disasm) { b->disasm(rb[15] - (rb[20] ? 8 : 4), d, sizeof d); printf("  cand en PC-%d: %s\n", rb[20] ? 8 : 4, d); }
	}
	if (a->sn != b->sn) { printf("  tamaño de estado distinto: ref=%zu cand=%zu\n", a->sn, b->sn); return; }
	size_t i = 0; int ranges = 0; char nm[96];
	while (i < a->sn && ranges < 14) {
		if (a->st[i] == b->st[i]) { ++i; continue; }
		size_t s = i; while (i < a->sn && (a->st[i] != b->st[i] || (i + 1 < a->sn && a->st[i + 1] != b->st[i + 1]))) ++i;
		if (a->describe) a->describe(s, nm, sizeof nm); else snprintf(nm, sizeof nm, "offset %zu", s);
		printf("  estado: %zu bytes distintos desde %zu (%s)", i - s, s, nm);
		if (i - s <= 8) { printf("  ref="); for (size_t k = s; k < i; ++k) printf("%02x", a->st[k]); printf(" cand="); for (size_t k = s; k < i; ++k) printf("%02x", b->st[k]); }
		printf("\n"); ++ranges;
	}
	if (ranges == 14) printf("  ...\n");
}
int main(int argc, char** argv) {
	if (argc < 5) { fprintf(stderr, "uso: %s ref.so cand.so rom.gba fotogramas [-s N] [-d carpeta] [-p salida.ppm] [-v]\n", argv[0]); return 2; }
	int frames = atoi(argv[4]), every = 1, verbose = 0; const char *dir = NULL, *ppm = NULL; unsigned watch = 0;
	for (int i = 5; i < argc; ++i) {
		if (!strcmp(argv[i], "-s") && i + 1 < argc) every = atoi(argv[++i]);
		else if (!strcmp(argv[i], "-d") && i + 1 < argc) dir = argv[++i];
		else if (!strcmp(argv[i], "-p") && i + 1 < argc) ppm = argv[++i];
		else if (!strcmp(argv[i], "-w") && i + 1 < argc) watch = strtoul(argv[++i], NULL, 0);
		else if (!strcmp(argv[i], "-J")) want_jit = 1;
		else if (!strcmp(argv[i], "-X")) want_nosmc = 1;
		else if (!strcmp(argv[i], "-N")) want_nonative = 1;
		else if (!strcmp(argv[i], "-A")) want_app = 1;
		else if (!strcmp(argv[i], "-M2")) want_mode = 2;
		else if (!strcmp(argv[i], "-M3")) want_mode = 3;
		else if (!strcmp(argv[i], "-v")) verbose = 1;
	}
	if (every < 1) every = 1;
	FILE* f = fopen(argv[3], "rb"); if (!f) { perror(argv[3]); return 2; }
	fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); uint8_t* rom = malloc(n);
	if (fread(rom, 1, n, f) != (size_t) n) return 2;
	fclose(f);
	if (!load(0, argv[1], "ref", rom, n, argv[3]) || !load(1, argv[2], "cand", rom, n, argv[3])) return 2;
	int bad = 0, cmp = 0;
	for (int i = 1; i <= frames && !bad; ++i) {
		for (int k = 0; k < 2; ++k) { struct timespec t0, t1; clock_gettime(CLOCK_MONOTONIC, &t0); C[k].run(); clock_gettime(CLOCK_MONOTONIC, &t1); C[k].secs += (t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9; }
		if (i % every && i != frames) continue;
		++cmp;
		for (int k = 0; k < 2; ++k) if (!C[k].ser(C[k].st, C[k].sn)) { fprintf(stderr, "serialize falla (%s)\n", C[k].name); return 2; }
		bool st = C[0].sn == C[1].sn && !memcmp(C[0].st, C[1].st, C[0].sn);
		bool v = C[0].vh == C[1].vh, a = C[0].ah == C[1].ah;
		if (verbose) printf("f%05d estado %s video %s audio %s\n", i, st ? "=" : "DIF", v ? "=" : "DIF", a ? "=" : "DIF");
		if (!st || !v || !a) {
			bad = 1;
			if (st) printf("DIFERENCIA en el fotograma %d: el estado es igual pero %s%s difiere\n", i, v ? "" : "el vídeo ", a ? "" : "el audio");
			else describe_diff(i);
			if (dir) {
				char p[512]; snprintf(p, sizeof p, "%s/ref.state", dir); FILE* o = fopen(p, "wb"); if (o) { fwrite(C[0].st, 1, C[0].sn, o); fclose(o); }
				snprintf(p, sizeof p, "%s/cand.state", dir); o = fopen(p, "wb"); if (o) { fwrite(C[1].st, 1, C[1].sn, o); fclose(o); }
			}
		}
	}
	if (ppm && C[0].fb) {
		FILE* o = fopen(ppm, "wb");
		if (o) { fprintf(o, "P6\n%u %u\n255\n", C[0].fw, C[0].fh); for (size_t k = 0; k < (size_t) C[0].fw * C[0].fh; ++k) { uint16_t p = C[0].fb[k]; uint8_t rgb[3] = {(uint8_t) ((p >> 11) << 3), (uint8_t) (((p >> 5) & 63) << 2), (uint8_t) ((p & 31) << 3)}; fwrite(rgb, 1, 3, o); } fclose(o); }
	}
	int crashed = 0;
	if (C[0].regs) {
		uint32_t r[32]; int m = C[0].regs(r);
		if (m) printf("final (ref): pc=%08x cpsr=%08x r12=%08x\n", r[15], r[16], r[12]);
		if (m && !bad && (r[16] & 0x1F) == 0x1B) { crashed = 1; printf("AVISO: la ROM acabó en modo indefinido (se colgó en una instrucción indefinida): ref y cand coinciden, pero la prueba NO es representativa\n"); }
	}
	if (watch && C[0].peek) printf("mem[%08x] ref= %08x %08x %08x\n", watch, C[0].peek(watch), C[0].peek(watch + 4), C[0].peek(watch + 8));
	if (C[1].jstats) {
		static const char* JN[] = {"bloques_creados", "bloques_ejecutados", "instr_en_bloques", "instr_interpretadas", "invalidaciones", "vaciados", "avisos_smc", "trozos_prohibidos", "salidas_prematuras", "pipeline_distinto", "traduccion_rechazada", "bloques_nativos", "ejecuciones_nativas", "sin_margen", "instr_nativas", "saltos_tomados", "saltos_no_tomados", "salidas_tempranas"};
		uint32_t js[32]; int nj = C[1].jstats(js);
		printf("JIT:"); for (int k = 0; k < nj && k < 18; ++k) printf(" %s=%u", JN[k], js[k]); printf("\n");
		if (nj > 20) printf("CODIGO: palabras_emitidas=%u instr_cubiertas=%u\n", js[19], js[20]);
		if (want_mode == 2) { /* diagnóstico A: no hay bloques con código; el despachador solo agrupa (entradas «sin código nativo» = índice 18) */
			if (nj > 18 && js[18] == 0 && js[2] + js[3] > 100000) { printf("FALLO: modo A activo pero el despachador no agrupó ninguna entrada\n"); bad = 1; }
		} else
		if (js[1] == 0 && js[2] + js[3] > 100000) { printf("FALLO: el JIT está activo pero no ejecutó ni un bloque en %u instrucciones\n", js[3]); bad = 1; }
		if (js[8]) { printf("FALLO: %u salidas prematuras de bloque (el clasificador de saltos deja pasar una instrucción que cambia el PC)\n", js[8]); bad = 1; }
	}
	printf("%s: %d fotogramas, %d comparaciones. ref %.1f fps, cand %.1f fps (x%.2f)\n", bad ? "FALLO" : "OK", frames, cmp, frames / C[0].secs, frames / C[1].secs, C[0].secs / C[1].secs);
	return bad ? 1 : crashed ? 3 : 0;
}
