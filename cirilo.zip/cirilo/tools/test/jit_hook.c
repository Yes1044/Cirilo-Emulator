/* Cirilo: gancho SOLO PARA PRUEBAS del JIT (no va al APK). Se añade al final de mgba/src/platform/libretro/libretro.c (comparte su `core` estático),
 * igual que fast_diff_hook.c. Lo usa tools/test/jit_cmp.c para decir QUÉ difiere cuando dos núcleos (intérprete de referencia y núcleo con JIT) se separan.
 * - test_regs(out): r0-r15, cpsr, spsr, ciclos, nextEvent, modo de ejecución (0 Thumb, 1 ARM), halted, prefetch[0], prefetch[1]  (22 valores)
 * - test_state_describe(offset, buf, n): nombre del campo del estado serializado (struct GBASerializedState) que contiene ese byte
 * - test_disasm(addr, buf, n): desensambla la instrucción en `addr` (ARM o Thumb según el modo actual de la CPU), sin efectos secundarios */
#include <mgba/internal/arm/arm.h>
#include <mgba/internal/arm/decoder.h>
#include <mgba/internal/gba/serialize.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#define TEST_EXPORT __attribute__((visibility("default")))
/* El desensamblador de mGBA solo existe si se compila con depuradores (el núcleo libretro no los trae): si falta, se imprime el opcode en hexadecimal. */
extern int ARMDisassemble(const struct ARMInstructionInfo* info, struct ARMCore* core, const struct mDebuggerSymbols* symbols, uint32_t pc, char* buffer, int blen) __attribute__((weak));

TEST_EXPORT int test_regs(uint32_t* out) {
	if (!core || core->platform(core) != mPLATFORM_GBA) {
		return 0;
	}
	struct ARMCore* cpu = core->cpu;
	for (int i = 0; i < 16; ++i) {
		out[i] = (uint32_t) cpu->gprs[i];
	}
	out[16] = cpu->cpsr.packed;
	out[17] = cpu->spsr.packed;
	out[18] = (uint32_t) cpu->cycles;
	out[19] = (uint32_t) cpu->nextEvent;
	out[20] = (uint32_t) cpu->executionMode;
	out[21] = (uint32_t) cpu->halted;
	out[22] = cpu->prefetch[0];
	out[23] = cpu->prefetch[1];
	return 24;
}

#define F(name, member) {name, offsetof(struct GBASerializedState, member), sizeof(((struct GBASerializedState*) 0)->member)}
static const struct { const char* name; size_t off, size; } fields[] = {
	F("versionMagic", versionMagic), F("biosChecksum", biosChecksum), F("romCrc32", romCrc32), F("masterCycles", masterCycles),
	F("cpu.gprs", cpu.gprs), F("cpu.cpsr", cpu.cpsr), F("cpu.spsr", cpu.spsr), F("cpu.cycles", cpu.cycles), F("cpu.nextEvent", cpu.nextEvent),
	F("cpu.bankedRegisters", cpu.bankedRegisters), F("cpu.bankedSPSRs", cpu.bankedSPSRs),
	F("audio", audio), F("video", video), F("timers", timers), F("dma", dma), F("hw", hw), F("dmaTransferRegister", dmaTransferRegister),
	F("dmaBlockPC", dmaBlockPC), F("matrix", matrix), F("savedata", savedata), F("biosPrefetch", biosPrefetch),
	F("cpuPrefetch", cpuPrefetch), F("reservedCpu", reservedCpu), F("globalCycles", globalCycles), F("lastPrefetchedPc", lastPrefetchedPc),
	F("miscFlags", miscFlags), F("nextIrq", nextIrq), F("biosStall", biosStall), F("(union cartuchos)", matrix2),
	F("samples", samples), F("currentSamples", currentSamples), F("bus", bus), F("dmaLatch", dmaLatch), F("dmaCountLatch", dmaCountLatch),
	F("reserved", reserved), F("io", io), F("pram", pram), F("oam", oam), F("vram", vram), F("iwram", iwram), F("wram", wram),
};
#undef F

TEST_EXPORT void test_state_describe(size_t off, char* buf, size_t n) {
	for (size_t i = 0; i < sizeof(fields) / sizeof(*fields); ++i) {
		if (off < fields[i].off || off >= fields[i].off + fields[i].size) {
			continue;
		}
		size_t r = off - fields[i].off;
		const char* nm = fields[i].name;
		if (!strcmp(nm, "cpu.gprs")) {
			snprintf(buf, n, "cpu.gprs: r%zu", r / 4);
		} else if (!strcmp(nm, "iwram")) {
			snprintf(buf, n, "iwram: 0x%08zX", 0x03000000 + r);
		} else if (!strcmp(nm, "wram")) {
			snprintf(buf, n, "wram (EWRAM): 0x%08zX", 0x02000000 + r);
		} else if (!strcmp(nm, "io")) {
			snprintf(buf, n, "io: 0x%08zX", 0x04000000 + r);
		} else if (!strcmp(nm, "vram")) {
			snprintf(buf, n, "vram: 0x%08zX", 0x06000000 + r);
		} else if (!strcmp(nm, "pram")) {
			snprintf(buf, n, "paleta: 0x%08zX", 0x05000000 + r);
		} else if (!strcmp(nm, "oam")) {
			snprintf(buf, n, "oam: 0x%08zX", 0x07000000 + r);
		} else if (!strcmp(nm, "timers")) {
			snprintf(buf, n, "timers[%zu] +%zu", r / sizeof(((struct GBASerializedState*) 0)->timers[0]), r % sizeof(((struct GBASerializedState*) 0)->timers[0]));
		} else if (!strcmp(nm, "dma")) {
			snprintf(buf, n, "dma[%zu] +%zu", r / sizeof(((struct GBASerializedState*) 0)->dma[0]), r % sizeof(((struct GBASerializedState*) 0)->dma[0]));
		} else {
			snprintf(buf, n, "%s +%zu", nm, r);
		}
		return;
	}
	snprintf(buf, n, "(relleno) +%zu", off);
}

TEST_EXPORT void test_disasm(uint32_t addr, char* buf, size_t n) {
	buf[0] = 0;
	if (!core || core->platform(core) != mPLATFORM_GBA) {
		return;
	}
	struct ARMCore* cpu = core->cpu;
	bool thumb = cpu->executionMode == MODE_THUMB;
	uint32_t op = thumb ? (uint32_t) core->rawRead16(core, addr, -1) : core->rawRead32(core, addr, -1);
	if (!ARMDisassemble) {
		snprintf(buf, n, thumb ? "%s %04X" : "%s %08X", thumb ? "thumb" : "arm", op);
		return;
	}
	struct ARMInstructionInfo info;
	if (thumb) {
		ARMDecodeThumb((uint16_t) op, &info);
	} else {
		ARMDecodeARM(op, &info);
	}
	if (ARMDisassemble(&info, cpu, NULL, addr + (thumb ? 4 : 8), buf, (int) n) <= 0) {
		snprintf(buf, n, "?");
	}
}

/* Lectura de memoria sin efectos secundarios (para -w de jit_cmp). */
TEST_EXPORT uint32_t test_peek32(uint32_t addr) {
	return core ? core->rawRead32(core, addr, -1) : 0;
}
