import app.cirilo.*
import java.io.File
var fails=0;var total=0
fun check(c:Boolean,m:String){total++;if(!c){fails++;println("  FALLO: $m")}else println("  ok:    $m")}
fun near(a:Float,b:Float)=Math.abs(a-b)<0.002f
fun load(dir:String)=File(dir).listFiles()!!.associate{it.name to it.readText(Charsets.UTF_8)}
fun fac(land:Boolean)=listOf(Ctl("screen","screen",.5f,if(land).5f else -1f,1f,1f))
fun main(a:Array<String>){
 val root=if(a.isNotEmpty())a[0] else "tools/test/layouts-samples"
 val mb=LayoutImport.profiles(load("$root/my-boy"));val ob=LayoutImport.profiles(load("$root/my-oldboy"))
 println("[perfiles]")
 check(mb.map{it.name}==listOf("Default","Layout My Boy todos los botones","Sólo un botón en esquina inferior izquierda","Sólo un botón en esquina inferior izquierda con tamaño distinto"),"My Boy!: nombres de perfil (%XX decodificados): "+mb.map{it.name})
 check(ob.size==4&&ob.all{it.name.isNotEmpty()},"My OldBoy!: 4 perfiles")
 check(mb[1].shots.size==2&&mb[1].shots.any{it.w==1541&&it.h==720}&&mb[1].shots.any{it.w==720&&it.h==1541},"«todos»: dos tamaños (horizontal y vertical)")
 check(LayoutImport.splitFile("a%2Bb%20c-720x1541.xml")==Triple("a+b c",720,1541),"«%2B» y «%20» decodificados")
 println("[Default de My Boy! (horizontal) → GBA]")
 var r=LayoutImport.convert(mb[0],LSys.GBA,720,1541,::fac);var h=r.l.associateBy{it.t}
 check(r.l.first().t=="screen"&&near(h["screen"]!!.s,1f)&&h["screen"]!!.y==-1f,"pantalla primera, s=1, pegada arriba")
 check(near(h["dpad"]!!.x,.123f)&&near(h["dpad"]!!.y,.738f)&&near(h["dpad"]!!.s,.475f),"D-Pad x/y/s")
 check(near(h["l"]!!.x,.058f)&&near(h["l"]!!.s,.154f)&&near(h["r"]!!.x,.942f),"L y R")
 check(near(h["b"]!!.x,.775f)&&near(h["a"]!!.x,.903f)&&near(h["a"]!!.s,.203f),"pareja AB → B a la izquierda, A a la derecha")
 check(near(h["select"]!!.x,.570f)&&near(h["start"]!!.x,.636f),"«start» → Select + Start")
 check(near(h["ab"]!!.s,.228f)&&h["qload"]!=null&&h["ff"]!=null,"a+b → AB, load → qload, ff")
 check(r.l.map{it.id}.toSet().size==r.l.size,"ids únicos")
 check(h["menu"]!=null&&near(h["menu"]!!.s,.1f)&&r.notes.none{it.startsWith("Sin equivalente")}&&r.notes.any{it.startsWith("Sin distribución vertical")},"menú importado como control «menu»; solo avisa de la falta de vertical: "+r.notes)
 println("[mismo perfil → GB/GBC]")
 r=LayoutImport.convert(mb[0],LSys.GB,720,1541,::fac)
 check(r.l.none{it.t=="l"||it.t=="r"}&&r.notes.any{it.contains("L, R")},"sin L ni R, con aviso: "+r.notes)
 println("[«todos los botones» de My Boy! → GBA y GB]")
 r=LayoutImport.convert(mb[1],LSys.GBA,720,1541,::fac);var ts=r.p.map{it.t}
 check(listOf("lr","la","lb","ra","rb","turboa","turbob","qload","qsave","ff","shot","ab","menu").all{it in ts},"todos los tipos con equivalente se importan: $ts")
 check(r.p.first().t=="screen"&&r.p.first().y==-1f&&near(r.p.first().s,1f),"vertical: pantalla arriba a todo el ancho")
 r=LayoutImport.convert(mb[1],LSys.GB,720,1541,::fac);ts=r.p.map{it.t}
 check(ts.none{it in LSys.SHOULDER}&&"turboa" in ts&&"qload" in ts,"GB: ningún control de gatillo, turbo A/B sí")
 check(near(r.p.first().s,.741f),"GB desde pantalla GBA en vertical: s=.741 (10:9 dentro del recuadro 3:2)")
 println("[«todos los botones» de My OldBoy! → GBA]")
 r=LayoutImport.convert(ob.first{it.name.contains("todos")},LSys.GBA,720,1541,::fac)
 check(r.p.any{it.t=="start"}&&r.p.any{it.t=="select"}&&r.l.any{it.t=="turbob"},"importa sin gatillos (se añaden a mano)")
 check(near(r.l.first().s,.741f),"horizontal: 800 de ancho dentro del recuadro → s=.741")
 println("[Cirilo → Cirilo entre consolas]")
 val g=Lay("x","X",listOf(Ctl("screen","screen",.5f,-1f,1f,1f),Ctl("l","l",.1f,.1f,.15f),Ctl("a","a",.9f,.8f,.2f),Ctl("t","turbol",.5f,.5f,.1f)),listOf(Ctl("screen","screen",.5f,.5f,1f,1f),Ctl("lr","lr",.5f,.5f,.1f)),LSys.GBA)
 val c=LSys.convert(g,LSys.GB)
 check(c.sys==LSys.GB&&c.p.map{it.t}==listOf("screen","a")&&c.l.map{it.t}==listOf("screen"),"GBA → GB quita L, R y combos")
 check(near(c.p[0].s,.741f)&&near(c.l[0].s,1f),"la pantalla conserva su recuadro")
 val b=LSys.convert(c,LSys.GBA)
 check(b.sys==LSys.GBA&&b.p.map{it.t}==listOf("screen","a"),"GB → GBA no inventa controles (los gatillos se añaden a mano)")
 check(LSys.convert(g,LSys.GBA)===g,"misma consola: sin cambios")
 println("[Control Menú: siempre presente]")
 val sm=Lay("s","S",listOf(Ctl("screen","screen",.5f,-1f,1f,1f),Ctl("l","l",.1f,.1f,.15f)),listOf(Ctl("screen","screen",.5f,.5f,1f,1f)),LSys.GB)
 val sn=LSys.sanitize(sm)
 check(sn.p.map{it.t}==listOf("screen","menu")&&sn.l.map{it.t}==listOf("screen","menu"),"sanitize quita lo no admitido y añade «Menú» en las dos orientaciones: "+sn.p.map{it.t})
 check(LSys.sanitize(sn)==sn&&LSys.ensureMenu(sn.p,false)===sn.p,"si ya hay «Menú» no se duplica")
 check(near(LSys.menuCtl(false).x,.92f)&&near(LSys.menuCtl(true).x,.5f),"posición por defecto: arriba a la derecha en vertical, arriba al centro en horizontal")
 r=LayoutImport.convert(ob.first{it.name.contains("todos")},LSys.GBA,720,1541,::fac)
 check(r.p.count{it.t=="menu"}==1&&r.l.count{it.t=="menu"}==1,"importar sin «menu» en el perfil añade uno por orientación; notas: "+r.notes)
 println("\n$total comprobaciones, $fails fallos");if(fails>0)System.exit(1)
}
