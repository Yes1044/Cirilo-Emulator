# Informe de continuidad — JIT ARM de Cirilo

## Estado: Fases 0-1 hechas. Fase 2 (procesamiento de datos + condiciones, solo tramos puros) IMPLEMENTADA y validada en x86; falta CI en aarch64 real y medir en Doom. Fases 3-8 NO empezadas.

### Entorno de esta sesión
- Sin cmake, sin compilador cruzado AArch64, sin qemu, sin red, sin dispositivo Android.
- Se compila a mano con gcc (x86-64): `tools/test/build_manual.sh <carpeta mgba> <salida.so> [flags]` (equivale al CMake libretro mínimo; excluye extra/proxy, hilos, scripting, video-logger).
- Sobre x86-64 el código nativo lo ejecuta el simulador `cirilo_jit_a64sim.inc` (-DCIRILO_JIT_SIM). NO se ha ejecutado AArch64 real ni Gradle/NDK.

### Línea base ejecutada (mGBA fijado a67176c + parches prof, fast, jit)
- `jit_unit` semilla 1, 20000 secuencias Thumb: OK, 0 discrepancias.
- `jit_cmp` ref vs cand (-J -A, 300 fotogramas) con mkrom_jit.py semilla 1: arm, thumb, mixed, smc → todas OK.
- Cobertura ARM actual: `palabras_emitidas=0 instr_cubiertas=0` en la ROM ARM (confirmado: ARM no se traduce).
- NO ejecutado: jit_test.sh completo (necesita cmake y red para jsmolka/gba-tests), fast_stress, perfiles PGO.
- Las fps x0.14-0.26 del candidato son del simulador en x86: no son medida de rendimiento.

### Hallazgos de auditoría (código real, tools/cirilo_jit_arm.inc, 1807 líneas)
- `cjTranslate`: `if (!thumb && !CJ_COPY_MODE) return NULL;` → ARM solo se bloquea en modo copia (pruebas). Existe `cjTermArm` y `cjRunBlockArm` (marcado `unused`, intérprete por bloque).
- `cjRun`: en modo app, ARM entra en un bucle `ARMStep` puro (sin caché ni despachador). `cjPlain/cjPlainHooked` llaman a `ThumbStep` fijo: hay que parametrizar por modo.
- Ganchos (`cirilo_jit_patch.py`): solo `ThumbWritePC` y Bcond Thumb no tomado. Faltan `ARMWritePC` y el no-tomado ARM. `cirilo_hook_bits/heat` se indexan por `a>>1`: las claves ARM deben distinguirse (modo en la clave).
- `cjNativize`/`cjWorth`/`cjThumbInfo`/`cjEmitThumbPrefix` son solo Thumb; no existen `cjArmInfo`/`cjEmitOneArm`.
- El parche ya es "todo o nada" para lo que toca (escribe al final); hay que mantenerlo al añadir ARMWritePC y ARM Bcond.
- Diagnóstico adjunto: ARM = 22073 instr/fot (99% IWRAM, 193 distintas), el JIT Thumb apenas empata (+1.8%); coste de despachador ≈ +8% base. Los ns/instrucción del diagnóstico están mal calculados (se dividió entre Thumb solo): hay que recalcularlos con 46134 instr.

### Fase 1 — qué se hizo
- `cirilo_jit_arm.inc`: `cjPlain`/`cjPlainHooked` reciben el modo (ARMStep/ThumbStep); `cjRun` ya no usa el bucle ARM aparte (queda solo con diag 128 = ARM fuera del despachador, y diag 64 = perfil por región); `cjTranslate` crea bloques ARM sin nativo (agrupan, se ejecutan con ARMStep, exactos). Nuevo `cjArmDisp` + flag de diagnóstico 128 para medir A/B.
- `cirilo_jit_patch.py`: gancho en `ARMWritePC` y en el B/BL ARM no cumplido (`ARMStep`, arm.c), claves ARM separadas por sal (`cirilo_hook_check_arm`). Sigue siendo todo-o-nada (se escribe al final; cualquier ancla que falte aborta antes de tocar nada).
- `test/jit_cmp.c`: la comprobación de cordura aceptaba solo bloques con código; ahora acepta también entradas «sin código» (la comparación de estado no se tocó).
- `test/build_manual.sh`: compilación sin cmake.

### Fase 1 — resultados (x86-64 con simulador a64; NO es AArch64 ni Android)
- jit_unit semilla 1 (20000 Thumb): 0 discrepancias.
- jit_cmp 300 fotogramas, 6 semillas × {arm, mixed, smc, thumb} × {-A, -A -M2, -A -M3, copia, -A -M128}: **120/120 idénticas** (registros, memoria, ciclos, vídeo, audio según jit_cmp).
- Suelo del despachador ARM: sin diferencia medible en x86 (cand/ref ≈ 0,79 con y sin diag 128, ruido ±5 %). **El objetivo +3 % NO está verificado**: requiere el diagnóstico en el móvil (diag 128 frente a normal).
- Pendiente de la Fase 1: gancho solo en B/BL no cumplido (no en otros condicionales no cumplidos); hace falta medir en Android; jit_test.sh completo no ejecutado (cmake/red).

### Resultados en hardware (aportados por el usuario)
- CI `jit_test.sh` JIT=1, 238/238 idénticas en ubuntu-24.04-arm (**aarch64 real**) y ubuntu-latest (x86 + simulador): incluye jit_unit 5×200000 y jsmolka arm/thumb/memory/bios. Con el código de Fase 1 (los bloques ARM aparecen en el modo app).
- Diagnóstico en Doom (ARM 90 % de los ciclos, 117957 instr ARM/fot, 100 % IWRAM, 2326 instr ARM distintas, 21 % condicionales): con ARM por el despachador y sin nativo, «solo despachador» = **+14,6 % (núcleo 6) y +9,3 % (núcleo 0)**. El objetivo +3 % NO se cumple: la Fase 1 tal cual regresa. El intérprete de Doom cuesta ~3,1 ms/fot en el núcleo 6 (5,0× tiempo real) y 6,0 ms en el 0 (2,7×).
- Las líneas «Thumb 127159 / ARM 0 instr» del informe eran un artefacto: con ARM por el despachador las instrucciones iban a otro contador (ya corregido). Real ≈ 117957 ARM + ~9200 Thumb. Los ns/instrucción del informe de Doom salen de dividir entre el total, ahora sí válidos como orden de magnitud (~24 ns/instr en el núcleo 6).

### Corrección tras Doom
- `cjPlain*` especializados por modo (sin `if (thumb)` por instrucción).
- En la app `cjArmDisp` vale 0 por defecto (ARM usa el bucle original, coste 0 respecto al estado anterior) hasta que exista nativo ARM; el diag 128 lo invierte para medir A/B. En el núcleo de pruebas sigue en 1 para que el CI lo ejercite.
- Validado en x86 (120/120, unit 0 discrepancias); la mejora del coste NO está medida en el móvil: repetir el diagnóstico de Doom con y sin diag 128.

### Implicación para el diseño de la Fase 2 (lo que enseña Doom)
- El despachador por gancho cuesta ~5 ns por instrucción ARM (≈ 18 % del coste de interpretar) aunque casi no haya bloques: el coste está en el gancho por salto tomado y en el B no cumplido. Para ganar hay que cubrir TODO el bucle caliente ARM (2326 instr, ~9 KB de IWRAM) con bloques largos y encadenados; cubrir poco pierde, como hoy pierde Thumb (1 % nativo y +17,8 %).
- Doom tiene 20 % LDR/STR y 15 % saltos: la memoria en línea y el encadenado (en ARM, `cjPieceHopArm`) son imprescindibles desde el principio, no una fase tardía. Considerar adelantar las Fases 4 y 5 junto a la 2 y evaluar el beneficio sobre Doom antes de segui### Resultado de Doom tras la corrección de Fase 1b (aportado por el usuario)
Suelo del despachador ARM (sin nativo): +3,2 % (núcleo 6) y +2,6 % (núcleo 0): ya cerca del objetivo +3 %. ARM contado correctamente (114990 instr/fot, 92 %). Doom: 54 % proceso de datos, 23 % LDR/STR, 16 % saltos, 21 % condicionales, 1906 instr ARM distintas, 100 % IWRAM.

### Fase 2 — qué se hizo
- `cirilo_jit_a64.inc`: `cjArmInfo` (clasifica), `cjEmitOneArm` (emite una instrucción), `cjEmitArmPrefix` (tramo puro). Cubre las 16 operaciones de proceso de datos, inmediato rotado y registro con desplazamiento INMEDIATO (LSL/LSR/ASR/ROR/RRX, con los casos #0 = #32 / RRX), con y sin S, las 15 condiciones (A64 usa la misma numeración y el mismo carry de resta), PC como Rn/Rm (A+8). Fuera (siguen interpretadas y cortan el tramo): desplazamiento por registro, Rd = PC, MRS/MSR/BX, multiplicaciones, memoria, saltos.
- Ciclos: el intérprete cobra 1 + activeSeqCycles32 por instrucción ejecutada Y por la no ejecutada, así que el tramo cuesta k·(1+seq32) estático (`cjRunNativeArm`).
- Hallazgo importante: mGBA hace que MULS/MLAS pongan C = `cpu->shifterCarryOut`, el residuo del último desplazador ejecutado. El nativo lo mantiene (w6) y lo vuelca al final del tramo; sin eso las ROM divergían en el flag C. La Fase 3 (multiplicaciones) debe leer ese mismo valor.
- `cirilo_jit_arm.inc`: `cjNativizeArm`, `cjWorthArm`, `cjNativeTailArm`, ejecución en `cjRun`, `cjRunBlockArm(i0)`, sal ARM en el mapa de ganchos, autoprueba `cirilo_jit_selftest_arm` y verificación en vivo `CJ_ARM_CHECK=1` (solo núcleo de pruebas).
- `cirilo_jit_a64sim.inc`: el simulador x86 ahora entiende EXTR y los 4 tipos de desplazamiento en las operaciones lógicas.
- `test/jit_unit.c`: ejecuta también la autoprueba ARM. `app/.../diag.h`: dos configuraciones nuevas («ARM por despachador, sin nativo» y «completo + ARM nativo», bit 128) y sus líneas de veredicto.
- En la app `cjArmDisp` sigue en 0 por defecto: el ARM nativo solo se activa con el bit 128 (diagnóstico) hasta que las mediciones en Doom demuestren ganancia.

### Fase 2 — pruebas (x86-64 + simulador a64; NO aarch64 real aún)
- jit_unit: 5×200000 Thumb + 5×200000 ARM (1 000 000 de secuencias ARM de 1-24 instrucciones, todas las ops/condiciones/desplazamientos, PC, flags y márgenes aleatorios, seq32 aleatorio): 0 discrepancias. Prueba de mutación (ADC→ADD): detectada (1303 fallos).
- jit_cmp, 8 semillas × {arm, mixed, smc, thumb} × 5-7 configuraciones (app, diag B, copia, bloques, sin encadenado…): todas idénticas; con `-X` (SMC apagado) las ROM con SMC difieren, como debe ser (autoprueba del CI, también con el ARM nativo apagado).
- Compila también en modo app (sin simulador) con gcc x86; NO compilado con el NDK.

### Cobertura actual (honesta)
Solo tramos ARM puros al principio del bloque: en el Doom del usuario (23 % LDR/STR, 16 % saltos) los tramos serán cortos hasta que haya memoria (Fase 5) y saltos/encadenado (Fase 4). Esperable: el ARM nativo no gana todavía; hay que medirlo con el bit 128 antes de activarlo por defecto.

### Próximo paso exacto
1. Pedir al usuario: CI en aarch64 real con esta versión y el diagnóstico de Doom (nuevas filas «ARM por despachador…» y «completo + ARM nativo»).
2. Fase 4/5 adelantadas (Doom): LDR/STR/LDRH + B/BL/Bcond con encadenado ARM (`cjPieceHopArm`) para tramos que crucen bucles; después Fase 3 (MUL con CLZ/cjArmMulCycles exactos y shifterCarryOut).
