# Informe de continuidad — JIT ARM de Cirilo

## Estado: Fase 0 HECHA. Fase 1 IMPLEMENTADA y validada en x86 (sin hardware). Fases 2-8 NO empezadas.

### Entorno de esta sesión
- Sin cmake, sin compilador cruzado AArch64, sin qemu, sin red, sin dispositivo Android.
- Se compila a mano con gcc (x86-64): `tools/test/build_manual.sh <carpeta mgba> <salida.so> [flags]` (equivale al CMake libretro mínimo; excluye extra/proxy, hilos, scripting, video-logger).
- Sobre x86-64 el código nativo lo ejecuta el simulador `cirilo_jit_a64sim.inc` (-DCIRILO_JIT_SIM). NO se ha ejecutado AArch64 real ni Gradle/NDK.

### Línea base ejecutada (mGBA fijado a67176c + parches prof, fast, jit)
- `jit_unit` semilla 1, 20000 secuencias Thumb: OK, 0 discrepancias.
- `jit_cmp` ref vs cand (-J -A, 300 fotogramas) con mkrom_jit.py semilla 1: arm, thumb, mixed, smc → todas OK.
- Cobertura ARM actual: `palabras_emitidas=0 instr_cubiertas=0` en la ROM ARM (confirmado: ARM no se traduce).
- NO ejecutado: jit_test.sh completo (necesita cmake y red para jsmolka/gba-tests), fast_stress, perfiles PGO.
- Las fps x0.14-0.26 del candidato son del simulador en x86: no son medida de rendimiento.

### Hallazgos de auditoría (código real, tools/cirilo_jit_arm.inc, 1807 líneas)
- `cjTranslate`: `if (!thumb && !CJ_COPY_MODE) return NULL;` → ARM solo se bloquea en modo copia (pruebas). Existe `cjTermArm` y `cjRunBlockArm` (marcado `unused`, intérprete por bloque).
- `cjRun`: en modo app, ARM entra en un bucle `ARMStep` puro (sin caché ni despachador). `cjPlain/cjPlainHooked` llaman a `ThumbStep` fijo: hay que parametrizar por modo.
- Ganchos (`cirilo_jit_patch.py`): solo `ThumbWritePC` y Bcond Thumb no tomado. Faltan `ARMWritePC` y el no-tomado ARM. `cirilo_hook_bits/heat` se indexan por `a>>1`: las claves ARM deben distinguirse (modo en la clave).
- `cjNativize`/`cjWorth`/`cjThumbInfo`/`cjEmitThumbPrefix` son solo Thumb; no existen `cjArmInfo`/`cjEmitOneArm`.
- El parche ya es "todo o nada" para lo que toca (escribe al final); hay que mantenerlo al añadir ARMWritePC y ARM Bcond.
- Diagnóstico adjunto: ARM = 22073 instr/fot (99% IWRAM, 193 distintas), el JIT Thumb apenas empata (+1.8%); coste de despachador ≈ +8% base. Los ns/instrucción del diagnóstico están mal calculados (se dividió entre Thumb solo): hay que recalcularlos con 46134 instr.

### Fase 1 — qué se hizo
- `cirilo_jit_arm.inc`: `cjPlain`/`cjPlainHooked` reciben el modo (ARMStep/ThumbStep); `cjRun` ya no usa el bucle ARM aparte (queda solo con diag 128 = ARM fuera del despachador, y diag 64 = perfil por región); `cjTranslate` crea bloques ARM sin nativo (agrupan, se ejecutan con ARMStep, exactos). Nuevo `cjArmDisp` + flag de diagnóstico 128 para medir A/B.
- `cirilo_jit_patch.py`: gancho en `ARMWritePC` y en el B/BL ARM no cumplido (`ARMStep`, arm.c), claves ARM separadas por sal (`cirilo_hook_check_arm`). Sigue siendo todo-o-nada (se escribe al final; cualquier ancla que falte aborta antes de tocar nada).
- `test/jit_cmp.c`: la comprobación de cordura aceptaba solo bloques con código; ahora acepta también entradas «sin código» (la comparación de estado no se tocó).
- `test/build_manual.sh`: compilación sin cmake.

### Fase 1 — resultados (x86-64 con simulador a64; NO es AArch64 ni Android)
- jit_unit semilla 1 (20000 Thumb): 0 discrepancias.
- jit_cmp 300 fotogramas, 6 semillas × {arm, mixed, smc, thumb} × {-A, -A -M2, -A -M3, copia, -A -M128}: **120/120 idénticas** (registros, memoria, ciclos, vídeo, audio según jit_cmp).
- Suelo del despachador ARM: sin diferencia medible en x86 (cand/ref ≈ 0,79 con y sin diag 128, ruido ±5 %). **El objetivo +3 % NO está verificado**: requiere el diagnóstico en el móvil (diag 128 frente a normal).
- Pendiente de la Fase 1: gancho solo en B/BL no cumplido (no en otros condicionales no cumplidos); hace falta medir en Android; jit_test.sh completo no ejecutado (cmake/red).

### Próximo paso exacto (Fase 2)
Crear `cjArmInfo` + `cjEmitOneArm` para proceso de datos con condición AL (imm rotado y registro con LSL/LSR/ASR/ROR por inmediato) reutilizando el emisor a64 y la caché de registros; `cjNativize` para ARM en IWRAM (cjTranslate ya crea el bloque); ciclos ARM con `activeSeqCycles32`; ampliar `cjRandOp`/jit_unit con secuencias ARM + `cjNativeTail` ARM (ARMWritePC); después condiciones, RRX/desplazamiento por registro, y mkrom_jit ya cubre modo arm.
