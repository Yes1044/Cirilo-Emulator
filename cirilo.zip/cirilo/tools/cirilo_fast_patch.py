#!/usr/bin/env python3
"""Acelera el intérprete de mGBA (ver cirilo_fast.h). Uso: cirilo_fast_patch.py <carpeta mgba> [cpu para -mtune en arm64]
1) Camino rápido de memoria: todo o nada. Si algo no encaja exactamente (otra versión de mGBA), no toca nada y sale con código 1.
2) -mtune (opcional, segundo argumento, p. ej. cortex-a76): solo cambia el orden de las instrucciones que genera el compilador en arm64,
   no el juego de instrucciones, así que el .so sigue valiendo para cualquier móvil. Si falla, solo avisa (no afecta al código de salida)."""
import sys,os,re,shutil
root=sys.argv[1];tune=sys.argv[2] if len(sys.argv)>2 else ""
here=os.path.dirname(os.path.abspath(__file__))
def rd(p):
    with open(os.path.join(root,p),encoding="utf-8") as f:return f.read()
def wr(p,s):
    with open(os.path.join(root,p),"w",encoding="utf-8",newline="") as f:f.write(s)
def die(m):
    print("cirilo_fast_patch: "+m,file=sys.stderr);sys.exit(1)

# ---- 1) camino rápido -------------------------------------------------------------------------------------------------------------
# firmas de memory.c en las que se basa cirilo_fast.h: si cambian, los ciclos podrían dejar de coincidir
mem=rd("src/gba/memory.c")
SIG=["LOAD_32(value, address & (GBA_SIZE_IWRAM - 4), memory->iwram)","wait += waitstatesRegion[GBA_REGION_EWRAM];",
 "if ((address & (GBA_SIZE_ROM0 - 4)) < memory->romSize)","wait += waitstatesRegion[address >> BASE_OFFSET];",
 "wait = memory->waitstatesNonseq16[GBA_REGION_EWRAM];","if ((address & (GBA_SIZE_ROM0 - 2)) < memory->romSize)",
 "if ((address & (GBA_SIZE_ROM0 - 1)) < memory->romSize)","if (memory->activeRegion < GBA_REGION_ROM0 || !memory->prefetch)",
 "cpu->memory.stall = GBAMemoryStall;","wait += 2;","++wait;"]
for s in SIG:
    if s not in mem:die("memory.c no es la versión esperada (falta: %s)"%s)
if "GBA_SIZE_ROM0 - 4" not in mem:die("memory.c")
hdr=os.path.join(here,"cirilo_fast.h")
if not os.path.isfile(hdr):die("falta tools/cirilo_fast.h")

new={};total=0
for p,inc in (("src/arm/isa-arm.c","#include <mgba/internal/arm/isa-inlines.h>\n"),("src/arm/isa-thumb.c","#include <mgba/internal/arm/isa-inlines.h>\n")):
    s=rd(p)
    if s.count(inc)!=1:die("%s: no encuentro el include esperado"%p)
    s,n=re.subn(r"cpu->memory\.(load|store)(32|16|8)\(",lambda m:"cirilo_%s%s("%("ld" if m.group(1)=="load" else "st",m.group(2)),s)
    if n<10:die("%s: solo %d accesos a memoria (se esperaban más)"%(p,n))
    if re.search(r"cpu->memory\.(load|store)(32|16|8)\(",s):die("%s: quedan accesos sin cambiar"%p)
    s=s.replace(inc,inc+"#include <mgba/internal/gba/cirilo_fast.h>\n",1)
    new[p]=s;total+=n
# sanity: los LDM/STM y el resto siguen yendo por los punteros normales
for p,s in new.items():
    if "cirilo_ld32(" not in s or "cirilo_st32(" not in s:die("%s: faltan cambios"%p)

# todo comprobado: ahora se escribe
shutil.copyfile(hdr,os.path.join(root,"include/mgba/internal/gba/cirilo_fast.h"))
for p,s in new.items():wr(p,s)
print("ok: camino rapido de memoria (%d accesos en isa-arm.c/isa-thumb.c)"%total)

# ---- 2) -mtune --------------------------------------------------------------------------------------------------------------------
if tune:
    if not re.fullmatch(r"[a-z0-9.\-]+",tune):print("::warning::-mtune: nombre de CPU no valido, se omite");sys.exit(0)
    c=rd("CMakeLists.txt");key="project(mGBA)\n"
    if c.count(key)!=1:print("::warning::-mtune: no encuentro project(mGBA) en CMakeLists.txt, se omite");sys.exit(0)
    blk=key+"""# Cirilo: ajusta el orden de las instrucciones (no el juego de instrucciones) a un nucleo grande moderno de arm64
if(ANDROID AND ANDROID_ABI STREQUAL "arm64-v8a")
	include(CheckCCompilerFlag)
	check_c_compiler_flag(-mtune=%s CIRILO_HAS_MTUNE)
	if(CIRILO_HAS_MTUNE)
		set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -mtune=%s")
	endif()
endif()
"""%(tune,tune)
    wr("CMakeLists.txt",c.replace(key,blk,1));print("ok: -mtune=%s en arm64 (si el compilador lo acepta)"%tune)
