#!/usr/bin/env python3
"""Genera los índices locales de carátulas (app/src/main/assets/libretro/).
Uso: python3 tools/gen_libretro_index.py <dir con clones de libretro-thumbnails> <dir libretro-database/metadat/no-intro>
  <dir>/Nintendo_-_Game_Boy{,_Color,_Advance}.txt  = salida de `git ls-tree -r --name-only HEAD -- Named_Boxarts`
Produce por plataforma:  {gb,gbc,gba}.txt  (un nombre de Named_Boxarts por línea, sin .png)
                         {gb,gbc,gba}.dat  (crc \t serial \t nombre)  solo entradas No-Intro que EXISTEN en Named_Boxarts."""
import re,sys,os
SYS={'gb':('Nintendo - Game Boy','Nintendo_-_Game_Boy'),'gbc':('Nintendo - Game Boy Color','Nintendo_-_Game_Boy_Color'),'gba':('Nintendo - Game Boy Advance','Nintendo_-_Game_Boy_Advance')}
san=lambda s:re.sub(r'[&*/:`<>?\\|]','_',s)
lt,dat=sys.argv[1],sys.argv[2];out=os.path.join(os.path.dirname(__file__),'..','app','src','main','assets','libretro');os.makedirs(out,exist_ok=True)
for k,(dn,rn) in SYS.items():
    names=sorted({l.strip().split('/',1)[1][:-4] for l in open(os.path.join(lt,rn+'.txt'),encoding='utf-8') if l.strip().endswith('.png')})
    S=set(names);open(os.path.join(out,k+'.txt'),'w',encoding='utf-8').write('\n'.join(names)+'\n')
    rows=[];miss=0;txt=open(os.path.join(dat,dn+'.dat'),encoding='utf-8').read()
    for g in re.finditer(r'game \(\s*name "([^"]+)"(.*?)\n\)',txt,re.S):
        n=san(g.group(1));crc=re.search(r'\bcrc ([0-9A-Fa-f]{8})',g.group(2));ser=re.search(r'\bserial "([^"]+)"',g.group(2))
        if not crc:continue
        if n in S:rows.append((crc.group(1).upper(),ser.group(1) if ser else '',n))
        else:miss+=1
    open(os.path.join(out,k+'.dat'),'w',encoding='utf-8').write('\n'.join('\t'.join(r) for r in rows)+'\n')
    print(k,len(names),'boxarts;',len(rows),'DAT con carátula;',miss,'DAT sin carátula')
