/* Cirilo: ajustes avanzados del núcleo (tipo de guardado forzado y efecto mosaico).
 * Se añade al final de mgba/src/platform/libretro/libretro.c (comparte su `core` estático), como cirilo_cheats.c.
 * - cirilo_savetype / cirilo_mosaic son los valores que leen los parches del workflow (override.c y renderers GBA).
 * - cirilo_adv_set() se llama desde jni.cpp ANTES de retro_load_game; cirilo_adv_post() justo DESPUÉS (para ROMs sin entrada en la base de mGBA).
 * Si el workflow no pudo parchear mGBA, estas funciones existen pero no cambian nada. */
#include <mgba/core/core.h>
#ifdef M_CORE_GBA
#include <mgba/internal/gba/gba.h>
#endif
#define CIRILO_EXPORT __attribute__((visibility("default")))
int cirilo_mosaic = 1;
int cirilo_savetype = -2; /* -2 = automático (no se fuerza); otro = valor de enum SavedataType */
/* t: 0 automático, 1 EEPROM, 2 SRAM, 3 Flash 64K, 4 Flash 128K, 5 Ninguno */
CIRILO_EXPORT void cirilo_adv_set(int t, int mosaic) {
	cirilo_mosaic = mosaic ? 1 : 0;
#ifdef CIRILO_HAVE_SAVEFORCE
	switch (t) {
	case 1: cirilo_savetype = GBA_SAVEDATA_EEPROM; break;
	case 2: cirilo_savetype = GBA_SAVEDATA_SRAM; break;
	case 3: cirilo_savetype = GBA_SAVEDATA_FLASH512; break;
	case 4: cirilo_savetype = GBA_SAVEDATA_FLASH1M; break;
	case 5: cirilo_savetype = GBA_SAVEDATA_FORCE_NONE; break;
	default: cirilo_savetype = -2; break;
	}
#else
	(void) t;
#endif
}
CIRILO_EXPORT void cirilo_adv_post(void) {
#if defined(CIRILO_HAVE_SAVEFORCE) && defined(M_CORE_GBA)
	if (cirilo_savetype != -2 && core && core->platform(core) == mPLATFORM_GBA) {
		struct GBA* gba = core->board;
		if (gba->memory.savedata.type == GBA_SAVEDATA_AUTODETECT) {
			GBASavedataForceType(&gba->memory.savedata, (enum SavedataType) cirilo_savetype);
		}
	}
#endif
}
