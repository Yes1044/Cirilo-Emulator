plugins{id("com.android.library")}
android{
 namespace="app.cirilo.core2";compileSdk=34
 defaultConfig{minSdk=24
  ndk{abiFilters+=listOf("arm64-v8a","armeabi-v7a")}
  externalNativeBuild{cmake{
   targets("mgba2_libretro")
   arguments+=listOf("-DCMAKE_BUILD_TYPE=Release","-DCMAKE_C_FLAGS_DEBUG=-O3 -DNDEBUG -flto=thin","-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG -flto=thin","-DBUILD_LIBRETRO=ON","-DSKIP_LIBRARY=ON","-DBUILD_QT=OFF","-DBUILD_SDL=OFF","-DDISABLE_DEPS=ON","-DUSE_EPOXY=OFF","-DBUILD_GL=OFF","-DBUILD_GLES2=OFF","-DBUILD_GLES3=OFF","-DENABLE_SCRIPTING=OFF","-DUSE_LUA=OFF","-DUSE_FREETYPE=OFF","-DUSE_JSON_C=OFF","-DUSE_LZMA=OFF","-DUSE_ELF=OFF","-DUSE_DISCORD_RPC=OFF")}}}
 externalNativeBuild{cmake{path=file("../mgba2/CMakeLists.txt");version="3.22.1"}}
}
