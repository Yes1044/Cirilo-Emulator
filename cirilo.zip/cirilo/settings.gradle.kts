pluginManagement{repositories{google();mavenCentral();gradlePluginPortal()}}
dependencyResolutionManagement{repositories{google();mavenCentral()}}
rootProject.name="Cirilo"
include(":app",":core")
// Segundo núcleo (Link local): el workflow copia mgba a mgba2 con otro nombre de biblioteca. Sin esa carpeta la app compila igual y Link local avisa de que falta.
if(file("mgba2").exists())include(":core2")
